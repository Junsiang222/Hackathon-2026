import { QueryClient } from '@tanstack/react-query';
import axios from 'axios';

const NON_RETRYABLE = new Set([400, 401, 403, 404, 422]);

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      gcTime: 5 * 60_000,
      refetchOnWindowFocus: true,
      // Client errors won't fix themselves; retry only network/5xx failures.
      retry: (failureCount, error) => {
        const status = axios.isAxiosError(error) ? error.response?.status : undefined;
        if (status !== undefined && NON_RETRYABLE.has(status)) return false;
        return failureCount < 2;
      },
    },
    mutations: {
      retry: false,
    },
  },
});
