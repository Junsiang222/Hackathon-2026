import axios, { AxiosError, AxiosHeaders, type InternalAxiosRequestConfig } from 'axios';
import { mockAdapter } from '@/mocks';
import { useAuthStore } from '@/store/authStore';
import type { ApiErrorBody, ApiSuccess, AuthResponse } from '@/types/api.types';

const baseURL = import.meta.env.VITE_API_BASE_URL ?? '';

export const api = axios.create({
  baseURL,
  withCredentials: true, // send the httpOnly refresh cookie to /auth routes
  timeout: 30_000,
  headers: { 'Content-Type': 'application/json' },
  adapter: mockAdapter,
});

// Separate instance with no interceptors, so a failing refresh can never
// trigger another refresh.
const authClient = axios.create({ baseURL, withCredentials: true, timeout: 15_000, adapter: mockAdapter });

let refreshInFlight: Promise<string> | null = null;

/**
 * Exchanges the refresh cookie for a new access token. Concurrent callers
 * share one request: the server rotates refresh tokens and treats reuse of
 * an old one as theft, so parallel refreshes must never happen.
 */
export function refreshSession(): Promise<string> {
  refreshInFlight ??= authClient
    .post<ApiSuccess<AuthResponse>>('/api/v1/auth/refresh')
    .then(({ data }) => {
      useAuthStore.getState().setSession(data.data.accessToken, data.data.user);
      return data.data.accessToken;
    })
    .catch((error: unknown) => {
      useAuthStore.getState().clearSession();
      throw error;
    })
    .finally(() => {
      refreshInFlight = null;
    });
  return refreshInFlight;
}

api.interceptors.request.use((config) => {
  const token = useAuthStore.getState().accessToken;
  if (token) {
    config.headers = AxiosHeaders.from(config.headers);
    config.headers.set('Authorization', `Bearer ${token}`);
  }
  return config;
});

interface RetriableConfig extends InternalAxiosRequestConfig {
  _retried?: boolean;
}

api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<ApiErrorBody>) => {
    const config = error.config as RetriableConfig | undefined;
    const isAuthRoute = config?.url?.startsWith('/api/v1/auth/') ?? false;
    // A 401 from the shop is about the shopper's session, never the staff login.
    const isShopRoute = config?.url?.startsWith('/api/v1/shop/') ?? false;

    if (error.response?.status === 401 && config && !config._retried && !isAuthRoute && !isShopRoute) {
      config._retried = true;
      const token = await refreshSession(); // rejects → session cleared → caller sees error
      config.headers = AxiosHeaders.from(config.headers);
      config.headers.set('Authorization', `Bearer ${token}`);
      return api(config);
    }

    return Promise.reject(error);
  },
);

/** Machine-readable error code from the API envelope, if any. */
export function getApiErrorCode(error: unknown): string | undefined {
  return axios.isAxiosError<ApiErrorBody>(error) ? error.response?.data?.error?.code : undefined;
}

export function getApiErrorDetails(error: unknown): unknown[] {
  return axios.isAxiosError<ApiErrorBody>(error) ? (error.response?.data?.error?.details ?? []) : [];
}

/** Human-readable message for toasts and inline errors. */
export function getApiErrorMessage(error: unknown, fallback = 'Something went wrong. Please try again.'): string {
  if (axios.isAxiosError<ApiErrorBody>(error)) {
    if (error.code === 'ECONNABORTED') return 'The request timed out. Please try again.';
    if (!error.response) return 'Cannot reach the server. Check your connection.';
    return error.response.data?.error?.message ?? fallback;
  }
  return error instanceof Error && error.message ? error.message : fallback;
}
