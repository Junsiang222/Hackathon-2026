import { keepPreviousData, useIsMutating, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/axios';
import type { ApiSuccess } from '@/types/api.types';

// The store's own cost tracking. Tenant-only: the super admin has no access.

export const EXPENSE_CATEGORIES = ['rent', 'wages', 'utilities', 'marketing', 'supplies', 'shipping', 'software', 'other'] as const;
export type ExpenseCategory = (typeof EXPENSE_CATEGORIES)[number];

export interface ExpenseItem {
  id: number;
  category: ExpenseCategory;
  description: string | null;
  amount: string;
  /** YYYY-MM-DD */
  incurred_on: string;
  created_at: string;
}

export interface ExpenseList {
  items: ExpenseItem[];
  byCategory: { category: ExpenseCategory; amount: string; entries: number }[];
}

export interface ExpenseInput {
  category: ExpenseCategory;
  description: string | null;
  amount: number;
  incurredOn: string;
}

const key = (range: { from: string; to: string }) => ['store', 'expenses', range] as const;

export function useExpenses(range: { from: string; to: string }) {
  return useQuery({
    queryKey: key(range),
    placeholderData: keepPreviousData,
    queryFn: async () =>
      (await api.get<ApiSuccess<ExpenseList>>('/api/v1/admin/expenses', { params: { ...range, limit: 200 } })).data.data,
  });
}

const SAVE_KEY = ['store', 'expenses', 'save'] as const;

/** True while an expense is being saved (for the modal's Save button). */
export const useIsSavingExpense = () => useIsMutating({ mutationKey: SAVE_KEY }) > 0;

export function useSaveExpense() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationKey: SAVE_KEY,
    mutationFn: async ({ id, input }: { id: number | null; input: ExpenseInput }) =>
      id === null
        ? (await api.post<ApiSuccess<ExpenseItem>>('/api/v1/admin/expenses', input)).data.data
        : (await api.patch<ApiSuccess<ExpenseItem>>(`/api/v1/admin/expenses/${id}`, input)).data.data,
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['store', 'expenses'] }),
  });
}

export function useDeleteExpense() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => (await api.delete<ApiSuccess<{ deleted: true }>>(`/api/v1/admin/expenses/${id}`)).data.data,
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ['store', 'expenses'] }),
  });
}
