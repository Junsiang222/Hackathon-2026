import { keepPreviousData, useMutation, useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { usePreferencesStore } from '@/i18n';
import { api } from '@/lib/axios';
import type { ApiSuccess } from '@/types/api.types';
import type {
  AnalyticsOverview,
  AssistantMessage,
  PeriodRange,
  StoreDetail,
} from '@/types/platformAnalytics.types';

/** Near-real-time refresh, as set in Settings (0 = off). */
function useRefreshInterval(): number | false {
  const seconds = usePreferencesStore((state) => state.refreshSeconds);
  return seconds > 0 ? seconds * 1000 : false;
}
const DAY_MS = 86_400_000;

export const PERIOD_PRESETS = [
  { value: 'today', label: 'Today' },
  { value: '7d', label: '7 days' },
  { value: '30d', label: '30 days' },
  { value: 'month', label: 'This month' },
  { value: '90d', label: '90 days' },
  { value: 'custom', label: 'Custom' },
] as const;
export type PeriodPreset = (typeof PERIOD_PRESETS)[number]['value'];

const iso = (time: number) => new Date(time).toISOString().slice(0, 10);

function todayUtc(): number {
  const now = new Date();
  return Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
}

export function presetRange(preset: Exclude<PeriodPreset, 'custom'>): PeriodRange {
  const today = todayUtc();
  if (preset === 'today') return { from: iso(today), to: iso(today) };
  if (preset === 'month') {
    const now = new Date(today);
    return { from: iso(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), 1)), to: iso(today) };
  }
  const days = preset === '7d' ? 7 : preset === '30d' ? 30 : 90;
  return { from: iso(today - (days - 1) * DAY_MS), to: iso(today) };
}

/** The period lives in the URL (?period=7d or ?from=…&to=…) so a store drill-down keeps it. */
export function usePeriod() {
  const [params, setParams] = useSearchParams();
  const defaultPeriod = usePreferencesStore((state) => state.defaultPeriod);
  const preset = (params.get('period') as PeriodPreset | null) ?? (params.get('from') ? 'custom' : defaultPeriod);

  const range = useMemo<PeriodRange>(() => {
    if (preset === 'custom') {
      const fallback = presetRange('30d');
      return { from: params.get('from') ?? fallback.from, to: params.get('to') ?? fallback.to };
    }
    return presetRange(PERIOD_PRESETS.some((p) => p.value === preset) ? preset : defaultPeriod);
  }, [preset, params, defaultPeriod]);

  const setPreset = (value: PeriodPreset) =>
    setParams((current) => {
      const next = new URLSearchParams(current);
      next.set('period', value);
      if (value === 'custom') {
        next.set('from', range.from);
        next.set('to', range.to);
      } else {
        next.delete('from');
        next.delete('to');
      }
      return next;
    });

  const setCustom = (custom: PeriodRange) =>
    setParams((current) => {
      const next = new URLSearchParams(current);
      next.set('period', 'custom');
      next.set('from', custom.from);
      next.set('to', custom.to);
      return next;
    });

  /** Query string to carry the period into links. */
  const search = preset === 'custom' ? `?period=custom&from=${range.from}&to=${range.to}` : `?period=${preset}`;
  return { preset, range, setPreset, setCustom, search };
}

const keys = {
  overview: (range: PeriodRange) => ['platform-analytics', 'overview', range] as const,
  store: (tenantId: number, range: PeriodRange) => ['platform-analytics', 'store', tenantId, range] as const,
};

export function useAnalyticsOverview(range: PeriodRange) {
  const refetchInterval = useRefreshInterval();
  return useQuery({
    queryKey: keys.overview(range),
    placeholderData: keepPreviousData,
    refetchInterval,
    queryFn: async () =>
      (await api.get<ApiSuccess<AnalyticsOverview>>('/api/v1/superadmin/analytics/overview', { params: range })).data.data,
  });
}

const fetchStore = async (tenantId: number, range: PeriodRange) =>
  (await api.get<ApiSuccess<StoreDetail>>(`/api/v1/superadmin/analytics/stores/${tenantId}`, { params: range })).data.data;

export function useStoreAnalytics(tenantId: number, range: PeriodRange) {
  const refetchInterval = useRefreshInterval();
  return useQuery({
    queryKey: keys.store(tenantId, range),
    placeholderData: keepPreviousData,
    refetchInterval,
    queryFn: () => fetchStore(tenantId, range),
  });
}

export function useAnalyticsAssistant() {
  return useMutation({
    mutationFn: async (body: { question: string; history: AssistantMessage[] } & PeriodRange) =>
      (
        await api.post<ApiSuccess<{ answer: string }>>('/api/v1/superadmin/analytics/assistant', body, {
          timeout: 120_000,
        })
      ).data.data.answer,
  });
}
