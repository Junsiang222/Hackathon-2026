import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { api, getApiErrorMessage, refreshSession } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';
import type { ApiSuccess, AuthResponse, LoginPayload, RegisterPayload } from '@/types/api.types';

/** Restores a session from the refresh cookie once per page load. */
export function useBootstrapSession(): void {
  const status = useAuthStore((state) => state.status);
  const setStatus = useAuthStore((state) => state.setStatus);

  useEffect(() => {
    if (status !== 'idle') return;
    setStatus('loading');
    // Failure just means "not signed in"; refreshSession clears the store.
    refreshSession().catch(() => undefined);
  }, [status, setStatus]);
}

export function useAuth() {
  const user = useAuthStore((state) => state.user);
  const role = useAuthStore((state) => state.role);
  const status = useAuthStore((state) => state.status);
  return { user, role, status, isAuthenticated: status === 'authenticated' };
}

function useSessionMutation<TVariables>(request: (variables: TVariables) => Promise<AuthResponse>) {
  const setSession = useAuthStore((state) => state.setSession);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: request,
    onSuccess: (data) => {
      queryClient.clear(); // never show a previous user's cached data
      setSession(data.accessToken, data.user);
      toast.success(`Welcome, ${data.user.businessName}`);
      navigate('/dashboard', { replace: true });
    },
  });
}

export function useLogin() {
  return useSessionMutation(async (payload: LoginPayload) => {
    const { data } = await api.post<ApiSuccess<AuthResponse>>('/api/v1/auth/login', payload);
    return data.data;
  });
}

export function useRegister() {
  return useSessionMutation(async (payload: RegisterPayload) => {
    const { data } = await api.post<ApiSuccess<AuthResponse>>('/api/v1/auth/register', payload);
    return data.data;
  });
}

const MOCK_TOKEN_KEY = (provider: string) => `crm.mockOAuthToken.${provider}`;

/** Stable per-browser mock token so repeat sign-ins reuse the same workspace. */
function getMockOAuthToken(provider: string): string {
  try {
    const existing = window.localStorage.getItem(MOCK_TOKEN_KEY(provider));
    if (existing) return existing;
    const token = `mock-${provider}-${crypto.randomUUID()}`;
    window.localStorage.setItem(MOCK_TOKEN_KEY(provider), token);
    return token;
  } catch {
    return `mock-${provider}-${crypto.randomUUID()}`;
  }
}

export function useOAuthLogin() {
  return useSessionMutation(async (provider: 'google' | 'facebook') => {
    // TODO(oauth): replace with the provider's real SDK flow (Google Identity
    // Services / Facebook Login) and send the returned ID/access token.
    const { data } = await api.post<ApiSuccess<AuthResponse>>(`/api/v1/auth/oauth/${provider}`, {
      mockOAuthToken: getMockOAuthToken(provider),
    });
    return data.data;
  });
}

export function useLogout() {
  const clearSession = useAuthStore((state) => state.clearSession);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      await api.post('/api/v1/auth/logout');
    },
    onError: (error) => {
      // Local sign-out still happens; the server session expires on its own.
      console.warn('Logout request failed:', getApiErrorMessage(error));
    },
    onSettled: () => {
      clearSession();
      queryClient.clear();
      navigate('/auth', { replace: true });
    },
  });
}
