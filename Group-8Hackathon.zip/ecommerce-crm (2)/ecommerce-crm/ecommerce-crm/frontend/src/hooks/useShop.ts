import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import axios from 'axios';
import { useEffect, useRef } from 'react';
import { useOutletContext } from 'react-router-dom';
import { api } from '@/lib/axios';
import { useShopAccountStore, useShopSession } from '@/store/shopAccountStore';
import type { ApiSuccess } from '@/types/api.types';
import type {
  CheckoutPayload,
  ContactPayload,
  PlacedOrder,
  RegisterPayload,
  ShopAccount,
  ShopAuthResult,
  ShopCatalogue,
  ShopInfo,
  ShopProduct,
  TrackedOrder,
} from '@/types/shop.types';

const base = (shopId: string) => `/api/v1/shop/${encodeURIComponent(shopId)}`;
const unwrap = <T>(response: { data: ApiSuccess<T> }) => response.data.data;

export const shopKeys = {
  info: (shopId: string) => ['shop', shopId] as const,
  products: (shopId: string, filters: object) => ['shop', shopId, 'products', filters] as const,
  product: (shopId: string, productId: number) => ['shop', shopId, 'product', productId] as const,
  account: (shopId: string) => ['shop', shopId, 'account'] as const,
};

/** The shopper's session header for this shop, if they are logged in. */
const sessionHeaders = (shopId: string) => {
  const token = useShopAccountStore.getState().sessions[shopId]?.token;
  return token ? { 'X-Shop-Session': token } : undefined;
};

/** What ShopLayout hands to every shop page. */
export interface ShopContext {
  shopId: string;
  shop: ShopInfo;
}

export const useShopContext = () => useOutletContext<ShopContext>();

export function useShopInfo(shopId: string) {
  return useQuery({
    queryKey: shopKeys.info(shopId),
    staleTime: 60_000,
    retry: false,
    queryFn: async () => unwrap(await api.get<ApiSuccess<ShopInfo>>(base(shopId))),
  });
}

export function useShopProducts(shopId: string, filters: { search?: string; category?: string }) {
  const params = Object.fromEntries(Object.entries(filters).filter(([, value]) => value));
  return useQuery({
    queryKey: shopKeys.products(shopId, params),
    placeholderData: keepPreviousData,
    queryFn: async () => unwrap(await api.get<ApiSuccess<ShopCatalogue>>(`${base(shopId)}/products`, { params })),
  });
}

export function useShopProduct(shopId: string, productId: number) {
  return useQuery({
    queryKey: shopKeys.product(shopId, productId),
    retry: false,
    queryFn: async () => unwrap(await api.get<ApiSuccess<ShopProduct>>(`${base(shopId)}/products/${productId}`)),
  });
}

export function useCheckout(shopId: string) {
  return useMutation({
    mutationFn: async (payload: CheckoutPayload) =>
      unwrap(
        await api.post<ApiSuccess<PlacedOrder>>(`${base(shopId)}/checkout`, payload, { headers: sessionHeaders(shopId) }),
      ),
  });
}

// ─── Shopper accounts ────────────────────────────────────────────────────────

export function useShopRegister(shopId: string) {
  const signIn = useShopAccountStore((state) => state.signIn);
  return useMutation({
    mutationFn: async (payload: RegisterPayload) =>
      unwrap(await api.post<ApiSuccess<ShopAuthResult>>(`${base(shopId)}/account/register`, payload)),
    onSuccess: (session) => signIn(shopId, session),
  });
}

export function useShopLogin(shopId: string) {
  const signIn = useShopAccountStore((state) => state.signIn);
  return useMutation({
    mutationFn: async (payload: { email: string; password: string }) =>
      unwrap(await api.post<ApiSuccess<ShopAuthResult>>(`${base(shopId)}/account/login`, payload)),
    onSuccess: (session) => signIn(shopId, session),
  });
}

/** Signs out on the server, then forgets the session locally even if the server call fails. */
export function useShopLogout(shopId: string) {
  const signOut = useShopAccountStore((state) => state.signOut);
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      await api.post(`${base(shopId)}/account/logout`, undefined, { headers: sessionHeaders(shopId) }).catch(() => undefined);
    },
    onSettled: () => {
      signOut(shopId);
      queryClient.removeQueries({ queryKey: shopKeys.account(shopId) });
    },
  });
}

/** Profile + orders. An expired session signs the shopper out. */
export function useShopAccount(shopId: string) {
  const session = useShopSession(shopId);
  const signOut = useShopAccountStore((state) => state.signOut);
  return useQuery({
    queryKey: shopKeys.account(shopId),
    enabled: session !== null,
    retry: false,
    queryFn: async () => {
      try {
        return unwrap(await api.get<ApiSuccess<ShopAccount>>(`${base(shopId)}/account`, { headers: sessionHeaders(shopId) }));
      } catch (error) {
        if (axios.isAxiosError(error) && error.response?.status === 401) signOut(shopId);
        throw error;
      }
    },
  });
}

export function useTrackOrder(shopId: string) {
  return useMutation({
    mutationFn: async ({ orderRef, email }: { orderRef: string; email: string }) =>
      unwrap(
        await api.get<ApiSuccess<TrackedOrder>>(`${base(shopId)}/orders/${encodeURIComponent(orderRef)}`, {
          params: { email },
        }),
      ),
  });
}

export function useContact(shopId: string) {
  return useMutation({
    mutationFn: async (payload: ContactPayload) =>
      unwrap(await api.post<ApiSuccess<{ ticketId: number }>>(`${base(shopId)}/contact`, payload)),
  });
}

type ShopEvent = 'page_view' | 'add_to_cart' | 'checkout_started';

/** Fire-and-forget storefront analytics (feeds the admin's Storefront chart). */
export function trackShopEvent(shopId: string, type: ShopEvent, productId: number | null = null) {
  api.post(`${base(shopId)}/events`, { type, productId }).catch(() => undefined);
}

/** Records one event when the page mounts. */
export function useShopEvent(shopId: string, type: ShopEvent, productId: number | null = null) {
  // Ref guard: StrictMode re-runs effects in development, which would double-count.
  const sent = useRef<string | null>(null);
  useEffect(() => {
    const key = `${shopId}:${type}:${productId}`;
    if (sent.current === key) return;
    sent.current = key;
    trackShopEvent(shopId, type, productId);
  }, [shopId, type, productId]);
}
