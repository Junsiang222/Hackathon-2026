import { keepPreviousData, useIsMutating, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';
import type { ApiSuccess } from '@/types/api.types';
import type { ModuleKey } from '@/types/dashboard.types';
import type {
  CampaignInput,
  CampaignItem,
  CustomerInput,
  CustomerItem,
  OrderDetail,
  OrderStatus,
  OrderSummary,
  ProductInput,
  ProductItem,
  StoreOverview,
  StoreSetup,
  TicketItem,
  TicketPriority,
  TicketStatus,
} from '@/types/store.types';

export const storeKeys = {
  setup: ['store', 'setup'] as const,
  overview: ['store', 'overview'] as const,
  list: (resource: StoreResource, params: ListParams) => ['store', resource, params] as const,
  resource: (resource: StoreResource) => ['store', resource] as const,
  order: (orderId: number) => ['store', 'orders', 'detail', orderId] as const,
};

type StoreResource = 'products' | 'orders' | 'customers' | 'campaigns' | 'tickets';

export interface ListParams {
  search?: string;
  status?: string;
  priority?: string;
  limit?: number;
}

const unwrap = <T>(response: { data: ApiSuccess<T> }) => response.data.data;

// ─── Setup ───────────────────────────────────────────────────────────────────

/** The store's wizard answers; null until the super admin has set the store up. */
export function useStoreSetup() {
  const role = useAuthStore((state) => state.role);
  return useQuery({
    queryKey: storeKeys.setup,
    enabled: role === 'admin',
    staleTime: 60_000,
    queryFn: async () => unwrap(await api.get<ApiSuccess<StoreSetup | null>>('/api/v1/admin/setup')),
  });
}

/** True when ANY of the given modules is enabled for the signed-in store. */
export function hasModule(setup: StoreSetup | null | undefined, modules: readonly ModuleKey[]): boolean {
  return Boolean(setup && modules.some((module) => setup.modules[module]));
}

export function useStoreOverview() {
  return useQuery({
    queryKey: storeKeys.overview,
    queryFn: async () => unwrap(await api.get<ApiSuccess<StoreOverview>>('/api/v1/admin/overview')),
  });
}

// ─── Lists ───────────────────────────────────────────────────────────────────

function useStoreList<T>(resource: StoreResource, params: ListParams) {
  const cleaned = Object.fromEntries(Object.entries(params).filter(([, value]) => value !== '' && value !== undefined));
  return useQuery({
    queryKey: storeKeys.list(resource, cleaned),
    placeholderData: keepPreviousData,
    queryFn: async () =>
      unwrap(await api.get<ApiSuccess<T[]>>(`/api/v1/admin/${resource}`, { params: { limit: 100, ...cleaned } })),
  });
}

export const useProducts = (params: ListParams) => useStoreList<ProductItem>('products', params);
export const useOrders = (params: ListParams) => useStoreList<OrderSummary>('orders', params);
export const useCustomers = (params: ListParams) => useStoreList<CustomerItem>('customers', params);
export const useCampaigns = (params: ListParams) => useStoreList<CampaignItem>('campaigns', params);
export const useTickets = (params: ListParams) => useStoreList<TicketItem>('tickets', params);

export function useOrder(orderId: number | null) {
  return useQuery({
    queryKey: storeKeys.order(orderId ?? 0),
    enabled: orderId !== null,
    queryFn: async () => unwrap(await api.get<ApiSuccess<OrderDetail>>(`/api/v1/admin/orders/${orderId}`)),
  });
}

// ─── Mutations ───────────────────────────────────────────────────────────────

const saveKey = (resource: 'product' | 'customer' | 'campaign') => ['store', 'save', resource] as const;

/** True while a save is in flight, for submit buttons rendered outside the form. */
export function useIsSaving(resource: 'product' | 'customer' | 'campaign') {
  return useIsMutating({ mutationKey: saveKey(resource) }) > 0;
}

/** Refresh a resource's lists plus everything derived from it (overview, bell, charts). */
function useInvalidate() {
  const queryClient = useQueryClient();
  return (...resources: StoreResource[]) => {
    for (const resource of resources) void queryClient.invalidateQueries({ queryKey: storeKeys.resource(resource) });
    void queryClient.invalidateQueries({ queryKey: storeKeys.overview });
    void queryClient.invalidateQueries({ queryKey: ['notifications'] });
    void queryClient.invalidateQueries({ queryKey: ['widget'] });
  };
}

export function useSaveProduct() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationKey: saveKey('product'),
    mutationFn: async ({ id, input }: { id: number | null; input: ProductInput }) => {
      const { stock, ...product } = input;
      if (id === null) return unwrap(await api.post<ApiSuccess<ProductItem>>('/api/v1/admin/products', input));
      const saved = unwrap(await api.patch<ApiSuccess<ProductItem>>(`/api/v1/admin/products/${id}`, product));
      if (!stock) return saved;
      return unwrap(await api.put<ApiSuccess<ProductItem>>(`/api/v1/admin/products/${id}/stock`, stock));
    },
    onSuccess: () => invalidate('products'),
  });
}

export function useDeleteProduct() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async (id: number) =>
      unwrap(await api.delete<ApiSuccess<{ deleted: boolean; archived: boolean }>>(`/api/v1/admin/products/${id}`)),
    onSuccess: () => invalidate('products'),
  });
}

export function useUpdateOrderStatus() {
  const invalidate = useInvalidate();
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, status }: { id: number; status: OrderStatus }) =>
      unwrap(await api.patch<ApiSuccess<OrderDetail>>(`/api/v1/admin/orders/${id}`, { status })),
    onSuccess: (order) => {
      queryClient.setQueryData(storeKeys.order(order.id), order);
      invalidate('orders');
    },
  });
}

export function useSaveCustomer() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationKey: saveKey('customer'),
    mutationFn: async ({ id, input }: { id: number | null; input: CustomerInput }) =>
      id === null
        ? unwrap(await api.post<ApiSuccess<CustomerItem>>('/api/v1/admin/customers', input))
        : unwrap(await api.patch<ApiSuccess<CustomerItem>>(`/api/v1/admin/customers/${id}`, input)),
    onSuccess: () => invalidate('customers'),
  });
}

export function useSaveCampaign() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationKey: saveKey('campaign'),
    mutationFn: async ({ id, input }: { id: number | null; input: Partial<CampaignInput> }) =>
      id === null
        ? unwrap(await api.post<ApiSuccess<CampaignItem>>('/api/v1/admin/campaigns', input))
        : unwrap(await api.patch<ApiSuccess<CampaignItem>>(`/api/v1/admin/campaigns/${id}`, input)),
    onSuccess: () => invalidate('campaigns'),
  });
}

export function useDeleteCampaign() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async (id: number) => unwrap(await api.delete<ApiSuccess<{ deleted: true }>>(`/api/v1/admin/campaigns/${id}`)),
    onSuccess: () => invalidate('campaigns'),
  });
}

export function useUpdateTicket() {
  const invalidate = useInvalidate();
  return useMutation({
    mutationFn: async ({ id, changes }: { id: number; changes: { status?: TicketStatus; priority?: TicketPriority } }) =>
      unwrap(await api.patch<ApiSuccess<unknown>>(`/api/v1/admin/tickets/${id}`, changes)),
    onSuccess: () => invalidate('tickets'),
  });
}
