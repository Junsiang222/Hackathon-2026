import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';
import { sanitizeWidgetData } from '@/utils/sanitizeWidgetData';
import type {
  ApiSuccess,
  NotificationSummary,
  ResetPasswordResult,
  Tenant,
} from '@/types/api.types';
import type {
  DashboardGenerationPayload,
  DashboardLayout,
  GeneratedLayout,
  WidgetConfig,
  WidgetDatum,
} from '@/types/dashboard.types';

export const dashboardKeys = {
  tenants: ['superadmin', 'tenants'] as const,
  tenantLayouts: (tenantId: number) => ['superadmin', 'tenants', tenantId, 'layouts'] as const,
  activeLayout: ['dashboard', 'layout', 'active'] as const,
  notifications: (role: string | null) => ['notifications', role] as const,
  widget: (config: Pick<WidgetConfig, 'widgetId' | 'dataSourceUrl'>) =>
    ['widget', config.widgetId, config.dataSourceUrl] as const,
};

// ─── Super admin ─────────────────────────────────────────────────────────────

export function useTenants() {
  return useQuery({
    queryKey: dashboardKeys.tenants,
    queryFn: async () => (await api.get<ApiSuccess<Tenant[]>>('/api/v1/superadmin/tenants')).data.data,
  });
}

export function useTenantLayouts(tenantId: number | null) {
  return useQuery({
    queryKey: dashboardKeys.tenantLayouts(tenantId ?? 0),
    enabled: tenantId !== null,
    queryFn: async () =>
      (await api.get<ApiSuccess<DashboardLayout[]>>(`/api/v1/superadmin/tenants/${tenantId}/layouts`)).data.data,
  });
}

export function useGenerateDashboard() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (payload: DashboardGenerationPayload) =>
      (
        await api.post<ApiSuccess<GeneratedLayout>>('/api/v1/superadmin/generate-dashboard', payload, {
          // AI generation is slow: up to 4 min for the website, 60s to repair a broken script, then photos.
          timeout: 360_000,
        })
      ).data.data,
    onSuccess: (_data, payload) => {
      void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants });
      void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenantLayouts(payload.tenantId) });
    },
  });
}

/** Creates a store's first admin login with a temporary password, returned once. */
export function useCreateStoreLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (tenantId: number) =>
      (await api.post<ApiSuccess<ResetPasswordResult>>(`/api/v1/superadmin/tenants/${tenantId}/logins`)).data.data,
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants }),
  });
}

/** Sets the password the super admin typed for a store login. */
export function useResetStoreLogin() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({
      tenantId,
      userId,
      ...body
    }: {
      tenantId: number;
      userId: number;
      newPassword: string;
      mustChangePassword: boolean;
    }) =>
      (
        await api.post<ApiSuccess<{ email: string; mustChangePassword: boolean }>>(
          `/api/v1/superadmin/tenants/${tenantId}/logins/${userId}/reset-password`,
          body,
        )
      ).data.data,
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants }),
  });
}

/** Removes a store (soft delete): its website goes offline and its logins stop working. */
export function useRemoveTenant() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (tenantId: number) =>
      (await api.delete<ApiSuccess<{ removed: true; businessName: string }>>(`/api/v1/superadmin/tenants/${tenantId}`))
        .data.data,
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants }),
  });
}

// ─── Admin (tenant-scoped) ───────────────────────────────────────────────────

export function useActiveLayout() {
  return useQuery({
    queryKey: dashboardKeys.activeLayout,
    queryFn: async () =>
      (await api.get<ApiSuccess<DashboardLayout | null>>('/api/v1/dashboard/layout/active')).data.data,
  });
}

/**
 * Badge count for the header bell.
 *  admin       → urgent open tickets + low-stock products
 *  super_admin → tenants whose trial ends within 7 days
 */
export function useNotificationCount() {
  const role = useAuthStore((state) => state.role);
  return useQuery({
    queryKey: dashboardKeys.notifications(role),
    enabled: role === 'admin' || role === 'super_admin',
    refetchInterval: 60_000,
    queryFn: async (): Promise<number> => {
      if (role === 'admin') {
        return (await api.get<ApiSuccess<NotificationSummary>>('/api/v1/admin/notifications/summary')).data.data.count;
      }
      const tenants = (await api.get<ApiSuccess<Tenant[]>>('/api/v1/superadmin/tenants')).data.data;
      const horizon = Date.now() + 7 * 24 * 60 * 60 * 1000;
      return tenants.filter((tenant) => {
        if (!tenant.trialEndsAt || tenant.status !== 'active') return false;
        const ends = new Date(tenant.trialEndsAt).getTime();
        return ends >= Date.now() && ends <= horizon;
      }).length;
    },
  });
}

// ─── Chart widgets ───────────────────────────────────────────────────────────

/**
 * dataSourceUrl comes from AI output persisted in the DB. Only same-origin
 * API paths are fetched — an absolute URL would leak the bearer token.
 */
const SAFE_DATA_SOURCE = /^\/api\/v1\/[a-z0-9/_-]+$/i;

export function useWidgetData(config: WidgetConfig) {
  return useQuery({
    queryKey: dashboardKeys.widget(config),
    refetchInterval: 60_000,
    queryFn: async (): Promise<WidgetDatum[]> => {
      if (!SAFE_DATA_SOURCE.test(config.dataSourceUrl)) {
        throw new Error('This widget points at an unsupported data source.');
      }
      const { data } = await api.get<ApiSuccess<unknown>>(config.dataSourceUrl);
      const rows = Array.isArray(data.data)
        ? data.data.filter((row): row is Record<string, unknown> => typeof row === 'object' && row !== null)
        : [];
      // Defence in depth: strip monetary keys before ANY chart sees the data.
      return sanitizeWidgetData(rows);
    },
  });
}

export interface TenantWebsite {
  hasWebsite: boolean;
  /** The saved step 9 description. */
  websitePrompt: string;
  isAiDesigned: boolean;
}

export function useTenantWebsite(tenantId: number, enabled: boolean) {
  return useQuery({
    queryKey: ['superadmin', 'tenants', tenantId, 'website'] as const,
    enabled,
    queryFn: async () =>
      (await api.get<ApiSuccess<TenantWebsite>>(`/api/v1/superadmin/tenants/${tenantId}/website`)).data.data,
  });
}

/** Builds a new AI home page for a store; saved as a new layout version with the same dashboard. */
export function useRegenerateWebsite() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ tenantId, websitePrompt }: { tenantId: number; websitePrompt: string }) =>
      (
        await api.post<ApiSuccess<WebsitePhotoResult & { layoutId: number }>>(
          `/api/v1/superadmin/tenants/${tenantId}/website/regenerate`,
          { websitePrompt },
          // Up to 4 min for the page, 60s to repair a broken script, then photos.
          { timeout: 360_000 },
        )
      ).data.data,
    onSuccess: (_data, { tenantId }) => {
      void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants });
      void queryClient.invalidateQueries({ queryKey: ['superadmin', 'tenants', tenantId] });
    },
  });
}

export interface WebsitePhotoResult {
  imageCount: number;
  /** Photos the page asked for that couldn't be found (e.g. the photo quota ran out). */
  missingPhotos: number;
  /** False while the photo provider's hourly quota is used up. */
  photoSearchAvailable: boolean;
}

/** Fills in an AI page's missing photos and product photos, without redesigning it. */
export function useRefreshWebsitePhotos() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (tenantId: number) =>
      (
        await api.post<ApiSuccess<WebsitePhotoResult & { layoutId: number | null; added: number }>>(
          `/api/v1/superadmin/tenants/${tenantId}/website/refresh-photos`,
          {},
          { timeout: 120_000 },
        )
      ).data.data,
    onSuccess: (_data, tenantId) => {
      void queryClient.invalidateQueries({ queryKey: dashboardKeys.tenants });
      void queryClient.invalidateQueries({ queryKey: ['superadmin', 'tenants', tenantId] });
    },
  });
}
