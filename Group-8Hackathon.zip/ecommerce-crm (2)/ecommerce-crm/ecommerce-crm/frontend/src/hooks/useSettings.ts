import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect } from 'react';
import { usePreferencesStore, type Language, type Preferences } from '@/i18n';
import { api } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';
import type { ApiSuccess } from '@/types/api.types';

// Super admin Settings (preferences are per account, platform settings apply to every store).

export const STORE_CURRENCIES = ['USD', 'MYR', 'SGD', 'IDR', 'THB', 'PHP', 'EUR', 'GBP', 'AUD'] as const;
export type StoreCurrency = (typeof STORE_CURRENCIES)[number];

export interface PlatformSettings {
  websiteLanguage: Language;
  storeCurrency: StoreCurrency;
}

export interface SettingsResponse {
  preferences: Preferences;
  platform: PlatformSettings;
}

export interface SystemStatus {
  database: { ok: boolean; ms: number };
  ai: { model: string; host: string };
  photos: { provider: 'Unsplash' | 'Pexels' | null; remaining: number | null; paused: boolean };
}

export interface TestResult {
  ok: boolean;
  message: string;
  ms?: number;
  remaining?: number | null;
  paused?: boolean;
}

const keys = {
  settings: ['superadmin', 'settings'] as const,
  status: ['superadmin', 'settings', 'status'] as const,
};

export function useSettings(enabled = true) {
  return useQuery({
    queryKey: keys.settings,
    enabled,
    staleTime: 5 * 60_000,
    queryFn: async () => (await api.get<ApiSuccess<SettingsResponse>>('/api/v1/superadmin/settings')).data.data,
  });
}

/** Loads the super admin's saved preferences after sign-in; other roles use the defaults. */
export function usePreferencesSync() {
  const role = useAuthStore((state) => state.role);
  const isSuperAdmin = role === 'super_admin';
  const settings = useSettings(isSuperAdmin);
  const apply = usePreferencesStore((state) => state.apply);
  const reset = usePreferencesStore((state) => state.reset);

  useEffect(() => {
    if (role && !isSuperAdmin) reset();
  }, [role, isSuperAdmin, reset]);

  useEffect(() => {
    if (isSuperAdmin && settings.data) apply(settings.data.preferences);
  }, [isSuperAdmin, settings.data, apply]);
}

export function useSavePreferences() {
  const queryClient = useQueryClient();
  const apply = usePreferencesStore((state) => state.apply);
  return useMutation({
    mutationFn: async (changes: Partial<Preferences>) =>
      (await api.put<ApiSuccess<Preferences>>('/api/v1/superadmin/settings/preferences', changes)).data.data,
    onSuccess: (preferences) => {
      apply(preferences);
      queryClient.setQueryData<SettingsResponse>(keys.settings, (current) => (current ? { ...current, preferences } : current));
      // Alerts and AI answers are written in the dashboard language.
      void queryClient.invalidateQueries({ queryKey: ['platform-analytics'] });
    },
  });
}

export function useSavePlatformSettings() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (changes: Partial<PlatformSettings>) =>
      (await api.put<ApiSuccess<PlatformSettings>>('/api/v1/superadmin/settings/platform', changes)).data.data,
    onSuccess: (platform) =>
      queryClient.setQueryData<SettingsResponse>(keys.settings, (current) => (current ? { ...current, platform } : current)),
  });
}

export function useChangeOwnPassword() {
  return useMutation({
    mutationFn: async (body: { currentPassword: string; newPassword: string }) =>
      (await api.post<ApiSuccess<{ changed: true }>>('/api/v1/superadmin/settings/password', body)).data.data,
  });
}

export function useSystemStatus() {
  return useQuery({
    queryKey: keys.status,
    queryFn: async () => (await api.get<ApiSuccess<SystemStatus>>('/api/v1/superadmin/settings/status')).data.data,
  });
}

export function useSystemTest(target: 'ai' | 'photos') {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () =>
      (await api.post<ApiSuccess<TestResult>>(`/api/v1/superadmin/settings/test/${target}`, {}, { timeout: 45_000 })).data.data,
    onSettled: () => void queryClient.invalidateQueries({ queryKey: keys.status }),
  });
}
