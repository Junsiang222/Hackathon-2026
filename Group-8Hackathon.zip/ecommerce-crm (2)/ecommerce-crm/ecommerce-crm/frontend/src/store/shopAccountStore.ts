import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import type { ShopCustomer } from '@/types/shop.types';
import { safeStorage } from './cartStore';

interface ShopSession {
  token: string;
  customer: ShopCustomer;
}

interface ShopAccountState {
  /** One shopper session per shop, keyed by tenant_uid. Never shared with the staff dashboard login. */
  sessions: Record<string, ShopSession>;
  signIn: (shopId: string, session: ShopSession) => void;
  signOut: (shopId: string) => void;
}

export const useShopAccountStore = create<ShopAccountState>()(
  persist(
    (set) => ({
      sessions: {},
      signIn: (shopId, session) => set((state) => ({ sessions: { ...state.sessions, [shopId]: session } })),
      signOut: (shopId) =>
        set((state) => {
          const { [shopId]: _removed, ...rest } = state.sessions;
          return { sessions: rest };
        }),
    }),
    { name: 'verdant.shop-sessions', storage: createJSONStorage(() => safeStorage) },
  ),
);

export const useShopSession = (shopId: string): ShopSession | null =>
  useShopAccountStore((state) => state.sessions[shopId] ?? null);
