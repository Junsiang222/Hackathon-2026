import { create } from 'zustand';
import { createJSONStorage, persist, type StateStorage } from 'zustand/middleware';
import type { CartLine } from '@/types/shop.types';

/** localStorage that never throws (private mode, blocked storage): the cart just won't survive a reload. */
export const safeStorage: StateStorage = {
  getItem: (name) => {
    try {
      return localStorage.getItem(name);
    } catch {
      return null;
    }
  },
  setItem: (name, value) => {
    try {
      localStorage.setItem(name, value);
    } catch {
      /* ignore */
    }
  },
  removeItem: (name) => {
    try {
      localStorage.removeItem(name);
    } catch {
      /* ignore */
    }
  },
};

interface CartState {
  /** One cart per shop, keyed by tenant_uid. */
  carts: Record<string, CartLine[]>;
  add: (shopId: string, line: Omit<CartLine, 'qty'>, qty: number) => void;
  setQty: (shopId: string, productId: number, qty: number) => void;
  remove: (shopId: string, productId: number) => void;
  clear: (shopId: string) => void;
}

const clamp = (qty: number, max: number) => Math.max(1, Math.min(qty, Math.max(max, 1)));

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      carts: {},
      add: (shopId, line, qty) =>
        set((state) => {
          const cart = state.carts[shopId] ?? [];
          const existing = cart.find((item) => item.productId === line.productId);
          const next = existing
            ? cart.map((item) =>
                item.productId === line.productId ? { ...item, ...line, qty: clamp(item.qty + qty, line.maxQty) } : item,
              )
            : [...cart, { ...line, qty: clamp(qty, line.maxQty) }];
          return { carts: { ...state.carts, [shopId]: next } };
        }),
      setQty: (shopId, productId, qty) =>
        set((state) => ({
          carts: {
            ...state.carts,
            [shopId]: (state.carts[shopId] ?? []).map((item) =>
              item.productId === productId ? { ...item, qty: clamp(qty, item.maxQty) } : item,
            ),
          },
        })),
      remove: (shopId, productId) =>
        set((state) => ({
          carts: { ...state.carts, [shopId]: (state.carts[shopId] ?? []).filter((item) => item.productId !== productId) },
        })),
      clear: (shopId) => set((state) => ({ carts: { ...state.carts, [shopId]: [] } })),
    }),
    { name: 'verdant.carts', storage: createJSONStorage(() => safeStorage) },
  ),
);

const EMPTY: CartLine[] = [];

export function useCart(shopId: string) {
  const lines = useCartStore((state) => state.carts[shopId] ?? EMPTY);
  const count = lines.reduce((sum, line) => sum + line.qty, 0);
  const total = Math.round(lines.reduce((sum, line) => sum + line.qty * line.price, 0) * 100) / 100;
  return { lines, count, total };
}
