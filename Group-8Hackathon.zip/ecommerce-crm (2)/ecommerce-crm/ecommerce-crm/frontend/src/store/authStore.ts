import { create } from 'zustand';
import type { Role, SessionUser } from '@/types/api.types';

export type AuthStatus = 'idle' | 'loading' | 'authenticated' | 'anonymous';

interface AuthState {
  /** Short-lived JWT. Kept in memory only — never in localStorage. */
  accessToken: string | null;
  user: SessionUser | null;
  role: Role | null;
  status: AuthStatus;
  setSession: (accessToken: string, user: SessionUser) => void;
  setStatus: (status: AuthStatus) => void;
  clearSession: () => void;
}

export const useAuthStore = create<AuthState>()((set) => ({
  accessToken: null,
  user: null,
  role: null,
  status: 'idle',
  setSession: (accessToken, user) => set({ accessToken, user, role: user.role, status: 'authenticated' }),
  setStatus: (status) => set({ status }),
  clearSession: () => set({ accessToken: null, user: null, role: null, status: 'anonymous' }),
}));
