/**
 * In-browser fake of the CRM API, used only by the hosted preview build
 * (VITE_MOCK_API=true). It mirrors the real response envelopes, roles and
 * financial rules closely enough to click through every screen without a
 * backend. Nothing here ships in the normal build.
 */
import { AxiosError, AxiosHeaders, type AxiosAdapter, type AxiosResponse, type InternalAxiosRequestConfig } from 'axios';
import type { Role, SessionUser, Tenant } from '@/types/api.types';
import type { ChartKind, DashboardLayout, DashboardModules, WidgetConfig, WidgetType } from '@/types/dashboard.types';

// ─── Deterministic random ────────────────────────────────────────────────────

function mulberry32(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rand = mulberry32(20261022);
const between = (min: number, max: number) => Math.floor(min + rand() * (max - min + 1));
const uuid = () => crypto.randomUUID();

// ─── Seed data ───────────────────────────────────────────────────────────────

const DAY = 86_400_000;
const now = Date.now();
const iso = (offsetDays: number) => new Date(now - offsetDays * DAY).toISOString();
const ymd = (offsetDays: number) => new Date(now - offsetDays * DAY).toISOString().slice(0, 10);

const STATUS_COLOR: Record<string, string> = {
  active: '#22C55E', confirmed: '#22C55E', shipped: '#22C55E', delivered: '#22C55E', resolved: '#22C55E',
  pending: '#DCFCE7', suspended: '#DCFCE7', open: '#DCFCE7', in_progress: '#DCFCE7', pending_customer: '#DCFCE7', draft: '#DCFCE7',
  cancelled: '#15803D', refunded: '#15803D', closed: '#15803D', archived: '#15803D',
};

const tenants: Tenant[] = [
  { id: 2, tenantUid: uuid(), businessName: 'Urban Thread Co.', industry: 'fashion', plan: 'growth', status: 'active', statusColor: '#22C55E', registeredAt: iso(212), trialEndsAt: null, layoutCount: 1, lastLayoutAt: iso(3), hasWebsite: true, logins: [] },
  { id: 3, tenantUid: uuid(), businessName: 'Volt Electronics', industry: 'electronics', plan: 'starter', status: 'active', statusColor: '#22C55E', registeredAt: iso(9), trialEndsAt: new Date(now + 5 * DAY).toISOString(), layoutCount: 0, lastLayoutAt: null, hasWebsite: false, logins: [] },
  { id: 4, tenantUid: uuid(), businessName: 'Bloom Botanics', industry: 'health', plan: 'enterprise', status: 'active', statusColor: '#22C55E', registeredAt: iso(340), trialEndsAt: null, layoutCount: 0, lastLayoutAt: null, hasWebsite: false, logins: [] },
  { id: 5, tenantUid: uuid(), businessName: 'Crumb & Co. Bakery', industry: 'food', plan: 'starter', status: 'suspended', statusColor: '#DCFCE7', registeredAt: iso(61), trialEndsAt: null, layoutCount: 0, lastLayoutAt: null, hasWebsite: false, logins: [] },
  { id: 6, tenantUid: uuid(), businessName: 'Northwind Outfitters', industry: 'retail', plan: 'growth', status: 'cancelled', statusColor: '#15803D', registeredAt: iso(500), trialEndsAt: null, layoutCount: 0, lastLayoutAt: null, hasWebsite: false, logins: [] },
];

const PLATFORM_USER: SessionUser = {
  id: 1, email: 'superadmin@crm.local', role: 'super_admin', tenantId: 1,
  tenantUid: '00000000-0000-4000-8000-000000000001', businessName: 'CRM Platform Operations',
};
const DEMO_ADMIN: SessionUser = {
  id: 2, email: 'demo@urbanthread.test', role: 'admin', tenantId: 2,
  tenantUid: tenants[0]!.tenantUid, businessName: 'Urban Thread Co.',
};

const SOURCES: Record<string, { module: keyof DashboardModules; title: string; keys: string[]; charts: ChartKind[] }> = {
  '/api/v1/admin/analytics/orders': { module: 'orders', title: 'Daily orders', keys: ['count', 'delta'], charts: ['line', 'bar'] },
  '/api/v1/admin/analytics/customers': { module: 'customers', title: 'New vs active customers', keys: ['new_customers', 'active_customers'], charts: ['line', 'bar'] },
  '/api/v1/admin/analytics/inventory': { module: 'inventory', title: 'Stock health', keys: ['in_stock', 'low_stock', 'out_of_stock'], charts: ['bar', 'circle'] },
  '/api/v1/admin/analytics/campaigns': { module: 'marketing', title: 'Campaign engagement', keys: ['sent', 'opens', 'open_rate'], charts: ['line', 'bar', 'circle'] },
  '/api/v1/admin/analytics/tickets': { module: 'customerService', title: 'Ticket resolution', keys: ['opened', 'resolved', 'resolution_rate'], charts: ['line', 'bar', 'circle'] },
  '/api/v1/admin/analytics/storefront': { module: 'storefront', title: 'Storefront funnel', keys: ['page_views', 'add_to_cart', 'checkouts'], charts: ['line', 'bar', 'circle'] },
};

const KIND_TO_TYPE: Record<ChartKind, WidgetType> = { line: 'LineChart', bar: 'BarChart', circle: 'CircleChart' };

/** Same rules the server applies to model output: allowlisted sources, requested types only. */
function compileLayout(modules: DashboardModules, charts: ChartKind[]): WidgetConfig[] {
  const widgets: WidgetConfig[] = [];
  for (const [url, source] of Object.entries(SOURCES)) {
    if (!modules[source.module]) continue;
    const usable = source.charts.filter((kind) => charts.includes(kind));
    if (usable.length === 0) continue;
    // Prefer a circle for ratio-style sources, a line for time series.
    const kind: ChartKind =
      usable.includes('circle') && ['inventory', 'customerService', 'marketing'].includes(source.module)
        ? 'circle'
        : usable.includes('line')
          ? 'line'
          : usable[0]!;
    widgets.push({
      widgetId: uuid(),
      type: KIND_TO_TYPE[kind],
      title: source.title,
      dataSourceUrl: url,
      colSpan: kind === 'circle' ? 4 : 6,
      dataKeys: source.keys,
    });
  }
  // Pack into full 12-column rows: one full-width lead trend, other trends
  // in pairs (6+6), circles in threes (4+4+4); leftovers widen to fill.
  const trends = widgets.filter((widget) => widget.type !== 'CircleChart');
  const circles = widgets.filter((widget) => widget.type === 'CircleChart');
  const lead = trends.shift();
  const sized = (list: WidgetConfig[], perRow: number): WidgetConfig[] =>
    list.map((widget, index) => {
      const rowStart = index - (index % perRow);
      const inRow = Math.min(perRow, list.length - rowStart);
      return { ...widget, colSpan: (12 / inRow) as WidgetConfig['colSpan'] };
    });
  return [...(lead ? [{ ...lead, colSpan: 12 as const }] : []), ...sized(circles, 3), ...sized(trends, 2)];
}

const layoutsByTenant = new Map<number, DashboardLayout[]>();
layoutsByTenant.set(2, [
  {
    id: 1, tenantId: 2, layoutName: 'Urban Thread Co. · v1', version: 1, isActive: true, createdBy: 1, createdAt: iso(3),
    config: compileLayout(
      { storefront: true, inventory: true, orders: true, customers: true, marketing: true, customerService: true },
      ['line', 'bar', 'circle'],
    ),
  },
]);
let nextLayoutId = 2;

// Time series are generated once so charts stay stable while you click around.
function series<T extends Record<string, number>>(keysFor: (day: number) => T): ({ date: string } & T)[] {
  return Array.from({ length: 30 }, (_, index) => ({ date: ymd(29 - index), ...keysFor(29 - index) }));
}
const ordersSeries = (() => {
  const rows = series((day) => {
    const weekend = new Date(now - day * DAY).getDay() % 6 === 0 ? 1.4 : 1;
    const count = Math.round((14 + (29 - day) * 0.35 + between(-4, 4)) * weekend);
    return { count, fulfilled: Math.round(count * (0.6 + rand() * 0.25)) };
  });
  return rows.map((row, i) => ({ ...row, delta: i === 0 ? 0 : row.count - rows[i - 1]!.count }));
})();
const customersSeries = series((day) => ({ new_customers: between(3, 11) + Math.round((29 - day) / 8), active_customers: between(28, 52) }));
const campaignsSeries = series(() => {
  const sent = rand() < 0.3 ? 0 : between(400, 1800);
  const opens = Math.round(sent * (0.22 + rand() * 0.18));
  return { sent, opens, clicks: Math.round(opens * 0.18), open_rate: sent ? Math.round((opens / sent) * 1000) / 10 : 0 };
});
const ticketsSeries = series(() => {
  const opened = between(4, 14);
  const resolved = Math.min(opened + 2, between(3, 14));
  return { opened, resolved, resolution_rate: Math.round((resolved / opened) * 1000) / 10 };
});
const storefrontSeries = series((day) => {
  const views = between(900, 1500) + (29 - day) * 12;
  const cart = Math.round(views * (0.07 + rand() * 0.03));
  return { page_views: views, add_to_cart: cart, checkouts: Math.round(cart * (0.38 + rand() * 0.1)) };
});
const ANALYTICS: Record<string, Record<string, unknown>[]> = {
  orders: ordersSeries,
  customers: customersSeries,
  inventory: [{ date: ymd(0), in_stock: 31, low_stock: 9, out_of_stock: 4 }],
  campaigns: campaignsSeries,
  tickets: ticketsSeries,
  storefront: storefrontSeries,
};

const firstNames = ['Ava', 'Leo', 'Maya', 'Noah', 'Ines', 'Kai', 'Zara', 'Omar', 'Lena', 'Theo', 'Priya', 'Sam'];
const lastNames = ['Chen', 'Okafor', 'Silva', 'Novak', 'Haddad', 'Tanaka', 'Moreau', 'Kim', 'Reyes', 'Larsen'];
const customers = Array.from({ length: 36 }, (_, i) => {
  const name = `${firstNames[i % firstNames.length]} ${lastNames[(i * 7) % lastNames.length]}`;
  return {
    id: 100 + i, full_name: name, email: `${name.toLowerCase().replace(' ', '.')}@mail.test`, phone: null,
    acquisition_channel: ['organic', 'paid_social', 'referral', 'email'][i % 4]!, status: 'active',
    total_orders: between(1, 14), ltv: (between(40, 900) + 0.5).toFixed(4), last_active_at: iso(between(0, 20)), created_at: iso(between(5, 200)),
  };
});
const orderStatuses = ['pending', 'confirmed', 'shipped', 'delivered', 'delivered', 'delivered', 'cancelled', 'refunded'];
const orders = Array.from({ length: 40 }, (_, i) => {
  const status = orderStatuses[between(0, orderStatuses.length - 1)]!;
  return {
    id: 5000 - i, customer_id: customers[i % customers.length]!.id, order_ref: `UT-${String(24811 - i).padStart(6, '0')}`,
    status, status_color: STATUS_COLOR[status]!, total_amount: (between(24, 310) + 0.99).toFixed(4), currency: 'USD',
    placed_at: new Date(now - i * 0.7 * DAY - between(0, 600) * 60_000).toISOString(), fulfilled_at: null,
  };
});
const productNames = ['Linen Camp Shirt', 'Selvedge Denim', 'Merino Crew', 'Canvas Tote', 'Wool Overshirt', 'Cotton Tee', 'Chore Jacket', 'Cord Trousers', 'Silk Scarf', 'Leather Belt', 'Knit Beanie', 'Rain Shell'];
const products = productNames.map((name, i) => {
  const status = i === 10 ? 'draft' : i === 11 ? 'archived' : 'active';
  return {
    id: 300 + i, sku_code: `UT-${name.split(' ').map((w) => w[0]).join('')}-${String(i + 1).padStart(3, '0')}`, name,
    category: ['Tops', 'Bottoms', 'Knitwear', 'Accessories', 'Outerwear'][i % 5]!, base_price: (between(25, 180) + 0.0).toFixed(4),
    status, status_color: STATUS_COLOR[status]!, image_url: null, created_at: iso(between(10, 300)),
  };
});
const ticketSubjects = ['Where is my order?', 'Wrong size received', 'Exchange request', 'Discount code not working', 'Package arrived damaged', 'Change delivery address', 'Return label request', 'Fabric care question'];
const ticketStatuses = ['open', 'in_progress', 'pending_customer', 'resolved', 'resolved', 'closed'];
const tickets = Array.from({ length: 18 }, (_, i) => {
  const status = ticketStatuses[between(0, ticketStatuses.length - 1)]!;
  return {
    id: 900 - i, customer_id: customers[(i * 3) % customers.length]!.id, assigned_to: null, subject: ticketSubjects[i % ticketSubjects.length]!,
    priority: (['low', 'medium', 'high', 'urgent'] as const)[between(0, 3)]!, status, status_color: STATUS_COLOR[status]!,
    channel: (['email', 'chat', 'phone'] as const)[i % 3]!, created_at: new Date(now - i * 0.9 * DAY).toISOString(),
    resolved_at: status === 'resolved' || status === 'closed' ? iso(Math.max(0, i * 0.9 - 0.5)) : null,
  };
});

// ─── Session ─────────────────────────────────────────────────────────────────

let session: SessionUser | null = null;
const registered = new Map<string, SessionUser>();

function issue(user: SessionUser) {
  session = user;
  return { accessToken: `mock.${user.role}.${uuid()}`, expiresIn: 900, user };
}

// ─── Plumbing ────────────────────────────────────────────────────────────────

class MockHttpError extends Error {
  constructor(public status: number, public code: string, message: string, public details: unknown[] = []) {
    super(message);
  }
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

function requireRole(role: Role): SessionUser {
  if (!session) throw new MockHttpError(401, 'UNAUTHORIZED', 'Authentication required');
  if (session.role !== role) throw new MockHttpError(403, 'FORBIDDEN', `This endpoint requires the ${role} role`);
  return session;
}

function parseBody(config: InternalAxiosRequestConfig): Record<string, unknown> {
  if (!config.data) return {};
  if (typeof config.data === 'string') {
    try {
      return JSON.parse(config.data) as Record<string, unknown>;
    } catch {
      return {};
    }
  }
  return config.data as Record<string, unknown>;
}

async function route(method: string, path: string, body: Record<string, unknown>): Promise<{ status?: number; data: unknown }> {
  // Auth
  if (path === '/api/v1/auth/refresh') {
    if (!session) throw new MockHttpError(401, 'INVALID_SESSION', 'No active session');
    return { data: issue(session) };
  }
  if (path === '/api/v1/auth/logout') {
    session = null;
    return { data: { loggedOut: true } };
  }
  if (path === '/api/v1/auth/login') {
    await sleep(500);
    const email = String(body.email ?? '').toLowerCase();
    if (!body.password) throw new MockHttpError(422, 'VALIDATION_ERROR', 'password is required');
    if (email === PLATFORM_USER.email) return { data: issue(PLATFORM_USER) };
    const user = registered.get(email) ?? (email === DEMO_ADMIN.email ? DEMO_ADMIN : null);
    if (!user) throw new MockHttpError(401, 'INVALID_CREDENTIALS', 'Invalid email or password. In this preview use one of the demo accounts shown above.');
    return { data: issue(user) };
  }
  if (path === '/api/v1/auth/register') {
    await sleep(700);
    const id = 100 + tenants.length;
    const tenant: Tenant = {
      id, tenantUid: uuid(), businessName: String(body.businessName), industry: body.industry as Tenant['industry'], plan: 'starter',
      status: 'active', statusColor: '#22C55E', registeredAt: new Date().toISOString(), trialEndsAt: new Date(now + 14 * DAY).toISOString(),
      layoutCount: 0, lastLayoutAt: null, hasWebsite: false, logins: [],
    };
    tenants.unshift(tenant);
    const user: SessionUser = { id: 1000 + id, email: String(body.email).toLowerCase(), role: 'admin', tenantId: id, tenantUid: tenant.tenantUid, businessName: tenant.businessName };
    registered.set(user.email, user);
    return { status: 201, data: issue(user) };
  }
  if (path.startsWith('/api/v1/auth/oauth/')) {
    await sleep(600);
    return { data: issue(DEMO_ADMIN) };
  }

  // Super admin (no monetary fields anywhere below — mirrors the DB views)
  if (path === '/api/v1/superadmin/tenants') {
    requireRole('super_admin');
    return { data: tenants };
  }
  const removeMatch = /^\/api\/v1\/superadmin\/tenants\/(\d+)$/.exec(path);
  if (removeMatch && method === 'delete') {
    requireRole('super_admin');
    const tenant = tenants.find((t) => t.id === Number(removeMatch[1]));
    if (!tenant) throw new MockHttpError(404, 'NOT_FOUND', 'Tenant does not exist');
    if (tenant.status === 'cancelled') throw new MockHttpError(409, 'CONFLICT', 'This store has already been removed');
    tenant.status = 'cancelled';
    tenant.statusColor = '#15803D';
    return { data: { removed: true, businessName: tenant.businessName } };
  }
  if (path === '/api/v1/superadmin/generate-dashboard' && method === 'post') {
    const user = requireRole('super_admin');
    const tenant = tenants.find((t) => t.id === body.tenantId);
    if (!tenant) throw new MockHttpError(404, 'NOT_FOUND', 'Tenant does not exist');
    if (tenant.layoutCount > 0) throw new MockHttpError(409, 'CONFLICT', 'This store already has a dashboard. See it in Websites.');
    await sleep(2200); // stands in for the model call
    const config = compileLayout(body.modules as DashboardModules, body.analyticsCharts as ChartKind[]);
    if (config.length === 0) throw new MockHttpError(422, 'VALIDATION_ERROR', 'Enable at least one module that supports the selected chart types');
    const history = layoutsByTenant.get(tenant.id) ?? [];
    history.forEach((layout) => (layout.isActive = false));
    const layout: DashboardLayout = {
      id: nextLayoutId++, tenantId: tenant.id, layoutName: `${String(body.storeName)} · v${history.length + 1}`,
      version: history.length + 1, isActive: true, createdBy: user.id, createdAt: new Date().toISOString(), config,
    };
    layoutsByTenant.set(tenant.id, [layout, ...history]);
    tenant.layoutCount += 1;
    tenant.lastLayoutAt = layout.createdAt;
    tenant.hasWebsite = Boolean((body.modules as DashboardModules).storefront);
    return { status: 201, data: { layoutId: layout.id, config } };
  }

  // Tenant admin
  if (path === '/api/v1/dashboard/layout/active') {
    const user = requireRole('admin');
    return { data: layoutsByTenant.get(user.tenantId)?.find((layout) => layout.isActive) ?? null };
  }
  if (path.startsWith('/api/v1/admin/')) {
    const user = requireRole('admin');
    const ownStore = user.tenantId === DEMO_ADMIN.tenantId; // new sign-ups start empty
    const resource = path.slice('/api/v1/admin/'.length);
    if (resource === 'notifications/summary') {
      const urgent = ownStore ? tickets.filter((t) => ['open', 'in_progress'].includes(t.status) && ['high', 'urgent'].includes(t.priority)).length : 0;
      const lowStock = ownStore ? 13 : 0;
      return { data: { urgentTickets: urgent, lowStockProducts: lowStock, count: urgent + lowStock } };
    }
    if (resource.startsWith('analytics/')) {
      await sleep(between(250, 900));
      const metric = resource.slice('analytics/'.length);
      const rows = ANALYTICS[metric];
      if (!rows) throw new MockHttpError(422, 'VALIDATION_ERROR', `Unknown metric ${metric}`);
      return { data: ownStore ? rows : [] };
    }
    const tables: Record<string, unknown[]> = { orders, products, customers, tickets };
    const rows = tables[resource];
    if (!rows) throw new MockHttpError(404, 'NOT_FOUND', `Route GET ${path} does not exist`);
    await sleep(250);
    return { data: ownStore ? rows : [] };
  }

  throw new MockHttpError(404, 'NOT_FOUND', `Route ${method.toUpperCase()} ${path} does not exist`);
}

export const isMockApi = true;

export const mockAdapter: AxiosAdapter = async (config) => {
  const method = (config.method ?? 'get').toLowerCase();
  const path = (config.url ?? '').split('?')[0]!;
  const headers = new AxiosHeaders({ 'content-type': 'application/json' });

  try {
    await sleep(120);
    const { status = 200, data } = await route(method, path, parseBody(config));
    return { data: { success: true, data }, status, statusText: 'OK', headers, config, request: {} } satisfies AxiosResponse;
  } catch (error) {
    const httpError =
      error instanceof MockHttpError ? error : new MockHttpError(500, 'INTERNAL_ERROR', 'An unexpected error occurred');
    const response: AxiosResponse = {
      data: { success: false, error: { code: httpError.code, message: httpError.message, details: httpError.details, requestId: uuid() } },
      status: httpError.status,
      statusText: httpError.code,
      headers,
      config,
      request: {},
    };
    throw new AxiosError(httpError.message, String(httpError.status), config, {}, response);
  }
};
