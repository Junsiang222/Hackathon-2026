import type { AxiosAdapter } from 'axios';

// Normal builds: no mock. The hosted preview build (vite.preview.config.ts)
// aliases '@/mocks' to ./mockApi.ts, which exports the in-browser fake API.
export const isMockApi = false;
export const mockAdapter: AxiosAdapter | undefined = undefined;
