import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Suspense, useCallback, useEffect, useState } from 'react';
import { useLocation, useOutlet } from 'react-router-dom';
import { ChangePasswordGate } from '@/components/ChangePasswordGate';
import { Header } from '@/components/Header';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { PLATFORM_NAME, Sidebar } from '@/components/Sidebar';
import { usePreferencesSync } from '@/hooks/useSettings';
import { usePreferencesStore, useT } from '@/i18n';
import { useAuthStore } from '@/store/authStore';

const PAGE_TITLES: Record<string, string> = {
  '/dashboard/super-admin': 'Platform Overview',
  '/dashboard/stores': 'Stores',
  '/dashboard/websites': 'Websites',
  '/dashboard/platform-analytics': 'Analytics',
  '/dashboard/settings': 'Settings',
  '/dashboard/expenses': 'Expenses',
  '/dashboard/admin': 'Overview',
  '/dashboard/products': 'Products',
  '/dashboard/orders': 'Orders',
  '/dashboard/customers': 'Customers',
  '/dashboard/marketing': 'Marketing',
  '/dashboard/tickets': 'Support Tickets',
  '/dashboard/analytics': 'Analytics',
};

export function DashboardLayout() {
  const location = useLocation();
  // Freeze the outlet element so the exiting page keeps rendering its own
  // content during the exit animation.
  const outlet = useOutlet();
  const reduceMotion = useReducedMotion();
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const closeMobileNav = useCallback(() => setMobileNavOpen(false), []);

  const mustChangePassword = useAuthStore(
    (state) => state.user?.role === 'admin' && state.user.mustChangePassword === true,
  );
  usePreferencesSync();
  const t = useT();
  const theme = usePreferencesStore((state) => state.theme);

  // Dark mode covers the dashboard only (not the public shops or the login page).
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    root.style.colorScheme = theme;
    return () => {
      root.classList.remove('dark');
      root.style.colorScheme = '';
    };
  }, [theme]);

  // The whole back office (super admin and store admin) uses the Clauday editorial design.
  // Public shops and the sign-in page keep their own look: the class only lives while the dashboard is mounted.
  useEffect(() => {
    const root = document.documentElement;
    root.classList.add('sa-minimal');
    return () => root.classList.remove('sa-minimal');
  }, []);
  const title = t(
    PAGE_TITLES[location.pathname] ??
      (location.pathname.startsWith('/dashboard/platform-analytics/') ? 'Store analytics' : 'Dashboard'),
  );

  useEffect(() => {
    document.title = `${title} · ${PLATFORM_NAME}`;
  }, [title]);

  return (
    <div className="min-h-screen bg-gray-50">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-brand-black"
      >
        {t('Skip to content')}
      </a>

      <Sidebar mobileOpen={mobileNavOpen} onMobileClose={closeMobileNav} />

      <div className="flex min-h-screen flex-col lg:pl-64">
        <Header title={title} onOpenMobileNav={() => setMobileNavOpen(true)} />

        <main id="main-content" className="flex-1 overflow-y-auto p-4 sm:p-8">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={location.pathname}
              initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, transition: { duration: 0.12 } }}
              transition={{ duration: 0.22, ease: 'easeOut' }}
            >
              {/* Lazy pages suspend here, so the shell stays on screen. */}
              {/* A temporary password must be replaced before the store's tools open. */}
              <Suspense fallback={<LoadingShimmer rows={3} />}>
                {mustChangePassword ? <ChangePasswordGate /> : outlet}
              </Suspense>
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
