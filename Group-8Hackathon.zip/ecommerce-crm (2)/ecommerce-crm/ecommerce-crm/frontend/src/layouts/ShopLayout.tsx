import { LogIn, Package, ShieldCheck, ShoppingCart, Store, UserRound } from 'lucide-react';
import { useEffect } from 'react';
import { Link, NavLink, Outlet, useMatch, useParams } from 'react-router-dom';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { EmptyState } from '@/components/ui/EmptyState';
import { useShopInfo, type ShopContext } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useCart } from '@/store/cartStore';
import { useShopSession } from '@/store/shopAccountStore';
import { initialsFrom } from '@/utils/format';

const navClass = ({ isActive }: { isActive: boolean }) =>
  `rounded-lg px-3 py-2 text-sm font-medium ${isActive ? 'bg-brand-mint text-brand-green-dark' : 'text-gray-700 hover:bg-gray-100'}`;

/** Public storefront shell. Shows only what the store's setup wizard enabled. */
export function ShopLayout() {
  const { tenantUid = '' } = useParams();
  const infoQuery = useShopInfo(tenantUid);
  const { count } = useCart(tenantUid);
  const session = useShopSession(tenantUid);
  const isHome = useMatch('/shop/:tenantUid') !== null;
  const shop = infoQuery.data;

  useEffect(() => {
    if (shop) document.title = shop.storeName;
  }, [shop]);

  if (infoQuery.isPending) return <LoadingShimmer variant="page" />;
  if (!shop) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-50 p-4">
        <div className="w-full max-w-md">
          <EmptyState icon={Store} title="Shop not found" description={getApiErrorMessage(infoQuery.error)} minHeight={280} />
        </div>
      </main>
    );
  }

  const root = `/shop/${tenantUid}`;
  const context: ShopContext = { shopId: tenantUid, shop };

  // An AI-designed home page brings its own header, navigation and footer.
  if (isHome && shop.website && 'html' in shop.website) return <Outlet context={context} />;

  return (
    <div className="flex min-h-screen flex-col bg-gray-50">
      <a
        href="#shop-main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b border-gray-100 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-3 px-4 sm:px-6">
          <Link to={root} className="flex min-w-0 items-center gap-2.5">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-brand-black text-xs font-bold text-brand-green">
              {initialsFrom(shop.storeName)}
            </span>
            <span className="truncate text-lg font-bold tracking-tight text-brand-black">{shop.storeName}</span>
          </Link>
          <nav aria-label="Shop" className="ml-auto hidden items-center gap-1 sm:flex">
            <NavLink to={root} end className={navClass}>
              Shop
            </NavLink>
            {shop.features.orderTracking ? (
              <NavLink to={`${root}/track`} className={navClass}>
                Track order
              </NavLink>
            ) : null}
            {shop.features.contact ? (
              <NavLink to={`${root}/contact`} className={navClass}>
                Contact
              </NavLink>
            ) : null}
          </nav>
          {shop.features.accounts ? (
            <Link
              to={session ? `${root}/account` : `${root}/login`}
              className="ml-auto flex h-11 shrink-0 items-center gap-2 rounded-full border border-gray-200 px-3 text-sm font-semibold text-brand-black hover:bg-gray-50 sm:ml-2"
            >
              {session ? (
                <UserRound className="h-4 w-4" aria-hidden="true" />
              ) : (
                <LogIn className="h-4 w-4" aria-hidden="true" />
              )}
              <span className="hidden max-w-[10rem] truncate sm:inline">
                {session ? session.customer.fullName.split(' ')[0] : 'Log in'}
              </span>
              <span className="sr-only sm:hidden">{session ? 'My account' : 'Log in'}</span>
            </Link>
          ) : null}
          {/* No cart without "Orders & Checkout". */}
          {shop.features.checkout ? (
            <Link
              to={`${root}/cart`}
              className={`relative flex h-11 items-center gap-2 rounded-full bg-brand-black px-4 text-sm font-semibold text-white hover:bg-gray-800 sm:ml-2 ${shop.features.accounts ? '' : 'ml-auto'}`}
              aria-label={`Cart, ${count} ${count === 1 ? 'item' : 'items'}`}
            >
              <ShoppingCart className="h-4 w-4" aria-hidden="true" />
              <span aria-hidden="true">{count}</span>
            </Link>
          ) : null}
        </div>
        {/* Phone nav */}
        <nav aria-label="Shop" className="flex gap-1 overflow-x-auto border-t border-gray-100 px-4 py-2 sm:hidden">
          <NavLink to={root} end className={navClass}>
            Shop
          </NavLink>
          {shop.features.orderTracking ? (
            <NavLink to={`${root}/track`} className={navClass}>
              Track order
            </NavLink>
          ) : null}
          {shop.features.contact ? (
            <NavLink to={`${root}/contact`} className={navClass}>
              Contact
            </NavLink>
          ) : null}
        </nav>
      </header>

      <main id="shop-main" className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6">
        <Outlet context={context} />
      </main>

      <footer className="border-t border-gray-100 bg-white">
        <div className="mx-auto flex max-w-6xl flex-col gap-1 px-4 py-6 text-sm text-gray-500 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>
            © {new Date().getFullYear()} {shop.storeName}
          </p>
          <p className="inline-flex items-center gap-1.5">
            <Package className="h-4 w-4" aria-hidden="true" />
            Demo shop: payments are simulated, no real money is charged.
          </p>
          {/* The store owner's admin dashboard (staff login, not shopper accounts). */}
          <Link to="/auth" className="inline-flex items-center gap-1.5 hover:text-brand-black hover:underline">
            <ShieldCheck className="h-4 w-4" aria-hidden="true" />
            Store admin
          </Link>
        </div>
      </footer>
    </div>
  );
}
