import { useEffect } from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { BrandLogo, PLATFORM_NAME } from '@/components/BrandLogo';
import { isMockApi } from '@/mocks';
import { useAuthStore } from '@/store/authStore';

export function AuthLayout() {
  const status = useAuthStore((state) => state.status);

  useEffect(() => {
    document.title = `Sign in · ${PLATFORM_NAME}`;
  }, []);

  // Sign-in shares the back office's Clauday design (light only), so the hand-off to the dashboard looks seamless.
  useEffect(() => {
    const root = document.documentElement;
    root.classList.add('sa-minimal');
    return () => root.classList.remove('sa-minimal');
  }, []);

  if (status === 'idle' || status === 'loading') return <LoadingShimmer variant="page" />;
  if (status === 'authenticated') return <Navigate to="/dashboard" replace />;

  return (
    <div className="flex min-h-screen flex-col bg-gray-50 px-4 py-8 sm:py-12">
      <header className="mx-auto mb-8">
        <BrandLogo size="lg" />
      </header>
      {isMockApi ? (
        <aside className="mx-auto mb-6 w-full max-w-5xl rounded-2xl border border-brand-green bg-white px-5 py-4 text-sm text-gray-700">
          <p className="font-semibold text-brand-black">Preview with sample data. No real backend is connected.</p>
          <p className="mt-1">
            Platform view: <code className="font-semibold text-brand-black">superadmin@crm.local</code> · Store view:{' '}
            <code className="font-semibold text-brand-black">demo@urbanthread.test</code> · any password. Creating an account also works.
          </p>
        </aside>
      ) : null}
      <main className="flex flex-1 items-start justify-center lg:items-center">
        <Outlet />
      </main>
    </div>
  );
}
