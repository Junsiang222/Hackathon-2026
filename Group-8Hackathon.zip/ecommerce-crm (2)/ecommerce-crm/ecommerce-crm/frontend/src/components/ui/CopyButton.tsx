import { Check, Copy } from 'lucide-react';
import { useState } from 'react';
import toast from 'react-hot-toast';
import { useT } from '@/i18n';

export function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);
  const t = useT();
  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error(t('Could not copy. Select the text and copy it manually.'));
    }
  };
  return (
    <button
      type="button"
      onClick={onCopy}
      aria-label={copied ? t('Copied') : label}
      className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-gray-500 hover:bg-brand-mint hover:text-brand-black"
    >
      {copied ? <Check className="h-4 w-4 text-brand-green-dark" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
    </button>
  );
}

/** One-time credentials card: email + temporary password, both copyable. */
export function CredentialsCard({ email, password }: { email: string; password: string }) {
  const t = useT();
  return (
    <div className="space-y-3">
      <dl className="divide-y divide-gray-200 rounded-xl border-2 border-brand-black bg-gray-50">
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <div className="min-w-0">
            <dt className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('Admin email')}</dt>
            <dd className="truncate font-mono text-sm font-semibold text-brand-black sm:text-base">{email}</dd>
          </div>
          <CopyButton text={email} label={t('Copy admin email')} />
        </div>
        <div className="flex items-center justify-between gap-3 px-4 py-3">
          <div>
            <dt className="text-xs font-semibold uppercase tracking-wide text-gray-500">{t('Temporary password')}</dt>
            <dd className="font-mono text-lg font-bold tracking-wider text-brand-black">{password}</dd>
          </div>
          <CopyButton text={password} label={t('Copy temporary password')} />
        </div>
      </dl>
      <p className="rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
        {t("Copy these now and give them to the store owner. The password is shown only this once. It's temporary: they'll be asked to choose their own the first time they log in.")}
      </p>
    </div>
  );
}
