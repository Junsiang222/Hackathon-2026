import { forwardRef, useId, type SelectHTMLAttributes, type TextareaHTMLAttributes } from 'react';

const CONTROL =
  'block min-h-[44px] w-full rounded-xl border bg-white px-3.5 py-2.5 text-base text-brand-black transition-colors focus:outline-none focus:ring-4';

function stateClasses(error?: string) {
  return error
    ? 'border-red-500 focus:border-red-600 focus:ring-red-100'
    : 'border-gray-300 focus:border-brand-black focus:ring-gray-100';
}

function FieldMessages({ id, error, hint }: { id: string; error?: string; hint?: string }) {
  return (
    <>
      {hint && !error ? (
        <p id={`${id}-hint`} className="mt-1.5 text-xs text-gray-500">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm text-red-600">
          {error}
        </p>
      ) : null}
    </>
  );
}

interface SelectFieldProps extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'id'> {
  label: string;
  options: readonly { value: string; label: string }[];
  error?: string;
  hint?: string;
  /** Visually hide the label (it stays available to screen readers). */
  hideLabel?: boolean;
}

export const SelectField = forwardRef<HTMLSelectElement, SelectFieldProps>(function SelectField(
  { label, options, error, hint, hideLabel = false, className = '', ...props },
  ref,
) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className={hideLabel ? 'sr-only' : 'mb-1.5 block text-sm font-medium text-brand-black'}>
        {label}
      </label>
      <select
        ref={ref}
        id={id}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-error` : hint ? `${id}-hint` : undefined}
        className={`${CONTROL} pr-9 ${stateClasses(error)}`}
        {...props}
      >
        {options.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
      <FieldMessages id={id} error={error} hint={hint} />
    </div>
  );
});

interface TextAreaFieldProps extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'id'> {
  label: string;
  error?: string;
  hint?: string;
}

export const TextAreaField = forwardRef<HTMLTextAreaElement, TextAreaFieldProps>(function TextAreaField(
  { label, error, hint, className = '', rows = 3, ...props },
  ref,
) {
  const id = useId();
  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-brand-black">
        {label}
      </label>
      <textarea
        ref={ref}
        id={id}
        rows={rows}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${id}-error` : hint ? `${id}-hint` : undefined}
        className={`${CONTROL} ${stateClasses(error)}`}
        {...props}
      />
      <FieldMessages id={id} error={error} hint={hint} />
    </div>
  );
});

/** Turns "in_progress" into an option label "In progress". */
export function optionsFrom<T extends string>(values: readonly T[]): { value: T; label: string }[] {
  return values.map((value) => {
    const text = value.replace(/_/g, ' ');
    return { value, label: text.charAt(0).toUpperCase() + text.slice(1) };
  });
}
