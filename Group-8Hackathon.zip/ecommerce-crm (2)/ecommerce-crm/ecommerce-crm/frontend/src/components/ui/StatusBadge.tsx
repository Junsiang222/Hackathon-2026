import { useT } from '@/i18n';

interface StatusBadgeProps {
  status: string;
  /** status_color from the API: #22C55E (active/paid), #DCFCE7 (pending), #15803D (structural). */
  color: string;
}

// Text colour chosen per background so every badge clears WCAG AA 4.5:1.
function textColorFor(background: string): string {
  switch (background.toUpperCase()) {
    case '#15803D':
      return '#FFFFFF';
    case '#DCFCE7':
      return '#15803D';
    default:
      return '#0A0A0A';
  }
}

export function StatusBadge({ status, color }: StatusBadgeProps) {
  const t = useT();
  const words = status.replace(/_/g, ' ');
  const label = t(words.charAt(0).toUpperCase() + words.slice(1));
  return (
    <span
      className="inline-flex items-center whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize"
      style={{ backgroundColor: color, color: textColorFor(color) }}
    >
      {label}
    </span>
  );
}
