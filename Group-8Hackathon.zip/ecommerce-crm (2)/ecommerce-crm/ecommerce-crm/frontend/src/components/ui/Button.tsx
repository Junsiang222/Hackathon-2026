import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Spinner } from './Spinner';

type Variant = 'primary' | 'ghost' | 'outline' | 'dark' | 'danger';

const VARIANT_CLASSES: Record<Variant, string> = {
  primary: 'bg-brand-green text-white hover:bg-brand-green-dark disabled:hover:bg-brand-green',
  ghost: 'bg-transparent text-brand-black hover:bg-brand-mint',
  outline: 'border border-gray-300 bg-white text-brand-black hover:border-brand-black hover:bg-gray-50',
  dark: 'bg-brand-black text-white hover:bg-gray-800',
  danger: 'bg-red-600 text-white hover:bg-red-700 disabled:hover:bg-red-600',
};

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  loading?: boolean;
  loadingText?: string;
  leftIcon?: ReactNode;
  fullWidth?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = 'primary',
    loading = false,
    loadingText,
    leftIcon,
    fullWidth = false,
    disabled,
    className = '',
    children,
    type = 'button',
    ...rest
  },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      data-ui="button"
      data-variant={variant}
      className={[
        'inline-flex min-h-[44px] items-center justify-center gap-2 rounded-xl px-5 text-sm font-semibold',
        'transition-colors duration-150 disabled:cursor-not-allowed disabled:opacity-60',
        VARIANT_CLASSES[variant],
        fullWidth ? 'w-full' : '',
        className,
      ].join(' ')}
      {...rest}
    >
      {loading ? <Spinner /> : leftIcon}
      <span>{loading && loadingText ? loadingText : children}</span>
    </button>
  );
});
