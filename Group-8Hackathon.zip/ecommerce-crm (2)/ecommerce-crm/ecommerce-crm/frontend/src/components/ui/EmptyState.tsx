import type { LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
  minHeight?: number;
}

export function EmptyState({ icon: Icon, title, description, action, minHeight = 200 }: EmptyStateProps) {
  return (
    <div
      style={{ minHeight }}
      className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-gray-200 px-6 py-8 text-center"
    >
      <span className="mb-1 flex h-11 w-11 items-center justify-center rounded-full bg-brand-mint">
        <Icon className="h-5 w-5 text-brand-green-dark" aria-hidden="true" />
      </span>
      <p className="text-sm font-semibold text-brand-black">{title}</p>
      {description ? <p className="max-w-sm text-sm text-gray-500">{description}</p> : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}
