import { Search } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { SelectField } from '@/components/ui/FormFields';
import { getApiErrorMessage } from '@/lib/axios';
import type { LucideIcon } from 'lucide-react';

export interface Column<R> {
  header: string;
  align?: 'right';
  /** Hide below the `sm` breakpoint to keep tables readable on phones. */
  hideOnMobile?: boolean;
  render: (row: R) => ReactNode;
}

interface DataTableProps<R extends { id: number }> {
  caption: string;
  columns: Column<R>[];
  rows: R[] | undefined;
  isPending: boolean;
  error: unknown;
  onRetry: () => void;
  isFetching: boolean;
  empty: { icon: LucideIcon; title: string; description?: string };
  onRowClick?: (row: R) => void;
  /** Accessible name for the row button, e.g. "Open order ORD-1". */
  rowLabel?: (row: R) => string;
}

export function DataTable<R extends { id: number }>({
  caption,
  columns,
  rows,
  isPending,
  error,
  onRetry,
  isFetching,
  empty,
  onRowClick,
  rowLabel,
}: DataTableProps<R>) {
  if (isPending) return <LoadingShimmer rows={5} />;
  if (error) return <ErrorPlaceholder message={getApiErrorMessage(error)} onRetry={onRetry} isRetrying={isFetching} />;
  if (!rows || rows.length === 0) {
    return <EmptyState icon={empty.icon} title={empty.title} description={empty.description} minHeight={240} />;
  }

  const cell = (column: Column<R>) =>
    `px-5 py-4 ${column.align === 'right' ? 'text-right tabular-nums' : ''} ${column.hideOnMobile ? 'hidden sm:table-cell' : ''}`;

  return (
    <div className={`overflow-x-auto rounded-2xl border border-gray-100 bg-white shadow-sm ${isFetching ? 'opacity-70' : ''}`}>
      <table className="w-full text-left text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead className="border-b border-gray-100 text-xs uppercase tracking-wide text-gray-500">
          <tr>
            {columns.map((column) => (
              <th key={column.header} scope="col" className={`${cell(column)} py-3 font-semibold`}>
                {column.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {rows.map((row) => (
            <tr
              key={row.id}
              className={onRowClick ? 'cursor-pointer hover:bg-gray-50 focus-within:bg-gray-50' : 'hover:bg-gray-50'}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
            >
              {columns.map((column, index) => (
                <td key={column.header} className={`${cell(column)} text-gray-700`}>
                  {/* First cell carries a real button so rows are keyboard-reachable. */}
                  {index === 0 && onRowClick ? (
                    <button
                      type="button"
                      className="text-left focus:outline-none"
                      aria-label={rowLabel?.(row)}
                      onClick={(event) => {
                        event.stopPropagation();
                        onRowClick(row);
                      }}
                    >
                      {column.render(row)}
                    </button>
                  ) : (
                    column.render(row)
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Debounced value, for search boxes that query the API. */
export function useDebounced<T>(value: T, delay = 300): T {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

interface ToolbarProps {
  search?: { value: string; onChange: (value: string) => void; placeholder: string };
  filter?: { label: string; value: string; onChange: (value: string) => void; options: readonly { value: string; label: string }[] };
  actions?: ReactNode;
}

export function Toolbar({ search, filter, actions }: ToolbarProps) {
  return (
    <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
      {search ? (
        <div className="relative flex-1">
          <label className="sr-only" htmlFor="toolbar-search">
            {search.placeholder}
          </label>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" aria-hidden="true" />
          <input
            id="toolbar-search"
            type="search"
            value={search.value}
            onChange={(event) => search.onChange(event.target.value)}
            placeholder={search.placeholder}
            className="block min-h-[44px] w-full rounded-xl border border-gray-300 bg-white py-2.5 pl-10 pr-3.5 text-base text-brand-black placeholder:text-gray-400 focus:border-brand-black focus:outline-none focus:ring-4 focus:ring-gray-100"
          />
        </div>
      ) : (
        <div className="flex-1" />
      )}
      {filter ? (
        <SelectField
          label={filter.label}
          hideLabel
          value={filter.value}
          onChange={(event) => filter.onChange(event.target.value)}
          options={filter.options}
          className="sm:w-48"
        />
      ) : null}
      {actions}
    </div>
  );
}

export function PageIntro({ title, description }: { title: string; description: string }) {
  return (
    <div className="mb-5">
      <h2 className="text-lg font-bold tracking-tight text-brand-black">{title}</h2>
      <p className="text-sm text-gray-700">{description}</p>
    </div>
  );
}
