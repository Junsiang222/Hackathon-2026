import { AlertCircle, RotateCw } from 'lucide-react';
import { useT } from '@/i18n';

interface ErrorPlaceholderProps {
  message: string;
  /** Typically TanStack Query's refetch(). */
  onRetry?: () => unknown;
  isRetrying?: boolean;
  height?: number;
}

export function ErrorPlaceholder({ message, onRetry, isRetrying = false, height = 280 }: ErrorPlaceholderProps) {
  const t = useT();
  return (
    <div
      role="alert"
      style={{ minHeight: height }}
      className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-gray-200 px-6 text-center"
    >
      <AlertCircle className="h-8 w-8 text-red-400" aria-hidden="true" />
      <p className="max-w-xs text-sm text-gray-500">{message}</p>
      {onRetry ? (
        <button
          type="button"
          onClick={() => void onRetry()}
          disabled={isRetrying}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-lg px-4 text-sm font-semibold text-brand-green-dark hover:bg-brand-mint disabled:opacity-60"
        >
          <RotateCw className={`h-4 w-4 ${isRetrying ? 'animate-spin' : ''}`} aria-hidden="true" />
          {isRetrying ? t('Retrying…') : t('Retry')}
        </button>
      ) : null}
    </div>
  );
}
