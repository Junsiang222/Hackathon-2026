interface ShimmerSkeletonProps {
  height: number;
  width?: string;
  className?: string;
}

/** Animated placeholder that reserves the exact space of the content it replaces (no layout shift). */
export function ShimmerSkeleton({ height, width = '100%', className = '' }: ShimmerSkeletonProps) {
  return (
    <div
      role="status"
      aria-label="Loading"
      style={{ height, width }}
      className={[
        'rounded-xl bg-gradient-to-r from-gray-100 via-brand-mint to-gray-100 bg-size-200',
        'animate-shimmer motion-reduce:animate-none',
        className,
      ].join(' ')}
    />
  );
}
