import { Check } from 'lucide-react';
import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from 'react';

export interface TextFieldProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'id'> {
  label: string;
  error?: string;
  hint?: string;
  /** Show the green "valid" state (only after the user has interacted). */
  isValid?: boolean;
  /** Trailing control inside the input, e.g. a show/hide password button. */
  trailing?: ReactNode;
}

export const TextField = forwardRef<HTMLInputElement, TextFieldProps>(function TextField(
  { label, error, hint, isValid = false, trailing, className = '', ...inputProps },
  ref,
) {
  const id = useId();
  const errorId = `${id}-error`;
  const hintId = `${id}-hint`;
  const describedBy = [error ? errorId : null, hint ? hintId : null].filter(Boolean).join(' ') || undefined;

  const stateClasses = error
    ? 'border-red-500 focus:border-red-600 focus:ring-red-100'
    : isValid
      ? 'border-brand-green focus:border-brand-green-dark focus:ring-brand-mint'
      : 'border-gray-300 focus:border-brand-black focus:ring-gray-100';

  return (
    <div className={className}>
      <label htmlFor={id} className="mb-1.5 block text-sm font-medium text-brand-black">
        {label}
      </label>
      <div className="relative">
        <input
          ref={ref}
          id={id}
          aria-invalid={error ? true : undefined}
          aria-describedby={describedBy}
          className={[
            'block min-h-[44px] w-full rounded-xl border bg-white px-3.5 py-2.5 text-base text-brand-black',
            'placeholder:text-gray-400 transition-colors focus:outline-none focus:ring-4',
            isValid && trailing ? 'pr-20' : isValid || trailing ? 'pr-11' : '',
            stateClasses,
          ].join(' ')}
          {...inputProps}
        />
        <div className="absolute inset-y-0 right-0 flex items-center gap-1 pr-2">
          {isValid && !error ? (
            <Check className="h-5 w-5 text-brand-green-dark" aria-hidden="true" strokeWidth={2.5} />
          ) : null}
          {trailing}
        </div>
      </div>
      {hint && !error ? (
        <p id={hintId} className="mt-1.5 text-xs text-gray-500">
          {hint}
        </p>
      ) : null}
      {error ? (
        <p id={errorId} role="alert" className="mt-1.5 text-sm text-red-600">
          {error}
        </p>
      ) : null}
    </div>
  );
});
