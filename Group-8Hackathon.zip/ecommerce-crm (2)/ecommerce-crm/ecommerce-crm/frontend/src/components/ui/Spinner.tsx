import { Loader2 } from 'lucide-react';

interface SpinnerProps {
  className?: string;
  /** Announced to screen readers; omit when a visible label sits next to it. */
  label?: string;
}

export function Spinner({ className = 'h-4 w-4', label }: SpinnerProps) {
  return (
    <>
      <Loader2 className={`animate-spin ${className}`} aria-hidden="true" />
      {label ? <span className="sr-only">{label}</span> : null}
    </>
  );
}
