import { Lock, Settings2 } from 'lucide-react';
import type { ReactNode } from 'react';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { hasModule, useStoreSetup } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { ModuleKey } from '@/types/dashboard.types';

export const MODULE_LABEL: Record<ModuleKey, string> = {
  storefront: 'Storefront',
  inventory: 'Inventory tracking',
  orders: 'Orders & Checkout',
  customers: 'Customer Profiles',
  marketing: 'Automated Marketing',
  customerService: 'Support Desk',
};

export function StoreNotSetUp() {
  return (
    <EmptyState
      icon={Settings2}
      minHeight={320}
      title="Your store isn't set up yet"
      description="Your platform administrator chooses which features your store gets. Once they finish your store setup, your tools appear in the sidebar."
    />
  );
}

/** Renders children only when ANY of `modules` was enabled in the store's setup wizard. */
export function RequireModule({ modules, children }: { modules: readonly ModuleKey[]; children: ReactNode }) {
  const setupQuery = useStoreSetup();

  if (setupQuery.isPending) return <LoadingShimmer rows={3} />;
  if (setupQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(setupQuery.error)}
        onRetry={() => setupQuery.refetch()}
        isRetrying={setupQuery.isFetching}
      />
    );
  }
  if (!setupQuery.data) return <StoreNotSetUp />;
  if (!hasModule(setupQuery.data, modules)) {
    return (
      <EmptyState
        icon={Lock}
        minHeight={320}
        title={`${modules.map((module) => MODULE_LABEL[module]).join(' / ')} isn't part of your store`}
        description="This feature wasn't selected when your store was set up. Ask your platform administrator if you need it."
      />
    );
  }
  return <>{children}</>;
}
