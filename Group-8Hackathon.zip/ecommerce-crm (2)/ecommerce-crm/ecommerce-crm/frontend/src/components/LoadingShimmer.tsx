import { ShimmerSkeleton } from './ui/ShimmerSkeleton';

interface LoadingShimmerProps {
  /** 'page' for full-page bootstrapping, 'section' inside a content area. */
  variant?: 'page' | 'section';
  rows?: number;
}

export function LoadingShimmer({ variant = 'section', rows = 3 }: LoadingShimmerProps) {
  if (variant === 'page') {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white p-8" aria-busy="true">
        <div className="w-full max-w-md space-y-4">
          <ShimmerSkeleton height={40} width="40%" />
          <ShimmerSkeleton height={16} />
          <ShimmerSkeleton height={16} width="80%" />
          <ShimmerSkeleton height={160} />
          <span className="sr-only">Loading your workspace…</span>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4" aria-busy="true">
      {Array.from({ length: rows }, (_, index) => (
        <ShimmerSkeleton key={index} height={index === 0 ? 120 : 64} />
      ))}
    </div>
  );
}
