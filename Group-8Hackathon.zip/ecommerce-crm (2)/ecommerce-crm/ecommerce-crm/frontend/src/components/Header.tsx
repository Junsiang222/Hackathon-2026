import { AnimatePresence, motion } from 'framer-motion';
import { Bell, ChevronDown, Menu } from 'lucide-react';
import { useEffect, useId, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useNotificationCount } from '@/hooks/useDashboard';
import { useDisplayName, useT } from '@/i18n';
import { ProfileMenu } from './ProfileMenu';
import { ThemeToggle } from './ThemeToggle';
import { useAuthStore } from '@/store/authStore';
import { initialsFrom } from '@/utils/format';

interface HeaderProps {
  title: string;
  onOpenMobileNav: () => void;
}

export function Header({ title, onOpenMobileNav }: HeaderProps) {
  const user = useAuthStore((state) => state.user);
  const { data: notificationCount = 0 } = useNotificationCount();
  const navigate = useNavigate();
  const t = useT();
  const displayName = useDisplayName(user?.email, user?.role === 'super_admin');
  // The bell jumps to where the flagged items live.
  const notificationsHref = user?.role === 'admin' ? '/dashboard/tickets' : '/dashboard/stores';

  const [menuOpen, setMenuOpen] = useState(false);
  const menuId = useId();
  const menuRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) setMenuOpen(false);
    };
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMenuOpen(false);
        triggerRef.current?.focus();
      }
    };
    document.addEventListener('pointerdown', onPointerDown);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('pointerdown', onPointerDown);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [menuOpen]);

  const badgeText = notificationCount > 99 ? '99+' : String(notificationCount);

  return (
    <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b border-gray-100 bg-white/95 px-4 backdrop-blur sm:px-8">
      <button
        type="button"
        onClick={onOpenMobileNav}
        aria-label={t('Open navigation')}
        className="-ml-2 flex h-11 w-11 items-center justify-center rounded-lg text-brand-black hover:bg-brand-mint lg:hidden"
      >
        <Menu className="h-5 w-5" aria-hidden="true" />
      </button>

      <h1 className="min-w-0 flex-1 truncate text-lg font-bold tracking-tight text-brand-black sm:text-xl">{title}</h1>

      <ThemeToggle />

      <button
        type="button"
        onClick={() => navigate(notificationsHref)}
        aria-label={notificationCount > 0 ? t('Notifications, {count} need attention', { count: notificationCount }) : t('Notifications')}
        className="relative flex h-11 w-11 items-center justify-center rounded-full text-brand-black hover:bg-brand-mint"
      >
        <Bell className="h-5 w-5" aria-hidden="true" />
        {notificationCount > 0 ? (
          <span
            aria-hidden="true"
            className="absolute right-1 top-1 flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-brand-black px-1 text-[11px] font-bold text-white ring-2 ring-white"
          >
            {badgeText}
          </span>
        ) : null}
      </button>

      <div className="relative" ref={menuRef}>
        <button
          ref={triggerRef}
          type="button"
          aria-haspopup="menu"
          aria-expanded={menuOpen}
          aria-controls={menuId}
          onClick={() => setMenuOpen((open) => !open)}
          className="flex min-h-[44px] items-center gap-2 rounded-full py-1 pl-1 pr-2 hover:bg-brand-mint"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-black text-xs font-bold text-white">
            {user ? initialsFrom(displayName) : ''}
          </span>
          <span className="sr-only">{t('Account menu')}</span>
          <ChevronDown className="hidden h-4 w-4 text-gray-500 sm:block" aria-hidden="true" />
        </button>

        <AnimatePresence>
          {menuOpen && user ? (
            <motion.div
              id={menuId}
              role="menu"
              aria-label={t('Account')}
              initial={{ opacity: 0, y: -4, scale: 0.98 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -4, scale: 0.98, transition: { duration: 0.1 } }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 mt-2 w-80 origin-top-right rounded-2xl border border-gray-100 bg-white pt-2 shadow-lg"
            >
              <ProfileMenu user={user} onNavigate={() => setMenuOpen(false)} />
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </header>
  );
}
