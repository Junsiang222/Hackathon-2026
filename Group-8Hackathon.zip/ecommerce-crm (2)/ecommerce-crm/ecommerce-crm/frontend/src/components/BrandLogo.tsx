/** The platform's name, shown in the sidebar, sign-in page and browser tab. */
export const PLATFORM_NAME = 'Clauday';

/** The one accent colour of the brand: the sun. */
export const BRAND_ORANGE = '#E8590C';

/**
 * Clauday mark: a half sun resting on the horizon, with a shorter line below.
 * Flat and single-accent: the sun is orange, the lines follow the text colour.
 */
export function BrandMark({ className = 'h-7 w-7' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true" focusable="false">
      <path d="M8.5 19a7.5 7.5 0 0 1 15 0Z" fill={BRAND_ORANGE} />
      <rect x="5" y="19.25" width="22" height="1.75" rx="0.875" fill="currentColor" />
      <rect x="11" y="23.5" width="10" height="1.75" rx="0.875" fill="currentColor" opacity="0.45" />
    </svg>
  );
}

/** Mark + wordmark. `className` sets the text colour (the lines follow it). */
export function BrandLogo({ className = 'text-brand-black', size = 'md' }: { className?: string; size?: 'md' | 'lg' }) {
  return (
    <span className={`inline-flex items-center gap-2 ${className}`}>
      <BrandMark className={size === 'lg' ? 'h-9 w-9' : 'h-8 w-8'} />
      <span className={`brand-wordmark font-bold tracking-tight ${size === 'lg' ? 'text-2xl' : 'text-xl'}`}>{PLATFORM_NAME}</span>
    </span>
  );
}
