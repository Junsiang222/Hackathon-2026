import { Bot, Send, Sparkles, Trash2, X } from 'lucide-react';
import { useEffect, useRef, useState, type FormEvent } from 'react';
import { useAnalyticsAssistant } from '@/hooks/usePlatformAnalytics';
import { useT } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import type { AssistantMessage, PeriodRange } from '@/types/platformAnalytics.types';

const SUGGESTIONS = [
  'Summarise how each store is doing',
  'What needs my attention right now?',
  'Which store is growing fastest, and why?',
  'Which stores are still waiting for a website?',
];

/**
 * Chat with the dashboard AI. It only answers about the super admin dashboard (Overview, Stores,
 * Websites, Analytics) from non-financial data, and politely refuses anything else.
 */
function AnalyticsAssistant({ range, open, onClose }: { range: PeriodRange; open: boolean; onClose: () => void }) {
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [draft, setDraft] = useState('');
  const ask = useAnalyticsAssistant();
  const t = useT();
  const listRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (open) requestAnimationFrame(() => inputRef.current?.focus());
  }, [open]);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, ask.isPending]);

  const send = (question: string) => {
    const text = question.trim();
    if (!text || ask.isPending) return;
    const history = messages;
    setMessages([...history, { role: 'user', content: text }]);
    setDraft('');
    ask.mutate(
      { question: text, history, ...range },
      {
        onSuccess: (answer) => setMessages((current) => [...current, { role: 'assistant', content: answer }]),
        onError: (error) =>
          setMessages((current) => [...current, { role: 'assistant', content: `⚠️ ${getApiErrorMessage(error)}` }]),
      },
    );
  };

  const onSubmit = (event: FormEvent) => {
    event.preventDefault();
    send(draft);
  };

  return (
    <section
      role="dialog"
      aria-modal="true"
      aria-labelledby="assistant-heading"
      className="flex h-[min(720px,85vh)] w-full max-w-2xl flex-col rounded-2xl bg-white shadow-2xl"
      onClick={(event) => event.stopPropagation()}
    >
      <header className="flex items-center gap-2 border-b border-gray-100 px-4 py-3">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-black">
          <Bot className="h-4 w-4 text-brand-green" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <h2 id="assistant-heading" className="text-sm font-semibold text-brand-black">
            {t('AI assistant')}
          </h2>
          <p className="text-xs text-gray-500">{t('Only answers about Overview, Stores, Websites and Analytics. No store finances.')}</p>
        </div>
        {messages.length > 0 ? (
          <button
            type="button"
            onClick={() => setMessages([])}
            disabled={ask.isPending}
            aria-label={t('Clear conversation')}
            title={t('Clear conversation')}
            className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"
          >
            <Trash2 className="h-4 w-4" aria-hidden="true" />
          </button>
        ) : null}
        <button
          type="button"
          onClick={onClose}
          aria-label={t('Close AI assistant')}
          title={t('Close')}
          className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"
        >
          <X className="h-5 w-5" aria-hidden="true" />
        </button>
      </header>

      <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4" aria-live="polite">
        {messages.length === 0 ? (
          <div className="space-y-2">
            <p className="text-sm text-gray-600">{t('Ask anything about your stores, or start with:')}</p>
            {SUGGESTIONS.map((suggestion) => (
              <button
                key={suggestion}
                type="button"
                onClick={() => send(t(suggestion))}
                className="flex w-full items-start gap-2 rounded-xl border border-gray-200 px-3 py-2 text-left text-sm text-brand-black hover:border-brand-green hover:bg-brand-mint"
              >
                <Sparkles className="mt-0.5 h-4 w-4 shrink-0 text-brand-green-dark" aria-hidden="true" />
                {t(suggestion)}
              </button>
            ))}
          </div>
        ) : (
          messages.map((message, index) => (
            <div key={index} className={message.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
              <p
                className={`max-w-[90%] whitespace-pre-wrap rounded-2xl px-3.5 py-2.5 text-sm ${
                  message.role === 'user' ? 'bg-brand-black text-white' : 'bg-gray-100 text-brand-black'
                }`}
              >
                {message.content}
              </p>
            </div>
          ))
        )}
        {ask.isPending ? (
          <p className="inline-flex items-center gap-2 rounded-2xl bg-gray-100 px-3.5 py-2.5 text-sm text-gray-500">
            <span className="h-2 w-2 animate-pulse rounded-full bg-brand-green" aria-hidden="true" />
            {t('Analysing your stores…')}
          </p>
        ) : null}
      </div>

      <form onSubmit={onSubmit} className="flex items-end gap-2 border-t border-gray-100 p-3">
        <label htmlFor="assistant-question" className="sr-only">
          {t('Ask the AI assistant')}
        </label>
        <textarea
          ref={inputRef}
          id="assistant-question"
          rows={2}
          maxLength={1000}
          value={draft}
          onChange={(event) => setDraft(event.target.value)}
          onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault();
              send(draft);
            }
          }}
          placeholder={t('e.g. Which store had the most orders last month?')}
          className="block flex-1 resize-none rounded-xl border border-gray-300 px-3 py-2 text-sm focus:border-brand-black focus:outline-none focus:ring-4 focus:ring-gray-100"
        />
        <button
          type="submit"
          disabled={!draft.trim() || ask.isPending}
          aria-label={t('Send question')}
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-black text-white disabled:opacity-40"
        >
          <Send className="h-4 w-4 text-brand-green" aria-hidden="true" />
        </button>
      </form>
    </section>
  );
}

/**
 * Floating "AI assistant" button (bottom right) that opens the chat in the middle of the screen.
 * The chat stays mounted while closed, so the conversation is still there when it's reopened.
 */
export function AnalyticsAssistantLauncher({ range }: { range: PeriodRange }) {
  const [open, setOpen] = useState(false);
  const t = useT();
  const buttonRef = useRef<HTMLButtonElement>(null);

  const close = () => {
    setOpen(false);
    buttonRef.current?.focus();
  };

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close();
    };
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = overflow;
    };
  }, [open]);

  return (
    <>
      <button
        ref={buttonRef}
        type="button"
        onClick={() => setOpen(true)}
        aria-haspopup="dialog"
        aria-expanded={open}
        className={`fixed bottom-6 right-6 z-40 inline-flex min-h-[52px] items-center gap-2 rounded-full bg-brand-black px-5 text-sm font-semibold text-white shadow-lg transition hover:bg-gray-800 ${
          open ? 'pointer-events-none opacity-0' : ''
        }`}
      >
        <Bot className="h-5 w-5 text-brand-green" aria-hidden="true" />
        {t('AI assistant')}
      </button>

      <div
        className={`fixed inset-0 z-50 items-center justify-center bg-black/40 p-4 backdrop-blur-[2px] ${open ? 'flex' : 'hidden'}`}
        onClick={close}
      >
        <AnalyticsAssistant range={range} open={open} onClose={close} />
      </div>
    </>
  );
}
