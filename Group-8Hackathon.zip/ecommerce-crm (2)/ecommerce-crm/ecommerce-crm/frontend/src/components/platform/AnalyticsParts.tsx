import { AlertTriangle, ArrowDownRight, ArrowUpRight, Download, Info, Loader2, Minus, Package, type LucideIcon } from 'lucide-react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { PERIOD_PRESETS, type PeriodPreset } from '@/hooks/usePlatformAnalytics';
import type { Insight, PeriodRange, ProductPerformance, StoreDetail } from '@/types/platformAnalytics.types';
import { useT } from '@/i18n';
import { formatInteger } from '@/utils/format';
import { downloadStoreReportPdf } from '@/utils/storeReportPdf';

/** Distinct colours (plus dash patterns in charts) so compared stores stay apart. */
export const STORE_PALETTE = ['#16A34A', '#2563EB', '#D97706', '#9333EA', '#DB2777', '#0891B2'] as const;
export const STORE_DASHES = [undefined, '6 4', '2 4', '8 3 2 3', undefined, '6 4'] as const;

/** % change, or null when there's nothing to compare with. */
export function percentChange(value: number, before: number): number | null {
  if (before === 0) return value === 0 ? 0 : null;
  return ((value - before) / before) * 100;
}

export const formatPercent = (ratio: number | null, digits = 1) =>
  ratio === null ? '—' : `${(ratio * 100).toFixed(digits)}%`;

export function ChangeBadge({ value, inverse = false, label: rawLabel }: { value: number | null; inverse?: boolean; label?: string }) {
  const t = useT();
  const label = rawLabel ? t(rawLabel) : undefined;
  if (value === null) {
    return <span className="text-xs font-medium text-gray-400">{label ? t('new {label}', { label }) : t('new')}</span>;
  }
  const rounded = Math.round(value);
  if (rounded === 0) {
    return (
      <span className="inline-flex items-center gap-0.5 text-xs font-semibold text-gray-500">
        <Minus className="h-3 w-3" aria-hidden="true" />
        0%{label ? ` ${label}` : ''}
      </span>
    );
  }
  const up = rounded > 0;
  const good = inverse ? !up : up;
  const Icon = up ? ArrowUpRight : ArrowDownRight;
  return (
    <span className={`inline-flex items-center gap-0.5 text-xs font-semibold ${good ? 'text-green-700' : 'text-red-600'}`}>
      <Icon className="h-3.5 w-3.5" aria-hidden="true" />
      {up ? '+' : ''}
      {rounded}%{label ? ` ${label}` : ''}
    </span>
  );
}

export function KpiCard({
  label,
  value,
  change,
  hint,
  inverse,
}: {
  label: string;
  value: string;
  change?: number | null;
  hint?: string;
  inverse?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{label}</p>
      <p className="mt-1.5 text-2xl font-bold tabular-nums tracking-tight text-brand-black">{value}</p>
      <div className="mt-1 flex min-h-[18px] items-center gap-2">
        {change !== undefined ? <ChangeBadge value={change} inverse={inverse} label="vs previous" /> : null}
        {hint ? <span className="text-xs text-gray-500">{hint}</span> : null}
      </div>
    </div>
  );
}

export function PeriodPicker({
  preset,
  range,
  onPreset,
  onCustom,
}: {
  preset: PeriodPreset;
  range: PeriodRange;
  onPreset: (preset: PeriodPreset) => void;
  onCustom: (range: PeriodRange) => void;
}) {
  const [draft, setDraft] = useState(range);
  const t = useT();
  useEffect(() => setDraft(range), [range]);
  const valid = draft.from && draft.to && draft.from <= draft.to;

  return (
    <div className="flex flex-wrap items-center gap-2">
      <div role="group" aria-label={t('Period')} className="flex flex-wrap gap-1 rounded-xl bg-gray-100 p-1">
        {PERIOD_PRESETS.map((option) => (
          <button
            key={option.value}
            type="button"
            aria-pressed={preset === option.value}
            onClick={() => onPreset(option.value)}
            className={`min-h-[36px] rounded-lg px-3 text-sm font-medium ${
              preset === option.value ? 'bg-white text-brand-black shadow-sm' : 'text-gray-600 hover:text-brand-black'
            }`}
          >
            {t(option.label)}
          </button>
        ))}
      </div>
      {preset === 'custom' ? (
        <form
          className="flex flex-wrap items-center gap-2"
          onSubmit={(event) => {
            event.preventDefault();
            if (valid) onCustom(draft);
          }}
        >
          <label className="sr-only" htmlFor="period-from">
            {t('From')}
          </label>
          <input
            id="period-from"
            type="date"
            value={draft.from}
            max={draft.to}
            onChange={(event) => setDraft((current) => ({ ...current, from: event.target.value }))}
            className="min-h-[36px] rounded-lg border border-gray-300 px-2 text-sm"
          />
          <span className="text-sm text-gray-500">{t('to')}</span>
          <label className="sr-only" htmlFor="period-to">
            {t('To')}
          </label>
          <input
            id="period-to"
            type="date"
            value={draft.to}
            min={draft.from}
            onChange={(event) => setDraft((current) => ({ ...current, to: event.target.value }))}
            className="min-h-[36px] rounded-lg border border-gray-300 px-2 text-sm"
          />
          <button
            type="submit"
            disabled={!valid}
            className="min-h-[36px] rounded-lg bg-brand-black px-3 text-sm font-semibold text-white disabled:opacity-50"
          >
            {t('Apply')}
          </button>
        </form>
      ) : (
        <span className="text-xs text-gray-500">
          {range.from === range.to ? range.from : `${range.from} → ${range.to}`} (UTC)
        </span>
      )}
    </div>
  );
}

const SEVERITY: Record<Insight['severity'], { icon: LucideIcon; ring: string; text: string; label: string }> = {
  high: { icon: AlertTriangle, ring: 'border-red-200 bg-red-50', text: 'text-red-700', label: 'Needs attention' },
  medium: { icon: AlertTriangle, ring: 'border-amber-200 bg-amber-50', text: 'text-amber-800', label: 'Watch' },
  info: { icon: Info, ring: 'border-blue-200 bg-blue-50', text: 'text-blue-800', label: 'Good to know' },
};

export function InsightList({ insights }: { insights: Insight[] }) {
  const t = useT();
  if (insights.length === 0) {
    return (
      <p className="rounded-2xl border border-gray-100 bg-white p-4 text-sm text-gray-600 shadow-sm">
        {t('No unusual changes detected in this period.')}
      </p>
    );
  }
  return (
    <ul className="grid gap-3 md:grid-cols-2">
      {insights.map((insight, index) => {
        const style = SEVERITY[insight.severity];
        const Icon = style.icon;
        return (
          <li key={`${insight.tenantId}-${insight.kind}-${index}`} className={`rounded-2xl border p-4 ${style.ring}`}>
            <p className={`flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide ${style.text}`}>
              <Icon className="h-3.5 w-3.5" aria-hidden="true" />
              {t(style.label)}
            </p>
            <p className="mt-1 text-sm font-medium text-brand-black">{insight.message}</p>
            <p className="mt-1 text-sm text-gray-700">{insight.recommendation}</p>
          </li>
        );
      })}
    </ul>
  );
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** Orders by weekday × hour (UTC). Darker = more orders; exact counts on hover and for screen readers. */
export function PeakHeatmap({ grid }: { grid: number[][] }) {
  const t = useT();
  const day = (index: number) => t(DAYS[index]!);
  const max = Math.max(1, ...grid.flat());
  let best = { day: 0, hour: 0, orders: 0 };
  grid.forEach((row, day) =>
    row.forEach((orders, hour) => {
      if (orders > best.orders) best = { day, hour, orders };
    }),
  );
  const dayTotals = grid.map((row) => row.reduce((a, b) => a + b, 0));
  const busiestDay = dayTotals.indexOf(Math.max(...dayTotals));

  return (
    <div>
      <p className="mb-3 text-sm text-gray-700">
        {best.orders > 0
          ? t('Busiest day: {day}. Peak hour: {peakDay} {hour}:00 ({count} orders).', {
              day: day(busiestDay),
              peakDay: day(best.day),
              hour: String(best.hour).padStart(2, '0'),
              count: best.orders,
            })
          : t('No orders in this period.')}
      </p>
      <div className="overflow-x-auto">
        <table className="border-separate border-spacing-0.5 text-[10px] text-gray-500">
          <caption className="sr-only">{t('Orders by day of week and hour, UTC')}</caption>
          <thead>
            <tr>
              <th scope="col" className="w-8" />
              {Array.from({ length: 24 }, (_, hour) => (
                <th key={hour} scope="col" className="w-5 font-normal">
                  {hour % 3 === 0 ? hour : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {grid.map((row, dayIndex) => (
              <tr key={dayIndex}>
                <th scope="row" className="pr-1 text-right font-medium">
                  {day(dayIndex)}
                </th>
                {row.map((orders, hour) => (
                  <td
                    key={hour}
                    title={t('{day} {hour}:00 — {count} orders', { day: day(dayIndex), hour: String(hour).padStart(2, '0'), count: orders })}
                    className="h-5 w-5 rounded-sm"
                    style={{ backgroundColor: orders === 0 ? 'var(--heat-empty, #F3F4F6)' : `rgba(22, 163, 74, ${0.15 + 0.85 * (orders / max)})` }}
                  >
                    <span className="sr-only">{orders}</span>
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ProductList({ title, products, empty }: { title: string; products: ProductPerformance[]; empty: string }) {
  const t = useT();
  const max = Math.max(1, ...products.map((product) => product.unitsSold));
  return (
    <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
      <h3 className="mb-3 text-sm font-semibold text-brand-black">{title}</h3>
      {products.length === 0 ? (
        <p className="text-sm text-gray-500">{empty}</p>
      ) : (
        <ol className="space-y-3">
          {products.map((product) => (
            <li key={product.productId} className="flex items-center gap-3">
              {product.imageUrl ? (
                <img src={product.imageUrl} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" loading="lazy" />
              ) : (
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100">
                  <Package className="h-4 w-4 text-gray-400" aria-hidden="true" />
                </span>
              )}
              <div className="min-w-0 flex-1">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="truncate text-sm font-medium text-brand-black">{product.name}</p>
                  <p className="shrink-0 text-sm font-semibold tabular-nums text-brand-black">
                    {formatInteger(product.unitsSold)} <span className="font-normal text-gray-500">{t('units')}</span>
                  </p>
                </div>
                <div className="mt-1 h-1.5 rounded-full bg-gray-100">
                  <div className="h-1.5 rounded-full bg-brand-green" style={{ width: `${(product.unitsSold / max) * 100}%` }} />
                </div>
                <p className="mt-0.5 text-xs text-gray-500">
                  {product.category ?? t('Uncategorised')}
                  {product.inStock !== null
                    ? ` · ${product.inStock === 0 ? t('out of stock') : t('{count} in stock', { count: product.inStock })}`
                    : ''}
                </p>
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

/** Saves the chosen store's analytics for the current period as a PDF. Disabled until its data has loaded. */
export function DownloadPdfButton({
  detail,
  insights,
  range,
}: {
  detail: StoreDetail | undefined;
  insights: Insight[];
  range: PeriodRange;
}) {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const onClick = async () => {
    if (!detail) return;
    setBusy(true);
    try {
      await downloadStoreReportPdf(detail, insights, range);
    } catch {
      toast.error(t('Could not create the PDF. Please try again.'));
    } finally {
      setBusy(false);
    }
  };
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={!detail || busy}
      className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl bg-brand-green px-3 text-sm font-semibold text-white hover:bg-brand-green-dark disabled:cursor-not-allowed disabled:opacity-60"
    >
      {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : <Download className="h-4 w-4" aria-hidden="true" />}
      {t('Download PDF')}
    </button>
  );
}
