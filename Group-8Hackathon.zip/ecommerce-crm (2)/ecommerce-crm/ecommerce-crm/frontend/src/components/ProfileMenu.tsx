import { Check, ChevronRight, LogOut, Moon, Pencil, Settings, Sun, X } from 'lucide-react';
import { useState, type FormEvent } from 'react';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { BRAND_ORANGE } from '@/components/BrandLogo';
import { useLogout } from '@/hooks/useAuth';
import { useSavePreferences } from '@/hooks/useSettings';
import { LANGUAGES, useDisplayName, usePreferencesStore, useT, type Language } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import type { Role, SessionUser } from '@/types/api.types';
import { initialsFrom } from '@/utils/format';

const ROLE_LABEL: Record<Role, string> = {
  super_admin: 'Super Admin',
  admin: 'Admin',
  staff: 'Staff',
};

/** Short labels for the language switch. */
const LANGUAGE_SHORT: Record<Language, string> = { en: 'EN', ms: 'BM', zh: '中文' };

function Segmented<T extends string>({
  label,
  value,
  options,
  onChange,
  disabled,
}: {
  label: string;
  value: T;
  options: { value: T; label: string; icon?: typeof Sun; title?: string }[];
  onChange: (value: T) => void;
  disabled?: boolean;
}) {
  return (
    <div role="radiogroup" aria-label={label} className="flex rounded-lg bg-gray-100 p-0.5">
      {options.map((option) => {
        const selected = option.value === value;
        const Icon = option.icon;
        return (
          <button
            key={option.value}
            type="button"
            role="radio"
            aria-checked={selected}
            title={option.title}
            disabled={disabled}
            onClick={() => !selected && onChange(option.value)}
            className={`flex min-h-[30px] flex-1 items-center justify-center gap-1 rounded-md px-2 text-xs font-semibold transition-colors disabled:opacity-60 ${
              selected ? 'bg-white text-brand-black shadow-sm' : 'text-gray-500 hover:text-brand-black'
            }`}
          >
            {Icon ? <Icon className="h-3.5 w-3.5" aria-hidden="true" /> : null}
            {option.label}
          </button>
        );
      })}
    </div>
  );
}

/** The name in the profile card, with a pencil to rename it in place (super admin). */
function EditableName({ name, editable }: { name: string; editable: boolean }) {
  const t = useT();
  const save = useSavePreferences();
  const [draft, setDraft] = useState<string | null>(null);

  if (draft === null) {
    return (
      <div className="flex min-w-0 items-center gap-1">
        <p className="truncate text-sm font-semibold text-brand-black">{name}</p>
        {editable ? (
          <button
            type="button"
            onClick={() => setDraft(name)}
            aria-label={t('Edit name')}
            title={t('Edit name')}
            className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-gray-400 hover:bg-gray-100 hover:text-brand-black"
          >
            <Pencil className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        ) : null}
      </div>
    );
  }

  const submit = (event?: FormEvent) => {
    event?.preventDefault();
    const next = draft.trim().replace(/\s+/g, ' ');
    if (next === name) {
      setDraft(null);
      return;
    }
    save.mutate(
      { displayName: next || null },
      {
        onSuccess: () => {
          setDraft(null);
          toast.success(next ? t('Name updated') : t('Name reset to your email'));
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    );
  };

  return (
    <form onSubmit={submit} className="flex min-w-0 items-center gap-1">
      <label htmlFor="profile-display-name" className="sr-only">
        {t('Display name')}
      </label>
      <input
        id="profile-display-name"
        autoFocus
        maxLength={60}
        value={draft}
        disabled={save.isPending}
        onChange={(event) => setDraft(event.target.value)}
        onKeyDown={(event) => {
          // Esc cancels the edit only; it must not also close the menu.
          if (event.key === 'Escape') {
            event.stopPropagation();
            setDraft(null);
          }
        }}
        placeholder={t('Your name')}
        className="min-w-0 flex-1 rounded-md border border-gray-300 bg-white px-2 py-1 text-sm font-semibold text-brand-black focus:border-brand-black focus:outline-none"
      />
      <button
        type="submit"
        disabled={save.isPending}
        aria-label={t('Save name')}
        title={t('Save name')}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-brand-green-dark hover:bg-gray-100 disabled:opacity-50"
      >
        <Check className="h-4 w-4" aria-hidden="true" />
      </button>
      <button
        type="button"
        onClick={() => setDraft(null)}
        disabled={save.isPending}
        aria-label={t('Cancel')}
        title={t('Cancel')}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md text-gray-400 hover:bg-gray-100 hover:text-brand-black"
      >
        <X className="h-4 w-4" aria-hidden="true" />
      </button>
    </form>
  );
}

/** Contents of the account menu under the avatar: who you are, quick switches, shortcuts, log out. */
export function ProfileMenu({ user, onNavigate }: { user: SessionUser; onNavigate: () => void }) {
  const t = useT();
  const navigate = useNavigate();
  const logout = useLogout();
  const theme = usePreferencesStore((state) => state.theme);
  const setTheme = usePreferencesStore((state) => state.setTheme);
  const language = usePreferencesStore((state) => state.language);
  const savePreferences = useSavePreferences();
  const isSuperAdmin = user.role === 'super_admin';
  const displayName = useDisplayName(user.email, isSuperAdmin);

  const changeLanguage = (next: Language) =>
    savePreferences.mutate({ language: next }, { onError: (error) => toast.error(getApiErrorMessage(error)) });

  return (
    <>
      {/* Who you are */}
      <div className="flex items-center gap-3 px-3 pb-3 pt-2">
        <span className="relative shrink-0">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-brand-black text-sm font-bold text-white">
            {initialsFrom(displayName)}
          </span>
          {/* A tiny sun from the logo */}
          <svg viewBox="0 0 16 16" className="absolute -bottom-0.5 -right-0.5 h-4 w-4 rounded-full bg-white p-0.5 ring-1 ring-gray-200" aria-hidden="true">
            <path d="M3 10.5a5 5 0 0 1 10 0Z" fill={BRAND_ORANGE} />
            <rect x="1.5" y="10.75" width="13" height="1.5" rx="0.75" fill="currentColor" />
          </svg>
        </span>
        <div className="min-w-0 flex-1">
          <EditableName name={displayName} editable={isSuperAdmin} />
          <p className="truncate text-xs text-gray-500">{user.email}</p>
        </div>
      </div>
      <p className="mx-3 mb-3 flex items-center gap-1.5 truncate text-[11px] font-semibold uppercase tracking-wider text-gray-500">
        <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ backgroundColor: BRAND_ORANGE }} aria-hidden="true" />
        {t(ROLE_LABEL[user.role])}
        {user.businessName ? <span className="truncate font-medium normal-case tracking-normal">· {user.businessName}</span> : null}
      </p>

      {/* Quick switches */}
      <div className="space-y-2.5 border-t border-gray-100 px-3 py-3">
        <div className="flex items-center justify-between gap-3">
          <span className="text-[11px] font-semibold uppercase tracking-wider text-gray-500">{t('Appearance')}</span>
          <div className="w-40">
            <Segmented
              label={t('Appearance')}
              value={theme}
              onChange={setTheme}
              options={[
                { value: 'light', label: t('Light'), icon: Sun },
                { value: 'dark', label: t('Dark'), icon: Moon },
              ]}
            />
          </div>
        </div>
        {isSuperAdmin ? (
          <div className="flex items-center justify-between gap-3">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-gray-500">{t('Language')}</span>
            <div className="w-40">
              <Segmented
                label={t('Language')}
                value={language}
                onChange={changeLanguage}
                disabled={savePreferences.isPending}
                options={LANGUAGES.map((option) => ({
                  value: option.value,
                  label: LANGUAGE_SHORT[option.value],
                  title: option.label,
                }))}
              />
            </div>
          </div>
        ) : null}
      </div>

      {/* Shortcuts */}
      {isSuperAdmin ? (
        <div className="border-t border-gray-100 p-1">
          <button
            type="button"
            role="menuitem"
            onClick={() => {
              onNavigate();
              navigate('/dashboard/settings');
            }}
            className="flex min-h-[44px] w-full items-center gap-2 rounded-lg px-3 text-sm font-medium text-brand-black hover:bg-gray-50"
          >
            <Settings className="h-4 w-4 text-gray-500" aria-hidden="true" />
            {t('Settings')}
            <ChevronRight className="ml-auto h-4 w-4 text-gray-400" aria-hidden="true" />
          </button>
        </div>
      ) : null}

      <div className="border-t border-gray-100 p-1">
        <button
          type="button"
          role="menuitem"
          onClick={() => logout.mutate()}
          disabled={logout.isPending}
          className="flex min-h-[44px] w-full items-center gap-2 rounded-lg px-3 text-sm font-medium text-brand-black hover:bg-red-50 hover:text-red-600 disabled:opacity-60"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
          {t('Log out')}
        </button>
      </div>
    </>
  );
}
