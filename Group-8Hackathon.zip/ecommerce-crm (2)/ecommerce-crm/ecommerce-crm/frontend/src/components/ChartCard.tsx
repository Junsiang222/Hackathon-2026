import type { ReactNode } from 'react';

interface ChartCardProps {
  title: string;
  /** Optional element rendered on the right of the title row (badge, menu…). */
  aside?: ReactNode;
  children: ReactNode;
  className?: string;
}

/** Shared white card shell for every chart and widget preview. */
export function ChartCard({ title, aside, children, className = '' }: ChartCardProps) {
  return (
    <section className={`rounded-2xl border border-gray-100 bg-white p-6 shadow-sm ${className}`}>
      <header className="mb-4 flex items-start justify-between gap-3">
        <h3 className="text-sm font-semibold text-brand-black">{title}</h3>
        {aside}
      </header>
      {children}
    </section>
  );
}
