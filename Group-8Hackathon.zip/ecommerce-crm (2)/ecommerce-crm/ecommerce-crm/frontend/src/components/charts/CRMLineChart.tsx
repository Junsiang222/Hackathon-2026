import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { WidgetConfig, WidgetDatum } from '@/types/dashboard.types';
import { formatInteger, formatMetric, formatShortDate, humanizeKey } from '@/utils/format';
import { ChartTooltip } from './ChartTooltip';
import { AXIS_TICK, CHART_HEIGHT, GRID_STROKE, LINE_DASHES, LINE_PALETTE, pick } from './chartTheme';
import { WidgetFrame } from './WidgetFrame';

interface CRMLineChartProps {
  config: WidgetConfig;
}

export function describeLatest(title: string, kind: string, data: WidgetDatum[], dataKeys: string[]): string {
  const latest = data[data.length - 1] ?? {};
  const parts = dataKeys.map((key) => `${humanizeKey(key)} ${formatMetric(key, latest[key])}`);
  return `${kind}: ${title}. ${data.length} data points. Latest values — ${parts.join(', ')}.`;
}

export function CRMLineChart({ config }: CRMLineChartProps) {
  return (
    <WidgetFrame config={config}>
      {(data, dataKeys) => (
        <div role="img" aria-label={describeLatest(config.title, 'Line chart', data, dataKeys)}>
          <ResponsiveContainer width="100%" height={CHART_HEIGHT}>
            <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID_STROKE} />
              <XAxis
                dataKey="date"
                tick={AXIS_TICK}
                tickFormatter={formatShortDate}
                tickLine={false}
                axisLine={{ stroke: GRID_STROKE }}
                minTickGap={24}
              />
              <YAxis
                domain={['auto', 'auto']}
                tick={AXIS_TICK}
                tickFormatter={formatInteger}
                tickLine={false}
                axisLine={false}
                width={56}
              />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: '#15803D', strokeWidth: 1, strokeDasharray: '3 3' }} />
              {dataKeys.length > 1 ? (
                <Legend iconType="plainline" wrapperStyle={{ fontSize: 12 }} formatter={(value) => humanizeKey(String(value))} />
              ) : null}
              {dataKeys.map((key, index) => (
                <Line
                  key={key}
                  type="monotone"
                  dataKey={key}
                  name={key}
                  stroke={pick(LINE_PALETTE, index)}
                  strokeDasharray={pick(LINE_DASHES, index)}
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                  isAnimationActive
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </WidgetFrame>
  );
}
