import { Inbox } from 'lucide-react';
import type { ReactNode } from 'react';
import { ChartCard } from '@/components/ChartCard';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { ShimmerSkeleton } from '@/components/ui/ShimmerSkeleton';
import { useWidgetData } from '@/hooks/useDashboard';
import type { WidgetConfig, WidgetDatum } from '@/types/dashboard.types';
import { sanitizeDataKeys } from '@/utils/sanitizeWidgetData';
import { CHART_HEIGHT } from './chartTheme';

interface WidgetFrameProps {
  config: WidgetConfig;
  height?: number;
  /** Receives already-sanitized rows and the non-monetary data keys. */
  children: (data: WidgetDatum[], dataKeys: string[]) => ReactNode;
}

/**
 * Card wrapper + fetch lifecycle shared by every chart type:
 * loading → shimmer, error → retryable placeholder, empty → empty state.
 */
export function WidgetFrame({ config, height = CHART_HEIGHT, children }: WidgetFrameProps) {
  const query = useWidgetData(config);
  const dataKeys = sanitizeDataKeys(config.dataKeys);

  let body: ReactNode;
  if (query.isPending) {
    body = <ShimmerSkeleton height={height} />;
  } else if (query.isError) {
    body = (
      <ErrorPlaceholder
        height={height}
        message={query.error.message || 'Could not load this chart.'}
        onRetry={() => query.refetch()}
        isRetrying={query.isFetching}
      />
    );
  } else if (query.data.length === 0 || dataKeys.length === 0) {
    body = (
      <EmptyState
        icon={Inbox}
        minHeight={height}
        title="No data yet"
        description="This chart fills in as activity is recorded."
      />
    );
  } else {
    body = children(query.data, dataKeys);
  }

  return (
    <ChartCard title={config.title} className="h-full">
      {body}
    </ChartCard>
  );
}
