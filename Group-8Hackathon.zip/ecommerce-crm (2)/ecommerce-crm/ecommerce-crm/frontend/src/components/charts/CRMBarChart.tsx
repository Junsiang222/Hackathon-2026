import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import type { WidgetConfig } from '@/types/dashboard.types';
import { formatInteger, formatShortDate, humanizeKey } from '@/utils/format';
import { ChartTooltip } from './ChartTooltip';
import { AXIS_TICK, BAR_PALETTE, CHART_HEIGHT, GRID_STROKE, pick } from './chartTheme';
import { describeLatest } from './CRMLineChart';
import { WidgetFrame } from './WidgetFrame';

interface CRMBarChartProps {
  config: WidgetConfig;
}

export function CRMBarChart({ config }: CRMBarChartProps) {
  return (
    <WidgetFrame config={config}>
      {(data, dataKeys) => (
        <div role="img" aria-label={describeLatest(config.title, 'Bar chart', data, dataKeys)}>
          <ResponsiveContainer width="100%" height={CHART_HEIGHT}>
            <BarChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
              <CartesianGrid vertical={false} stroke={GRID_STROKE} />
              <XAxis
                dataKey="date"
                tick={AXIS_TICK}
                tickFormatter={formatShortDate}
                tickLine={false}
                axisLine={{ stroke: GRID_STROKE }}
                minTickGap={24}
              />
              <YAxis
                // Bars encode magnitude by length, so the axis must start at zero.
                domain={[0, 'auto']}
                tick={AXIS_TICK}
                tickFormatter={formatInteger}
                tickLine={false}
                axisLine={false}
                width={56}
              />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: '#F0FDF4' }} />
              <Legend
                verticalAlign="bottom"
                iconType="circle"
                wrapperStyle={{ fontSize: 12, paddingTop: 8 }}
                formatter={(value) => <span className="text-gray-700">{humanizeKey(String(value))}</span>}
              />
              {dataKeys.map((key, index) => {
                const fill = pick(BAR_PALETTE, index);
                return (
                  <Bar
                    key={key}
                    dataKey={key}
                    name={key}
                    fill={fill}
                    // Mint is near-white; an outline keeps those bars visible on the white card.
                    stroke={fill === '#DCFCE7' ? '#15803D' : undefined}
                    strokeWidth={fill === '#DCFCE7' ? 1 : 0}
                    radius={[4, 4, 0, 0]}
                    maxBarSize={40}
                  />
                );
              })}
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </WidgetFrame>
  );
}
