import type { TooltipProps } from 'recharts';
import type { NameType, ValueType } from 'recharts/types/component/DefaultTooltipContent';
import { formatMetric, formatShortDate, humanizeKey } from '@/utils/format';

/** White card with a brand-green border. Values are plain numbers — never currency. */
export function ChartTooltip({ active, payload, label }: TooltipProps<ValueType, NameType>) {
  if (!active || !payload || payload.length === 0) return null;

  return (
    <div className="rounded-xl border border-brand-green bg-white px-3 py-2 shadow-md">
      <p className="mb-1 text-xs font-semibold text-brand-black">{formatShortDate(label)}</p>
      <ul className="space-y-0.5">
        {payload.map((entry) => {
          const key = String(entry.dataKey ?? entry.name ?? '');
          return (
            <li key={key} className="flex items-center gap-2 text-xs text-gray-700">
              <span
                aria-hidden="true"
                className="h-2 w-2 rounded-full ring-1 ring-brand-green-dark/30"
                style={{ backgroundColor: entry.color }}
              />
              {humanizeKey(key)}
              <span className="ml-auto pl-3 font-semibold tabular-nums text-brand-black">{formatMetric(key, entry.value)}</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
