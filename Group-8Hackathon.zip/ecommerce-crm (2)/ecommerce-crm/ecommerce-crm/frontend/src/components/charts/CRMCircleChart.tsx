import { motion, useReducedMotion } from 'framer-motion';
import { PolarAngleAxis, RadialBar, RadialBarChart, ResponsiveContainer } from 'recharts';
import type { WidgetConfig, WidgetDatum } from '@/types/dashboard.types';
import { formatMetric, humanizeKey, isPercentKey, toNumber } from '@/utils/format';
import { pick, RING_PALETTE } from './chartTheme';
import { WidgetFrame } from './WidgetFrame';

interface CRMCircleChartProps {
  config: WidgetConfig;
}

interface Ring {
  key: string;
  label: string;
  value: number;
  /** 0–100: how full the ring is drawn. */
  progress: number;
  fill: string;
}

const WHEEL_SIZE = 300;

/**
 * One ring per data key, using the most recent row. Percent keys (rate/pct)
 * are drawn against 100; count keys against the largest count shown, so the
 * biggest count reads as a full ring.
 */
export function buildRings(data: WidgetDatum[], dataKeys: string[]): Ring[] {
  const latest = data[data.length - 1] ?? {};
  const values = dataKeys.map((key) => ({ key, value: toNumber(latest[key]) }));
  const maxCount = Math.max(1, ...values.filter(({ key }) => !isPercentKey(key)).map(({ value }) => value));

  return values.map(({ key, value }, index) => ({
    key,
    label: humanizeKey(key),
    value,
    progress: isPercentKey(key) ? Math.min(Math.max(value, 0), 100) : (Math.max(value, 0) / maxCount) * 100,
    fill: pick(RING_PALETTE, index),
  }));
}

function CircleBody({ data, dataKeys, title }: { data: WidgetDatum[]; dataKeys: string[]; title: string }) {
  const reduceMotion = useReducedMotion();
  const rings = buildRings(data, dataKeys);
  const largest = rings.reduce((best, ring) => (ring.value > best.value ? ring : best), rings[0]!);
  const centerText = formatMetric(largest.key, largest.value);
  const summary = `Circle chart: ${title}. ${rings.map((ring) => `${ring.label} ${formatMetric(ring.key, ring.value)}`).join(', ')}.`;

  return (
    <motion.div
      initial={reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.4 }}
      className="flex flex-wrap items-center justify-center gap-6"
    >
      {/* Up to 300×300; shrinks to fit narrow (col-span-4) cards instead of overflowing. */}
      <div role="img" aria-label={summary} className="relative aspect-square w-full" style={{ maxWidth: WHEEL_SIZE }}>
        <ResponsiveContainer width="100%" height="100%">
          <RadialBarChart
            cx="50%"
            cy="50%"
            innerRadius="30%"
            outerRadius="90%"
            barSize={12}
            data={rings}
            // 90° → -270° draws clockwise from 12 o'clock.
            startAngle={90}
            endAngle={-270}
          >
            <PolarAngleAxis type="number" domain={[0, 100]} tick={false} axisLine={false} />
            <RadialBar dataKey="progress" background={{ fill: '#F3F4F6' }} cornerRadius={6} isAnimationActive />
          </RadialBarChart>
        </ResponsiveContainer>
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold tabular-nums tracking-tight text-brand-black">{centerText}</span>
          <span className="block max-w-[38%] truncate text-center text-xs text-gray-500">{largest.label}</span>
        </div>
      </div>

      <ul className="min-w-[10rem] space-y-2">
        {rings.map((ring) => (
          <li key={ring.key} className="flex items-center gap-2 text-sm">
            <span
              aria-hidden="true"
              className="h-3 w-3 shrink-0 rounded-full ring-1 ring-brand-green-dark/40"
              style={{ backgroundColor: ring.fill }}
            />
            <span className="text-gray-700">{ring.label}</span>
            <span className="ml-auto pl-4 font-semibold tabular-nums text-brand-black">{formatMetric(ring.key, ring.value)}</span>
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

export function CRMCircleChart({ config }: CRMCircleChartProps) {
  return (
    <WidgetFrame config={config} height={WHEEL_SIZE}>
      {(data, dataKeys) => <CircleBody data={data} dataKeys={dataKeys} title={config.title} />}
    </WidgetFrame>
  );
}
