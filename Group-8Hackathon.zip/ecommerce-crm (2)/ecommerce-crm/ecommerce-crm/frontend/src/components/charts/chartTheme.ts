export const LINE_PALETTE = ['#22C55E', '#15803D', '#86EFAC'] as const;
export const BAR_PALETTE = ['#22C55E', '#15803D', '#DCFCE7'] as const;
export const RING_PALETTE = ['#22C55E', '#15803D', '#86EFAC', '#DCFCE7'] as const;

/** Second channel besides hue so series stay distinguishable without colour. */
export const LINE_DASHES = [undefined, '6 4', '2 4'] as const;

export const AXIS_TICK = { fontSize: 12, fill: '#6B7280' } as const;
export const GRID_STROKE = '#DCFCE7';
export const CHART_HEIGHT = 280;

export function pick<T>(palette: readonly T[], index: number): T {
  return palette[index % palette.length]!;
}
