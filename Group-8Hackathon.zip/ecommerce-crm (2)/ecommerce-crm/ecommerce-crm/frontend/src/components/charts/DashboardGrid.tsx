import type { WidgetConfig } from '@/types/dashboard.types';
import { CRMBarChart } from './CRMBarChart';
import { CRMCircleChart } from './CRMCircleChart';
import { CRMLineChart } from './CRMLineChart';

interface DashboardGridProps {
  widgets: WidgetConfig[];
}

export const COL_SPAN_CLASS: Record<WidgetConfig['colSpan'], string> = {
  4: 'col-span-12 md:col-span-6 lg:col-span-4',
  6: 'col-span-12 md:col-span-6',
  12: 'col-span-12',
};

function renderWidget(widget: WidgetConfig) {
  switch (widget.type) {
    case 'LineChart':
      return <CRMLineChart config={widget} />;
    case 'BarChart':
      return <CRMBarChart config={widget} />;
    case 'CircleChart':
      return <CRMCircleChart config={widget} />;
    default:
      return null; // unknown widget types from older/newer layouts are skipped
  }
}

export function DashboardGrid({ widgets }: DashboardGridProps) {
  return (
    <div className="grid grid-cols-12 gap-6 p-6">
      {widgets.map((widget) => (
        <div key={widget.widgetId} className={COL_SPAN_CLASS[widget.colSpan] ?? COL_SPAN_CLASS[12]}>
          {renderWidget(widget)}
        </div>
      ))}
    </div>
  );
}
