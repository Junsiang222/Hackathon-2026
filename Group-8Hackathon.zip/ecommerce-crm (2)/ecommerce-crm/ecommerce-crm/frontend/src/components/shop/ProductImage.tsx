import { ShoppingBag } from 'lucide-react';
import { useState } from 'react';

// Soft placeholder tints, picked by product name so each product keeps its colour.
const TINTS = ['bg-emerald-100', 'bg-amber-100', 'bg-sky-100', 'bg-rose-100', 'bg-violet-100', 'bg-lime-100', 'bg-orange-100', 'bg-teal-100'];
const INK = ['text-emerald-800', 'text-amber-800', 'text-sky-800', 'text-rose-800', 'text-violet-800', 'text-lime-800', 'text-orange-800', 'text-teal-800'];

function hash(text: string): number {
  let value = 0;
  for (const char of text) value = (value * 31 + char.charCodeAt(0)) >>> 0;
  return value;
}

/** Product photo, or a tinted tile with the product's initials when there is none (or it fails to load). */
export function ProductImage({ name, url, className = '' }: { name: string; url: string | null; className?: string }) {
  const [failed, setFailed] = useState(false);
  if (url && !failed) {
    return <img src={url} alt="" loading="lazy" onError={() => setFailed(true)} className={`object-cover ${className}`} />;
  }
  const index = hash(name) % TINTS.length;
  const initials = name
    .split(/\s+/)
    .slice(0, 2)
    .map((word) => word[0]?.toUpperCase() ?? '')
    .join('');
  return (
    <div className={`flex flex-col items-center justify-center gap-1 ${TINTS[index]} ${className}`} aria-hidden="true">
      <ShoppingBag className={`h-6 w-6 opacity-60 ${INK[index]}`} />
      <span className={`text-2xl font-bold tracking-tight ${INK[index]}`}>{initials}</span>
    </div>
  );
}

const priceFormatter = new Intl.NumberFormat(undefined, { style: 'currency', currency: 'USD' });

export function formatPrice(amount: number, currency = 'USD'): string {
  if (currency === 'USD') return priceFormatter.format(amount);
  return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(amount);
}
