import { useEffect, useMemo, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { trackShopEvent, useShopContext, useShopEvent, useShopProducts } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useCart, useCartStore } from '@/store/cartStore';
import type { GeneratedWebsite, ShopCatalogue, ShopInfo } from '@/types/shop.types';

/**
 * The AI-designed page runs with scripts but WITHOUT allow-same-origin: it gets
 * an opaque origin, so it can't read this app's storage, cookies or DOM. It can
 * only ask for things through postMessage, and every request is checked here.
 */
const SANDBOX = 'allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox';

/** Defines `window.shop` inside the frame. Mirrors the contract in the backend's websiteGenerator prompt. */
const BRIDGE = `(function () {
  var data = __SHOP_DATA__;
  var listeners = [];
  var count = 0;
  function send(message) {
    message.source = 'ai-shop';
    parent.postMessage(message, '*');
  }
  var images = data.images || {};
  // Soft grey tile with a label, for photos that were not found or fail to load.
  function placeholder(label) {
    var text = String(label || '').slice(0, 28).replace(/[<>&"']/g, '');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800" viewBox="0 0 800 800">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f4f4f5"/>' +
      '<stop offset="1" stop-color="#e4e4e7"/></linearGradient></defs><rect width="800" height="800" fill="url(#g)"/>' +
      '<text x="400" y="415" font-family="system-ui,sans-serif" font-size="40" fill="#a1a1aa" text-anchor="middle">' +
      text + '</text></svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  }
  // A page photo that wasn't found borrows a product photo (the same one per key) before a placeholder.
  var productPhotos = data.products.map(function (p) { return p.imageUrl; }).filter(Boolean);
  function image(key) {
    if (images[key]) return images[key];
    if (!productPhotos.length) return placeholder('');
    var hash = 0;
    for (var i = 0; i < String(key).length; i++) hash = (hash * 31 + String(key).charCodeAt(i)) >>> 0;
    return productPhotos[hash % productPhotos.length];
  }
  function productImage(product) {
    return (product && product.imageUrl) || placeholder(product && product.name);
  }
  function categoryImage(name) {
    if (images['category:' + name]) return images['category:' + name];
    var withPhoto = data.products.filter(function (p) { return p.category === name && p.imageUrl; })[0];
    return withPhoto ? withPhoto.imageUrl : placeholder(name);
  }
  // <img data-shop-image="hero"> and <div data-shop-bg="hero"> in the page's markup.
  function fill(root) {
    if (!root.querySelectorAll) return;
    var nodes = [root].concat(Array.prototype.slice.call(root.querySelectorAll('[data-shop-image],[data-shop-bg]')));
    nodes.forEach(function (el) {
      if (!el.getAttribute) return;
      var key = el.getAttribute('data-shop-image');
      if (key && !el.getAttribute('src')) el.setAttribute('src', image(key));
      var bg = el.getAttribute('data-shop-bg');
      if (bg && !el.style.backgroundImage) el.style.backgroundImage = 'url("' + image(bg) + '")';
    });
  }
  document.addEventListener('DOMContentLoaded', function () {
    fill(document.documentElement);
    new MutationObserver(function (records) {
      records.forEach(function (record) {
        Array.prototype.forEach.call(record.addedNodes, function (node) {
          if (node.nodeType === 1) fill(node);
        });
      });
    }).observe(document.documentElement, { childList: true, subtree: true });
  });
  // The hero must always show a photo, even when the page forgot to wire it up.
  function findHero() {
    var hero = document.querySelector('[data-shop-hero], #hero, .hero');
    if (hero) return hero;
    var candidates = document.querySelectorAll('[class*="hero"], [id*="hero"], main > section, body > section');
    for (var i = 0; i < candidates.length; i++) {
      var rect = candidates[i].getBoundingClientRect();
      if (rect.height >= 250 && rect.top < 900) return candidates[i];
    }
    return null;
  }
  // A large image or background picture inside the hero (small floating product cards don't count).
  function heroHasPicture(hero) {
    var minWidth = hero.offsetWidth * 0.3;
    var nodes = [hero].concat(Array.prototype.slice.call(hero.querySelectorAll('*')));
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (node.offsetWidth < minWidth) continue;
      if (node.tagName === 'IMG' && node.getAttribute('src')) return true;
      var layers = [null, '::before', '::after'];
      for (var j = 0; j < layers.length; j++) {
        if (getComputedStyle(node, layers[j]).backgroundImage.indexOf('url(') !== -1) return true;
      }
    }
    return false;
  }
  // CSS variables the page's styles use for its hero photo, e.g. var(--hero-img).
  function heroVariables() {
    var names = {};
    Array.prototype.forEach.call(document.styleSheets, function (sheet) {
      var rules;
      try { rules = sheet.cssRules; } catch (e) { return; }
      Array.prototype.forEach.call(rules || [], function (rule) {
        var match, re = /var\\(\\s*(--[\\w-]*hero[\\w-]*)/gi;
        while ((match = re.exec(rule.cssText))) names[match[1]] = true;
      });
    });
    return Object.keys(names);
  }
  function ensureHeroPhoto() {
    var hero = findHero();
    if (!hero || heroHasPicture(hero)) return;
    if (!images.hero && !productPhotos.length) return;
    var url = 'url("' + image('hero') + '")';
    heroVariables().forEach(function (name) {
      if (!getComputedStyle(hero).getPropertyValue(name).trim()) hero.style.setProperty(name, url);
    });
    if (heroHasPicture(hero)) return;
    // Last resort: the photo behind the hero's own content, shaded so its text stays readable.
    var rgb = (getComputedStyle(hero).color.match(/\\d+/g) || [0, 0, 0]).map(Number);
    var lightText = rgb[0] * 0.299 + rgb[1] * 0.587 + rgb[2] * 0.114 > 150;
    var shade = lightText
      ? 'linear-gradient(90deg, rgba(0,0,0,.72), rgba(0,0,0,.45) 55%, rgba(0,0,0,.2))'
      : 'linear-gradient(90deg, rgba(255,255,255,.9), rgba(255,255,255,.6) 55%, rgba(255,255,255,.2))';
    hero.style.backgroundImage = shade + ', ' + url;
    hero.style.backgroundSize = 'cover';
    hero.style.backgroundPosition = 'center';
  }
  window.addEventListener('load', function () {
    ensureHeroPhoto();
    setTimeout(ensureHeroPhoto, 1200);
  });
  // A broken photo becomes a placeholder instead of a broken-image icon.
  document.addEventListener('error', function (event) {
    var el = event.target;
    if (el && el.tagName === 'IMG' && !el.getAttribute('data-shop-fallback')) {
      el.setAttribute('data-shop-fallback', '1');
      el.src = placeholder(el.alt);
    }
  }, true);
  window.shop = {
    data: data,
    image: image,
    productImage: productImage,
    categoryImage: categoryImage,
    formatPrice: function (amount) {
      try {
        return new Intl.NumberFormat('en-US', { style: 'currency', currency: data.currency }).format(amount);
      } catch (e) {
        return String(amount);
      }
    },
    addToCart: function (productId, qty) {
      send({ type: 'addToCart', productId: productId, qty: qty == null ? 1 : qty });
    },
    go: function (page, productId) {
      send({ type: 'go', page: page, productId: productId });
    },
    onCartChange: function (fn) {
      if (typeof fn !== 'function') return;
      listeners.push(fn);
      try { fn(count); } catch (e) { console.error(e); }
    },
  };
  addEventListener('message', function (event) {
    var message = event.data;
    if (event.source !== parent || !message || message.source !== 'ai-shop-host' || message.type !== 'cart') return;
    count = message.count;
    listeners.forEach(function (fn) {
      try { fn(count); } catch (e) { console.error(e); }
    });
  });
  // The frame must never navigate itself. A srcdoc page resolves links against the shop's own URL,
  // so even "#section" would load the whole app inside the sandbox (a blank page). In-page anchors
  // scroll here instead, other relative links are blocked (shop pages go through shop.go()), and
  // external links open in a new tab. Runs after the page's own handlers; skipped if they handled it.
  function scrollToHash(hash) {
    var id = decodeURIComponent(hash.slice(1));
    var target = id ? document.getElementById(id) || document.querySelector('[name="' + id.replace(/"/g, '') + '"]') : null;
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    else if (!id || id === 'top' || id === 'home') window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  window.addEventListener('click', function (event) {
    var link = event.target && event.target.closest ? event.target.closest('a[href]') : null;
    if (!link || event.defaultPrevented) return;
    var href = link.getAttribute('href') || '';
    if (/^(mailto|tel):/i.test(href)) return;
    if (/^https?:/i.test(href)) {
      link.target = '_blank';
      link.rel = 'noopener';
      return;
    }
    event.preventDefault();
    if (href.charAt(0) === '#') scrollToHash(href);
  });
  // A form without its own submit handler would reload the frame: keep it on the page.
  window.addEventListener('submit', function (event) {
    if (!event.defaultPrevented) event.preventDefault();
  });
})();`;

function buildSrcDoc(website: GeneratedWebsite, shop: ShopInfo, catalogue: ShopCatalogue): string {
  const { html } = website;
  const data = {
    images: Object.fromEntries(Object.entries(website.images ?? {}).map(([key, image]) => [key, image.url])),
    storeName: shop.storeName,
    industry: shop.industry,
    currency: shop.currency,
    features: {
      checkout: shop.features.checkout,
      contact: shop.features.contact,
      orderTracking: shop.features.orderTracking,
      accounts: shop.features.accounts,
    },
    categories: catalogue.categories,
    products: catalogue.products.map(({ maxQty: _maxQty, ...product }) => product),
  };
  // Escape "<" so product text can never close the <script> element early.
  const json = JSON.stringify(data).replace(/</g, '\\u003c');
  const tag = `<script>${BRIDGE.replace('__SHOP_DATA__', () => json)}</script>`;

  // Must run before the page's own scripts, without pushing anything above <!doctype>.
  for (const pattern of [/<head[^>]*>/i, /<html[^>]*>/i, /<!doctype[^>]*>/i]) {
    const match = pattern.exec(html);
    if (match) {
      const at = match.index + match[0].length;
      return html.slice(0, at) + tag + html.slice(at);
    }
  }
  return tag + html;
}

/** A store's home page that the AI designed freely, wired to the real cart and catalogue. */
export function GeneratedShopPage({ website }: { website: GeneratedWebsite }) {
  const { shopId, shop } = useShopContext();
  const navigate = useNavigate();
  const query = useShopProducts(shopId, {});
  const add = useCartStore((state) => state.add);
  const { count } = useCart(shopId);
  const frameRef = useRef<HTMLIFrameElement>(null);
  useShopEvent(shopId, 'page_view');

  const catalogue = query.data;
  const srcDoc = useMemo(() => (catalogue ? buildSrcDoc(website, shop, catalogue) : null), [website, shop, catalogue]);

  // Latest values for the message handler without re-subscribing.
  const latest = useRef({ catalogue, count });
  latest.current = { catalogue, count };

  const postCount = (value: number) =>
    frameRef.current?.contentWindow?.postMessage({ source: 'ai-shop-host', type: 'cart', count: value }, '*');

  useEffect(() => {
    postCount(count);
  }, [count]);

  useEffect(() => {
    const root = `/shop/${shopId}`;
    const pages: Record<string, string | null> = {
      home: root,
      cart: shop.features.checkout ? `${root}/cart` : null,
      checkout: shop.features.checkout ? `${root}/checkout` : null,
      track: shop.features.orderTracking ? `${root}/track` : null,
      contact: shop.features.contact ? `${root}/contact` : null,
      login: shop.features.accounts ? `${root}/login` : null,
      account: shop.features.accounts ? `${root}/account` : null,
    };

    const onMessage = (event: MessageEvent) => {
      // Only our frame, and only the two requests the bridge can make. Everything else is ignored.
      if (!frameRef.current || event.source !== frameRef.current.contentWindow) return;
      const message = event.data as { source?: unknown; type?: unknown; page?: unknown; productId?: unknown; qty?: unknown };
      if (!message || message.source !== 'ai-shop') return;
      const products = latest.current.catalogue?.products ?? [];

      if (message.type === 'go' && typeof message.page === 'string') {
        if (message.page === 'product') {
          const product = products.find((item) => item.id === Number(message.productId));
          if (product) navigate(`${root}/product/${product.id}`);
          return;
        }
        const path = Object.prototype.hasOwnProperty.call(pages, message.page) ? pages[message.page] : null;
        if (path && path !== root) navigate(path);
        return;
      }

      if (message.type === 'addToCart' && shop.features.checkout) {
        const product = products.find((item) => item.id === Number(message.productId));
        if (!product) return;
        if (!product.inStock) {
          toast.error(`${product.name} is out of stock`);
          return;
        }
        const qty = Math.max(1, Math.floor(Number(message.qty) || 1));
        add(shopId, { productId: product.id, name: product.name, price: product.price, imageUrl: product.imageUrl, maxQty: product.maxQty }, qty);
        trackShopEvent(shopId, 'add_to_cart', product.id);
        toast.success(`${product.name} added to cart`);
      }
    };

    window.addEventListener('message', onMessage);
    return () => window.removeEventListener('message', onMessage);
  }, [shopId, shop, navigate, add]);

  if (query.isPending) return <LoadingShimmer variant="page" />;
  if (query.isError || !srcDoc) {
    return (
      <main className="mx-auto max-w-6xl p-6">
        <ErrorPlaceholder message={getApiErrorMessage(query.error)} onRetry={() => query.refetch()} isRetrying={query.isFetching} />
      </main>
    );
  }

  return (
    <iframe
      ref={frameRef}
      title={shop.storeName}
      srcDoc={srcDoc}
      sandbox={SANDBOX}
      onLoad={() => postCount(latest.current.count)}
      className="block h-[100dvh] w-full border-0"
    />
  );
}
