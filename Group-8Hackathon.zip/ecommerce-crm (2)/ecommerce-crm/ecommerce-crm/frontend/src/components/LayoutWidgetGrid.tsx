import { motion } from 'framer-motion';
import { BarChart2, PieChart, TrendingUp, type LucideIcon } from 'lucide-react';
import { COL_SPAN_CLASS } from '@/components/charts/DashboardGrid';
import { ChartCard } from '@/components/ChartCard';
import type { WidgetConfig, WidgetType } from '@/types/dashboard.types';
import { useT } from '@/i18n';
import { humanizeKey } from '@/utils/format';

const WIDGET_ICON: Record<WidgetType, LucideIcon> = {
  LineChart: TrendingUp,
  BarChart: BarChart2,
  CircleChart: PieChart,
};

/**
 * Super-admin view of a layout: widget structure only. Super admins never see
 * tenant data, so no chart is rendered — that happens on the tenant's Analytics page.
 */
export function LayoutWidgetGrid({ widgets }: { widgets: WidgetConfig[] }) {
  const t = useT();
  return (
    <div className="grid grid-cols-12 gap-6">
      {widgets.map((widget, index) => {
        const Icon = WIDGET_ICON[widget.type];
        return (
          <motion.div
            key={widget.widgetId}
            className={COL_SPAN_CLASS[widget.colSpan]}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: Math.min(index * 0.04, 0.3), duration: 0.2 }}
          >
            <ChartCard
              title={widget.title}
              className="h-full"
              aside={<Icon className="h-5 w-5 shrink-0 text-brand-green-dark" aria-label={widget.type} />}
            >
              <p className="font-mono text-xs text-gray-500">{widget.dataSourceUrl}</p>
              <ul className="mt-3 flex flex-wrap gap-2" aria-label={t('Data keys')}>
                {widget.dataKeys.map((key) => (
                  <li key={key} className="rounded-full bg-brand-mint px-2.5 py-0.5 text-xs font-semibold text-brand-green-dark">
                    {humanizeKey(key)}
                  </li>
                ))}
              </ul>
            </ChartCard>
          </motion.div>
        );
      })}
    </div>
  );
}
