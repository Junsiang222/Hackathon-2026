import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Lightbulb } from 'lucide-react';
import { usePreferencesStore, useT } from '@/i18n';

/** Light rays around the top of the bulb, as angles in degrees (0 = straight up). */
const RAYS = [-80, -40, 0, 40, 80];

/**
 * Light / dark switch next to the notification bell. Light mode shows the bulb
 * switched on (glowing, with light rays); dark mode shows it switched off.
 */
export function ThemeToggle() {
  const theme = usePreferencesStore((state) => state.theme);
  const setTheme = usePreferencesStore((state) => state.setTheme);
  const reduceMotion = useReducedMotion();
  const t = useT();
  const light = theme === 'light';

  return (
    <button
      type="button"
      onClick={() => setTheme(light ? 'dark' : 'light')}
      aria-label={light ? t('Switch to dark mode') : t('Switch to light mode')}
      title={light ? t('Switch to dark mode') : t('Switch to light mode')}
      className="relative flex h-11 w-11 items-center justify-center rounded-full text-brand-black hover:bg-brand-mint"
    >
      <AnimatePresence>
        {light ? (
          <motion.span key="on" aria-hidden="true" className="pointer-events-none absolute inset-0" exit={{ opacity: 0, transition: { duration: 0.2 } }}>
            {/* Soft glow behind the bulb */}
            <motion.span
              className="absolute left-1/2 top-[13px] h-6 w-6 -translate-x-1/2 rounded-full bg-amber-300 blur-md"
              initial={{ opacity: 0, scale: 0.4 }}
              animate={reduceMotion ? { opacity: 0.55, scale: 1 } : { opacity: [0.4, 0.7, 0.4], scale: [0.9, 1.1, 0.9] }}
              transition={reduceMotion ? { duration: 0.2 } : { duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
            />
            {/* Rays, pivoting around the centre of the bulb's glass */}
            {RAYS.map((angle, index) => (
              <span
                key={angle}
                className="absolute left-1/2 top-[19px] h-0 w-0"
                style={{ transform: `rotate(${angle}deg)` }}
              >
                <motion.span
                  className="absolute -left-px block h-[5px] w-[2px] rounded-full bg-amber-500"
                  style={{ bottom: 8 }}
                  initial={{ opacity: 0, scaleY: 0 }}
                  animate={reduceMotion ? { opacity: 1, scaleY: 1 } : { opacity: [0.35, 1, 0.35], scaleY: [0.7, 1, 0.7] }}
                  transition={
                    reduceMotion
                      ? { duration: 0.2 }
                      : { duration: 1.6, delay: index * 0.08, repeat: Infinity, ease: 'easeInOut' }
                  }
                />
              </span>
            ))}
          </motion.span>
        ) : null}
      </AnimatePresence>
      <motion.span
        aria-hidden="true"
        className="relative mt-1 flex"
        animate={{ scale: light ? 1 : 0.92 }}
        transition={{ type: 'spring', stiffness: 400, damping: 18 }}
      >
        <Lightbulb
          className={`h-5 w-5 transition-colors duration-300 ${light ? 'fill-amber-300 text-amber-600' : 'fill-transparent text-gray-400'}`}
        />
      </motion.span>
    </button>
  );
}
