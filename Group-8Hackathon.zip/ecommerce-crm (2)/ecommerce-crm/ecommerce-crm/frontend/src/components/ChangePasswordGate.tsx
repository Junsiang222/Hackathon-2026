import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation } from '@tanstack/react-query';
import { KeyRound, LogOut } from 'lucide-react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { useLogout } from '@/hooks/useAuth';
import { api, getApiErrorMessage } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';

// Same rules the server enforces for every password.
const schema = z
  .object({
    currentPassword: z.string().min(1, 'Enter the temporary password you logged in with'),
    newPassword: z
      .string()
      .min(12, 'At least 12 characters')
      .refine((value) => /[a-z]/.test(value) && /[A-Z]/.test(value) && /\d/.test(value), {
        message: 'Use upper-case, lower-case and a number',
      }),
    confirmPassword: z.string(),
  })
  .refine((values) => values.newPassword === values.confirmPassword, {
    path: ['confirmPassword'],
    message: "Passwords don't match",
  });
type Values = z.infer<typeof schema>;

/**
 * Shown instead of the admin panel while the store admin is still on the
 * temporary password the super admin created.
 */
export function ChangePasswordGate() {
  const user = useAuthStore((state) => state.user);
  const accessToken = useAuthStore((state) => state.accessToken);
  const setSession = useAuthStore((state) => state.setSession);
  const logout = useLogout();
  const { register, handleSubmit, setError, formState } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { currentPassword: '', newPassword: '', confirmPassword: '' },
  });
  const { errors } = formState;

  const change = useMutation({
    mutationFn: async (values: Values) =>
      api.post('/api/v1/admin/account/password', {
        currentPassword: values.currentPassword,
        newPassword: values.newPassword,
      }),
    onSuccess: () => {
      if (user && accessToken) setSession(accessToken, { ...user, mustChangePassword: false });
      toast.success('Password saved. Welcome to your store!');
    },
    onError: (error) => {
      const message = getApiErrorMessage(error);
      if (/current password/i.test(message)) setError('currentPassword', { message });
      else toast.error(message);
    },
  });

  return (
    <div className="flex min-h-[70vh] items-center justify-center">
      <div className="w-full max-w-md rounded-2xl border border-gray-100 bg-white p-6 shadow-sm sm:p-8">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-mint">
          <KeyRound className="h-6 w-6 text-brand-green-dark" aria-hidden="true" />
        </span>
        <h2 className="mt-4 text-xl font-bold tracking-tight text-brand-black">Choose your own password</h2>
        <p className="mt-1 text-sm text-gray-700">
          You logged in with a temporary password from your platform administrator. Set a password only you know to
          continue to {user?.businessName ?? 'your store'}.
        </p>
        <form onSubmit={handleSubmit((values) => change.mutate(values))} noValidate className="mt-6 space-y-4">
          <TextField
            label="Temporary password"
            type="password"
            autoComplete="current-password"
            error={errors.currentPassword?.message}
            {...register('currentPassword')}
          />
          <TextField
            label="New password"
            type="password"
            autoComplete="new-password"
            hint="At least 12 characters, with upper-case, lower-case and a number"
            error={errors.newPassword?.message}
            {...register('newPassword')}
          />
          <TextField
            label="Confirm new password"
            type="password"
            autoComplete="new-password"
            error={errors.confirmPassword?.message}
            {...register('confirmPassword')}
          />
          <Button type="submit" fullWidth loading={change.isPending}>
            Save password and continue
          </Button>
        </form>
        <button
          type="button"
          onClick={() => logout.mutate()}
          className="mt-4 inline-flex min-h-[44px] w-full items-center justify-center gap-2 text-sm font-medium text-gray-700 hover:text-brand-black"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
          Log out
        </button>
      </div>
    </div>
  );
}
