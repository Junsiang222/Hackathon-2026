import type { ComponentType, ReactNode } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuthStore } from '@/store/authStore';
import type { Role } from '@/types/api.types';
import { LoadingShimmer } from './LoadingShimmer';

interface ProtectedRouteProps {
  /** Omit to allow any signed-in role. */
  allowedRoles?: readonly Role[];
  children?: ReactNode;
}

/**
 * Route guard driven by the Zustand auth store.
 *  - still restoring the session → shimmer
 *  - signed out                  → /auth (remembering where they were going)
 *  - wrong role                  → /dashboard (their own home)
 * The API enforces roles independently; this only shapes navigation.
 */
export function ProtectedRoute({ allowedRoles, children }: ProtectedRouteProps) {
  const status = useAuthStore((state) => state.status);
  const role = useAuthStore((state) => state.role);
  const location = useLocation();

  if (status === 'idle' || status === 'loading') return <LoadingShimmer variant="page" />;

  if (status !== 'authenticated' || !role) {
    return <Navigate to="/auth" replace state={{ from: location.pathname }} />;
  }

  if (allowedRoles && !allowedRoles.includes(role)) {
    return <Navigate to="/dashboard" replace />;
  }

  return children ? <>{children}</> : <Outlet />;
}

/** HOC form of the guard: `export default withRoleGuard(Page, ['admin'])`. */
export function withRoleGuard<P extends object>(Component: ComponentType<P>, allowedRoles?: readonly Role[]) {
  function Guarded(props: P) {
    return (
      <ProtectedRoute allowedRoles={allowedRoles}>
        <Component {...props} />
      </ProtectedRoute>
    );
  }
  Guarded.displayName = `withRoleGuard(${Component.displayName ?? Component.name ?? 'Component'})`;
  return Guarded;
}
