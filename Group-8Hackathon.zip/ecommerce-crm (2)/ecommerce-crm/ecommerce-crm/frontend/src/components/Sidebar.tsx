import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import {
  BarChart3,
  ExternalLink,
  Globe,
  LayoutDashboard,
  LogOut,
  Megaphone,
  Package,
  Receipt,
  Settings,
  ShoppingBag,
  Store,
  Ticket,
  UserRound,
  Users,
  X,
  type LucideIcon,
} from 'lucide-react';
import { useEffect } from 'react';
import { NavLink } from 'react-router-dom';
import { useLogout } from '@/hooks/useAuth';
import { hasModule, useStoreSetup } from '@/hooks/useStore';
import { useT } from '@/i18n';
import { useAuthStore } from '@/store/authStore';
import type { Role } from '@/types/api.types';
import type { ModuleKey } from '@/types/dashboard.types';
import { BrandLogo } from './BrandLogo';
import { Spinner } from './ui/Spinner';

export { PLATFORM_NAME } from './BrandLogo';

interface NavItem {
  label: string;
  icon: LucideIcon;
  /** Destination per role; a role without an entry doesn't see the item. */
  to?: Partial<Record<Role, string>>;
  /** Shown to store admins (not the super admin) as a non-interactive "Soon" item. */
  comingSoon?: boolean;
  /**
   * Store admins only: shown when ANY of these modules was enabled in the
   * store's setup wizard. An empty list means "once the store is set up".
   */
  modules?: readonly ModuleKey[];
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Overview', icon: LayoutDashboard, to: { super_admin: '/dashboard/super-admin', admin: '/dashboard/admin' } },
  { label: 'Stores', icon: Store, to: { super_admin: '/dashboard/stores' } },
  { label: 'Websites', icon: Globe, to: { super_admin: '/dashboard/websites' } },
  { label: 'Products', icon: Package, to: { admin: '/dashboard/products' }, modules: ['inventory', 'storefront'] },
  { label: 'Orders', icon: ShoppingBag, to: { admin: '/dashboard/orders' }, modules: ['orders'] },
  { label: 'Customers', icon: UserRound, to: { admin: '/dashboard/customers' }, modules: ['customers'] },
  { label: 'Marketing', icon: Megaphone, to: { admin: '/dashboard/marketing' }, modules: ['marketing'] },
  { label: 'Tickets', icon: Ticket, to: { admin: '/dashboard/tickets' }, modules: ['customerService'] },
  { label: 'Expenses', icon: Receipt, to: { admin: '/dashboard/expenses' }, modules: [] },
  {
    label: 'Analytics',
    icon: BarChart3,
    to: { super_admin: '/dashboard/platform-analytics', admin: '/dashboard/analytics' },
    modules: [],
  },
  { label: 'Settings', icon: Settings, to: { super_admin: '/dashboard/settings' } },
  { label: 'Users', icon: Users, comingSoon: true },
  { label: 'Settings', icon: Settings, comingSoon: true },
];

const itemBase =
  'flex min-h-[44px] w-full items-center gap-3 rounded-lg px-3 text-sm font-medium transition-colors duration-150';

function SidebarContent({ onNavigate }: { onNavigate?: () => void }) {
  const role = useAuthStore((state) => state.role);
  const tenantUid = useAuthStore((state) => state.user?.tenantUid);
  const logout = useLogout();
  const { data: setup } = useStoreSetup();
  const t = useT();

  const visibleForStore = (item: NavItem) =>
    role !== 'admin' || !item.modules || (item.modules.length === 0 ? Boolean(setup) : hasModule(setup, item.modules));

  return (
    <div className="flex h-full flex-col bg-brand-black px-4 py-6">
      <div className="mb-8 px-2">
        <BrandLogo className="text-white" />
      </div>

      <nav aria-label={t('Main')} className="flex-1">
        <ul className="space-y-1">
          {NAV_ITEMS.map((item, index) => {
            const Icon = item.icon;
            const key = `${item.label}-${index}`;
            const destination = role ? item.to?.[role] : undefined;

            if (item.comingSoon) {
              if (role === 'super_admin') return null;
              return (
                <li key={key}>
                  <span aria-disabled="true" className={`${itemBase} cursor-not-allowed text-gray-400`}>
                    <Icon className="h-5 w-5" aria-hidden="true" />
                    {t(item.label)}
                    <span className="ml-auto rounded-full bg-gray-800 px-2 py-0.5 text-[11px] font-semibold text-gray-300">
                      {t('Soon')}
                    </span>
                  </span>
                </li>
              );
            }

            if (!destination || !visibleForStore(item)) return null;

            return (
              <li key={key}>
                <NavLink
                  to={destination}
                  onClick={onNavigate}
                  className={({ isActive }) =>
                    `${itemBase} ${
                      isActive ? 'rounded-lg bg-brand-green text-white' : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                    }`
                  }
                >
                  <Icon className="h-5 w-5" aria-hidden="true" />
                  {t(item.label)}
                </NavLink>
              </li>
            );
          })}
          {role === 'admin' && setup?.modules.storefront && tenantUid ? (
            <li>
              <a
                href={`/shop/${tenantUid}`}
                target="_blank"
                rel="noopener"
                className={`${itemBase} text-gray-400 hover:bg-gray-800 hover:text-white`}
              >
                <ExternalLink className="h-5 w-5" aria-hidden="true" />
                {t('Online shop')}
                <span className="sr-only">{t('(opens in a new tab)')}</span>
              </a>
            </li>
          ) : null}
        </ul>
      </nav>

      <button
        type="button"
        onClick={() => logout.mutate()}
        disabled={logout.isPending}
        className={`${itemBase} text-gray-400 hover:bg-gray-800 hover:text-white disabled:opacity-60`}
      >
        {logout.isPending ? <Spinner className="h-5 w-5" /> : <LogOut className="h-5 w-5" aria-hidden="true" />}
        {t('Logout')}
      </button>
    </div>
  );
}

interface SidebarProps {
  mobileOpen: boolean;
  onMobileClose: () => void;
}

export function Sidebar({ mobileOpen, onMobileClose }: SidebarProps) {
  const reduceMotion = useReducedMotion();

  const t = useT();

  useEffect(() => {
    if (!mobileOpen) return;
    const onKey = (event: KeyboardEvent) => event.key === 'Escape' && onMobileClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [mobileOpen, onMobileClose]);

  return (
    <>
      {/* Desktop: fixed rail */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 lg:block">
        <SidebarContent />
      </aside>

      {/* Mobile: off-canvas drawer */}
      <AnimatePresence>
        {mobileOpen ? (
          <div className="fixed inset-0 z-40 lg:hidden" role="dialog" aria-modal="true" aria-label={t('Navigation')}>
            <motion.div
              className="absolute inset-0 bg-black/50"
              onClick={onMobileClose}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            />
            <motion.aside
              className="absolute inset-y-0 left-0 w-64"
              initial={reduceMotion ? { opacity: 0 } : { x: '-100%' }}
              animate={reduceMotion ? { opacity: 1 } : { x: 0 }}
              exit={reduceMotion ? { opacity: 0 } : { x: '-100%' }}
              transition={{ type: 'tween', duration: 0.22, ease: 'easeOut' }}
            >
              <SidebarContent onNavigate={onMobileClose} />
              <button
                type="button"
                onClick={onMobileClose}
                aria-label={t('Close navigation')}
                className="absolute right-2 top-5 flex h-11 w-11 items-center justify-center rounded-lg text-gray-400 hover:bg-gray-800 hover:text-white"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </motion.aside>
          </div>
        ) : null}
      </AnimatePresence>
    </>
  );
}
