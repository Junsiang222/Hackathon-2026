import { zodResolver } from '@hookform/resolvers/zod';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { ArrowLeft, ArrowRight, BarChart2, PieChart, TrendingUp, X, Zap, type LucideIcon } from 'lucide-react';
import { useCallback, useEffect, useId, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { Controller, useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { useGenerateDashboard } from '@/hooks/useDashboard';
import { useT } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import type { ChartKind, DashboardModules, GeneratedLayout } from '@/types/dashboard.types';
import { ToggleSwitch } from './ToggleSwitch';
import { Button } from './ui/Button';
import { Spinner } from './ui/Spinner';

// ─── Form model ──────────────────────────────────────────────────────────────

const WEBSITE_PROMPT_MAX = 1000;

const generatorSchema = z
  .object({
    storeName: z.string().trim().min(2, 'Enter at least 2 characters').max(80, 'Keep it under 80 characters'),
    modules: z
      .object({
        storefront: z.boolean(),
        inventory: z.boolean(),
        orders: z.boolean(),
        customers: z.boolean(),
        marketing: z.boolean(),
        customerService: z.boolean(),
      })
      .refine((modules) => Object.values(modules).some(Boolean), {
        message: 'Turn on at least one module — go back and enable one.',
      }),
    analyticsCharts: z.array(z.enum(['line', 'bar', 'circle'])).min(1, 'Select at least one chart type'),
    websitePrompt: z.string().trim().max(WEBSITE_PROMPT_MAX, `Keep it under ${WEBSITE_PROMPT_MAX} characters`),
  })
  // Only stores with a Storefront get a public website to describe.
  .refine((values) => !values.modules.storefront || values.websitePrompt.length >= 10, {
    path: ['websitePrompt'],
    message: 'Describe the website in at least 10 characters',
  });
type GeneratorValues = z.infer<typeof generatorSchema>;

type ModuleKey = keyof DashboardModules;

type StepDefinition =
  | { kind: 'text'; label: string; sublabel?: string }
  | { kind: 'toggle'; label: string; sublabel?: string; module: ModuleKey; switchLabel: string }
  | { kind: 'charts'; label: string; sublabel?: string }
  | { kind: 'prompt'; label: string; sublabel?: string };

const STEPS: readonly StepDefinition[] = [
  { kind: 'text', label: "What is this store's name?" },
  { kind: 'toggle', label: 'Enable Storefront? (sell products online)', module: 'storefront', switchLabel: 'Enable Storefront' },
  {
    kind: 'toggle',
    label: 'Enable Inventory tracking?',
    sublabel: 'Track SKU quantities and restock safety thresholds',
    module: 'inventory',
    switchLabel: 'Enable Inventory tracking',
  },
  {
    kind: 'toggle',
    label: 'Enable Orders & Checkout?',
    sublabel: 'Activate order processing and logistics tracking',
    module: 'orders',
    switchLabel: 'Enable Orders & Checkout',
  },
  {
    kind: 'toggle',
    label: 'Enable Customer Profiles?',
    sublabel: 'Track behaviour events and lifetime value metrics',
    module: 'customers',
    switchLabel: 'Enable Customer Profiles',
  },
  {
    kind: 'toggle',
    label: 'Enable Automated Marketing?',
    sublabel: 'Deploy email, SMS and push campaigns',
    module: 'marketing',
    switchLabel: 'Enable Automated Marketing',
  },
  {
    kind: 'toggle',
    label: 'Enable Support Desk?',
    sublabel: 'Provision live chat and ticketing system',
    module: 'customerService',
    switchLabel: 'Enable Support Desk',
  },
  { kind: 'charts', label: 'Select dashboard chart types', sublabel: 'Pick all that apply' },
  {
    kind: 'prompt',
    label: 'Describe the website',
    sublabel: 'The AI designs the shop’s website and tailors the admin dashboard from this: what you sell, who it’s for, the feel, what to highlight.',
  },
];

const TOTAL_STEPS = STEPS.length; // 9

const CHART_OPTIONS: { value: ChartKind; label: string; icon: LucideIcon }[] = [
  { value: 'line', label: 'Line Chart', icon: TrendingUp },
  { value: 'bar', label: 'Bar Chart', icon: BarChart2 },
  { value: 'circle', label: 'Circle Chart', icon: PieChart },
];

const DEFAULT_MODULES: DashboardModules = {
  storefront: true,
  inventory: true,
  orders: true,
  customers: true,
  marketing: false,
  customerService: false,
};

// ─── Component ───────────────────────────────────────────────────────────────

export interface DashboardGeneratorModalProps {
  open: boolean;
  /** Tenant the layout is generated for. */
  tenant: { id: number; businessName: string } | null;
  onClose: () => void;
  onLayoutGenerated: (layout: GeneratedLayout) => void;
}

const FOCUSABLE = 'button:not([disabled]), input:not([disabled]), select:not([disabled]), [href], [tabindex]:not([tabindex="-1"])';

export function DashboardGeneratorModal({ open, tenant, onClose, onLayoutGenerated }: DashboardGeneratorModalProps) {
  const [step, setStep] = useState(1);
  const [direction, setDirection] = useState<1 | -1>(1);
  const reduceMotion = useReducedMotion();
  const generate = useGenerateDashboard();
  const t = useT();

  const titleId = useId();
  const sublabelId = useId();
  const storeNameId = useId();
  const websitePromptId = useId();
  const errorId = useId();
  const dialogRef = useRef<HTMLDivElement>(null);
  const stepBodyRef = useRef<HTMLDivElement>(null);
  const restoreFocusRef = useRef<HTMLElement | null>(null);

  const form = useForm<GeneratorValues>({
    resolver: zodResolver(generatorSchema),
    mode: 'onTouched',
    defaultValues: { storeName: '', modules: DEFAULT_MODULES, analyticsCharts: [], websitePrompt: '' },
  });
  const { control, register, trigger, formState, reset, handleSubmit, watch } = form;
  const storefrontEnabled = watch('modules.storefront');
  const websitePromptLength = watch('websitePrompt').length;

  const isSubmitting = generate.isPending;
  const current = STEPS[step - 1]!;

  // Reset for each opening (and each tenant).
  useEffect(() => {
    if (!open) return;
    restoreFocusRef.current = document.activeElement as HTMLElement | null;
    reset({ storeName: tenant?.businessName ?? '', modules: DEFAULT_MODULES, analyticsCharts: [], websitePrompt: '' });
    setStep(1);
    setDirection(1);
    generate.reset();
    // Intentionally keyed on open/tenant only: re-running on every render would wipe input.
  }, [open, tenant?.id]);

  // Lock page scroll while open; restore focus to the trigger on close.
  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = previousOverflow;
      restoreFocusRef.current?.focus?.();
    };
  }, [open]);

  // Move focus to the new step's primary control after each transition.
  useEffect(() => {
    if (!open) return;
    const id = window.setTimeout(() => {
      const target = stepBodyRef.current?.querySelector<HTMLElement>('input, textarea, [role="switch"]');
      target?.focus();
    }, reduceMotion ? 0 : 260);
    return () => window.clearTimeout(id);
  }, [open, step, reduceMotion]);

  const requestClose = useCallback(() => {
    if (!isSubmitting) onClose();
  }, [isSubmitting, onClose]);

  const goTo = (next: number) => {
    setDirection(next > step ? 1 : -1);
    setStep(Math.min(Math.max(next, 1), TOTAL_STEPS));
  };

  const goNext = async () => {
    if (current.kind === 'text' && !(await trigger('storeName'))) return;
    if (current.kind === 'charts' && !(await trigger(['analyticsCharts', 'modules']))) return;
    goTo(step + 1);
  };

  const submit = handleSubmit(
    (values) => {
      if (!tenant) return;
      generate.mutate(
        {
          tenantId: tenant.id,
          storeName: values.storeName,
          modules: values.modules,
          analyticsCharts: values.analyticsCharts,
          websitePrompt: values.modules.storefront ? values.websitePrompt : '',
        },
        {
          onSuccess: (layout) => {
            toast.success(t('Dashboard generated with {count} widgets', { count: layout.config.length }));
            onLayoutGenerated(layout);
            onClose();
          },
          onError: (error) => toast.error(getApiErrorMessage(error)), // stay on step 9
        },
      );
    },
    (errors) => {
      // A failure on an earlier step (e.g. store name) jumps back to it.
      if (errors.storeName) goTo(1);
      else if (errors.analyticsCharts || errors.modules) goTo(STEPS.findIndex((s) => s.kind === 'charts') + 1);
    },
  );

  const onFormSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (step < TOTAL_STEPS) void goNext();
    else void submit();
  };

  // Escape to close + simple focus trap.
  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === 'Escape') {
      event.stopPropagation();
      requestClose();
      return;
    }
    if (event.key !== 'Tab' || !dialogRef.current) return;
    const focusable = Array.from(dialogRef.current.querySelectorAll<HTMLElement>(FOCUSABLE));
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (!first || !last) return;
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  };

  const progress = step / TOTAL_STEPS;
  const chartsError = formState.errors.analyticsCharts?.message;
  const modulesError = formState.errors.modules?.root?.message ?? formState.errors.modules?.message;
  const websitePromptError = formState.errors.websitePrompt?.message;

  const flipVariants = reduceMotion
    ? { enter: { opacity: 0 }, center: { opacity: 1 }, exit: { opacity: 0 } }
    : {
        enter: (dir: number) => ({ opacity: 0, rotateY: dir * 70, x: dir * 24 }),
        center: { opacity: 1, rotateY: 0, x: 0 },
        exit: (dir: number) => ({ opacity: 0, rotateY: dir * -70, x: dir * -24 }),
      };

  return (
    <AnimatePresence>
      {open && tenant ? (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.15 } }}
          onMouseDown={(event) => event.target === event.currentTarget && requestClose()}
        >
          <motion.div
            ref={dialogRef}
            role="dialog"
            aria-modal="true"
            aria-labelledby={titleId}
            aria-describedby={current.sublabel ? sublabelId : undefined}
            onKeyDown={onKeyDown}
            className="w-full max-w-lg"
            initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 16, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 8, scale: 0.98, transition: { duration: 0.15 } }}
            transition={{ type: 'spring', stiffness: 420, damping: 34 }}
          >
            {/* Progress — sits above the card border and spans its full width. */}
            <div
              role="progressbar"
              aria-label={t('Dashboard setup progress')}
              aria-valuemin={1}
              aria-valuemax={TOTAL_STEPS}
              aria-valuenow={step}
              aria-valuetext={t('Step {step} of {total}', { step, total: TOTAL_STEPS })}
              className="mb-3 h-1 w-full overflow-hidden rounded-full bg-white/30"
            >
              {/* scaleX instead of width: same visual, compositor-only animation. */}
              <div
                className="h-1 w-full origin-left rounded-full bg-brand-green transition-transform duration-300 ease-in-out"
                style={{ transform: `scaleX(${progress})` }}
              />
            </div>

            <div className="relative overflow-hidden rounded-2xl border-2 border-brand-black bg-white">
              <button
                type="button"
                onClick={requestClose}
                disabled={isSubmitting}
                aria-label={t('Close dashboard generator')}
                className="absolute right-3 top-3 z-10 flex h-11 w-11 items-center justify-center rounded-full text-gray-500 hover:bg-brand-mint hover:text-brand-black disabled:opacity-50"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>

              <form onSubmit={onFormSubmit} noValidate className="p-6 sm:p-8">
                <p className="text-xs font-semibold uppercase tracking-wider text-brand-green-dark">
                  {t('Step {step} of {total}', { step, total: TOTAL_STEPS })} · {tenant.businessName}
                </p>

                <div style={{ perspective: 1200 }} className="mt-2 min-h-[220px]">
                  <AnimatePresence mode="wait" custom={direction} initial={false}>
                    <motion.div
                      key={step}
                      ref={stepBodyRef}
                      custom={direction}
                      variants={flipVariants}
                      initial="enter"
                      animate="center"
                      exit="exit"
                      transition={{ duration: 0.24, ease: [0.2, 0.8, 0.2, 1] }}
                      style={{ transformOrigin: 'center', backfaceVisibility: 'hidden' }}
                    >
                      {current.kind === 'text' ? (
                        <>
                          <label id={titleId} htmlFor={storeNameId} className="block pr-10 text-xl font-bold tracking-tight text-brand-black">
                            {t(current.label)}
                          </label>
                          <input
                            id={storeNameId}
                            type="text"
                            autoComplete="off"
                            placeholder={t('e.g. Urban Thread Co.')}
                            aria-invalid={formState.errors.storeName ? true : undefined}
                            aria-describedby={formState.errors.storeName ? errorId : undefined}
                            className={`mt-5 block min-h-[48px] w-full rounded-xl border-2 bg-white px-4 text-base text-brand-black placeholder:text-gray-400 focus:outline-none focus:ring-4 ${
                              formState.errors.storeName
                                ? 'border-red-500 focus:ring-red-100'
                                : 'border-gray-200 focus:border-brand-black focus:ring-brand-mint'
                            }`}
                            {...register('storeName')}
                          />
                          {formState.errors.storeName ? (
                            <p id={errorId} role="alert" className="mt-2 text-sm text-red-600">
                              {t(formState.errors.storeName.message ?? '')}
                            </p>
                          ) : null}
                        </>
                      ) : null}

                      {current.kind === 'toggle' ? (
                        <>
                          <h2 id={titleId} className="pr-10 text-xl font-bold tracking-tight text-brand-black">
                            {t(current.label)}
                          </h2>
                          {current.sublabel ? (
                            <p id={sublabelId} className="mt-2 text-sm text-gray-700">
                              {current.sublabel ? t(current.sublabel) : null}
                            </p>
                          ) : null}
                          <div className="mt-8">
                            <Controller
                              control={control}
                              name={`modules.${current.module}`}
                              render={({ field }) => (
                                <ToggleSwitch
                                  size="lg"
                                  checked={field.value}
                                  onChange={field.onChange}
                                  label={t(current.switchLabel)}
                                  describedBy={current.sublabel ? sublabelId : undefined}
                                />
                              )}
                            />
                          </div>
                        </>
                      ) : null}

                      {current.kind === 'charts' ? (
                        <fieldset aria-describedby={chartsError || modulesError ? errorId : undefined}>
                          <legend id={titleId} className="pr-10 text-xl font-bold tracking-tight text-brand-black">
                            {t(current.label)}
                          </legend>
                          <p id={sublabelId} className="mt-2 text-sm text-gray-700">
                            {current.sublabel ? t(current.sublabel) : null}
                          </p>
                          <Controller
                            control={control}
                            name="analyticsCharts"
                            render={({ field }) => (
                              <div className="mt-5 grid grid-cols-3 gap-3">
                                {CHART_OPTIONS.map(({ value, label, icon: Icon }) => {
                                  const selected = field.value.includes(value);
                                  return (
                                    <label
                                      key={value}
                                      className={`group relative flex min-h-[112px] cursor-pointer flex-col items-center justify-center gap-2 rounded-xl border-2 p-3 text-center transition-colors duration-150 has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-brand-green-dark has-[:focus-visible]:ring-offset-2 ${
                                        selected
                                          ? 'border-brand-green bg-brand-mint'
                                          : 'border-gray-200 bg-white hover:border-brand-black'
                                      }`}
                                    >
                                      <input
                                        type="checkbox"
                                        className="sr-only"
                                        checked={selected}
                                        onBlur={field.onBlur}
                                        onChange={(event) =>
                                          field.onChange(
                                            event.target.checked
                                              ? [...field.value, value]
                                              : field.value.filter((kind) => kind !== value),
                                          )
                                        }
                                      />
                                      <Icon
                                        className={`h-7 w-7 ${selected ? 'text-brand-green-dark' : 'text-brand-black'}`}
                                        aria-hidden="true"
                                      />
                                      <span className="text-sm font-semibold text-brand-black">{t(label)}</span>
                                      <span
                                        aria-hidden="true"
                                        className={`absolute right-2 top-2 h-4 w-4 rounded border-2 ${
                                          selected ? 'border-brand-green-dark bg-brand-green-dark' : 'border-gray-300 bg-white'
                                        }`}
                                      />
                                    </label>
                                  );
                                })}
                              </div>
                            )}
                          />
                          {chartsError || modulesError ? (
                            <p id={errorId} role="alert" className="mt-3 text-sm text-red-600">
                              {t(chartsError ?? modulesError ?? '')}
                            </p>
                          ) : null}
                        </fieldset>
                      ) : null}

                      {current.kind === 'prompt' ? (
                        <>
                          <label id={titleId} htmlFor={websitePromptId} className="block pr-10 text-xl font-bold tracking-tight text-brand-black">
                            {t(current.label)}
                          </label>
                          {storefrontEnabled ? (
                            <>
                              <p id={sublabelId} className="mt-2 text-sm text-gray-700">
                                {current.sublabel ? t(current.sublabel) : null}
                              </p>
                              <textarea
                                id={websitePromptId}
                                rows={5}
                                maxLength={WEBSITE_PROMPT_MAX}
                                placeholder={t('e.g. A friendly neighbourhood bike workshop. Warm, down-to-earth tone. Highlight same-day repairs, quality parts and our love of cycling.')}
                                aria-invalid={websitePromptError ? true : undefined}
                                aria-describedby={`${sublabelId} ${websitePromptError ? errorId : ''}`.trim()}
                                className={`mt-4 block w-full resize-none rounded-xl border-2 bg-white px-4 py-3 text-base text-brand-black placeholder:text-gray-400 focus:outline-none focus:ring-4 ${
                                  websitePromptError
                                    ? 'border-red-500 focus:ring-red-100'
                                    : 'border-gray-200 focus:border-brand-black focus:ring-brand-mint'
                                }`}
                                {...register('websitePrompt')}
                              />
                              <div className="mt-2 flex items-start justify-between gap-3">
                                {websitePromptError ? (
                                  <p id={errorId} role="alert" className="text-sm text-red-600">
                                    {t(websitePromptError)}
                                  </p>
                                ) : (
                                  <span />
                                )}
                                <span className="shrink-0 text-xs tabular-nums text-gray-500">
                                  {websitePromptLength}/{WEBSITE_PROMPT_MAX}
                                </span>
                              </div>
                            </>
                          ) : (
                            <p id={sublabelId} className="mt-3 rounded-xl bg-gray-50 p-4 text-sm text-gray-700">
                              {t('Storefront is turned off, so this store has no public website. The AI will build the admin dashboard only — go back to step 2 to add a website.')}
                            </p>
                          )}
                        </>
                      ) : null}
                    </motion.div>
                  </AnimatePresence>
                </div>

                <p aria-live="polite" className="sr-only">
                  {isSubmitting ? t('AI is designing your website & dashboard (2–3 min)…') : ''}
                </p>

                {step < TOTAL_STEPS ? (
                  <div className="mt-6 flex items-center justify-between gap-3">
                    <Button variant="ghost" onClick={() => goTo(step - 1)} disabled={step === 1} leftIcon={<ArrowLeft className="h-4 w-4" aria-hidden="true" />}>
                      {t('Back')}
                    </Button>
                    <Button type="submit">
                      {t('Continue')} <ArrowRight className="-mr-1 inline h-4 w-4" aria-hidden="true" />
                    </Button>
                  </div>
                ) : (
                  <div className="mt-6 space-y-3">
                    {isSubmitting ? (
                      <div className="flex min-h-[48px] w-full items-center justify-center gap-3 rounded-xl bg-brand-mint text-sm font-semibold text-brand-green-dark">
                        <Spinner className="h-5 w-5" />
                        {t('AI is designing your website & dashboard (2–3 min)…')}
                      </div>
                    ) : (
                      <Button
                        type="submit"
                        fullWidth
                        className="min-h-[48px] motion-safe:hover:animate-pulse"
                        leftIcon={<Zap className="h-4 w-4" aria-hidden="true" />}
                      >
                        {t('Create website & dashboard with AI')}
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      fullWidth
                      onClick={() => goTo(step - 1)}
                      disabled={isSubmitting}
                      leftIcon={<ArrowLeft className="h-4 w-4" aria-hidden="true" />}
                    >
                      {t('Back')}
                    </Button>
                  </div>
                )}
              </form>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}
