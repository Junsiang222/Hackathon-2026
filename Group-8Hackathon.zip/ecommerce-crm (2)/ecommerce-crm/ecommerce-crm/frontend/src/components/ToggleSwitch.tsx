import { useT } from '@/i18n';
import { motion } from 'framer-motion';

export interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  /** Accessible name, e.g. "Enable Storefront". */
  label: string;
  /** id of an element that describes the switch (sublabel). */
  describedBy?: string;
  disabled?: boolean;
  size?: 'md' | 'lg';
}

const SIZES = {
  md: { track: 'h-7 w-12', thumb: 'h-5 w-5', travel: 20 },
  lg: { track: 'h-10 w-[4.5rem]', thumb: 'h-8 w-8', travel: 32 },
} as const;

export function ToggleSwitch({ checked, onChange, label, describedBy, disabled = false, size = 'lg' }: ToggleSwitchProps) {
  const t = useT();
  const dims = SIZES[size];

  return (
    <div className="inline-flex items-center gap-3">
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        aria-label={label}
        aria-describedby={describedBy}
        disabled={disabled}
        onClick={() => onChange(!checked)}
        className={[
          'relative inline-flex shrink-0 cursor-pointer items-center rounded-full p-1 transition-colors duration-200',
          'disabled:cursor-not-allowed disabled:opacity-50',
          checked ? 'bg-brand-green' : 'bg-gray-300',
          dims.track,
        ].join(' ')}
      >
        <motion.span
          aria-hidden="true"
          className={`block rounded-full bg-white shadow-md ${dims.thumb}`}
          initial={false}
          animate={{ x: checked ? dims.travel : 0 }}
          transition={{ type: 'spring', stiffness: 500, damping: 32 }}
        />
      </button>
      {/* Text state so on/off never relies on colour alone. */}
      <span aria-hidden="true" className={`text-sm font-semibold ${checked ? 'text-brand-green-dark' : 'text-gray-500'}`}>
        {checked ? t('On') : t('Off')}
      </span>
    </div>
  );
}
