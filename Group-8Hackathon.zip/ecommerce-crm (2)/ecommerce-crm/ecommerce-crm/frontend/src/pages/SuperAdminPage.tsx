import { Building2, CheckCircle2, Clock, LayoutTemplate, Trash2, Zap, type LucideIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { DashboardGeneratorModal } from '@/components/DashboardGeneratorModal';
import { LayoutWidgetGrid } from '@/components/LayoutWidgetGrid';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { Button } from '@/components/ui/Button';
import { CredentialsCard } from '@/components/ui/CopyButton';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useRemoveTenant, useTenants } from '@/hooks/useDashboard';
import { getApiErrorMessage } from '@/lib/axios';
import type { Tenant } from '@/types/api.types';
import type { GeneratedLayout } from '@/types/dashboard.types';
import { capitalize, useT } from '@/i18n';
import { formatDateTime, formatInteger } from '@/utils/format';

function StatTile({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-mint">
          <Icon className="h-5 w-5 text-brand-green-dark" aria-hidden="true" />
        </span>
        <p className="text-sm font-medium text-gray-700">{label}</p>
      </div>
      <p className="mt-3 text-3xl font-bold tabular-nums tracking-tight text-brand-black">{formatInteger(value)}</p>
    </div>
  );
}

function isInTrial(tenant: Tenant): boolean {
  return tenant.trialEndsAt !== null && new Date(tenant.trialEndsAt).getTime() > Date.now();
}

function GeneratedLayoutPreview({ storeName, layout }: { storeName: string; layout: GeneratedLayout }) {
  const t = useT();
  return (
    <section aria-labelledby="generated-layout-heading" className="mt-10">
      <div className="mb-4">
        <h2 id="generated-layout-heading" className="text-lg font-bold tracking-tight text-brand-black">
          {t('Latest generated layout')} · {storeName}
        </h2>
        <p className="text-sm text-gray-700">
          {t('The website and admin dashboard for this store are ready (layout #{id}). The store has moved to', { id: layout.layoutId })}{' '}
          <Link to="/dashboard/websites" className="font-semibold text-brand-green-dark underline underline-offset-2">
            {t('Websites')}
          </Link>
          .
          {layout.adminLogin ? (
            <>
              {' '}
              {t('Admin login:')} <span className="font-mono font-semibold text-brand-black">{layout.adminLogin.email}</span>.
            </>
          ) : null}
        </p>
      </div>
      <LayoutWidgetGrid widgets={layout.config} />
    </section>
  );
}

interface SuperAdminPageProps {
  /** 'stores' shows only the tenant directory. */
  view?: 'overview' | 'stores';
}

export function SuperAdminPage({ view = 'overview' }: SuperAdminPageProps) {
  const tenantsQuery = useTenants();
  const [generatorTenant, setGeneratorTenant] = useState<Tenant | null>(null);
  const [lastGenerated, setLastGenerated] = useState<{ storeName: string; layout: GeneratedLayout } | null>(null);
  const [credentialsOpen, setCredentialsOpen] = useState(false);
  const [removing, setRemoving] = useState<Tenant | null>(null);
  const remove = useRemoveTenant();
  const t = useT();

  const onRemove = () => {
    if (!removing) return;
    remove.mutate(removing.id, {
      onSuccess: () => {
        toast.success(t('{name} removed', { name: removing.businessName }));
        setRemoving(null);
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });
  };

  const tenants = tenantsQuery.data ?? [];
  // Stores with a dashboard live on the Websites page, so none get a duplicate. Removed stores are hidden.
  const pendingTenants = useMemo(
    () => tenants.filter((tenant) => tenant.layoutCount === 0 && tenant.status !== 'cancelled'),
    [tenants],
  );
  const stats = useMemo(
    () => ({
      total: tenants.length,
      active: tenants.filter((tenant) => tenant.status === 'active').length,
      trial: tenants.filter(isInTrial).length,
      layouts: tenants.reduce((sum, tenant) => sum + tenant.layoutCount, 0),
    }),
    [tenants],
  );

  if (tenantsQuery.isPending) return <LoadingShimmer rows={4} />;
  if (tenantsQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(tenantsQuery.error)}
        onRetry={() => tenantsQuery.refetch()}
        isRetrying={tenantsQuery.isFetching}
      />
    );
  }

  return (
    <div className="mx-auto max-w-7xl">
      {view === 'overview' ? (
        <section aria-label={t('Platform summary')} className="mb-10 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatTile icon={Building2} label={t('Tenants')} value={stats.total} />
          <StatTile icon={Zap} label={t('Active')} value={stats.active} />
          <StatTile icon={Clock} label={t('In trial')} value={stats.trial} />
          <StatTile icon={LayoutTemplate} label={t('Dashboards generated')} value={stats.layouts} />
        </section>
      ) : null}

      <section aria-labelledby="tenants-heading">
        <div className="mb-4">
          <h2 id="tenants-heading" className="text-lg font-bold tracking-tight text-brand-black">
            {t('Tenant workspaces')}
          </h2>
          <p className="text-sm text-gray-700">
            {t('Stores waiting for their website and admin dashboard. Finished stores move to')}{' '}
            <Link to="/dashboard/websites" className="font-semibold text-brand-green-dark underline underline-offset-2">
              {t('Websites')}
            </Link>
            .
          </p>
        </div>

        {tenants.length === 0 ? (
          <EmptyState
            icon={Building2}
            title={t('No tenants yet')}
            description={t('Workspaces appear here as merchants sign up.')}
          />
        ) : pendingTenants.length === 0 ? (
          <EmptyState
            icon={CheckCircle2}
            title={t('Every store has a dashboard')}
            description={t('New stores appear here as merchants sign up. Finished stores are in Websites.')}
          />
        ) : (
          <div className="overflow-x-auto rounded-2xl border border-gray-100 bg-white shadow-sm">
            <table className="w-full min-w-[760px] text-left text-sm">
              <caption className="sr-only">{t('Tenant workspaces')}</caption>
              <thead className="border-b border-gray-100 text-xs uppercase tracking-wide text-gray-500">
                <tr>
                  <th scope="col" className="px-5 py-3 font-semibold">
                    {t('Store')}
                  </th>
                  <th scope="col" className="px-5 py-3 font-semibold">
                    {t('Plan')}
                  </th>
                  <th scope="col" className="px-5 py-3 font-semibold">
                    {t('Status')}
                  </th>
                  <th scope="col" className="px-5 py-3 font-semibold">
                    {t('Registered')}
                  </th>
                  <th scope="col" className="px-5 py-3 text-right font-semibold">
                    {t('Layouts')}
                  </th>
                  <th scope="col" className="px-5 py-3 text-right font-semibold">
                    <span className="sr-only">{t('Actions')}</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {pendingTenants.map((tenant) => (
                  <tr key={tenant.id} className="hover:bg-gray-50">
                    <td className="px-5 py-4">
                      <p className="font-semibold text-brand-black">{tenant.businessName}</p>
                      <p className="text-xs capitalize text-gray-500">{t(capitalize(tenant.industry))}</p>
                    </td>
                    <td className="px-5 py-4 capitalize text-gray-700">
                      {t(capitalize(tenant.plan))}
                      {isInTrial(tenant) ? (
                        <span className="ml-2 rounded-full border border-gray-200 px-2 py-0.5 text-xs text-gray-700">
                          {t('trial')}
                        </span>
                      ) : null}
                    </td>
                    <td className="px-5 py-4">
                      <StatusBadge status={tenant.status} color={tenant.statusColor} />
                    </td>
                    <td className="whitespace-nowrap px-5 py-4 text-gray-700">{formatDateTime(tenant.registeredAt)}</td>
                    <td className="px-5 py-4 text-right tabular-nums text-gray-700">
                      {formatInteger(tenant.layoutCount)}
                    </td>
                    <td className="px-5 py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button
                          variant="dark"
                          className="whitespace-nowrap"
                          onClick={() => setGeneratorTenant(tenant)}
                          leftIcon={<Zap className="h-4 w-4 text-brand-green" aria-hidden="true" />}
                          aria-label={t('Create website with admin dashboard for {name}', { name: tenant.businessName })}
                        >
                          {t('Create Website with Admin Dashboard')}
                        </Button>
                        <button
                          type="button"
                          onClick={() => setRemoving(tenant)}
                          aria-label={t('Remove {name}', { name: tenant.businessName })}
                          title={t('Remove store')}
                          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-gray-500 hover:bg-red-50 hover:text-red-600"
                        >
                          <Trash2 className="h-5 w-5" aria-hidden="true" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {lastGenerated ? (
        <GeneratedLayoutPreview storeName={lastGenerated.storeName} layout={lastGenerated.layout} />
      ) : null}

      {/* One-time credentials for the store's new admin login. */}
      <Modal
        open={credentialsOpen && Boolean(lastGenerated?.layout.adminLogin?.temporaryPassword)}
        title={t('Website created')}
        description={t('Admin login for {name}', { name: lastGenerated?.storeName ?? t('the store') })}
        onClose={() => setCredentialsOpen(false)}
        footer={
          <Button variant="dark" onClick={() => setCredentialsOpen(false)}>
            {t("I've saved them")}
          </Button>
        }
      >
        {lastGenerated?.layout.adminLogin?.temporaryPassword ? (
          <CredentialsCard
            email={lastGenerated.layout.adminLogin.email}
            password={lastGenerated.layout.adminLogin.temporaryPassword}
          />
        ) : null}
      </Modal>

      <Modal
        open={removing !== null}
        title={t('Remove {name}?', { name: removing?.businessName ?? t('store') })}
        onClose={() => setRemoving(null)}
        footer={
          <>
            <Button variant="outline" onClick={() => setRemoving(null)}>
              {t('Cancel')}
            </Button>
            <Button
              variant="danger"
              onClick={onRemove}
              loading={remove.isPending}
              leftIcon={<Trash2 className="h-4 w-4" aria-hidden="true" />}
            >
              {t('Remove store')}
            </Button>
          </>
        }
      >
        <ul className="list-disc space-y-1 pl-5 text-sm text-gray-700">
          <li>{t('The store leaves this list and no website or dashboard can be created for it.')}</li>
          <li>{t("Any store admin and staff logins are signed out and can't log in.")}</li>
          <li>{t('Orders and customer records are kept, not deleted.')}</li>
        </ul>
      </Modal>

      <DashboardGeneratorModal
        open={generatorTenant !== null}
        tenant={generatorTenant}
        onClose={() => setGeneratorTenant(null)}
        onLayoutGenerated={(layout) => {
          setLastGenerated({ storeName: generatorTenant?.businessName ?? 'Store', layout });
          setCredentialsOpen(true);
        }}
      />
    </div>
  );
}
