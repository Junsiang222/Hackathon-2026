import { zodResolver } from '@hookform/resolvers/zod';
import { CheckCircle2, Globe2, KeyRound, Server, Store, XCircle, type LucideIcon } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { Button } from '@/components/ui/Button';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { SelectField } from '@/components/ui/FormFields';
import { TextField } from '@/components/ui/TextField';
import {
  STORE_CURRENCIES,
  useChangeOwnPassword,
  useSavePlatformSettings,
  useSavePreferences,
  useSettings,
  useSystemStatus,
  useSystemTest,
  type PlatformSettings,
  type TestResult,
} from '@/hooks/useSettings';
import { LANGUAGES, usePreferencesStore, useT, type Preferences, type TFunction } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';

function Card({ icon: Icon, title, description, children }: { icon: LucideIcon; title: string; description: string; children: ReactNode }) {
  return (
    <section className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
      <div className="mb-5 flex items-start gap-3">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-mint">
          <Icon className="h-5 w-5 text-brand-green-dark" aria-hidden="true" />
        </span>
        <div>
          <h2 className="text-lg font-bold tracking-tight text-brand-black">{title}</h2>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
      </div>
      {children}
    </section>
  );
}

// ─── Language & display (saved as soon as it changes) ────────────────────────

function DisplaySettings({ preferences, t }: { preferences: Preferences; t: TFunction }) {
  const save = useSavePreferences();
  const update = (changes: Partial<Preferences>) =>
    save.mutate(changes, {
      onSuccess: () => toast.success(t('Saved')),
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });

  return (
    <Card icon={Globe2} title={t('Language & display')} description={t('Applies to your account on any device.')}>
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectField
          label={t('Dashboard language')}
          hint={t('The AI assistant and alerts also answer in this language.')}
          value={preferences.language}
          options={LANGUAGES.map((option) => ({ value: option.value, label: option.label }))}
          onChange={(event) => update({ language: event.target.value as Preferences['language'] })}
          disabled={save.isPending}
        />
        <SelectField
          label={t('Show times in')}
          value={preferences.timeDisplay}
          options={[
            { value: 'local', label: t('My local time') },
            { value: 'utc', label: t('UTC') },
          ]}
          onChange={(event) => update({ timeDisplay: event.target.value as Preferences['timeDisplay'] })}
          disabled={save.isPending}
        />
        <SelectField
          label={t('Default analytics period')}
          value={preferences.defaultPeriod}
          options={[
            { value: 'today', label: t('Today') },
            { value: '7d', label: t('7 days') },
            { value: '30d', label: t('30 days') },
            { value: 'month', label: t('This month') },
            { value: '90d', label: t('90 days') },
          ]}
          onChange={(event) => update({ defaultPeriod: event.target.value as Preferences['defaultPeriod'] })}
          disabled={save.isPending}
        />
        <SelectField
          label={t('Refresh analytics')}
          value={String(preferences.refreshSeconds)}
          options={[
            { value: '30', label: t('Every 30 seconds') },
            { value: '60', label: t('Every minute') },
            { value: '300', label: t('Every 5 minutes') },
            { value: '0', label: t('Off (refresh manually)') },
          ]}
          onChange={(event) => update({ refreshSeconds: Number(event.target.value) as Preferences['refreshSeconds'] })}
          disabled={save.isPending}
        />
      </div>
    </Card>
  );
}

// ─── Website builder (platform-wide, explicit Save) ──────────────────────────

const CURRENCY_LABELS: Record<string, string> = {
  USD: 'USD — US dollar',
  MYR: 'MYR — Malaysian ringgit',
  SGD: 'SGD — Singapore dollar',
  IDR: 'IDR — Indonesian rupiah',
  THB: 'THB — Thai baht',
  PHP: 'PHP — Philippine peso',
  EUR: 'EUR — Euro',
  GBP: 'GBP — British pound',
  AUD: 'AUD — Australian dollar',
};

function WebsiteSettings({ platform, t }: { platform: PlatformSettings; t: TFunction }) {
  const [draft, setDraft] = useState(platform);
  useEffect(() => setDraft(platform), [platform]);
  const save = useSavePlatformSettings();
  const changed = draft.websiteLanguage !== platform.websiteLanguage || draft.storeCurrency !== platform.storeCurrency;

  return (
    <Card
      icon={Store}
      title={t('Website builder')}
      description={t('Applies to every store on the platform.')}
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <SelectField
          label={t('Language of AI-generated websites')}
          hint={t('Used for new and regenerated websites. Existing websites keep their text until regenerated.')}
          value={draft.websiteLanguage}
          options={LANGUAGES.map((option) => ({ value: option.value, label: option.label }))}
          onChange={(event) => setDraft((current) => ({ ...current, websiteLanguage: event.target.value as PlatformSettings['websiteLanguage'] }))}
        />
        <SelectField
          label={t('Store currency')}
          hint={t('Shown on every storefront and saved on new orders. Prices are not converted.')}
          value={draft.storeCurrency}
          options={STORE_CURRENCIES.map((code) => ({ value: code, label: CURRENCY_LABELS[code] ?? code }))}
          onChange={(event) => setDraft((current) => ({ ...current, storeCurrency: event.target.value as PlatformSettings['storeCurrency'] }))}
        />
      </div>
      <div className="mt-5 flex justify-end gap-2">
        <Button variant="outline" disabled={!changed || save.isPending} onClick={() => setDraft(platform)}>
          {t('Cancel')}
        </Button>
        <Button
          variant="dark"
          disabled={!changed}
          loading={save.isPending}
          onClick={() =>
            save.mutate(draft, {
              onSuccess: () => toast.success(t('Website settings saved for all stores')),
              onError: (error) => toast.error(getApiErrorMessage(error)),
            })
          }
        >
          {t('Save changes')}
        </Button>
      </div>
    </Card>
  );
}

// ─── Account & security ──────────────────────────────────────────────────────

/** The name shown in the profile menu. Empty = use the email's name. */
function DisplayNameForm({ t }: { t: TFunction }) {
  const saved = usePreferencesStore((state) => state.displayName);
  const [draft, setDraft] = useState(saved ?? '');
  useEffect(() => setDraft(saved ?? ''), [saved]);
  const save = useSavePreferences();
  const next = draft.trim().replace(/\s+/g, ' ');
  const changed = next !== (saved ?? '');

  return (
    <form
      noValidate
      className="flex flex-col gap-3 sm:flex-row sm:items-end"
      onSubmit={(event) => {
        event.preventDefault();
        if (!changed) return;
        save.mutate(
          { displayName: next || null },
          {
            onSuccess: () => toast.success(next ? t('Name updated') : t('Name reset to your email')),
            onError: (error) => toast.error(getApiErrorMessage(error)),
          },
        );
      }}
    >
      <div className="flex-1">
        <TextField
          label={t('Display name')}
          hint={t('Shown in your profile menu. Leave empty to use your email.')}
          maxLength={60}
          value={draft}
          placeholder={t('Your name')}
          onChange={(event) => setDraft(event.target.value)}
        />
      </div>
      <Button variant="dark" type="submit" disabled={!changed} loading={save.isPending} className="sm:mb-6">
        {t('Save name')}
      </Button>
    </form>
  );
}

function AccountSettings({ t }: { t: TFunction }) {
  const email = useAuthStore((state) => state.user?.email ?? '');
  const change = useChangeOwnPassword();
  const schema = z
    .object({
      currentPassword: z.string().min(1, t('Enter your current password')),
      newPassword: z
        .string()
        .min(12, t('At least 12 characters'))
        .refine((value) => /[a-z]/.test(value) && /[A-Z]/.test(value) && /\d/.test(value), {
          message: t('Use upper-case, lower-case and a number'),
        }),
      confirmPassword: z.string(),
    })
    .refine((values) => values.newPassword === values.confirmPassword, {
      path: ['confirmPassword'],
      message: t("Passwords don't match"),
    });
  type Values = z.infer<typeof schema>;
  const { register, handleSubmit, reset, setError, formState } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { currentPassword: '', newPassword: '', confirmPassword: '' },
  });
  const { errors } = formState;

  const onSubmit = handleSubmit(({ currentPassword, newPassword }) =>
    change.mutate(
      { currentPassword, newPassword },
      {
        onSuccess: () => {
          toast.success(t('Password changed'));
          reset();
        },
        onError: (error) => {
          const message = getApiErrorMessage(error);
          if (/current password/i.test(message)) setError('currentPassword', { message: t('Your current password is not correct') });
          else toast.error(message);
        },
      },
    ),
  );

  return (
    <Card icon={KeyRound} title={t('Account & security')} description={t('Your super admin login.')}>
      <p className="mb-4 text-sm text-gray-700">
        {t('Signed in as')} <span className="font-mono font-semibold text-brand-black">{email}</span>
      </p>
      <DisplayNameForm t={t} />
      <h3 className="mb-3 mt-6 text-sm font-semibold text-brand-black">{t('Change password')}</h3>
      <form onSubmit={onSubmit} noValidate className="grid gap-4 sm:grid-cols-3">
        <TextField
          label={t('Current password')}
          type="password"
          autoComplete="current-password"
          error={errors.currentPassword?.message}
          {...register('currentPassword')}
        />
        <TextField
          label={t('New password')}
          type="password"
          autoComplete="new-password"
          hint={t('At least 12 characters, with upper-case, lower-case and a number')}
          error={errors.newPassword?.message}
          {...register('newPassword')}
        />
        <TextField
          label={t('Confirm new password')}
          type="password"
          autoComplete="new-password"
          error={errors.confirmPassword?.message}
          {...register('confirmPassword')}
        />
        <div className="sm:col-span-3 flex justify-end">
          <Button variant="dark" type="submit" loading={change.isPending}>
            {t('Change password')}
          </Button>
        </div>
      </form>
    </Card>
  );
}

// ─── System status ───────────────────────────────────────────────────────────

function StatusRow({
  label,
  ok,
  detail,
  action,
  result,
}: {
  label: string;
  ok: boolean | null;
  detail: string;
  action?: ReactNode;
  result?: TestResult | null;
}) {
  return (
    <li className="flex flex-wrap items-center gap-3 py-3">
      {ok === null ? (
        <span className="h-5 w-5 rounded-full border-2 border-gray-300" aria-hidden="true" />
      ) : ok ? (
        <CheckCircle2 className="h-5 w-5 text-green-600" aria-hidden="true" />
      ) : (
        <XCircle className="h-5 w-5 text-red-600" aria-hidden="true" />
      )}
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-brand-black">{label}</p>
        <p className="text-xs text-gray-600">{detail}</p>
        {result ? (
          <p className={`mt-1 text-xs font-medium ${result.ok ? 'text-green-700' : 'text-red-700'}`}>
            {result.message}
            {result.ms !== undefined ? ` (${(result.ms / 1000).toFixed(1)} s)` : ''}
          </p>
        ) : null}
      </div>
      {action}
    </li>
  );
}

function SystemSettings({ t }: { t: TFunction }) {
  const status = useSystemStatus();
  const aiTest = useSystemTest('ai');
  const photoTest = useSystemTest('photos');

  if (status.isPending) return <LoadingShimmer rows={2} />;
  if (status.isError) {
    return <ErrorPlaceholder message={getApiErrorMessage(status.error)} onRetry={() => status.refetch()} isRetrying={status.isFetching} />;
  }
  const { database, ai, photos } = status.data;
  const quota =
    photos.provider === null
      ? t('No photo key is set')
      : photos.paused
        ? t('Hourly limit used up; resumes automatically')
        : photos.remaining === null
          ? t('{provider} · searches left this hour: not known yet', { provider: photos.provider })
          : t('{provider} · {count} searches left this hour', { provider: photos.provider, count: photos.remaining });

  return (
    <Card icon={Server} title={t('System status')} description={t('Check the services the platform depends on.')}>
      <ul className="divide-y divide-gray-100">
        <StatusRow
          label={t('Database')}
          ok={database.ok}
          detail={database.ok ? t('Connected ({ms} ms)', { ms: database.ms }) : t('Not reachable')}
        />
        <StatusRow
          label={t('AI model')}
          ok={aiTest.data ? aiTest.data.ok : null}
          detail={`${ai.model} · ${ai.host}`}
          result={aiTest.data ?? null}
          action={
            <Button variant="outline" className="min-h-[36px] px-3 text-xs" loading={aiTest.isPending} onClick={() => aiTest.mutate()}>
              {t('Test')}
            </Button>
          }
        />
        <StatusRow
          label={t('Website photos')}
          ok={photoTest.data ? photoTest.data.ok : photos.provider === null ? false : photos.paused ? false : null}
          detail={quota}
          result={photoTest.data ?? null}
          action={
            <Button variant="outline" className="min-h-[36px] px-3 text-xs" loading={photoTest.isPending} onClick={() => photoTest.mutate()}>
              {t('Test')}
            </Button>
          }
        />
      </ul>
    </Card>
  );
}

export function SettingsPage() {
  const t = useT();
  const settings = useSettings();

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-brand-black">{t('Settings')}</h1>
        <p className="mt-1 text-sm text-gray-600">{t('Your dashboard preferences and platform-wide options.')}</p>
      </div>
      {settings.isPending ? (
        <LoadingShimmer rows={4} />
      ) : settings.isError ? (
        <ErrorPlaceholder message={getApiErrorMessage(settings.error)} onRetry={() => settings.refetch()} isRetrying={settings.isFetching} />
      ) : (
        <>
          <DisplaySettings preferences={settings.data.preferences} t={t} />
          <WebsiteSettings platform={settings.data.platform} t={t} />
        </>
      )}
      <AccountSettings t={t} />
      <SystemSettings t={t} />
    </div>
  );
}
