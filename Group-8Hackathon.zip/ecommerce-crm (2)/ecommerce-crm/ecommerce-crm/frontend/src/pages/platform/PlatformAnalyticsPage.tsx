import { BarChart3, ChevronRight, Lock, RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { AnalyticsAssistantLauncher } from '@/components/platform/AnalyticsAssistant';
import {
  ChangeBadge,
  DownloadPdfButton,
  InsightList,
  KpiCard,
  PeriodPicker,
  STORE_DASHES,
  STORE_PALETTE,
  formatPercent,
  percentChange,
} from '@/components/platform/AnalyticsParts';
import { AXIS_TICK, GRID_STROKE } from '@/components/charts/chartTheme';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { useAnalyticsOverview, usePeriod, useStoreAnalytics } from '@/hooks/usePlatformAnalytics';
import { capitalize, usePreferencesStore, useT, type TFunction } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import type { Insight, PeriodRange, StoreMetrics, StoreOverview } from '@/types/platformAnalytics.types';
import { formatInteger, formatShortDate } from '@/utils/format';

const sum = (stores: StoreOverview[], pick: (metrics: StoreMetrics) => number, period: 'current' | 'previous') =>
  stores.reduce((acc, store) => acc + pick(store[period]), 0);

/** Orders that weren't cancelled or refunded, per page view. */
const conversion = (m: StoreMetrics) => (m.pageViews > 0 ? (m.orders - m.cancelledOrRefunded) / m.pageViews : null);
const cancelRate = (m: StoreMetrics) => (m.orders > 0 ? m.cancelledOrRefunded / m.orders : null);

function PlatformTotals({ stores }: { stores: StoreOverview[] }) {
  const t = useT();
  const tile = (label: string, pick: (m: StoreMetrics) => number) => {
    const now = sum(stores, pick, 'current');
    return <KpiCard label={label} value={formatInteger(now)} change={percentChange(now, sum(stores, pick, 'previous'))} />;
  };
  const views = sum(stores, (m) => m.pageViews, 'current');
  const valid = sum(stores, (m) => m.orders - m.cancelledOrRefunded, 'current');
  const viewsBefore = sum(stores, (m) => m.pageViews, 'previous');
  const validBefore = sum(stores, (m) => m.orders - m.cancelledOrRefunded, 'previous');
  const conv = views ? valid / views : null;
  const convBefore = viewsBefore ? validBefore / viewsBefore : null;
  return (
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
      {tile(t('Orders, all stores'), (m) => m.orders)}
      {tile(t('Units sold'), (m) => m.unitsSold)}
      {tile(t('New customers'), (m) => m.newCustomers)}
      <KpiCard
        label={t('Conversion')}
        value={formatPercent(conv, 2)}
        change={conv !== null && convBefore ? percentChange(conv, convBefore) : null}
        hint={t('orders ÷ visits')}
      />
    </div>
  );
}

function StoreTable({
  stores,
  selected,
  onSelect,
  search,
}: {
  stores: StoreOverview[];
  selected: number | null;
  onSelect: (tenantId: number) => void;
  search: string;
}) {
  const t = useT();
  return (
    <div className="overflow-x-auto rounded-2xl border border-gray-100 bg-white shadow-sm">
      <table className="w-full min-w-[920px] text-sm">
        <caption className="sr-only">{t('Store overview for the selected period')}</caption>
        <thead>
          <tr className="border-b border-gray-100 text-left text-xs font-semibold uppercase tracking-wide text-gray-500">
            <th scope="col" className="px-4 py-3">
              {t('Show')}
            </th>
            <th scope="col" className="px-4 py-3">
              {t('Store')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Orders')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Units sold')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('New customers')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Conversion')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Cancelled')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Open tickets')}
            </th>
            <th scope="col" className="px-4 py-3 text-right">
              {t('Stock alerts')}
            </th>
            <th scope="col" className="px-4 py-3">
              <span className="sr-only">{t('Details')}</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {stores.map((store) => {
            const { current: now, previous: before } = store;
            const checked = selected === store.tenantId;
            return (
              <tr key={store.tenantId} className="border-b border-gray-50 last:border-0 hover:bg-gray-50">
                <td className="px-4 py-3">
                  <input
                    type="radio"
                    name="snapshot-store"
                    checked={checked}
                    onChange={() => onSelect(store.tenantId)}
                    aria-label={t('Show {name} below', { name: store.storeName })}
                    className="h-4 w-4 accent-brand-green"
                  />
                </td>
                <td className="min-w-[200px] px-4 py-3">
                  <Link
                    to={`/dashboard/platform-analytics/${store.tenantId}${search}`}
                    className="font-semibold text-brand-black hover:underline"
                  >
                    {store.storeName}
                  </Link>
                  <p className="text-xs capitalize text-gray-500">
                    {t(capitalize(store.industry))}
                    {store.status !== 'active' ? ` · ${t(capitalize(store.status))}` : ''}
                  </p>
                </td>
                <td className="px-4 py-3 text-right">
                  <p className="font-semibold tabular-nums">{formatInteger(now.orders)}</p>
                  <ChangeBadge value={percentChange(now.orders, before.orders)} />
                </td>
                <td className="px-4 py-3 text-right">
                  <p className="font-semibold tabular-nums">{formatInteger(now.unitsSold)}</p>
                  <ChangeBadge value={percentChange(now.unitsSold, before.unitsSold)} />
                </td>
                <td className="px-4 py-3 text-right">
                  <p className="font-semibold tabular-nums">{formatInteger(now.newCustomers)}</p>
                  <ChangeBadge value={percentChange(now.newCustomers, before.newCustomers)} />
                </td>
                <td className="px-4 py-3 text-right tabular-nums">{formatPercent(conversion(now), 2)}</td>
                <td className="px-4 py-3 text-right tabular-nums">{formatPercent(cancelRate(now), 0)}</td>
                <td className="px-4 py-3 text-right tabular-nums">
                  {store.openTickets}
                  {store.urgentTickets > 0 ? (
                    <span className="ml-1 rounded-full bg-red-50 px-1.5 py-0.5 text-xs font-semibold text-red-700">
                      {t('{count} urgent', { count: store.urgentTickets })}
                    </span>
                  ) : null}
                </td>
                <td className="px-4 py-3 text-right text-xs">
                  {store.outOfStock + store.lowStock === 0 ? (
                    <span className="text-gray-400">{t('None')}</span>
                  ) : (
                    <span className="whitespace-nowrap">
                      {store.outOfStock > 0 ? <span className="font-semibold text-red-700">{t('{count} out', { count: store.outOfStock })}</span> : null}
                      {store.outOfStock > 0 && store.lowStock > 0 ? ' · ' : ''}
                      {store.lowStock > 0 ? <span className="font-semibold text-amber-700">{t('{count} low', { count: store.lowStock })}</span> : null}
                    </span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <Link
                    to={`/dashboard/platform-analytics/${store.tenantId}${search}`}
                    aria-label={t('Open {name} analytics', { name: store.storeName })}
                    className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"
                  >
                    <ChevronRight className="h-4 w-4" aria-hidden="true" />
                  </Link>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function StoreSnapshot({
  store,
  insights,
  range,
  search,
}: {
  store: StoreOverview;
  insights: Insight[];
  range: PeriodRange;
  search: string;
}) {
  const detail = useStoreAnalytics(store.tenantId, range);
  const t = useT();
  const data = detail.data;

  const bars = [
    { metric: t('Orders'), pick: (m: StoreMetrics) => m.orders },
    { metric: t('Units sold'), pick: (m: StoreMetrics) => m.unitsSold },
    { metric: t('New customers'), pick: (m: StoreMetrics) => m.newCustomers },
    { metric: t('Buyers'), pick: (m: StoreMetrics) => m.buyers },
  ].map(({ metric, pick }) => ({ metric, current: pick(store.current), previous: pick(store.previous) }));

  const rates = [
    { label: t('Conversion (orders ÷ visits)'), value: formatPercent(data?.conversionRate ?? null, 2) },
    { label: t('Repeat buyers'), value: formatPercent(data?.retention.repeatRate ?? null, 0) },
    { label: t('Returning buyers'), value: formatPercent(data?.retention.returningRate ?? null, 0) },
    { label: t('Items per order'), value: data?.itemsPerOrder?.toFixed(2) ?? '—' },
    { label: t('Cancelled / refunded'), value: formatPercent(cancelRate(store.current), 0) },
    { label: t('Inventory turnover'), value: data?.inventory.turnover?.toFixed(2) ?? '—' },
    { label: t('Days of stock left'), value: data?.inventory.daysOfCover?.toString() ?? '—' },
  ];

  return (
    <section aria-labelledby="snapshot-heading" className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <h2 id="snapshot-heading" className="text-lg font-bold tracking-tight text-brand-black">
          {store.storeName}
        </h2>
        <div className="flex items-center gap-3">
          <Link
            to={`/dashboard/platform-analytics/${store.tenantId}${search}`}
            className="inline-flex items-center gap-1 text-sm font-semibold text-brand-green-dark hover:underline"
          >
            {t('Full breakdown')}
            <ChevronRight className="h-4 w-4" aria-hidden="true" />
          </Link>
          <DownloadPdfButton detail={data} insights={insights} range={range} />
        </div>
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold text-brand-black">{t('Key numbers vs previous period')}</h3>
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={bars} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID_STROKE} vertical={false} />
              <XAxis dataKey="metric" tick={AXIS_TICK} interval={0} tickLine={false} axisLine={{ stroke: GRID_STROKE }} />
              <YAxis tick={AXIS_TICK} tickFormatter={formatInteger} tickLine={false} axisLine={false} width={48} />
              <Tooltip cursor={{ fill: '#F0FDF4' }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="current" name={t('This period')} fill={STORE_PALETTE[0]} radius={[4, 4, 0, 0]} />
              <Bar dataKey="previous" name={t('Previous period')} fill="#BBF7D0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold text-brand-black">{t('Daily orders & units sold')}</h3>
          {detail.isPending ? (
            <LoadingShimmer rows={3} />
          ) : detail.isError ? (
            <ErrorPlaceholder
              message={getApiErrorMessage(detail.error)}
              onRetry={() => detail.refetch()}
              isRetrying={detail.isFetching}
              height={280}
            />
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={data?.trend ?? []} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={GRID_STROKE} />
                <XAxis dataKey="date" tick={AXIS_TICK} tickFormatter={formatShortDate} tickLine={false} minTickGap={24} />
                <YAxis tick={AXIS_TICK} tickFormatter={formatInteger} tickLine={false} axisLine={false} width={40} />
                <Tooltip labelFormatter={formatShortDate} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Line type="monotone" dataKey="orders" name={t('Orders')} stroke={STORE_PALETTE[0]} strokeWidth={2} dot={false} />
                <Line
                  type="monotone"
                  dataKey="unitsSold"
                  name={t('Units sold')}
                  stroke={STORE_PALETTE[1]}
                  strokeDasharray={STORE_DASHES[1]}
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <dl className="grid grid-cols-2 gap-3 md:grid-cols-4 xl:grid-cols-7">
        {rates.map((rate) => (
          <div key={rate.label} className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
            <dt className="text-xs font-medium text-gray-500">{rate.label}</dt>
            <dd className="mt-1 text-xl font-bold tabular-nums text-brand-black">{rate.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

/** "refreshes every minute" etc., following Settings → Refresh analytics. */
export function refreshLabel(seconds: number, t: TFunction): string {
  if (seconds === 0) return t('auto-refresh off');
  if (seconds === 30) return t('refreshes every 30 seconds');
  if (seconds === 300) return t('refreshes every 5 minutes');
  return t('refreshes every minute');
}

export function PlatformAnalyticsPage() {
  const { preset, range, setPreset, setCustom, search } = usePeriod();
  const query = useAnalyticsOverview(range);
  const [picked, setPicked] = useState<number | null>(null);
  const t = useT();
  const refreshSeconds = usePreferencesStore((state) => state.refreshSeconds);

  const stores = query.data?.stores ?? [];
  // One store at a time; until the admin picks, the first store with orders (or simply the first).
  const shown =
    stores.find((store) => store.tenantId === picked) ?? stores.find((store) => store.current.orders > 0) ?? stores[0] ?? null;

  return (
    <div className="w-full">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-brand-black">{t('Platform analytics')}</h1>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-gray-600">
            <Lock className="h-3.5 w-3.5" aria-hidden="true" />
            {t('Orders, customers, traffic and stock across all stores. Store finances stay private to each store.')}
          </p>
        </div>
        {query.dataUpdatedAt ? (
          <p className="flex items-center gap-1.5 text-xs text-gray-500">
            <RefreshCw className={`h-3.5 w-3.5 ${query.isFetching ? 'animate-spin' : ''}`} aria-hidden="true" />
            {t('Updated {time}', { time: new Date(query.dataUpdatedAt).toLocaleTimeString() })} · {refreshLabel(refreshSeconds, t)}
          </p>
        ) : null}
      </div>

      <div className="mb-5">
        <PeriodPicker preset={preset} range={range} onPreset={setPreset} onCustom={setCustom} />
      </div>

      <div className="min-w-0 space-y-6">
          {query.isPending ? (
            <LoadingShimmer rows={5} />
          ) : query.isError ? (
            <ErrorPlaceholder
              message={getApiErrorMessage(query.error)}
              onRetry={() => query.refetch()}
              isRetrying={query.isFetching}
            />
          ) : stores.length === 0 ? (
            <EmptyState icon={BarChart3} title={t('No stores yet')} description={t('Analytics appear once stores are created.')} />
          ) : (
            <>
              <PlatformTotals stores={stores} />

              {shown ? (
                <section aria-labelledby="insights-heading">
                  <h2 id="insights-heading" className="mb-3 text-lg font-bold tracking-tight text-brand-black">
                    {t('Alerts & recommendations')} <span className="font-normal text-gray-500">· {shown.storeName}</span>
                  </h2>
                  <InsightList insights={query.data.insights.filter((insight) => insight.tenantId === shown.tenantId)} />
                </section>
              ) : null}

              <section aria-labelledby="stores-heading">
                <h2 id="stores-heading" className="mb-1 text-lg font-bold tracking-tight text-brand-black">
                  {t('Stores')}
                </h2>
                <p className="mb-3 text-sm text-gray-600">
                  {t('Changes are against the previous period of the same length. Pick a store under Show to see its charts below.')}
                </p>
                <StoreTable stores={stores} selected={shown?.tenantId ?? null} onSelect={setPicked} search={search} />
              </section>

              {shown ? (
                <StoreSnapshot
                  store={shown}
                  insights={query.data.insights.filter((insight) => insight.tenantId === shown.tenantId)}
                  range={range}
                  search={search}
                />
              ) : null}
            </>
          )}
      </div>

      <AnalyticsAssistantLauncher range={range} />
    </div>
  );
}
