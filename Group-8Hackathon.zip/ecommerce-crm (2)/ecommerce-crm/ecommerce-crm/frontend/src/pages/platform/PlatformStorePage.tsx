import { ArrowLeft, ExternalLink, Lock, RefreshCw } from 'lucide-react';
import { Link, useParams } from 'react-router-dom';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  Legend,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { AXIS_TICK, GRID_STROKE } from '@/components/charts/chartTheme';
import {
  ChangeBadge,
  DownloadPdfButton,
  InsightList,
  KpiCard,
  PeakHeatmap,
  PeriodPicker,
  ProductList,
  formatPercent,
  percentChange,
} from '@/components/platform/AnalyticsParts';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { useAnalyticsOverview, usePeriod, useStoreAnalytics } from '@/hooks/usePlatformAnalytics';
import { capitalize, useT } from '@/i18n';
import { getApiErrorMessage } from '@/lib/axios';
import type { MonthComparisonValue } from '@/types/platformAnalytics.types';
import { formatInteger, formatShortDate } from '@/utils/format';

const monthLabel = (month: string) =>
  new Date(`${month}-01T00:00:00Z`).toLocaleDateString(undefined, { month: 'short', year: 'numeric', timeZone: 'UTC' });

function MonthCompare({ label, value }: { label: string; value: MonthComparisonValue }) {
  const t = useT();
  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
      <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{label}</p>
      <p className="mt-1.5 text-2xl font-bold tabular-nums text-brand-black">{formatInteger(value.value)}</p>
      <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
        <span className="text-xs text-gray-500">
          <ChangeBadge value={value.mom} label="MoM" /> ({t('was {count}', { count: formatInteger(value.lastMonth) })})
        </span>
        <span className="text-xs text-gray-500">
          <ChangeBadge value={value.yoy} label="YoY" />
          {value.yoy === null ? ` (${t('no data a year ago')})` : ` (${t('was {count}', { count: formatInteger(value.lastYear) })})`}
        </span>
      </div>
    </div>
  );
}

const STATUS_LABEL: Record<string, string> = {
  pending: 'Pending',
  confirmed: 'Confirmed',
  shipped: 'Shipped',
  delivered: 'Delivered',
  cancelled: 'Cancelled',
  refunded: 'Refunded',
};

export function PlatformStorePage() {
  const { tenantId: param = '' } = useParams();
  const tenantId = Number(param);
  const { preset, range, setPreset, setCustom, search } = usePeriod();
  const query = useStoreAnalytics(tenantId, range);
  const overview = useAnalyticsOverview(range);
  const insights = overview.data?.insights.filter((insight) => insight.tenantId === tenantId) ?? [];
  const t = useT();

  if (query.isPending) return <LoadingShimmer variant="page" />;
  if (query.isError) {
    return (
      <ErrorPlaceholder message={getApiErrorMessage(query.error)} onRetry={() => query.refetch()} isRetrying={query.isFetching} />
    );
  }

  const data = query.data;
  const { store } = data;
  const { current: now, previous: before } = store;
  const cancelNow = now.orders ? now.cancelledOrRefunded / now.orders : null;
  const cancelBefore = before.orders ? before.cancelledOrRefunded / before.orders : null;

  return (
    <div className="w-full space-y-6">
      <div>
        <Link
          to={`/dashboard/platform-analytics${search}`}
          className="inline-flex min-h-[40px] items-center gap-1.5 text-sm font-semibold text-gray-600 hover:text-brand-black"
        >
          <ArrowLeft className="h-4 w-4" aria-hidden="true" />
          {t('All stores')}
        </Link>
        <div className="mt-1 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-brand-black">{store.storeName}</h1>
            <p className="mt-1 flex items-center gap-1.5 text-sm capitalize text-gray-600">
              {t(capitalize(store.industry))} · {t(capitalize(store.status))}
              <span className="mx-1 text-gray-300">|</span>
              <Lock className="h-3.5 w-3.5" aria-hidden="true" />
              <span className="normal-case">{t('Finances private to the store')}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            <p className="flex items-center gap-1.5 text-xs text-gray-500">
              <RefreshCw className={`h-3.5 w-3.5 ${query.isFetching ? 'animate-spin' : ''}`} aria-hidden="true" />
              {t('Updated {time}', { time: new Date(query.dataUpdatedAt).toLocaleTimeString() })}
            </p>
            <a
              href={`/shop/${store.tenantUid}`}
              target="_blank"
              rel="noopener"
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-gray-200 px-3 text-sm font-semibold text-brand-black hover:bg-gray-50"
            >
              <ExternalLink className="h-4 w-4" aria-hidden="true" />
              {t('Visit website')}
            </a>
            <DownloadPdfButton detail={data} insights={insights} range={range} />
          </div>
        </div>
      </div>

      <PeriodPicker preset={preset} range={range} onPreset={setPreset} onCustom={setCustom} />

      {insights.length > 0 ? <InsightList insights={insights} /> : null}

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label={t('Orders')} value={formatInteger(now.orders)} change={percentChange(now.orders, before.orders)} />
        <KpiCard label={t('Units sold')} value={formatInteger(now.unitsSold)} change={percentChange(now.unitsSold, before.unitsSold)} />
        <KpiCard
          label={t('New customers')}
          value={formatInteger(now.newCustomers)}
          change={percentChange(now.newCustomers, before.newCustomers)}
        />
        <KpiCard label={t('Conversion')} value={formatPercent(data.conversionRate, 2)} hint={t('orders ÷ visits')} />
        <KpiCard
          label={t('Items per order')}
          value={data.itemsPerOrder?.toFixed(2) ?? '—'}
          hint={t('instead of order value')}
        />
        <KpiCard
          label={t('Repeat buyers')}
          value={formatPercent(data.retention.repeatRate, 0)}
          hint={t('{count} of {total} ordered 2+ times', { count: data.retention.repeatBuyers, total: data.retention.buyers })}
        />
        <KpiCard
          label={t('Returning buyers')}
          value={formatPercent(data.retention.returningRate, 0)}
          hint={t('had ordered before')}
        />
        <KpiCard
          label={t('Cancelled / refunded')}
          value={formatPercent(cancelNow, 0)}
          change={cancelNow !== null && cancelBefore ? percentChange(cancelNow, cancelBefore) : null}
          inverse
        />
      </div>

      <section aria-labelledby="trend-heading" className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h2 id="trend-heading" className="mb-3 text-sm font-semibold text-brand-black">
          {t('Sales trend')}
        </h2>
        <ResponsiveContainer width="100%" height={300}>
          <ComposedChart data={data.trend} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
            <CartesianGrid strokeDasharray="3 3" stroke={GRID_STROKE} />
            <XAxis dataKey="date" tick={AXIS_TICK} tickFormatter={formatShortDate} tickLine={false} minTickGap={24} />
            <YAxis yAxisId="left" tick={AXIS_TICK} tickFormatter={formatInteger} tickLine={false} axisLine={false} width={40} />
            <YAxis
              yAxisId="right"
              orientation="right"
              tick={AXIS_TICK}
              tickFormatter={formatInteger}
              tickLine={false}
              axisLine={false}
              width={48}
            />
            <Tooltip labelFormatter={formatShortDate} />
            <Legend wrapperStyle={{ fontSize: 12 }} />
            <Bar yAxisId="left" dataKey="unitsSold" name={t('Units sold')} fill="#BBF7D0" radius={[3, 3, 0, 0]} />
            <Line yAxisId="left" type="monotone" dataKey="orders" name={t('Orders')} stroke="#15803D" strokeWidth={2} dot={false} />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="pageViews"
              name={t('Visits (right axis)')}
              stroke="#2563EB"
              strokeDasharray="6 4"
              strokeWidth={1.5}
              dot={false}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </section>

      <section aria-labelledby="month-heading" className="space-y-3">
        <h2 id="month-heading" className="text-lg font-bold tracking-tight text-brand-black">
          {t('{month} vs last month and last year', { month: monthLabel(data.monthComparison.month) })}
        </h2>
        <div className="grid gap-3 md:grid-cols-3">
          <MonthCompare label={t('Orders')} value={data.monthComparison.orders} />
          <MonthCompare label={t('Units sold')} value={data.monthComparison.unitsSold} />
          <MonthCompare label={t('New customers')} value={data.monthComparison.newCustomers} />
        </div>
        <div className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h3 className="mb-3 text-sm font-semibold text-brand-black">{t('Orders by month')}</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={data.monthly} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={GRID_STROKE} vertical={false} />
              <XAxis dataKey="month" tick={AXIS_TICK} tickFormatter={monthLabel} tickLine={false} minTickGap={8} />
              <YAxis tick={AXIS_TICK} tickFormatter={formatInteger} tickLine={false} axisLine={false} width={40} />
              <Tooltip labelFormatter={monthLabel} />
              <Bar dataKey="orders" name={t('Orders')} fill="#22C55E" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-2">
        <ProductList title={t('Top-selling products')} products={data.topProducts} empty={t('No sales in this period.')} />
        <ProductList title={t('Lowest-performing products')} products={data.lowProducts} empty={t('No active products.')} />
      </div>

      <section aria-labelledby="peak-heading" className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
        <h2 id="peak-heading" className="mb-1 text-sm font-semibold text-brand-black">
          {t('Peak hours & days')}
        </h2>
        <PeakHeatmap grid={data.peakHours} />
        <p className="mt-2 text-xs text-gray-500">{t('Times are UTC.')}</p>
      </section>

      <div className="grid gap-4 lg:grid-cols-3">
        <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h2 className="mb-3 text-sm font-semibold text-brand-black">{t('Inventory')}</h2>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Units on hand')}</dt>
              <dd className="font-semibold tabular-nums">{formatInteger(data.inventory.unitsOnHand)}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Turnover this period')}</dt>
              <dd className="font-semibold tabular-nums">{data.inventory.turnover?.toFixed(2) ?? '—'}×</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Days of stock left')}</dt>
              <dd className="font-semibold tabular-nums">{data.inventory.daysOfCover ?? '—'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Out of stock / low')}</dt>
              <dd className="font-semibold tabular-nums">
                {store.outOfStock} / {store.lowStock}
              </dd>
            </div>
          </dl>
          <p className="mt-3 text-xs text-gray-500">
            {t('Turnover = units sold ÷ units on hand now (in units, approximate).')}
          </p>
        </section>

        <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h2 className="mb-3 text-sm font-semibold text-brand-black">{t('Order status')}</h2>
          <ul className="space-y-2 text-sm">
            {data.statusBreakdown.length === 0 ? <li className="text-gray-500">{t('No orders in this period.')}</li> : null}
            {data.statusBreakdown.map((row) => (
              <li key={row.status} className="flex justify-between">
                <span className="text-gray-600">{t(STATUS_LABEL[row.status] ?? row.status)}</span>
                <span className="font-semibold tabular-nums">{formatInteger(row.orders)}</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
          <h2 className="mb-3 text-sm font-semibold text-brand-black">{t('Customer support')}</h2>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Open tickets')}</dt>
              <dd className="font-semibold tabular-nums">{store.openTickets}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Urgent')}</dt>
              <dd className={`font-semibold tabular-nums ${store.urgentTickets > 0 ? 'text-red-700' : ''}`}>
                {store.urgentTickets}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Resolved this period')}</dt>
              <dd className="font-semibold tabular-nums">{data.tickets.resolved}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-600">{t('Avg. time to resolve')}</dt>
              <dd className="font-semibold tabular-nums">
                {data.tickets.avgResolutionHours === null ? '—' : t('{hours} h', { hours: data.tickets.avgResolutionHours })}
              </dd>
            </div>
          </dl>
        </section>
      </div>
    </div>
  );
}
