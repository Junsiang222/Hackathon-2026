import { zodResolver } from '@hookform/resolvers/zod';
import { motion } from 'framer-motion';
import { Check, ChevronDown, Eye, EyeOff } from 'lucide-react';
import { useId, useState, type ReactNode } from 'react';
import { useForm, type FieldPath, type FieldValues, type Resolver, type UseFormReturn } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { FacebookIcon, GoogleIcon } from '@/components/ui/BrandIcons';
import { TextField } from '@/components/ui/TextField';
import { useLogin, useOAuthLogin, useRegister } from '@/hooks/useAuth';
import { getApiErrorCode, getApiErrorDetails, getApiErrorMessage } from '@/lib/axios';
import { INDUSTRIES, type Industry, type WorkspaceChoice } from '@/types/api.types';

type PanelId = 'signin' | 'signup';

const PANEL_LABEL: Record<PanelId, string> = { signin: 'Sign in', signup: 'Create account' };

// ─── Shared bits ─────────────────────────────────────────────────────────────

function PasswordVisibilityToggle({ visible, onToggle }: { visible: boolean; onToggle: () => void }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-label={visible ? 'Hide password' : 'Show password'}
      aria-pressed={visible}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100 hover:text-brand-black"
    >
      {visible ? <EyeOff className="h-5 w-5" aria-hidden="true" /> : <Eye className="h-5 w-5" aria-hidden="true" />}
    </button>
  );
}

/** Real-time field state: valid only once the user has typed something that passes. */
function useFieldStatus<T extends FieldValues>(form: UseFormReturn<T>, name: FieldPath<T>) {
  const { formState, getFieldState } = form;
  const state = getFieldState(name, formState);
  const showError = Boolean(state.error) && (state.isDirty || state.isTouched || formState.isSubmitted);
  return {
    error: showError ? state.error?.message : undefined,
    isValid: state.isDirty && !state.invalid,
  };
}

// ─── Sign in ─────────────────────────────────────────────────────────────────

const signInSchema = z.object({
  email: z.string().trim().min(1, 'Email is required').email('Enter a valid email address'),
  password: z.string().min(1, 'Password is required'),
  rememberMe: z.boolean(),
  tenantUid: z.string().optional(),
});
type SignInValues = z.infer<typeof signInSchema>;

function SignInForm({ headingId }: { headingId: string }) {
  const [showPassword, setShowPassword] = useState(false);
  const [workspaces, setWorkspaces] = useState<WorkspaceChoice[]>([]);
  const login = useLogin();
  const oauth = useOAuthLogin();
  const workspaceFieldId = useId();

  const form = useForm<SignInValues>({
    resolver: zodResolver(signInSchema),
    mode: 'onTouched',
    defaultValues: { email: '', password: '', rememberMe: false, tenantUid: undefined },
  });
  const { register, handleSubmit } = form;
  const email = useFieldStatus(form, 'email');
  const password = useFieldStatus(form, 'password');

  const onSubmit = handleSubmit((values) => {
    login.mutate(
      {
        email: values.email,
        password: values.password,
        rememberMe: values.rememberMe,
        tenantUid: values.tenantUid || undefined,
      },
      {
        onError: (error) => {
          if (getApiErrorCode(error) === 'TENANT_SELECTION_REQUIRED') {
            setWorkspaces(getApiErrorDetails(error) as WorkspaceChoice[]);
          }
          toast.error(getApiErrorMessage(error));
        },
      },
    );
  });

  const startOAuth = (provider: 'google' | 'facebook') =>
    oauth.mutate(provider, { onError: (error) => toast.error(getApiErrorMessage(error)) });
  const oauthPendingFor = oauth.isPending ? oauth.variables : undefined;
  const busy = login.isPending || oauth.isPending;

  return (
    <div>
      <h2 id={headingId} className="text-2xl font-bold tracking-tight text-brand-black">
        Welcome back
      </h2>
      <p className="mt-1 text-sm text-gray-700">Sign in to manage your stores.</p>

      <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4" aria-labelledby={headingId}>
        <TextField
          label="Email"
          type="email"
          autoComplete="email"
          inputMode="email"
          error={email.error}
          {...register('email')}
        />
        <TextField
          label="Password"
          type={showPassword ? 'text' : 'password'}
          autoComplete="current-password"
          error={password.error}
          trailing={<PasswordVisibilityToggle visible={showPassword} onToggle={() => setShowPassword((v) => !v)} />}
          {...register('password')}
        />

        {workspaces.length > 0 ? (
          <div>
            <label htmlFor={workspaceFieldId} className="mb-1.5 block text-sm font-medium text-brand-black">
              Workspace
            </label>
            <select
              id={workspaceFieldId}
              className="block min-h-[44px] w-full rounded-xl border border-gray-300 bg-white px-3.5 text-base text-brand-black focus:border-brand-black focus:outline-none focus:ring-4 focus:ring-gray-100"
              {...register('tenantUid')}
            >
              <option value="">Choose a workspace…</option>
              {workspaces.map((workspace) => (
                <option key={workspace.tenantUid} value={workspace.tenantUid}>
                  {workspace.businessName}
                </option>
              ))}
            </select>
          </div>
        ) : null}

        <label className="flex min-h-[44px] cursor-pointer items-center gap-3 text-sm text-gray-700">
          <input
            type="checkbox"
            className="h-5 w-5 rounded border-gray-300 text-brand-green-dark accent-brand-green-dark"
            {...register('rememberMe')}
          />
          Remember me
        </label>

        <Button type="submit" fullWidth loading={login.isPending} loadingText="Signing in…" disabled={busy}>
          Sign In
        </Button>
      </form>

      <div className="my-6 flex items-center gap-3" role="separator" aria-label="or continue with">
        <span className="h-px flex-1 bg-gray-200" />
        <span className="text-xs font-medium uppercase tracking-wide text-gray-500">or continue with</span>
        <span className="h-px flex-1 bg-gray-200" />
      </div>

      <div className="space-y-3">
        <Button
          variant="outline"
          fullWidth
          className="relative"
          onClick={() => startOAuth('google')}
          loading={oauthPendingFor === 'google'}
          disabled={busy}
          leftIcon={<GoogleIcon className="absolute left-4 h-5 w-5" />}
        >
          Continue with Google
        </Button>
        <Button
          variant="outline"
          fullWidth
          className="relative"
          onClick={() => startOAuth('facebook')}
          loading={oauthPendingFor === 'facebook'}
          disabled={busy}
          leftIcon={<FacebookIcon className="absolute left-4 h-5 w-5" />}
        >
          Continue with Facebook
        </Button>
      </div>
    </div>
  );
}

// ─── Sign up ─────────────────────────────────────────────────────────────────

const signUpSchema = z
  .object({
    businessName: z
      .string()
      .trim()
      .min(2, 'Business name must be at least 2 characters')
      .max(255, 'Business name is too long'),
    industry: z.enum(INDUSTRIES, { errorMap: () => ({ message: 'Choose your industry' }) }),
    email: z.string().trim().min(1, 'Email is required').email('Enter a valid email address'),
    password: z
      .string()
      .min(12, 'Use at least 12 characters')
      .refine((value) => new TextEncoder().encode(value).length <= 72, 'Use at most 72 bytes')
      .refine((value) => /[a-z]/.test(value), 'Add a lower-case letter')
      .refine((value) => /[A-Z]/.test(value), 'Add an upper-case letter')
      .refine((value) => /\d/.test(value), 'Add a number'),
    confirmPassword: z.string().min(1, 'Confirm your password'),
  });
type SignUpValues = z.infer<typeof signUpSchema>;

const baseSignUpResolver = zodResolver(signUpSchema);

/**
 * Zod skips object-level refinements while any field is invalid, so a
 * `.refine()` match check would let a mismatched confirmation show as valid
 * until every other field passed. Checking it here runs on every keystroke.
 */
const signUpResolver: Resolver<SignUpValues> = async (values, context, options) => {
  const result = await baseSignUpResolver(values, context, options);
  if (values.confirmPassword && values.password !== values.confirmPassword && !result.errors.confirmPassword) {
    return {
      values: {},
      errors: {
        ...result.errors,
        confirmPassword: { type: 'match', message: 'Passwords do not match' },
      },
    };
  }
  return result;
};

const INDUSTRY_LABEL: Record<Industry, string> = {
  retail: 'Retail',
  fashion: 'Fashion',
  electronics: 'Electronics',
  food: 'Food & beverage',
  health: 'Health & wellness',
  other: 'Other',
};

function SignUpForm({ headingId }: { headingId: string }) {
  const [showPassword, setShowPassword] = useState(false);
  const registerAccount = useRegister();
  const industryId = useId();

  const form = useForm<SignUpValues>({
    resolver: signUpResolver,
    mode: 'onChange',
    defaultValues: {
      businessName: '',
      industry: '' as unknown as Industry, // forces an explicit choice
      email: '',
      password: '',
      confirmPassword: '',
    },
  });
  const { register, handleSubmit } = form;

  const businessName = useFieldStatus(form, 'businessName');
  const industry = useFieldStatus(form, 'industry');
  const email = useFieldStatus(form, 'email');
  const password = useFieldStatus(form, 'password');
  const confirmPassword = useFieldStatus(form, 'confirmPassword');

  const onSubmit = handleSubmit(({ confirmPassword: _confirm, ...payload }) => {
    registerAccount.mutate(payload, { onError: (error) => toast.error(getApiErrorMessage(error)) });
  });

  const industryBorder = industry.error
    ? 'border-red-500 focus:border-red-600 focus:ring-red-100'
    : industry.isValid
      ? 'border-brand-green focus:border-brand-green-dark focus:ring-brand-mint'
      : 'border-gray-300 focus:border-brand-black focus:ring-gray-100';

  return (
    <div>
      <h2 id={headingId} className="text-2xl font-bold tracking-tight text-brand-black">
        Start your free trial
      </h2>
      <p className="mt-1 text-sm text-gray-700">14 days free. No card required.</p>

      <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4" aria-labelledby={headingId}>
        <TextField
          label="Business name"
          autoComplete="organization"
          error={businessName.error}
          isValid={businessName.isValid}
          {...register('businessName')}
        />

        <div>
          <label htmlFor={industryId} className="mb-1.5 block text-sm font-medium text-brand-black">
            Industry
          </label>
          <div className="relative">
            <select
              id={industryId}
              aria-invalid={industry.error ? true : undefined}
              aria-describedby={industry.error ? `${industryId}-error` : undefined}
              className={`block min-h-[44px] w-full appearance-none rounded-xl border bg-white px-3.5 pr-16 text-base text-brand-black transition-colors focus:outline-none focus:ring-4 ${industryBorder}`}
              {...register('industry')}
            >
              <option value="" disabled>
                Select an industry…
              </option>
              {INDUSTRIES.map((value) => (
                <option key={value} value={value}>
                  {INDUSTRY_LABEL[value]}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-3 flex items-center gap-1">
              {industry.isValid ? <Check className="h-5 w-5 text-brand-green-dark" strokeWidth={2.5} aria-hidden="true" /> : null}
              <ChevronDown className="h-4 w-4 text-gray-500" aria-hidden="true" />
            </div>
          </div>
          {industry.error ? (
            <p id={`${industryId}-error`} role="alert" className="mt-1.5 text-sm text-red-600">
              {industry.error}
            </p>
          ) : null}
        </div>

        <TextField
          label="Email"
          type="email"
          autoComplete="email"
          inputMode="email"
          error={email.error}
          isValid={email.isValid}
          {...register('email')}
        />
        <TextField
          label="Password"
          type={showPassword ? 'text' : 'password'}
          autoComplete="new-password"
          hint="At least 12 characters with upper-case, lower-case and a number."
          error={password.error}
          isValid={password.isValid}
          trailing={<PasswordVisibilityToggle visible={showPassword} onToggle={() => setShowPassword((v) => !v)} />}
          {...register('password', { deps: ['confirmPassword'] })}
        />
        <TextField
          label="Confirm password"
          type={showPassword ? 'text' : 'password'}
          autoComplete="new-password"
          error={confirmPassword.error}
          isValid={confirmPassword.isValid}
          {...register('confirmPassword')}
        />

        <Button type="submit" fullWidth loading={registerAccount.isPending} loadingText="Creating account…">
          Create Account
        </Button>
      </form>
    </div>
  );
}

// ─── Page ────────────────────────────────────────────────────────────────────

interface PanelProps {
  id: PanelId;
  active: boolean;
  onActivate: (id: PanelId) => void;
  children: ReactNode;
}

function AuthPanel({ id, active, onActivate, children }: PanelProps) {
  return (
    <section
      id={`auth-panel-${id}`}
      role="tabpanel"
      aria-labelledby={`auth-tab-${id}`}
      onFocusCapture={() => onActivate(id)}
      onPointerDown={() => onActivate(id)}
      className={`relative p-6 sm:p-10 ${active ? 'block' : 'hidden'} lg:block`}
    >
      {active ? (
        // Desktop: a shared-layout highlight glides to whichever form is in use.
        <motion.div
          layoutId="auth-active-panel"
          aria-hidden="true"
          className="pointer-events-none absolute inset-3 hidden rounded-2xl bg-gray-50 ring-1 ring-gray-200 lg:block"
          transition={{ type: 'spring', stiffness: 380, damping: 34 }}
        />
      ) : null}
      <div className="relative">{children}</div>
    </section>
  );
}

export function AuthPage() {
  const [active, setActive] = useState<PanelId>('signin');

  return (
    <div className="w-full max-w-5xl">
      {/* Mobile / tablet: one form at a time, switched by tabs. */}
      <div role="tablist" aria-label="Account" className="mb-4 grid grid-cols-2 gap-1 rounded-2xl border border-gray-200 bg-white p-1 lg:hidden">
        {(['signin', 'signup'] as const).map((panel) => (
          <button
            key={panel}
            id={`auth-tab-${panel}`}
            type="button"
            role="tab"
            aria-selected={active === panel}
            aria-controls={`auth-panel-${panel}`}
            onClick={() => setActive(panel)}
            className={`relative min-h-[44px] rounded-xl text-sm font-semibold transition-colors ${
              active === panel ? 'text-white' : 'text-brand-black hover:bg-brand-mint'
            }`}
          >
            {active === panel ? (
              <motion.span
                layoutId="auth-tab-pill"
                className="absolute inset-0 rounded-xl bg-brand-black"
                transition={{ type: 'spring', stiffness: 420, damping: 36 }}
              />
            ) : null}
            <span className="relative">{PANEL_LABEL[panel]}</span>
          </button>
        ))}
      </div>

      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-lg lg:grid lg:grid-cols-2 lg:divide-x lg:divide-gray-100">
        <AuthPanel id="signin" active={active === 'signin'} onActivate={setActive}>
          <SignInForm headingId="signin-heading" />
        </AuthPanel>
        <AuthPanel id="signup" active={active === 'signup'} onActivate={setActive}>
          <SignUpForm headingId="signup-heading" />
        </AuthPanel>
      </div>
    </div>
  );
}
