import { ShoppingCart, Trash2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { formatPrice, ProductImage } from '@/components/shop/ProductImage';
import { EmptyState } from '@/components/ui/EmptyState';
import { useShopContext } from '@/hooks/useShop';
import { useCart, useCartStore } from '@/store/cartStore';
import { QtyStepper } from './ShopProductPage';

export function ShopCartPage() {
  const { shopId, shop } = useShopContext();
  const { lines, count, total } = useCart(shopId);
  const setQty = useCartStore((state) => state.setQty);
  const remove = useCartStore((state) => state.remove);

  if (lines.length === 0) {
    return (
      <EmptyState
        icon={ShoppingCart}
        minHeight={320}
        title="Your cart is empty"
        description="Find something you like and add it to your cart."
        action={
          <Link to={`/shop/${shopId}`} className="font-semibold text-brand-green-dark underline">
            Continue shopping
          </Link>
        }
      />
    );
  }

  return (
    <>
      <h1 className="mb-6 text-2xl font-bold tracking-tight text-brand-black">Your cart</h1>
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        <ul className="divide-y divide-gray-100 rounded-2xl border border-gray-100 bg-white shadow-sm lg:col-span-2" aria-label="Cart items">
          {lines.map((line) => (
            <li key={line.productId} className="flex flex-wrap items-center gap-4 p-4 sm:flex-nowrap">
              <ProductImage name={line.name} url={line.imageUrl} className="h-20 w-20 shrink-0 rounded-xl" />
              <div className="min-w-0 flex-1">
                <Link to={`/shop/${shopId}/product/${line.productId}`} className="font-semibold text-brand-black hover:underline">
                  {line.name}
                </Link>
                <p className="text-sm tabular-nums text-gray-500">{formatPrice(line.price, shop.currency)} each</p>
              </div>
              <QtyStepper
                value={line.qty}
                max={line.maxQty}
                onChange={(qty) => setQty(shopId, line.productId, qty)}
                label={`Quantity of ${line.name}`}
              />
              <p className="w-24 text-right font-semibold tabular-nums text-brand-black">
                {formatPrice(line.qty * line.price, shop.currency)}
              </p>
              <button
                type="button"
                onClick={() => remove(shopId, line.productId)}
                aria-label={`Remove ${line.name}`}
                className="flex h-11 w-11 items-center justify-center rounded-full text-gray-500 hover:bg-red-50 hover:text-red-600"
              >
                <Trash2 className="h-4 w-4" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ul>

        <aside className="h-fit rounded-2xl border border-gray-100 bg-white p-6 shadow-sm" aria-label="Order summary">
          <h2 className="text-lg font-bold tracking-tight text-brand-black">Summary</h2>
          <dl className="mt-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-700">Items</dt>
              <dd className="tabular-nums">{count}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-700">Delivery</dt>
              <dd>Free</dd>
            </div>
            <div className="flex justify-between border-t border-gray-100 pt-3 text-base font-bold text-brand-black">
              <dt>Total</dt>
              <dd className="tabular-nums">{formatPrice(total, shop.currency)}</dd>
            </div>
          </dl>
          {shop.features.checkout ? (
            <Link
              to={`/shop/${shopId}/checkout`}
              className="mt-6 flex min-h-[48px] items-center justify-center rounded-xl bg-brand-green px-4 font-semibold text-white hover:bg-brand-green-dark"
            >
              Go to checkout
            </Link>
          ) : (
            <p className="mt-6 text-sm text-gray-700">Online checkout isn't available for this shop.</p>
          )}
          <Link to={`/shop/${shopId}`} className="mt-3 block text-center text-sm font-medium text-gray-700 hover:underline">
            Continue shopping
          </Link>
        </aside>
      </div>
    </>
  );
}
