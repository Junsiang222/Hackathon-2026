import { Search, ShoppingBag } from 'lucide-react';
import { useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { GeneratedShopPage } from '@/components/shop/GeneratedShopPage';
import { formatPrice, ProductImage } from '@/components/shop/ProductImage';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { useDebounced } from '@/components/ui/DataTable';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { trackShopEvent, useShopContext, useShopEvent, useShopProducts } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useCartStore } from '@/store/cartStore';
import type { ShopInfo, ShopProduct, WebsiteCopy, WebsiteTheme } from '@/types/shop.types';

// Literal class names so Tailwind keeps them. Dark hero + light accents keep contrast safe for every theme.
const THEME_CLASSES: Record<WebsiteTheme, { hero: string; eyebrow: string; soft: string; accent: string }> = {
  green: { hero: 'bg-brand-black', eyebrow: 'text-brand-green', soft: 'bg-brand-mint', accent: 'text-brand-green-dark' },
  blue: { hero: 'bg-blue-950', eyebrow: 'text-blue-300', soft: 'bg-blue-50', accent: 'text-blue-800' },
  purple: { hero: 'bg-purple-950', eyebrow: 'text-purple-300', soft: 'bg-purple-50', accent: 'text-purple-800' },
  rose: { hero: 'bg-rose-950', eyebrow: 'text-rose-300', soft: 'bg-rose-50', accent: 'text-rose-800' },
  amber: { hero: 'bg-stone-900', eyebrow: 'text-amber-300', soft: 'bg-amber-50', accent: 'text-amber-800' },
  slate: { hero: 'bg-slate-900', eyebrow: 'text-slate-300', soft: 'bg-slate-100', accent: 'text-slate-700' },
};

function defaultSubtitle(shop: ShopInfo) {
  const base = shop.features.checkout
    ? 'Browse our products, add your favourites to the cart and check out in a minute.'
    : 'Browse our products below.';
  return !shop.features.checkout && shop.features.contact ? `${base} Get in touch through the Contact page to order.` : base;
}

function WebsiteAbout({ website }: { website: WebsiteCopy }) {
  const theme = THEME_CLASSES[website.theme];
  return (
    <>
      {website.highlights.length > 0 ? (
        <ul aria-label="Why shop with us" className="mt-12 grid gap-4 sm:grid-cols-3">
          {website.highlights.map((item) => (
            <li key={item.title} className={`rounded-2xl p-5 ${theme.soft}`}>
              <h3 className={`font-semibold ${theme.accent}`}>{item.title}</h3>
              <p className="mt-1 text-sm text-gray-700">{item.text}</p>
            </li>
          ))}
        </ul>
      ) : null}
      {website.aboutText ? (
        <section aria-labelledby="shop-about" className="mt-12 max-w-3xl">
          <h2 id="shop-about" className="text-2xl font-bold tracking-tight text-brand-black">
            {website.aboutTitle}
          </h2>
          {website.aboutText.split(/\n\s*\n/).map((paragraph, index) => (
            <p key={index} className="mt-3 whitespace-pre-line text-gray-700">
              {paragraph}
            </p>
          ))}
        </section>
      ) : null}
    </>
  );
}

function ProductCard({ product }: { product: ShopProduct }) {
  const { shopId, shop } = useShopContext();
  const add = useCartStore((state) => state.add);

  const onAdd = () => {
    add(shopId, { productId: product.id, name: product.name, price: product.price, imageUrl: product.imageUrl, maxQty: product.maxQty }, 1);
    trackShopEvent(shopId, 'add_to_cart', product.id);
    toast.success(`${product.name} added to cart`);
  };

  return (
    <li className="group flex flex-col overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm transition-shadow hover:shadow-md">
      <Link to={`/shop/${shopId}/product/${product.id}`} className="block">
        <ProductImage name={product.name} url={product.imageUrl} className="aspect-square w-full" />
      </Link>
      <div className="flex flex-1 flex-col p-4">
        {product.category ? <p className="text-xs font-medium uppercase tracking-wide text-gray-500">{product.category}</p> : null}
        <h3 className="mt-0.5 font-semibold text-brand-black">
          <Link to={`/shop/${shopId}/product/${product.id}`} className="hover:underline">
            {product.name}
          </Link>
        </h3>
        <p className="mt-1 text-lg font-bold tabular-nums text-brand-black">{formatPrice(product.price, shop.currency)}</p>
        {!product.inStock ? (
          <p className="mt-1 text-sm font-medium text-red-600">Out of stock</p>
        ) : product.lowStockQty ? (
          <p className="mt-1 text-sm font-medium text-amber-700">Only {product.lowStockQty} left</p>
        ) : null}
        <div className="mt-auto pt-4">
          {shop.features.checkout ? (
            <button
              type="button"
              onClick={onAdd}
              disabled={!product.inStock}
              className="min-h-[44px] w-full rounded-xl bg-brand-green px-4 text-sm font-semibold text-white hover:bg-brand-green-dark disabled:cursor-not-allowed disabled:bg-gray-200 disabled:text-gray-500"
            >
              {product.inStock ? 'Add to cart' : 'Sold out'}
            </button>
          ) : null}
        </div>
      </div>
    </li>
  );
}

export function ShopHomePage() {
  const { shop } = useShopContext();
  const website = shop.website;
  // New stores: the AI designed the whole page. Older stores: AI copy in the fixed template.
  return website && 'html' in website ? <GeneratedShopPage website={website} /> : <TemplateShopHomePage website={website} />;
}

function TemplateShopHomePage({ website }: { website: WebsiteCopy | null }) {
  const { shopId, shop } = useShopContext();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const query = useShopProducts(shopId, { search: useDebounced(search), category });
  useShopEvent(shopId, 'page_view');
  const theme = THEME_CLASSES[website?.theme ?? 'green'];

  return (
    <>
      <section className={`mb-8 overflow-hidden rounded-3xl px-6 py-10 text-white sm:px-10 sm:py-14 ${theme.hero}`}>
        <p className={`text-sm font-semibold uppercase tracking-wider ${theme.eyebrow}`}>{website?.heroEyebrow ?? 'Welcome to'}</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-white sm:text-5xl">{website?.heroTitle ?? shop.storeName}</h1>
        <p className="mt-3 max-w-xl text-gray-300">{website?.heroSubtitle || defaultSubtitle(shop)}</p>
      </section>

      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <label htmlFor="shop-search" className="sr-only">
            Search products
          </label>
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" aria-hidden="true" />
          <input
            id="shop-search"
            type="search"
            value={search}
            onChange={(event) => setSearch(event.target.value)}
            placeholder="Search products"
            className="block min-h-[44px] w-full rounded-xl border border-gray-300 bg-white py-2.5 pl-10 pr-3.5 text-base placeholder:text-gray-400 focus:border-brand-black focus:outline-none focus:ring-4 focus:ring-gray-100"
          />
        </div>
      </div>

      {query.data && query.data.categories.length > 0 ? (
        <div role="group" aria-label="Categories" className="mb-6 flex gap-2 overflow-x-auto pb-1">
          {['', ...query.data.categories].map((value) => (
            <button
              key={value || 'all'}
              type="button"
              aria-pressed={category === value}
              onClick={() => setCategory(value)}
              className={`min-h-[40px] shrink-0 rounded-full border px-4 text-sm font-medium ${
                category === value
                  ? 'border-brand-black bg-brand-black text-white'
                  : 'border-gray-200 bg-white text-gray-700 hover:border-gray-400'
              }`}
            >
              {value || 'All'}
            </button>
          ))}
        </div>
      ) : null}

      {query.isPending ? (
        <LoadingShimmer rows={3} />
      ) : query.isError ? (
        <ErrorPlaceholder message={getApiErrorMessage(query.error)} onRetry={() => query.refetch()} isRetrying={query.isFetching} />
      ) : query.data.products.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          minHeight={260}
          title={search || category ? 'No products match' : 'No products yet'}
          description={search || category ? 'Try another search or category.' : 'Check back soon, new products are on the way.'}
        />
      ) : (
        <ul
          aria-label="Products"
          className={`grid grid-cols-2 gap-4 sm:grid-cols-3 sm:gap-6 lg:grid-cols-4 ${query.isFetching ? 'opacity-70' : ''}`}
        >
          {query.data.products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </ul>
      )}

      {website ? <WebsiteAbout website={website} /> : null}
    </>
  );
}
