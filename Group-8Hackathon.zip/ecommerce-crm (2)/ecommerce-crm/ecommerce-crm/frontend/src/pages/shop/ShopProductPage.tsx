import { ArrowLeft, Minus, PackageX, Plus } from 'lucide-react';
import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { formatPrice, ProductImage } from '@/components/shop/ProductImage';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { trackShopEvent, useShopContext, useShopEvent, useShopProduct } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useCartStore } from '@/store/cartStore';

export function QtyStepper({ value, max, onChange, label }: { value: number; max: number; onChange: (qty: number) => void; label: string }) {
  return (
    <div className="inline-flex items-center rounded-xl border border-gray-300" role="group" aria-label={label}>
      <button
        type="button"
        onClick={() => onChange(value - 1)}
        disabled={value <= 1}
        aria-label="Decrease quantity"
        className="flex h-11 w-11 items-center justify-center rounded-l-xl hover:bg-gray-100 disabled:opacity-40"
      >
        <Minus className="h-4 w-4" aria-hidden="true" />
      </button>
      <span className="w-10 text-center font-semibold tabular-nums" aria-live="polite">
        {value}
      </span>
      <button
        type="button"
        onClick={() => onChange(value + 1)}
        disabled={value >= max}
        aria-label="Increase quantity"
        className="flex h-11 w-11 items-center justify-center rounded-r-xl hover:bg-gray-100 disabled:opacity-40"
      >
        <Plus className="h-4 w-4" aria-hidden="true" />
      </button>
    </div>
  );
}

export function ShopProductPage() {
  const { shopId, shop } = useShopContext();
  const productId = Number(useParams().productId);
  const query = useShopProduct(shopId, productId);
  const add = useCartStore((state) => state.add);
  const navigate = useNavigate();
  const [qty, setQty] = useState(1);
  useShopEvent(shopId, 'page_view', productId);

  if (query.isPending) return <LoadingShimmer rows={3} />;
  if (query.isError) {
    return (
      <EmptyState
        icon={PackageX}
        minHeight={300}
        title="Product not available"
        description={getApiErrorMessage(query.error)}
        action={
          <Link to={`/shop/${shopId}`} className="font-semibold text-brand-green-dark underline">
            Back to the shop
          </Link>
        }
      />
    );
  }

  const product = query.data;
  const addToCart = (goToCart: boolean) => {
    add(shopId, { productId: product.id, name: product.name, price: product.price, imageUrl: product.imageUrl, maxQty: product.maxQty }, qty);
    trackShopEvent(shopId, 'add_to_cart', product.id);
    if (goToCart) navigate(`/shop/${shopId}/cart`);
    else toast.success(`${qty} × ${product.name} added to cart`);
  };

  return (
    <>
      <Link to={`/shop/${shopId}`} className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-gray-700 hover:text-brand-black">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        All products
      </Link>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
        <ProductImage name={product.name} url={product.imageUrl} className="aspect-square w-full rounded-3xl" />
        <div>
          {product.category ? <p className="text-sm font-medium uppercase tracking-wide text-gray-500">{product.category}</p> : null}
          <h1 className="mt-1 text-3xl font-bold tracking-tight text-brand-black">{product.name}</h1>
          <p className="mt-3 text-2xl font-bold tabular-nums text-brand-black">{formatPrice(product.price, shop.currency)}</p>
          {!product.inStock ? (
            <p className="mt-2 font-medium text-red-600">Out of stock</p>
          ) : product.lowStockQty ? (
            <p className="mt-2 font-medium text-amber-700">Only {product.lowStockQty} left, order soon</p>
          ) : shop.features.stockLevels ? (
            <p className="mt-2 font-medium text-brand-green-dark">In stock</p>
          ) : null}
          {product.description ? <p className="mt-5 whitespace-pre-line text-gray-700">{product.description}</p> : null}

          {shop.features.checkout && product.inStock ? (
            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <QtyStepper value={qty} max={product.maxQty} onChange={(next) => setQty(Math.max(1, Math.min(next, product.maxQty)))} label="Quantity" />
              <Button variant="outline" onClick={() => addToCart(false)} className="sm:flex-1">
                Add to cart
              </Button>
              <Button onClick={() => addToCart(true)} className="sm:flex-1">
                Buy now
              </Button>
            </div>
          ) : !shop.features.checkout ? (
            <p className="mt-8 rounded-xl bg-gray-100 p-4 text-sm text-gray-700">
              Online ordering isn't available for this shop.
              {shop.features.contact ? (
                <>
                  {' '}
                  <Link to={`/shop/${shopId}/contact`} className="font-semibold text-brand-green-dark underline">
                    Contact us
                  </Link>{' '}
                  to order this product.
                </>
              ) : null}
            </p>
          ) : null}
        </div>
      </div>
    </>
  );
}
