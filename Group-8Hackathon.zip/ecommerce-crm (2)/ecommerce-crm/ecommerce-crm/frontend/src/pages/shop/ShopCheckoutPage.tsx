import { zodResolver } from '@hookform/resolvers/zod';
import { CheckCircle2, CreditCard, Lock, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, Navigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { formatPrice } from '@/components/shop/ProductImage';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { TextAreaField } from '@/components/ui/FormFields';
import { TextField } from '@/components/ui/TextField';
import { useCheckout, useShopContext, useShopEvent } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useCart, useCartStore } from '@/store/cartStore';
import { useShopSession } from '@/store/shopAccountStore';
import type { PlacedOrder } from '@/types/shop.types';

/** Luhn checksum: catches typos in card numbers. */
function luhn(digits: string): boolean {
  let sum = 0;
  for (let i = 0; i < digits.length; i += 1) {
    let digit = Number(digits[digits.length - 1 - i]);
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
  }
  return sum % 10 === 0;
}

function expiryInFuture(value: string): boolean {
  const [mm, yy] = value.split('/').map(Number);
  if (!mm || mm < 1 || mm > 12 || yy === undefined) return false;
  const endOfMonth = new Date(2000 + yy, mm, 1);
  return endOfMonth.getTime() > Date.now();
}

const checkoutSchema = z.object({
  fullName: z.string().trim().min(1, 'Enter your full name').max(255),
  email: z.string().trim().email('Enter a valid email'),
  phone: z.string().trim().max(32),
  shippingAddress: z.string().trim().min(5, 'Enter your delivery address').max(1000),
  cardName: z.string().trim().min(1, 'Enter the name on the card'),
  cardNumber: z
    .string()
    .transform((value) => value.replace(/\D/g, ''))
    .refine((digits) => digits.length >= 13 && digits.length <= 19 && luhn(digits), 'Enter a valid card number'),
  expiry: z.string().trim().regex(/^\d{2}\/\d{2}$/, 'Use MM/YY').refine(expiryInFuture, 'This card has expired'),
  cvc: z.string().trim().regex(/^\d{3,4}$/, '3 or 4 digits'),
});
type CheckoutValues = z.input<typeof checkoutSchema>;

/** "4242424242424242" → "4242 4242 4242 4242" while typing. */
const formatCardNumber = (value: string) =>
  value
    .replace(/\D/g, '')
    .slice(0, 19)
    .replace(/(.{4})/g, '$1 ')
    .trim();

const formatExpiry = (value: string) => {
  const digits = value.replace(/\D/g, '').slice(0, 4);
  return digits.length > 2 ? `${digits.slice(0, 2)}/${digits.slice(2)}` : digits;
};

function Confirmation({ order }: { order: PlacedOrder }) {
  const { shopId, shop } = useShopContext();
  return (
    <div className="mx-auto max-w-xl rounded-3xl border border-gray-100 bg-white p-8 text-center shadow-sm">
      <CheckCircle2 className="mx-auto h-14 w-14 text-brand-green" aria-hidden="true" />
      <h1 className="mt-4 text-2xl font-bold tracking-tight text-brand-black">Thank you for your order!</h1>
      <p className="mt-2 text-gray-700">
        Order <span className="font-semibold text-brand-black">{order.orderRef}</span> is confirmed. A receipt would be sent to{' '}
        {order.email} in a live shop.
      </p>
      <ul className="mt-6 divide-y divide-gray-100 rounded-xl border border-gray-100 text-left text-sm">
        {order.items.map((item) => (
          <li key={item.name} className="flex justify-between gap-4 px-4 py-3">
            <span>
              {item.qty} × {item.name}
            </span>
            <span className="tabular-nums">{formatPrice(item.subtotal, order.currency)}</span>
          </li>
        ))}
        <li className="flex justify-between px-4 py-3 font-bold text-brand-black">
          <span>Total paid</span>
          <span className="tabular-nums">{formatPrice(order.total, order.currency)}</span>
        </li>
      </ul>
      <p className="mt-4 text-xs text-gray-500">Save your order number. You'll need it with your email to track the order.</p>
      <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:justify-center">
        {shop.features.orderTracking ? (
          <Link
            to={`/shop/${shopId}/track?order=${encodeURIComponent(order.orderRef)}`}
            className="flex min-h-[44px] items-center justify-center rounded-xl border border-gray-300 px-5 font-semibold text-brand-black hover:bg-gray-50"
          >
            Track this order
          </Link>
        ) : null}
        <Link
          to={`/shop/${shopId}`}
          className="flex min-h-[44px] items-center justify-center rounded-xl bg-brand-green px-5 font-semibold text-white hover:bg-brand-green-dark"
        >
          Continue shopping
        </Link>
      </div>
    </div>
  );
}

export function ShopCheckoutPage() {
  const { shopId, shop } = useShopContext();
  const { lines, total } = useCart(shopId);
  const clearCart = useCartStore((state) => state.clear);
  const checkout = useCheckout(shopId);
  const [placed, setPlaced] = useState<PlacedOrder | null>(null);
  // Signed-in shoppers: details pre-filled, and the order goes on their account.
  const session = useShopSession(shopId);
  useShopEvent(shopId, 'checkout_started');

  const { register, handleSubmit, formState } = useForm<CheckoutValues>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      fullName: session?.customer.fullName ?? '',
      email: session?.customer.email ?? '',
      phone: session?.customer.phone ?? '',
      shippingAddress: '',
      cardName: '',
      cardNumber: '',
      expiry: '',
      cvc: '',
    },
  });
  const { errors } = formState;

  if (!shop.features.checkout) return <Navigate to={`/shop/${shopId}/cart`} replace />;
  if (placed) return <Confirmation order={placed} />;
  if (lines.length === 0) {
    return (
      <EmptyState
        icon={ShoppingCart}
        minHeight={300}
        title="Your cart is empty"
        action={
          <Link to={`/shop/${shopId}`} className="font-semibold text-brand-green-dark underline">
            Continue shopping
          </Link>
        }
      />
    );
  }

  const onSubmit = handleSubmit((values) => {
    const parsed = checkoutSchema.parse(values);
    checkout.mutate(
      {
        customer: { fullName: parsed.fullName, email: parsed.email, phone: parsed.phone },
        shippingAddress: parsed.shippingAddress,
        items: lines.map((line) => ({ productId: line.productId, qty: line.qty })),
        // The card never leaves the browser: only the last 4 digits, for the record.
        payment: { method: 'demo_card', last4: parsed.cardNumber.slice(-4) },
      },
      {
        onSuccess: (order) => {
          clearCart(shopId);
          setPlaced(order);
          window.scrollTo({ top: 0 });
        },
        onError: (error) => toast.error(getApiErrorMessage(error), { duration: 6000 }),
      },
    );
  });

  const cardNumberField = register('cardNumber');
  const expiryField = register('expiry');

  return (
    <form onSubmit={onSubmit} noValidate className="grid grid-cols-1 gap-8 lg:grid-cols-3">
      <div className="space-y-8 lg:col-span-2">
        <section aria-labelledby="contact-heading" className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          <h2 id="contact-heading" className="mb-4 text-lg font-bold tracking-tight text-brand-black">
            Contact & delivery
          </h2>
          {shop.features.accounts && !session ? (
            <p className="-mt-2 mb-4 text-sm text-gray-700">
              Have an account?{' '}
              <Link to={`/shop/${shopId}/login?next=checkout`} className="font-semibold text-brand-green-dark underline">
                Log in
              </Link>{' '}
              to check out faster, or continue as a guest.
            </p>
          ) : null}
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <TextField label="Full name" autoComplete="name" error={errors.fullName?.message} className="sm:col-span-2" {...register('fullName')} />
            <TextField
              label="Email"
              type="email"
              autoComplete="email"
              readOnly={session !== null}
              hint={session ? 'Your account email' : undefined}
              error={errors.email?.message}
              {...register('email')}
            />
            <TextField label="Phone" type="tel" autoComplete="tel" hint="Optional" error={errors.phone?.message} {...register('phone')} />
            <TextAreaField
              label="Delivery address"
              autoComplete="street-address"
              rows={3}
              error={errors.shippingAddress?.message}
              className="sm:col-span-2"
              {...register('shippingAddress')}
            />
          </div>
        </section>

        <section aria-labelledby="payment-heading" className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h2 id="payment-heading" className="text-lg font-bold tracking-tight text-brand-black">
              Payment
            </h2>
            <span className="inline-flex items-center gap-1 text-xs text-gray-500">
              <Lock className="h-3.5 w-3.5" aria-hidden="true" /> Demo payment
            </span>
          </div>
          <p className="mb-4 rounded-xl bg-amber-50 p-3 text-sm text-amber-900">
            This is a demo shop: no real money is taken. Use test card <span className="font-mono font-semibold">4242 4242 4242 4242</span>,
            any future expiry date and any 3-digit CVC.
          </p>
          <div className="grid grid-cols-2 gap-4">
            <TextField label="Name on card" autoComplete="cc-name" error={errors.cardName?.message} className="col-span-2" {...register('cardName')} />
            <TextField
              label="Card number"
              inputMode="numeric"
              autoComplete="cc-number"
              placeholder="1234 1234 1234 1234"
              error={errors.cardNumber?.message}
              className="col-span-2"
              {...cardNumberField}
              onChange={(event) => {
                event.target.value = formatCardNumber(event.target.value);
                void cardNumberField.onChange(event);
              }}
              trailing={<CreditCard className="h-5 w-5 text-gray-400" aria-hidden="true" />}
            />
            <TextField
              label="Expiry (MM/YY)"
              inputMode="numeric"
              autoComplete="cc-exp"
              placeholder="MM/YY"
              error={errors.expiry?.message}
              {...expiryField}
              onChange={(event) => {
                event.target.value = formatExpiry(event.target.value);
                void expiryField.onChange(event);
              }}
            />
            <TextField label="CVC" inputMode="numeric" autoComplete="cc-csc" maxLength={4} error={errors.cvc?.message} {...register('cvc')} />
          </div>
        </section>
      </div>

      <aside className="h-fit rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:sticky lg:top-24" aria-label="Order summary">
        <h2 className="text-lg font-bold tracking-tight text-brand-black">Your order</h2>
        <ul className="mt-4 space-y-2 text-sm">
          {lines.map((line) => (
            <li key={line.productId} className="flex justify-between gap-3">
              <span className="text-gray-700">
                {line.qty} × {line.name}
              </span>
              <span className="tabular-nums">{formatPrice(line.qty * line.price, shop.currency)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-4 flex justify-between border-t border-gray-100 pt-4 text-base font-bold text-brand-black">
          <span>Total</span>
          <span className="tabular-nums">{formatPrice(total, shop.currency)}</span>
        </div>
        <Button type="submit" fullWidth loading={checkout.isPending} loadingText="Placing order…" className="mt-6 min-h-[48px]">
          Pay {formatPrice(total, shop.currency)}
        </Button>
        <Link to={`/shop/${shopId}/cart`} className="mt-3 block text-center text-sm font-medium text-gray-700 hover:underline">
          Back to cart
        </Link>
      </aside>
    </form>
  );
}
