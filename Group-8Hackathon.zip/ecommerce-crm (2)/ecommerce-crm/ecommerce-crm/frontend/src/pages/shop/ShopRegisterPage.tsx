import { zodResolver } from '@hookform/resolvers/zod';
import { Eye, EyeOff, UserPlus } from 'lucide-react';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { useShopContext, useShopRegister } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useShopSession } from '@/store/shopAccountStore';
import { shopReturnPath } from './ShopLoginPage';

// Same rules the server enforces.
const registerSchema = z
  .object({
    fullName: z.string().trim().min(1, 'Enter your name').max(255),
    email: z.string().trim().email('Enter a valid email'),
    phone: z.string().trim().max(32),
    password: z
      .string()
      .min(12, 'At least 12 characters')
      .refine((value) => /[a-z]/.test(value) && /[A-Z]/.test(value) && /\d/.test(value), {
        message: 'Use upper-case, lower-case and a number',
      }),
    confirmPassword: z.string(),
  })
  .refine((values) => values.password === values.confirmPassword, {
    path: ['confirmPassword'],
    message: "Passwords don't match",
  });
type RegisterValues = z.infer<typeof registerSchema>;

export function ShopRegisterPage() {
  const { shopId, shop } = useShopContext();
  const session = useShopSession(shopId);
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const registerAccount = useShopRegister(shopId);
  const [visible, setVisible] = useState(false);
  const next = params.get('next');
  const { register, handleSubmit, formState } = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: { fullName: '', email: '', phone: '', password: '', confirmPassword: '' },
  });
  const { errors } = formState;

  if (session && !registerAccount.isSuccess) return <Navigate to={shopReturnPath(shopId, next)} replace />;

  const onSubmit = handleSubmit(({ confirmPassword: _confirm, ...values }) =>
    registerAccount.mutate(values, {
      onSuccess: () => {
        toast.success('Your account is ready');
        navigate(shopReturnPath(shopId, next), { replace: true });
      },
    }),
  );

  const toggle = (
    <button
      type="button"
      onClick={() => setVisible((value) => !value)}
      aria-label={visible ? 'Hide password' : 'Show password'}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"
    >
      {visible ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
    </button>
  );

  return (
    <div className="mx-auto max-w-md">
      <UserPlus className="h-10 w-10 text-brand-green-dark" aria-hidden="true" />
      <h1 className="mt-3 text-2xl font-bold tracking-tight text-brand-black">Create an account</h1>
      <p className="mt-1 text-gray-700">Check out faster and see your orders at {shop.storeName}.</p>
      <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <TextField label="Full name" autoComplete="name" error={errors.fullName?.message} {...register('fullName')} />
        <TextField label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <TextField label="Phone" type="tel" autoComplete="tel" hint="Optional" error={errors.phone?.message} {...register('phone')} />
        <TextField
          label="Password"
          type={visible ? 'text' : 'password'}
          autoComplete="new-password"
          hint="At least 12 characters, with upper-case, lower-case and a number"
          error={errors.password?.message}
          trailing={toggle}
          {...register('password')}
        />
        <TextField
          label="Confirm password"
          type={visible ? 'text' : 'password'}
          autoComplete="new-password"
          error={errors.confirmPassword?.message}
          {...register('confirmPassword')}
        />
        {registerAccount.isError ? (
          <p role="alert" className="text-sm text-red-600">
            {getApiErrorMessage(registerAccount.error)}
          </p>
        ) : null}
        <Button type="submit" fullWidth loading={registerAccount.isPending}>
          Create account
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-gray-700">
        Already have an account?{' '}
        <Link
          to={`/shop/${shopId}/login${next ? `?next=${encodeURIComponent(next)}` : ''}`}
          className="font-semibold text-brand-green-dark underline"
        >
          Log in
        </Link>
      </p>
    </div>
  );
}
