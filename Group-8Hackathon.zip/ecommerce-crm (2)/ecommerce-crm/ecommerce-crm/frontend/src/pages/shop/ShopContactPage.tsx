import { zodResolver } from '@hookform/resolvers/zod';
import { CheckCircle2, MessageCircle } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Navigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { TextAreaField } from '@/components/ui/FormFields';
import { TextField } from '@/components/ui/TextField';
import { useContact, useShopContext } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';

const contactSchema = z.object({
  fullName: z.string().trim().min(1, 'Enter your name').max(255),
  email: z.string().trim().email('Enter a valid email'),
  subject: z.string().trim().min(3, 'Add a short subject').max(255),
  message: z.string().trim().min(10, 'Tell us a little more (at least 10 characters)').max(5000),
});
type ContactValues = z.infer<typeof contactSchema>;

/** Only exists when the store has the Support Desk: each message becomes a support ticket. */
export function ShopContactPage() {
  const { shopId, shop } = useShopContext();
  const contact = useContact(shopId);
  const { register, handleSubmit, reset, formState } = useForm<ContactValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: { fullName: '', email: '', subject: '', message: '' },
  });
  const { errors } = formState;

  if (!shop.features.contact) return <Navigate to={`/shop/${shopId}`} replace />;

  if (contact.isSuccess) {
    return (
      <div className="mx-auto max-w-xl rounded-3xl border border-gray-100 bg-white p-8 text-center shadow-sm" aria-live="polite">
        <CheckCircle2 className="mx-auto h-12 w-12 text-brand-green" aria-hidden="true" />
        <h1 className="mt-4 text-2xl font-bold tracking-tight text-brand-black">Message sent</h1>
        <p className="mt-2 text-gray-700">Thanks for getting in touch. The {shop.storeName} team will reply by email.</p>
        <Button
          variant="outline"
          className="mt-6"
          onClick={() => {
            reset();
            contact.reset();
          }}
        >
          Send another message
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-xl">
      <MessageCircle className="h-10 w-10 text-brand-green-dark" aria-hidden="true" />
      <h1 className="mt-3 text-2xl font-bold tracking-tight text-brand-black">Contact us</h1>
      <p className="mt-1 text-gray-700">Questions about a product or an order? Send us a message.</p>
      <form
        onSubmit={handleSubmit((values) =>
          contact.mutate(values, { onError: (error) => toast.error(getApiErrorMessage(error)) }),
        )}
        noValidate
        className="mt-6 space-y-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm"
      >
        <TextField label="Your name" autoComplete="name" error={errors.fullName?.message} {...register('fullName')} />
        <TextField label="Email" type="email" autoComplete="email" error={errors.email?.message} {...register('email')} />
        <TextField label="Subject" error={errors.subject?.message} {...register('subject')} />
        <TextAreaField label="Message" rows={5} error={errors.message?.message} {...register('message')} />
        <Button type="submit" fullWidth loading={contact.isPending}>
          Send message
        </Button>
      </form>
    </div>
  );
}
