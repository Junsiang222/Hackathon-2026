import { zodResolver } from '@hookform/resolvers/zod';
import { LogIn } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { useShopContext, useShopLogin } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useShopSession } from '@/store/shopAccountStore';

const loginSchema = z.object({
  email: z.string().trim().email('Enter your email'),
  password: z.string().min(1, 'Enter your password'),
});
type LoginValues = z.infer<typeof loginSchema>;

/** Only pages inside this shop may be returned to after logging in. */
const RETURN_PAGES = ['account', 'checkout', 'cart'] as const;
export function shopReturnPath(shopId: string, next: string | null): string {
  const page = RETURN_PAGES.find((candidate) => candidate === next) ?? 'account';
  return `/shop/${shopId}/${page}`;
}

export function ShopLoginPage() {
  const { shopId, shop } = useShopContext();
  const session = useShopSession(shopId);
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const login = useShopLogin(shopId);
  const next = params.get('next');
  const { register, handleSubmit, formState } = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: '', password: '' },
  });

  if (session && !login.isSuccess) return <Navigate to={shopReturnPath(shopId, next)} replace />;

  const onSubmit = handleSubmit((values) =>
    login.mutate(values, {
      onSuccess: ({ customer }) => {
        toast.success(`Welcome back, ${customer.fullName.split(' ')[0]}`);
        navigate(shopReturnPath(shopId, next), { replace: true });
      },
    }),
  );

  return (
    <div className="mx-auto max-w-md">
      <LogIn className="h-10 w-10 text-brand-green-dark" aria-hidden="true" />
      <h1 className="mt-3 text-2xl font-bold tracking-tight text-brand-black">Log in</h1>
      <p className="mt-1 text-gray-700">Log in to your {shop.storeName} account.</p>
      <form onSubmit={onSubmit} noValidate className="mt-6 space-y-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <TextField label="Email" type="email" autoComplete="email" error={formState.errors.email?.message} {...register('email')} />
        <TextField
          label="Password"
          type="password"
          autoComplete="current-password"
          error={formState.errors.password?.message}
          {...register('password')}
        />
        {login.isError ? (
          <p role="alert" className="text-sm text-red-600">
            {getApiErrorMessage(login.error)}
          </p>
        ) : null}
        <Button type="submit" fullWidth loading={login.isPending}>
          Log in
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-gray-700">
        New here?{' '}
        <Link
          to={`/shop/${shopId}/register${next ? `?next=${encodeURIComponent(next)}` : ''}`}
          className="font-semibold text-brand-green-dark underline"
        >
          Create an account
        </Link>
      </p>
    </div>
  );
}
