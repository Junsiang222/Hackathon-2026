import { zodResolver } from '@hookform/resolvers/zod';
import { Check, PackageSearch } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { Navigate, useSearchParams } from 'react-router-dom';
import { z } from 'zod';
import { formatPrice } from '@/components/shop/ProductImage';
import { Button } from '@/components/ui/Button';
import { TextField } from '@/components/ui/TextField';
import { useShopContext, useTrackOrder } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import type { TrackedOrder } from '@/types/shop.types';
import { formatDateTime } from '@/utils/format';

const trackSchema = z.object({
  orderRef: z.string().trim().min(1, 'Enter your order number'),
  email: z.string().trim().email('Enter the email you ordered with'),
});
type TrackValues = z.infer<typeof trackSchema>;

const STEPS = ['confirmed', 'shipped', 'delivered'] as const;
const STEP_LABEL: Record<(typeof STEPS)[number], string> = { confirmed: 'Confirmed', shipped: 'Shipped', delivered: 'Delivered' };

function Progress({ status }: { status: string }) {
  if (status === 'cancelled' || status === 'refunded') {
    return <p className="rounded-xl bg-red-50 p-3 text-sm font-medium capitalize text-red-700">This order was {status}.</p>;
  }
  const reached = status === 'pending' ? -1 : STEPS.indexOf(status as (typeof STEPS)[number]);
  return (
    <ol className="grid grid-cols-3 gap-2" aria-label="Order progress">
      {STEPS.map((step, index) => {
        const done = index <= reached;
        return (
          <li key={step} className="flex flex-col items-center gap-2 text-center text-sm">
            <span
              className={`flex h-9 w-9 items-center justify-center rounded-full ${done ? 'bg-brand-green text-white' : 'bg-gray-100 text-gray-400'}`}
            >
              {done ? <Check className="h-5 w-5" aria-hidden="true" /> : index + 1}
            </span>
            <span className={done ? 'font-semibold text-brand-black' : 'text-gray-500'}>
              {STEP_LABEL[step]}
              <span className="sr-only">{done ? ' (done)' : ' (not yet)'}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}

function OrderResult({ order }: { order: TrackedOrder }) {
  return (
    <section aria-live="polite" className="mt-6 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
      <div className="mb-5 flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="text-lg font-bold tracking-tight text-brand-black">Order {order.orderRef}</h2>
        <p className="text-sm text-gray-500">Placed {formatDateTime(order.placedAt)}</p>
      </div>
      <Progress status={order.status} />
      <ul className="mt-6 divide-y divide-gray-100 border-t border-gray-100 text-sm">
        {order.items.map((item) => (
          <li key={item.name} className="flex justify-between gap-4 py-2.5">
            <span>
              {item.qty} × {item.name}
            </span>
            <span className="tabular-nums">{formatPrice(item.subtotal, order.currency)}</span>
          </li>
        ))}
        <li className="flex justify-between py-2.5 font-bold text-brand-black">
          <span>Total</span>
          <span className="tabular-nums">{formatPrice(order.total, order.currency)}</span>
        </li>
      </ul>
    </section>
  );
}

export function ShopTrackPage() {
  const { shopId, shop } = useShopContext();
  const [params] = useSearchParams();
  const track = useTrackOrder(shopId);
  const { register, handleSubmit, formState } = useForm<TrackValues>({
    resolver: zodResolver(trackSchema),
    defaultValues: { orderRef: params.get('order') ?? '', email: '' },
  });

  if (!shop.features.orderTracking) return <Navigate to={`/shop/${shopId}`} replace />;

  return (
    <div className="mx-auto max-w-xl">
      <PackageSearch className="h-10 w-10 text-brand-green-dark" aria-hidden="true" />
      <h1 className="mt-3 text-2xl font-bold tracking-tight text-brand-black">Track your order</h1>
      <p className="mt-1 text-gray-700">Enter your order number and the email you used at checkout.</p>
      <form
        onSubmit={handleSubmit((values) => track.mutate(values))}
        noValidate
        className="mt-6 space-y-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm"
      >
        <TextField label="Order number" placeholder="WEB-…" error={formState.errors.orderRef?.message} {...register('orderRef')} />
        <TextField label="Email" type="email" autoComplete="email" error={formState.errors.email?.message} {...register('email')} />
        {track.isError ? (
          <p role="alert" className="text-sm text-red-600">
            {getApiErrorMessage(track.error)}
          </p>
        ) : null}
        <Button type="submit" fullWidth loading={track.isPending}>
          Find my order
        </Button>
      </form>
      {track.data ? <OrderResult order={track.data} /> : null}
    </div>
  );
}
