import { LogOut, ShoppingBag, UserRound } from 'lucide-react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { formatPrice } from '@/components/shop/ProductImage';
import { Button } from '@/components/ui/Button';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { useShopAccount, useShopContext, useShopLogout } from '@/hooks/useShop';
import { getApiErrorMessage } from '@/lib/axios';
import { useShopSession } from '@/store/shopAccountStore';
import { formatDateTime } from '@/utils/format';

export function ShopAccountPage() {
  const { shopId, shop } = useShopContext();
  const session = useShopSession(shopId);
  const accountQuery = useShopAccount(shopId);
  const logout = useShopLogout(shopId);
  const navigate = useNavigate();
  const root = `/shop/${shopId}`;

  // After "Log out" the session is gone but we're already heading to the shop home.
  if (!session) return logout.isIdle ? <Navigate to={`${root}/login`} replace /> : null;

  const onLogout = () =>
    logout.mutate(undefined, {
      onSettled: () => {
        toast.success('You are logged out');
        navigate(root, { replace: true });
      },
    });

  if (accountQuery.isPending) return <LoadingShimmer rows={3} />;
  if (accountQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(accountQuery.error)}
        onRetry={() => accountQuery.refetch()}
        isRetrying={accountQuery.isFetching}
      />
    );
  }

  const { customer, orders, memberSince } = accountQuery.data;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <section className="flex flex-wrap items-center gap-4 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-mint text-brand-green-dark">
          <UserRound className="h-6 w-6" aria-hidden="true" />
        </span>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-xl font-bold tracking-tight text-brand-black">{customer.fullName}</h1>
          <p className="truncate text-sm text-gray-700">
            {customer.email}
            {customer.phone ? ` · ${customer.phone}` : ''}
          </p>
          <p className="text-xs text-gray-500">Member since {formatDateTime(memberSince)}</p>
        </div>
        <Button
          variant="outline"
          onClick={onLogout}
          loading={logout.isPending}
          leftIcon={<LogOut className="h-4 w-4" aria-hidden="true" />}
        >
          Log out
        </Button>
      </section>

      <section aria-labelledby="orders-heading" className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <h2 id="orders-heading" className="text-lg font-bold tracking-tight text-brand-black">
          My orders
        </h2>
        {orders.length === 0 ? (
          <EmptyState
            icon={ShoppingBag}
            minHeight={200}
            title="No orders yet"
            description="Orders you place while logged in show up here."
            action={
              <Link to={root} className="font-semibold text-brand-green-dark underline">
                Start shopping
              </Link>
            }
          />
        ) : (
          <ul className="mt-4 divide-y divide-gray-100">
            {orders.map((order) => (
              <li key={order.orderRef} className="flex flex-wrap items-center gap-x-4 gap-y-1 py-3 text-sm">
                <span className="font-mono font-semibold text-brand-black">{order.orderRef}</span>
                <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium capitalize text-gray-700">
                  {order.status}
                </span>
                <span className="text-gray-500">
                  {formatDateTime(order.placedAt)} · {order.itemCount} {order.itemCount === 1 ? 'item' : 'items'}
                </span>
                <span className="ml-auto font-semibold tabular-nums">{formatPrice(order.total, order.currency)}</span>
                {shop.features.orderTracking ? (
                  <Link
                    to={`${root}/track?order=${encodeURIComponent(order.orderRef)}`}
                    className="w-full text-xs font-semibold text-brand-green-dark hover:underline sm:w-auto"
                  >
                    Track
                  </Link>
                ) : null}
              </li>
            ))}
          </ul>
        )}
        {shop.features.orderTracking ? (
          <p className="mt-4 text-xs text-gray-500">
            Ordered as a guest before you made this account? Find those orders with{' '}
            <Link to={`${root}/track`} className="underline">
              Track order
            </Link>
            .
          </p>
        ) : null}
      </section>
    </div>
  );
}
