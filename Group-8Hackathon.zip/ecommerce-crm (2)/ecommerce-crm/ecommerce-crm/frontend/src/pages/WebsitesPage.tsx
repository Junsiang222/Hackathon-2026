import { zodResolver } from '@hookform/resolvers/zod';
import {
  ChevronDown,
  ExternalLink,
  Eye,
  EyeOff,
  Globe,
  Image as ImageIcon,
  KeyRound,
  LayoutTemplate,
  RotateCcw,
  Sparkles,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { LayoutWidgetGrid } from '@/components/LayoutWidgetGrid';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { Button } from '@/components/ui/Button';
import { CopyButton, CredentialsCard } from '@/components/ui/CopyButton';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { TextField } from '@/components/ui/TextField';
import {
  useCreateStoreLogin,
  useRefreshWebsitePhotos,
  useRegenerateWebsite,
  useRemoveTenant,
  type WebsitePhotoResult,
  useResetStoreLogin,
  useTenantLayouts,
  useTenants,
  useTenantWebsite,
} from '@/hooks/useDashboard';
import { getApiErrorMessage } from '@/lib/axios';
import type { ResetPasswordResult, StoreLogin, Tenant } from '@/types/api.types';
import { capitalize, useT, type TFunction } from '@/i18n';
import { formatDateTime, formatInteger } from '@/utils/format';

function TenantLayouts({ tenantId }: { tenantId: number }) {
  const layoutsQuery = useTenantLayouts(tenantId);
  const t = useT();

  if (layoutsQuery.isPending) return <LoadingShimmer rows={2} />;
  if (layoutsQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(layoutsQuery.error)}
        onRetry={() => layoutsQuery.refetch()}
        isRetrying={layoutsQuery.isFetching}
      />
    );
  }

  return (
    <div className="space-y-8">
      {layoutsQuery.data.map((layout) => (
        <section key={layout.id} aria-label={layout.layoutName}>
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <h3 className="text-sm font-semibold text-brand-black">{layout.layoutName}</h3>
            {layout.isActive ? (
              <span className="rounded-full bg-brand-mint px-2 py-0.5 text-xs font-semibold text-brand-green-dark">
                {t('Active')}
              </span>
            ) : (
              <span className="rounded-full border border-gray-200 px-2 py-0.5 text-xs text-gray-500">{t('Archived')}</span>
            )}
            <span className="text-xs text-gray-500">
              {t('Layout #{id} · generated {date} · {count} widgets', { id: layout.id, date: formatDateTime(layout.createdAt), count: layout.config.length })}
            </span>
          </div>
          <LayoutWidgetGrid widgets={layout.config} />
        </section>
      ))}
    </div>
  );
}

function signInLabel(login: StoreLogin, t: TFunction): string {
  const methods = [
    login.hasPassword ? t('Password') : null,
    login.oauthProvider ? t('{provider} sign-in', { provider: capitalize(login.oauthProvider) }) : null,
  ];
  return methods.filter(Boolean).join(' + ') || t('No sign-in method');
}

// Same rules the server enforces for every password.
const resetSchema = z
  .object({
    newPassword: z
      .string()
      .min(12, 'At least 12 characters')
      .refine((value) => /[a-z]/.test(value) && /[A-Z]/.test(value) && /\d/.test(value), {
        message: 'Use upper-case, lower-case and a number',
      }),
    confirmPassword: z.string(),
    mustChangePassword: z.boolean(),
  })
  .refine((values) => values.newPassword === values.confirmPassword, {
    path: ['confirmPassword'],
    message: "Passwords don't match",
  });
type ResetValues = z.infer<typeof resetSchema>;

/** e.g. "Kp7m-Qx2r-Wd9t": no look-alike characters, always meets the rules. */
function suggestPassword(): string {
  const pick = (chars: string) => chars[crypto.getRandomValues(new Uint32Array(1))[0]! % chars.length]!;
  const group = () =>
    pick('ABCDEFGHJKLMNPQRSTUVWXYZ') +
    pick('abcdefghijkmnpqrstuvwxyz') +
    pick('23456789') +
    pick('abcdefghijkmnpqrstuvwxyz');
  return [group(), group(), group()].join('-');
}

function ResetPasswordForm({
  onSubmit,
}: {
  onSubmit: (values: { newPassword: string; mustChangePassword: boolean }) => void;
}) {
  const [visible, setVisible] = useState(false);
  const t = useT();
  const { register, handleSubmit, setValue, formState } = useForm<ResetValues>({
    resolver: zodResolver(resetSchema),
    defaultValues: { newPassword: '', confirmPassword: '', mustChangePassword: false },
  });
  const { errors } = formState;

  const onSuggest = () => {
    const password = suggestPassword();
    setValue('newPassword', password, { shouldValidate: true });
    setValue('confirmPassword', password, { shouldValidate: true });
    setVisible(true);
  };

  const toggle = (
    <button
      type="button"
      onClick={() => setVisible((value) => !value)}
      aria-label={visible ? t('Hide password') : t('Show password')}
      className="flex h-9 w-9 items-center justify-center rounded-lg text-gray-500 hover:bg-gray-100"
    >
      {visible ? <EyeOff className="h-4 w-4" aria-hidden="true" /> : <Eye className="h-4 w-4" aria-hidden="true" />}
    </button>
  );

  return (
    <form
      id="reset-password-form"
      noValidate
      onSubmit={handleSubmit(({ newPassword, mustChangePassword }) => onSubmit({ newPassword, mustChangePassword }))}
      className="space-y-4"
    >
      <TextField
        label={t('New password')}
        type={visible ? 'text' : 'password'}
        autoComplete="new-password"
        hint={t('At least 12 characters, with upper-case, lower-case and a number')}
        error={errors.newPassword?.message && t(errors.newPassword.message)}
        trailing={toggle}
        {...register('newPassword')}
      />
      <TextField
        label={t('Confirm new password')}
        type={visible ? 'text' : 'password'}
        autoComplete="new-password"
        error={errors.confirmPassword?.message && t(errors.confirmPassword.message)}
        {...register('confirmPassword')}
      />
      <button
        type="button"
        onClick={onSuggest}
        className="inline-flex min-h-[40px] items-center gap-1.5 text-sm font-semibold text-brand-green-dark hover:underline"
      >
        <Sparkles className="h-4 w-4" aria-hidden="true" />
        {t('Suggest a strong password')}
      </button>
      <label className="flex cursor-pointer items-start gap-3 rounded-xl border border-gray-200 p-3 text-sm">
        <input type="checkbox" className="mt-0.5 h-4 w-4 accent-brand-green" {...register('mustChangePassword')} />
        <span>
          <span className="block font-medium text-brand-black">{t('Ask the owner to choose their own password')}</span>
          <span className="block text-gray-500">{t("They'll set a new one the next time they log in.")}</span>
        </span>
      </label>
      <p className="text-xs text-gray-500">
        {t('The new password works straight away and the store admin is signed out of any open sessions. Google sign-in keeps working.')}
      </p>
    </form>
  );
}

/** Store admin/staff logins. Passwords can't be shown (only a hash is stored); the super admin can set a new one. */
function StoreLogins({ tenant }: { tenant: Tenant }) {
  const reset = useResetStoreLogin();
  const create = useCreateStoreLogin();
  const [confirming, setConfirming] = useState<StoreLogin | null>(null);
  const [result, setResult] = useState<ResetPasswordResult | null>(null);
  const t = useT();

  const onCreate = () =>
    create.mutate(tenant.id, {
      onSuccess: setResult,
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });

  return (
    <div className="border-t border-gray-100 px-5 py-3">
      <h3 className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wide text-gray-500">
        <KeyRound className="h-3.5 w-3.5" aria-hidden="true" />
        {t('Store admin login')}
      </h3>
      {tenant.logins.length === 0 ? (
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-sm text-gray-500">{t('No admin account yet.')}</p>
          <Button
            variant="dark"
            className="min-h-[36px] px-3 text-xs"
            onClick={onCreate}
            loading={create.isPending}
            leftIcon={<UserPlus className="h-3.5 w-3.5 text-brand-green" aria-hidden="true" />}
          >
            {t('Create admin login')}
          </Button>
        </div>
      ) : (
        <ul className="space-y-2">
          {tenant.logins.map((login) => (
            <li key={login.userId} className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
              <span className="flex min-w-0 items-center gap-1">
                <span className="truncate font-mono text-brand-black">{login.email}</span>
                <CopyButton text={login.email} label={t('Copy email {email}', { email: login.email })} />
              </span>
              <span className="rounded-full bg-gray-100 px-2 py-0.5 text-xs font-medium capitalize text-gray-700">
                {t(capitalize(login.role))}
              </span>
              <span className="text-xs text-gray-500">{signInLabel(login, t)}</span>
              {login.hasTemporaryPassword ? (
                <span className="rounded-full bg-amber-100 px-2 py-0.5 text-xs font-semibold text-amber-900">
                  {t('Temporary password, not changed yet')}
                </span>
              ) : null}
              <span className="text-xs text-gray-500">{t('Last login {date}', { date: formatDateTime(login.lastLoginAt) })}</span>
              <Button
                variant="outline"
                className="ml-auto min-h-[36px] px-3 text-xs"
                onClick={() => setConfirming(login)}
                leftIcon={<RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />}
              >
                {t('Reset password')}
              </Button>
            </li>
          ))}
        </ul>
      )}

      <Modal
        open={confirming !== null}
        title={t('Reset password')}
        description={confirming ? `${confirming.email} · ${tenant.businessName}` : undefined}
        onClose={() => setConfirming(null)}
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirming(null)}>
              {t('Cancel')}
            </Button>
            <Button variant="dark" type="submit" form="reset-password-form" loading={reset.isPending}>
              {t('Save new password')}
            </Button>
          </>
        }
      >
        {confirming ? (
          <ResetPasswordForm
            onSubmit={({ newPassword, mustChangePassword }) =>
              reset.mutate(
                { tenantId: tenant.id, userId: confirming.userId, newPassword, mustChangePassword },
                {
                  onSuccess: (data) => {
                    setConfirming(null);
                    toast.success(
                      data.mustChangePassword
                        ? t("Password changed for {email}. They'll choose their own at next login.", { email: data.email })
                        : t('Password changed for {email}', { email: data.email }),
                    );
                  },
                  onError: (error) => toast.error(getApiErrorMessage(error)),
                },
              )
            }
          />
        ) : null}
      </Modal>

      <Modal
        open={result !== null}
        title={t('Admin login created')}
        description={tenant.businessName}
        onClose={() => setResult(null)}
        footer={
          <Button variant="dark" onClick={() => setResult(null)}>
            {t("I've saved them")}
          </Button>
        }
      >
        {result ? <CredentialsCard email={result.email} password={result.temporaryPassword} /> : null}
      </Modal>
    </div>
  );
}

/** Why some of the page's photos are missing, or null when none are. */
function missingPhotosNote(result: WebsitePhotoResult, t: TFunction): string | null {
  if (result.missingPhotos === 0) return null;
  return result.photoSearchAvailable
    ? t('{count} photo(s) still missing: no matching photo was found. Try Refresh photos, or Regenerate with a different description.', { count: result.missingPhotos })
    : t('{count} photo(s) still missing because the free photo limit (50 searches an hour) is used up. Click Refresh photos in about an hour.', { count: result.missingPhotos });
}

/** Finds the photos the current AI page is missing, without redesigning it. */
function RefreshPhotos({ tenant }: { tenant: Tenant }) {
  const refresh = useRefreshWebsitePhotos();
  const t = useT();
  const onRefresh = () =>
    refresh.mutate(tenant.id, {
      onSuccess: (data) => {
        const note = missingPhotosNote(data, t);
        const added = data.added > 0 ? `${t('Added {count} photo(s).', { count: data.added })} ` : '';
        if (note) toast(`${added}${note}`, { icon: '⚠️', duration: 9000 });
        else toast.success(`${added}${t('All website photos are in place. Product photos are being added in the background.')}`);
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });

  return (
    <Button
      variant="outline"
      className="mb-3 min-h-[44px] shrink-0 px-4 text-sm sm:mb-0"
      onClick={onRefresh}
      loading={refresh.isPending}
      leftIcon={<ImageIcon className="h-4 w-4" aria-hidden="true" />}
    >
      {t('Refresh photos')}
      <span className="sr-only"> · {tenant.businessName}</span>
    </Button>
  );
}

/** Rebuilds the store's home page with the AI, starting from the saved step 9 description. */
function RegenerateWebsite({ tenant }: { tenant: Tenant }) {
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState<string | null>(null);
  const websiteQuery = useTenantWebsite(tenant.id, open);
  const regenerate = useRegenerateWebsite();
  const t = useT();
  const promptId = `regenerate-prompt-${tenant.id}`;
  const value = prompt ?? websiteQuery.data?.websitePrompt ?? '';
  const tooShort = value.trim().length < 10;

  const close = () => {
    if (regenerate.isPending) return;
    setOpen(false);
    setPrompt(null);
  };

  const onRegenerate = () =>
    regenerate.mutate(
      { tenantId: tenant.id, websitePrompt: value.trim() },
      {
        onSuccess: (data) => {
          setOpen(false);
          setPrompt(null);
          const note = missingPhotosNote(data, t);
          const ready = t('New website ready for {name}.', { name: tenant.businessName });
          if (note) toast(`${ready} ${note}`, { icon: '⚠️', duration: 9000 });
          else toast.success(`${ready} ${t('Open it with Visit website.')}`);
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    );

  return (
    <>
      <Button
        variant="outline"
        className="mb-3 min-h-[44px] shrink-0 px-4 text-sm sm:mb-0"
        onClick={() => setOpen(true)}
        leftIcon={<Sparkles className="h-4 w-4 text-brand-green-dark" aria-hidden="true" />}
      >
        {t('Regenerate website')}
        <span className="sr-only"> · {tenant.businessName}</span>
      </Button>
      <Modal
        open={open}
        title={t('Regenerate website')}
        description={tenant.businessName}
        onClose={close}
        footer={
          <>
            <Button variant="outline" onClick={close} disabled={regenerate.isPending}>
              {t('Cancel')}
            </Button>
            <Button
              variant="dark"
              onClick={onRegenerate}
              loading={regenerate.isPending}
              disabled={tooShort || websiteQuery.isPending}
              leftIcon={<Sparkles className="h-4 w-4 text-brand-green" aria-hidden="true" />}
            >
              {regenerate.isPending ? t('Designing…') : t('Regenerate')}
            </Button>
          </>
        }
      >
        {websiteQuery.isPending ? (
          <LoadingShimmer rows={2} />
        ) : websiteQuery.isError ? (
          <ErrorPlaceholder
            message={getApiErrorMessage(websiteQuery.error)}
            onRetry={() => websiteQuery.refetch()}
            isRetrying={websiteQuery.isFetching}
          />
        ) : (
          <div className="space-y-3">
            <label htmlFor={promptId} className="block text-sm font-semibold text-brand-black">
              {t('Describe the website')}
            </label>
            <textarea
              id={promptId}
              rows={6}
              maxLength={1000}
              value={value}
              onChange={(event) => setPrompt(event.target.value)}
              disabled={regenerate.isPending}
              className="block w-full rounded-xl border border-gray-300 px-3.5 py-2.5 text-base focus:border-brand-black focus:outline-none focus:ring-4 focus:ring-gray-100 disabled:bg-gray-50"
              placeholder={t("What you sell, who it's for, the look and feel, what to highlight")}
            />
            <p className="text-xs text-gray-500">
              {value.length}/1000 · {t('The AI designs a brand-new home page with photos. This usually takes 2–3 minutes (up to 5). The admin dashboard stays the same, and the current website is kept as an archived version in this list.')}
            </p>
            {tooShort ? <p className="text-xs font-medium text-red-600">{t('Describe the website in at least 10 characters.')}</p> : null}
          </div>
        )}
      </Modal>
    </>
  );
}

function WebsiteRow({ tenant }: { tenant: Tenant }) {
  const [open, setOpen] = useState(false);
  const [confirmingRemove, setConfirmingRemove] = useState(false);
  const remove = useRemoveTenant();
  const t = useT();
  const panelId = `history-panel-${tenant.id}`;

  const onRemove = () =>
    remove.mutate(tenant.id, {
      onSuccess: () => {
        setConfirmingRemove(false);
        toast.success(t('{name} removed', { name: tenant.businessName }));
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });

  return (
    <li className="rounded-2xl border border-gray-100 bg-white shadow-sm">
      <div className="flex flex-wrap items-center gap-2 pr-3 sm:flex-nowrap">
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-controls={panelId}
          className="flex min-w-0 flex-1 flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl px-5 py-4 text-left hover:bg-gray-50"
        >
          <span className="min-w-[180px] flex-1">
            <span className="block font-semibold text-brand-black">{tenant.businessName}</span>
            <span className="block text-xs capitalize text-gray-500">
              {t(capitalize(tenant.industry))} · {t(capitalize(tenant.plan))}
            </span>
          </span>
          <StatusBadge status={tenant.status} color={tenant.statusColor} />
          <span className="text-sm text-gray-700">
            <span className="tabular-nums">{formatInteger(tenant.layoutCount)}</span>{' '}
            {tenant.layoutCount === 1 ? t('layout') : t('layouts')}
          </span>
          <span className="whitespace-nowrap text-sm text-gray-700">
            {tenant.lastLayoutAt ? t('Generated {date}', { date: formatDateTime(tenant.lastLayoutAt) }) : null}
          </span>
          <ChevronDown
            className={`h-5 w-5 text-gray-500 transition-transform ${open ? 'rotate-180' : ''}`}
            aria-hidden="true"
          />
        </button>
        {tenant.hasWebsite ? <RefreshPhotos tenant={tenant} /> : null}
        {tenant.hasWebsite ? <RegenerateWebsite tenant={tenant} /> : null}
        {tenant.hasWebsite ? (
          <a
            href={`/shop/${tenant.tenantUid}`}
            target="_blank"
            rel="noopener"
            className="mb-3 ml-5 inline-flex min-h-[44px] shrink-0 items-center gap-2 rounded-xl bg-brand-black px-4 text-sm font-semibold text-white hover:bg-gray-800 sm:mb-0 sm:ml-0"
          >
            <ExternalLink className="h-4 w-4 text-brand-green" aria-hidden="true" />
            {t('Visit website')}
            <span className="sr-only"> · {tenant.businessName} {t('(opens in a new tab)')}</span>
          </a>
        ) : (
          <span className="mb-3 ml-5 shrink-0 text-xs text-gray-500 sm:mb-0 sm:ml-0">{t('No website (Storefront off)')}</span>
        )}
        <button
          type="button"
          onClick={() => setConfirmingRemove(true)}
          aria-label={t('Remove {name}', { name: tenant.businessName })}
          title={t('Remove store')}
          className="mb-3 flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-gray-500 hover:bg-red-50 hover:text-red-600 sm:mb-0"
        >
          <Trash2 className="h-5 w-5" aria-hidden="true" />
        </button>
      </div>
      <Modal
        open={confirmingRemove}
        title={t('Remove {name}?', { name: tenant.businessName })}
        onClose={() => setConfirmingRemove(false)}
        footer={
          <>
            <Button variant="outline" onClick={() => setConfirmingRemove(false)}>
              {t('Cancel')}
            </Button>
            <Button
              variant="danger"
              onClick={onRemove}
              loading={remove.isPending}
              leftIcon={<Trash2 className="h-4 w-4" aria-hidden="true" />}
            >
              {t('Remove store')}
            </Button>
          </>
        }
      >
        <ul className="list-disc space-y-1 pl-5 text-sm text-gray-700">
          <li>{t('The website goes offline straight away.')}</li>
          <li>{t("Store admin and staff are signed out and can't log in.")}</li>
          <li>{t('Orders and customer records are kept, not deleted.')}</li>
        </ul>
      </Modal>
      <StoreLogins tenant={tenant} />
      {open ? (
        <div id={panelId} className="border-t border-gray-100 p-5">
          <TenantLayouts tenantId={tenant.id} />
        </div>
      ) : null}
    </li>
  );
}

/** Stores whose website and admin dashboard are built (formerly "History"). */
export function WebsitesPage() {
  const tenantsQuery = useTenants();
  const t = useT();

  const generated = useMemo(
    () =>
      (tenantsQuery.data ?? [])
        .filter((tenant) => tenant.layoutCount > 0 && tenant.status !== 'cancelled')
        .sort((a, b) => new Date(b.lastLayoutAt ?? 0).getTime() - new Date(a.lastLayoutAt ?? 0).getTime()),
    [tenantsQuery.data],
  );

  if (tenantsQuery.isPending) return <LoadingShimmer rows={4} />;
  if (tenantsQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(tenantsQuery.error)}
        onRetry={() => tenantsQuery.refetch()}
        isRetrying={tenantsQuery.isFetching}
      />
    );
  }

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-4">
        <h2 className="text-lg font-bold tracking-tight text-brand-black">{t('Created websites')}</h2>
        <p className="text-sm text-gray-700">
          {t('Stores whose website and admin dashboard are done, newest first. Visit a website, or open a store to see its dashboard layout.')}
        </p>
      </div>

      {generated.length === 0 ? (
        <EmptyState
          icon={Globe}
          title={t('No websites yet')}
          description={t('When you create a website for a store, it moves here from Tenant workspaces.')}
        />
      ) : (
        <ul className="space-y-3" aria-label={t('Generated dashboards')}>
          {generated.map((tenant) => (
            <WebsiteRow key={tenant.id} tenant={tenant} />
          ))}
        </ul>
      )}

      <p className="mt-6 flex items-center gap-2 text-xs text-gray-500">
        <LayoutTemplate className="h-4 w-4" aria-hidden="true" />
        {t("Layouts show structure only. Store data renders on each store's own Analytics page.")}
      </p>
    </div>
  );
}
