import { LayoutTemplate } from 'lucide-react';
import { DashboardGrid } from '@/components/charts/DashboardGrid';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { EmptyState } from '@/components/ui/EmptyState';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { useActiveLayout } from '@/hooks/useDashboard';
import { getApiErrorMessage } from '@/lib/axios';
import { formatDateTime } from '@/utils/format';

export function AnalyticsPage() {
  const layoutQuery = useActiveLayout();

  if (layoutQuery.isPending) return <LoadingShimmer rows={3} />;
  if (layoutQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(layoutQuery.error)}
        onRetry={() => layoutQuery.refetch()}
        isRetrying={layoutQuery.isFetching}
      />
    );
  }

  const layout = layoutQuery.data;
  if (!layout || layout.config.length === 0) {
    return (
      <EmptyState
        icon={LayoutTemplate}
        minHeight={320}
        title="No dashboard yet"
        description="Your platform administrator hasn't generated an analytics layout for this store. Once they do, it appears here automatically."
      />
    );
  }

  return (
    <div className="mx-auto max-w-7xl">
      <div className="px-6">
        <h2 className="text-lg font-bold tracking-tight text-brand-black">{layout.layoutName}</h2>
        <p className="text-sm text-gray-700">
          Version {layout.version} · generated {formatDateTime(layout.createdAt)} · refreshes every minute
        </p>
      </div>
      <DashboardGrid widgets={layout.config} />
    </div>
  );
}
