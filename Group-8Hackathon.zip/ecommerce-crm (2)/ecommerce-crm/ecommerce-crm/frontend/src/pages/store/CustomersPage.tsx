import { zodResolver } from '@hookform/resolvers/zod';
import { Plus, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { RequireModule } from '@/components/RequireModule';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, Toolbar, useDebounced, type Column } from '@/components/ui/DataTable';
import { SelectField, optionsFrom } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { TextField } from '@/components/ui/TextField';
import { useCustomers, useIsSaving, useSaveCustomer } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { CustomerItem, CustomerStatus } from '@/types/store.types';
import { formatAmount, formatDateTime, formatInteger } from '@/utils/format';

const STATUSES = ['active', 'inactive', 'blocked'] as const satisfies readonly CustomerStatus[];
const CHANNELS = ['organic', 'paid_social', 'referral', 'email', 'search', 'storefront', 'walk_in'] as const;

const customerSchema = z.object({
  fullName: z.string().trim().min(1, 'Enter a name').max(255),
  email: z.union([z.literal(''), z.string().trim().email('Enter a valid email')]),
  phone: z.string().trim().max(32),
  acquisitionChannel: z.string(),
  status: z.enum(STATUSES),
});
type CustomerValues = z.infer<typeof customerSchema>;

const EMPTY: CustomerValues = { fullName: '', email: '', phone: '', acquisitionChannel: '', status: 'active' };

const valuesFrom = (customer: CustomerItem): CustomerValues => ({
  fullName: customer.full_name,
  email: customer.email ?? '',
  phone: customer.phone ?? '',
  acquisitionChannel: customer.acquisition_channel ?? '',
  status: customer.status,
});

function CustomerForm({ customer, onClose }: { customer: CustomerItem | null; onClose: () => void }) {
  const save = useSaveCustomer();
  const { register, handleSubmit, reset, formState } = useForm<CustomerValues>({
    resolver: zodResolver(customerSchema),
    defaultValues: customer ? valuesFrom(customer) : EMPTY,
  });
  const { errors } = formState;

  useEffect(() => reset(customer ? valuesFrom(customer) : EMPTY), [customer, reset]);

  const onSubmit = handleSubmit((input) =>
    save.mutate(
      { id: customer?.id ?? null, input },
      {
        onSuccess: () => {
          toast.success(customer ? 'Customer updated' : 'Customer added');
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    ),
  );

  return (
    <form id="customer-form" onSubmit={onSubmit} noValidate className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <TextField label="Full name" autoComplete="off" error={errors.fullName?.message} className="sm:col-span-2" {...register('fullName')} />
      <TextField label="Email" type="email" autoComplete="off" hint="Optional" error={errors.email?.message} {...register('email')} />
      <TextField label="Phone" type="tel" autoComplete="off" hint="Optional" error={errors.phone?.message} {...register('phone')} />
      <SelectField
        label="How they found you"
        options={[{ value: '', label: 'Unknown' }, ...optionsFrom(CHANNELS)]}
        {...register('acquisitionChannel')}
      />
      <SelectField label="Status" options={optionsFrom(STATUSES)} {...register('status')} />
      {customer ? (
        <dl className="grid grid-cols-3 gap-3 rounded-xl bg-gray-50 p-4 text-sm sm:col-span-2">
          <div>
            <dt className="text-gray-500">Orders</dt>
            <dd className="font-semibold tabular-nums text-brand-black">{formatInteger(customer.total_orders)}</dd>
          </div>
          <div>
            <dt className="text-gray-500">Lifetime spend</dt>
            <dd className="font-semibold tabular-nums text-brand-black">{formatAmount(customer.ltv)}</dd>
          </div>
          <div>
            <dt className="text-gray-500">Customer since</dt>
            <dd className="font-semibold text-brand-black">{formatDateTime(customer.created_at)}</dd>
          </div>
        </dl>
      ) : null}
    </form>
  );
}

function CustomersContent() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const query = useCustomers({ search: useDebounced(search), status });
  const [editing, setEditing] = useState<CustomerItem | null | undefined>(undefined);
  const saving = useIsSaving('customer');

  const columns: Column<CustomerItem>[] = [
    {
      header: 'Customer',
      render: (row) => (
        <>
          <span className="block font-semibold text-brand-black">{row.full_name}</span>
          <span className="block text-xs text-gray-500">{row.email ?? '—'}</span>
        </>
      ),
    },
    { header: 'Status', render: (row) => <span className="capitalize">{row.status}</span> },
    { header: 'Channel', hideOnMobile: true, render: (row) => <span className="capitalize">{row.acquisition_channel?.replace(/_/g, ' ') ?? '—'}</span> },
    { header: 'Orders', align: 'right', render: (row) => formatInteger(row.total_orders) },
    { header: 'Lifetime spend', align: 'right', hideOnMobile: true, render: (row) => formatAmount(row.ltv) },
    { header: 'Last active', hideOnMobile: true, render: (row) => formatDateTime(row.last_active_at) },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <PageIntro title="Customers" description="Everyone who has bought from you, with their order history and lifetime spend." />
      <Toolbar
        search={{ value: search, onChange: setSearch, placeholder: 'Search by name or email' }}
        filter={{
          label: 'Filter by status',
          value: status,
          onChange: setStatus,
          options: [{ value: '', label: 'All statuses' }, ...optionsFrom(STATUSES)],
        }}
        actions={
          <Button onClick={() => setEditing(null)} leftIcon={<Plus className="h-4 w-4" aria-hidden="true" />}>
            Add customer
          </Button>
        }
      />
      <DataTable
        caption="Customers"
        columns={columns}
        rows={query.data}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{
          icon: Users,
          title: search || status ? 'No matching customers' : 'No customers yet',
          description: search || status ? 'Try a different search or filter.' : 'Customers appear here when they order or when you add them.',
        }}
        onRowClick={setEditing}
        rowLabel={(row) => `Edit ${row.full_name}`}
      />

      <Modal
        open={editing !== undefined}
        title={editing ? editing.full_name : 'Add customer'}
        onClose={() => setEditing(undefined)}
        footer={
          <>
            <Button variant="outline" onClick={() => setEditing(undefined)}>
              Cancel
            </Button>
            <Button type="submit" form="customer-form" loading={saving}>
              {editing ? 'Save changes' : 'Add customer'}
            </Button>
          </>
        }
      >
        {editing !== undefined ? <CustomerForm customer={editing} onClose={() => setEditing(undefined)} /> : null}
      </Modal>
    </div>
  );
}

export function CustomersPage() {
  return (
    <RequireModule modules={['customers']}>
      <CustomersContent />
    </RequireModule>
  );
}
