import {
  AlertTriangle,
  ArrowRight,
  BarChart3,
  Check,
  DollarSign,
  LifeBuoy,
  Megaphone,
  Package,
  ShoppingBag,
  Store,
  UserPlus,
  Users,
  type LucideIcon,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { MODULE_LABEL, StoreNotSetUp } from '@/components/RequireModule';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { hasModule, useOrders, useStoreOverview, useStoreSetup } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import { useAuthStore } from '@/store/authStore';
import type { ModuleKey } from '@/types/dashboard.types';
import { formatAmount, formatDateTime, formatInteger } from '@/utils/format';

interface Tile {
  modules: ModuleKey[];
  icon: LucideIcon;
  label: string;
  value: (o: NonNullable<ReturnType<typeof useStoreOverview>['data']>) => string;
  to: string;
  tone?: 'warn';
}

const TILES: Tile[] = [
  { modules: ['orders'], icon: DollarSign, label: 'Sales, last 30 days', value: (o) => formatAmount(o.revenue_30d), to: '/dashboard/orders' },
  { modules: ['orders'], icon: ShoppingBag, label: 'Orders to handle', value: (o) => formatInteger(o.open_orders), to: '/dashboard/orders' },
  { modules: ['inventory', 'storefront'], icon: Package, label: 'Active products', value: (o) => formatInteger(o.active_products), to: '/dashboard/products' },
  { modules: ['inventory'], icon: AlertTriangle, label: 'Low on stock', value: (o) => formatInteger(o.low_stock), to: '/dashboard/products', tone: 'warn' },
  { modules: ['customers'], icon: Users, label: 'Customers', value: (o) => formatInteger(o.customers), to: '/dashboard/customers' },
  { modules: ['customers'], icon: UserPlus, label: 'New customers, 30 days', value: (o) => formatInteger(o.new_customers_30d), to: '/dashboard/customers' },
  { modules: ['marketing'], icon: Megaphone, label: 'Live campaigns', value: (o) => formatInteger(o.live_campaigns), to: '/dashboard/marketing' },
  { modules: ['customerService'], icon: LifeBuoy, label: 'Open tickets', value: (o) => formatInteger(o.open_tickets), to: '/dashboard/tickets', tone: 'warn' },
];

function RecentOrders() {
  const query = useOrders({ limit: 5 });
  if (query.isPending) return <LoadingShimmer rows={2} />;
  if (!query.data?.length) return null;
  return (
    <section aria-labelledby="recent-orders" className="mt-8 rounded-2xl border border-gray-100 bg-white shadow-sm">
      <header className="flex items-center justify-between px-5 py-4">
        <h3 id="recent-orders" className="text-sm font-semibold text-brand-black">
          Recent orders
        </h3>
        <Link to="/dashboard/orders" className="inline-flex items-center gap-1 text-sm font-semibold text-brand-green-dark hover:underline">
          View all <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      </header>
      <ul className="divide-y divide-gray-100 border-t border-gray-100">
        {query.data.map((order) => (
          <li key={order.id} className="flex flex-wrap items-center gap-x-4 gap-y-1 px-5 py-3 text-sm">
            <span className="w-28 font-semibold text-brand-black">{order.order_ref}</span>
            <span className="min-w-0 flex-1 truncate text-gray-700">{order.customer_name}</span>
            <StatusBadge status={order.status} color={order.status_color} />
            <span className="hidden w-40 text-gray-500 sm:block">{formatDateTime(order.placed_at)}</span>
            <span className="w-24 text-right font-semibold tabular-nums text-brand-black">{formatAmount(order.total_amount)}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function StoreOverviewPage() {
  const setupQuery = useStoreSetup();
  const overviewQuery = useStoreOverview();
  const tenantUid = useAuthStore((state) => state.user?.tenantUid);

  if (setupQuery.isPending || overviewQuery.isPending) return <LoadingShimmer rows={3} />;
  const error = setupQuery.error ?? overviewQuery.error;
  if (error) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(error)}
        onRetry={() => {
          void setupQuery.refetch();
          void overviewQuery.refetch();
        }}
        isRetrying={setupQuery.isFetching || overviewQuery.isFetching}
      />
    );
  }

  const setup = setupQuery.data;
  if (!setup) return <StoreNotSetUp />;
  const overview = overviewQuery.data!;
  const tiles = TILES.filter((tile) => hasModule(setup, tile.modules));
  const enabled = (Object.keys(MODULE_LABEL) as ModuleKey[]).filter((module) => setup.modules[module]);

  return (
    <div className="mx-auto max-w-7xl">
      <section className="mb-8 rounded-2xl bg-brand-black p-6 text-white sm:p-8">
        <p className="text-sm text-gray-300">Welcome back to</p>
        <h2 className="mt-1 text-2xl font-bold tracking-tight text-white sm:text-3xl">{setup.storeName}</h2>
        <ul className="mt-4 flex flex-wrap gap-2" aria-label="Features enabled for your store">
          {enabled.map((module) => (
            <li key={module} className="inline-flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold">
              <Check className="h-3.5 w-3.5 text-brand-green" aria-hidden="true" />
              {MODULE_LABEL[module]}
            </li>
          ))}
        </ul>
        {setup.modules.storefront && tenantUid ? (
          <a
            href={`/shop/${tenantUid}`}
            target="_blank"
            rel="noopener"
            className="mt-6 inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-brand-green px-5 text-sm font-semibold text-white hover:bg-brand-green-dark"
          >
            <Store className="h-4 w-4" aria-hidden="true" />
            Open your online shop
            <span className="sr-only">(opens in a new tab)</span>
          </a>
        ) : null}
      </section>

      <section aria-label="Store summary" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {tiles.map(({ icon: Icon, label, value, to, tone }) => (
          <Link
            key={label}
            to={to}
            className="group rounded-2xl border border-gray-100 bg-white p-5 shadow-sm transition-shadow hover:shadow-md"
          >
            <span className="flex items-center gap-3">
              <span
                className={`flex h-10 w-10 items-center justify-center rounded-xl ${tone === 'warn' ? 'bg-amber-100' : 'bg-brand-mint'}`}
              >
                <Icon className={`h-5 w-5 ${tone === 'warn' ? 'text-amber-800' : 'text-brand-green-dark'}`} aria-hidden="true" />
              </span>
              <span className="text-sm font-medium text-gray-700">{label}</span>
            </span>
            <span className="mt-3 block text-3xl font-bold tabular-nums tracking-tight text-brand-black">{value(overview)}</span>
          </Link>
        ))}
        <Link
          to="/dashboard/analytics"
          className="flex items-center gap-3 rounded-2xl border border-dashed border-gray-300 bg-white p-5 text-sm font-semibold text-brand-black hover:border-brand-green"
        >
          <BarChart3 className="h-5 w-5 text-brand-green-dark" aria-hidden="true" />
          See your analytics charts
          <ArrowRight className="ml-auto h-4 w-4" aria-hidden="true" />
        </Link>
      </section>

      {setup.modules.orders ? <RecentOrders /> : null}
    </div>
  );
}
