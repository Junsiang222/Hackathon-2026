import { ShoppingBag } from 'lucide-react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { RequireModule } from '@/components/RequireModule';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, Toolbar, useDebounced, type Column } from '@/components/ui/DataTable';
import { ErrorPlaceholder } from '@/components/ui/ErrorPlaceholder';
import { SelectField, optionsFrom } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useOrder, useOrders, useUpdateOrderStatus } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { OrderStatus, OrderSummary } from '@/types/store.types';
import { formatCurrency, formatDateTime, formatInteger } from '@/utils/format';

const STATUSES = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded'] as const satisfies readonly OrderStatus[];

function OrderDetailBody({ orderId, onClose }: { orderId: number; onClose: () => void }) {
  const orderQuery = useOrder(orderId);
  const update = useUpdateOrderStatus();
  const [status, setStatus] = useState<OrderStatus>('pending');

  useEffect(() => {
    if (orderQuery.data) setStatus(orderQuery.data.status);
  }, [orderQuery.data]);

  if (orderQuery.isPending) return <LoadingShimmer rows={3} />;
  if (orderQuery.isError) {
    return (
      <ErrorPlaceholder
        message={getApiErrorMessage(orderQuery.error)}
        onRetry={() => orderQuery.refetch()}
        isRetrying={orderQuery.isFetching}
      />
    );
  }

  const order = orderQuery.data;
  const onSave = () =>
    update.mutate(
      { id: order.id, status },
      {
        onSuccess: () => {
          toast.success(`Order ${order.order_ref} marked ${status}`);
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    );

  return (
    <div className="space-y-6">
      <dl className="grid grid-cols-1 gap-4 text-sm sm:grid-cols-3">
        <div>
          <dt className="text-gray-500">Customer</dt>
          <dd className="font-semibold text-brand-black">{order.customer_name}</dd>
          <dd className="text-gray-700">{order.customer_email ?? '—'}</dd>
          {order.customer_phone ? <dd className="text-gray-700">{order.customer_phone}</dd> : null}
        </div>
        <div>
          <dt className="text-gray-500">Placed</dt>
          <dd className="text-brand-black">{formatDateTime(order.placed_at)}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Fulfilled</dt>
          <dd className="text-brand-black">{formatDateTime(order.fulfilled_at)}</dd>
        </div>
        {order.shipping_address ? (
          <div className="sm:col-span-3">
            <dt className="text-gray-500">Deliver to</dt>
            <dd className="whitespace-pre-line text-brand-black">{order.shipping_address}</dd>
          </div>
        ) : null}
      </dl>

      <div className="overflow-x-auto rounded-xl border border-gray-100">
        <table className="w-full text-left text-sm">
          <caption className="sr-only">Items in order {order.order_ref}</caption>
          <thead className="border-b border-gray-100 text-xs uppercase tracking-wide text-gray-500">
            <tr>
              <th scope="col" className="px-4 py-2 font-semibold">Item</th>
              <th scope="col" className="px-4 py-2 text-right font-semibold">Qty</th>
              <th scope="col" className="px-4 py-2 text-right font-semibold">Price</th>
              <th scope="col" className="px-4 py-2 text-right font-semibold">Subtotal</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {order.items.map((item) => (
              <tr key={item.id}>
                <td className="px-4 py-2">
                  <span className="block font-medium text-brand-black">{item.product_name}</span>
                  <span className="block text-xs text-gray-500">{item.sku_code}</span>
                </td>
                <td className="px-4 py-2 text-right tabular-nums">{formatInteger(item.qty)}</td>
                <td className="px-4 py-2 text-right tabular-nums">{formatCurrency(item.unit_price, order.currency)}</td>
                <td className="px-4 py-2 text-right tabular-nums">{formatCurrency(item.subtotal, order.currency)}</td>
              </tr>
            ))}
          </tbody>
          <tfoot className="border-t border-gray-200">
            <tr>
              <th scope="row" colSpan={3} className="px-4 py-2 text-right font-semibold text-brand-black">
                Total
              </th>
              <td className="px-4 py-2 text-right font-bold tabular-nums text-brand-black">
                {formatCurrency(order.total_amount, order.currency)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:items-end">
        <SelectField
          label="Order status"
          value={status}
          onChange={(event) => setStatus(event.target.value as OrderStatus)}
          options={optionsFrom(STATUSES)}
          className="flex-1"
        />
        <Button onClick={onSave} loading={update.isPending} disabled={status === order.status}>
          Update status
        </Button>
      </div>
    </div>
  );
}

function OrdersContent() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const query = useOrders({ search: useDebounced(search), status });
  const [openOrder, setOpenOrder] = useState<OrderSummary | null>(null);

  const columns: Column<OrderSummary>[] = [
    { header: 'Order', render: (row) => <span className="font-semibold text-brand-black">{row.order_ref}</span> },
    {
      header: 'Customer',
      hideOnMobile: true,
      render: (row) => (
        <>
          <span className="block text-brand-black">{row.customer_name}</span>
          <span className="block text-xs text-gray-500">{row.customer_email ?? ''}</span>
        </>
      ),
    },
    { header: 'Status', render: (row) => <StatusBadge status={row.status} color={row.status_color} /> },
    { header: 'Placed', hideOnMobile: true, render: (row) => formatDateTime(row.placed_at) },
    { header: 'Items', align: 'right', hideOnMobile: true, render: (row) => formatInteger(row.item_count ?? 0) },
    { header: 'Total', align: 'right', render: (row) => formatCurrency(row.total_amount, row.currency) },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <PageIntro title="Orders" description="Track every order and move it from pending to delivered." />
      <Toolbar
        search={{ value: search, onChange: setSearch, placeholder: 'Search by order number or customer' }}
        filter={{
          label: 'Filter by status',
          value: status,
          onChange: setStatus,
          options: [{ value: '', label: 'All statuses' }, ...optionsFrom(STATUSES)],
        }}
      />
      <DataTable
        caption="Orders"
        columns={columns}
        rows={query.data}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{
          icon: ShoppingBag,
          title: search || status ? 'No matching orders' : 'No orders yet',
          description: search || status ? 'Try a different search or filter.' : 'Orders from your shop will appear here.',
        }}
        onRowClick={setOpenOrder}
        rowLabel={(row) => `Open order ${row.order_ref}`}
      />

      <Modal
        open={openOrder !== null}
        title={openOrder ? `Order ${openOrder.order_ref}` : 'Order'}
        onClose={() => setOpenOrder(null)}
        size="lg"
      >
        {openOrder ? <OrderDetailBody orderId={openOrder.id} onClose={() => setOpenOrder(null)} /> : null}
      </Modal>
    </div>
  );
}

export function OrdersPage() {
  return (
    <RequireModule modules={['orders']}>
      <OrdersContent />
    </RequireModule>
  );
}
