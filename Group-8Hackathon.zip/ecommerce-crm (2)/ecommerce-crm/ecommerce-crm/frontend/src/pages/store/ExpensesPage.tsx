import { zodResolver } from '@hookform/resolvers/zod';
import { Lock, Plus, Receipt, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, type Column } from '@/components/ui/DataTable';
import { SelectField } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { TextField } from '@/components/ui/TextField';
import {
  EXPENSE_CATEGORIES,
  useDeleteExpense,
  useExpenses,
  useIsSavingExpense,
  useSaveExpense,
  type ExpenseCategory,
  type ExpenseItem,
} from '@/hooks/useExpenses';
import { getApiErrorMessage } from '@/lib/axios';
import { formatAmount, toNumber } from '@/utils/format';

const CATEGORY_LABEL: Record<ExpenseCategory, string> = {
  rent: 'Rent',
  wages: 'Wages',
  utilities: 'Utilities',
  marketing: 'Marketing',
  supplies: 'Supplies',
  shipping: 'Shipping',
  software: 'Software',
  other: 'Other',
};
const CATEGORY_OPTIONS = EXPENSE_CATEGORIES.map((value) => ({ value, label: CATEGORY_LABEL[value] }));

const today = () => new Date().toISOString().slice(0, 10);
const thisMonth = () => new Date().toISOString().slice(0, 7);

/** "2026-10" → first and last day of that month. */
function monthRange(month: string) {
  const [year, m] = month.split('-').map(Number) as [number, number];
  const last = new Date(Date.UTC(year, m, 0)).getUTCDate();
  return { from: `${month}-01`, to: `${month}-${String(last).padStart(2, '0')}` };
}

const expenseSchema = z.object({
  category: z.enum(EXPENSE_CATEGORIES),
  description: z.string().trim().max(255),
  amount: z.coerce.number({ invalid_type_error: 'Enter an amount' }).min(0, 'Amount cannot be negative'),
  incurredOn: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Pick a date'),
});
type ExpenseValues = z.infer<typeof expenseSchema>;

const valuesFrom = (expense: ExpenseItem | null): ExpenseValues =>
  expense
    ? {
        category: expense.category,
        description: expense.description ?? '',
        amount: toNumber(expense.amount),
        incurredOn: expense.incurred_on,
      }
    : { category: 'rent', description: '', amount: 0, incurredOn: today() };

function ExpenseForm({ expense, onClose }: { expense: ExpenseItem | null; onClose: () => void }) {
  const save = useSaveExpense();
  const remove = useDeleteExpense();
  const { register, handleSubmit, reset, formState } = useForm<ExpenseValues>({
    resolver: zodResolver(expenseSchema),
    defaultValues: valuesFrom(expense),
  });
  const { errors } = formState;
  useEffect(() => reset(valuesFrom(expense)), [expense, reset]);

  const onSubmit = handleSubmit(({ description, ...rest }) =>
    save.mutate(
      { id: expense?.id ?? null, input: { ...rest, description: description || null } },
      {
        onSuccess: () => {
          toast.success(expense ? 'Expense updated' : 'Expense added');
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    ),
  );

  const onDelete = () => {
    if (!expense || !window.confirm('Delete this expense? This cannot be undone.')) return;
    remove.mutate(expense.id, {
      onSuccess: () => {
        toast.success('Expense deleted');
        onClose();
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });
  };

  return (
    <form id="expense-form" onSubmit={onSubmit} noValidate className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <SelectField label="Category" options={CATEGORY_OPTIONS} error={errors.category?.message} {...register('category')} />
      <TextField label="Date" type="date" error={errors.incurredOn?.message} {...register('incurredOn')} />
      <TextField
        label="Amount"
        type="number"
        inputMode="decimal"
        step="0.01"
        min="0"
        error={errors.amount?.message}
        {...register('amount')}
      />
      <TextField label="Description" hint="Optional" error={errors.description?.message} {...register('description')} />
      {expense ? (
        <div className="sm:col-span-2">
          <Button
            type="button"
            variant="outline"
            onClick={onDelete}
            loading={remove.isPending}
            leftIcon={<Trash2 className="h-4 w-4" aria-hidden="true" />}
            className="text-red-600"
          >
            Delete expense
          </Button>
        </div>
      ) : null}
    </form>
  );
}

export function ExpensesPage() {
  const [month, setMonth] = useState(thisMonth);
  const query = useExpenses(monthRange(month));
  const [editing, setEditing] = useState<ExpenseItem | null>(null);
  const [adding, setAdding] = useState(false);
  const saving = useIsSavingExpense();

  const items = query.data?.items;
  const byCategory = query.data?.byCategory ?? [];
  const monthSum = byCategory.reduce((acc, row) => acc + toNumber(row.amount), 0);

  const columns: Column<ExpenseItem>[] = [
    { header: 'Date', render: (row) => row.incurred_on },
    { header: 'Category', render: (row) => <span className="font-medium text-brand-black">{CATEGORY_LABEL[row.category]}</span> },
    { header: 'Description', hideOnMobile: true, render: (row) => row.description ?? <span className="text-gray-400">—</span> },
    { header: 'Amount', align: 'right', render: (row) => formatAmount(row.amount) },
  ];

  const close = () => {
    setEditing(null);
    setAdding(false);
  };

  return (
    <div className="mx-auto max-w-6xl">
      <PageIntro
        title="Expenses"
        description="Record what running your store costs: rent, wages, utilities and more. Use Cost price on each product for the cost of goods."
      />
      <p className="-mt-3 mb-5 flex items-center gap-1.5 text-xs text-gray-500">
        <Lock className="h-3.5 w-3.5" aria-hidden="true" />
        Private to your store. The platform operator cannot see your expenses or costs.
      </p>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-end">
        <div>
          <label htmlFor="expense-month" className="mb-1 block text-sm font-medium text-gray-700">
            Month
          </label>
          <input
            id="expense-month"
            type="month"
            value={month}
            onChange={(event) => event.target.value && setMonth(event.target.value)}
            className="min-h-[44px] rounded-xl border border-gray-300 px-3 text-base"
          />
        </div>
        <div className="flex-1" />
        <Button variant="dark" onClick={() => setAdding(true)} leftIcon={<Plus className="h-4 w-4 text-brand-green" aria-hidden="true" />}>
          Add expense
        </Button>
      </div>

      {byCategory.length > 0 ? (
        <div className="mb-4 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="text-sm font-semibold text-brand-black">This month by category</p>
            <p className="text-sm text-gray-600">
              All expenses: <span className="font-bold tabular-nums text-brand-black">{formatAmount(monthSum)}</span>
            </p>
          </div>
          <ul className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {byCategory.map((row) => (
              <li key={row.category} className="rounded-xl bg-gray-50 px-3 py-2">
                <p className="text-xs text-gray-500">
                  {CATEGORY_LABEL[row.category]} · {row.entries}
                </p>
                <p className="font-semibold tabular-nums text-brand-black">{formatAmount(row.amount)}</p>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <DataTable
        caption="Expenses for the selected month"
        columns={columns}
        rows={items}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{ icon: Receipt, title: 'No expenses this month', description: 'Add rent, wages and other costs as they come in.' }}
        onRowClick={setEditing}
        rowLabel={(row) => `Edit ${CATEGORY_LABEL[row.category]} expense on ${row.incurred_on}`}
      />

      <Modal
        open={adding || editing !== null}
        title={editing ? 'Edit expense' : 'Add expense'}
        onClose={close}
        footer={
          <>
            <Button variant="outline" onClick={close}>
              Cancel
            </Button>
            <Button variant="dark" type="submit" form="expense-form" loading={saving}>
              Save
            </Button>
          </>
        }
      >
        {adding || editing ? <ExpenseForm expense={editing} onClose={close} /> : null}
      </Modal>
    </div>
  );
}
