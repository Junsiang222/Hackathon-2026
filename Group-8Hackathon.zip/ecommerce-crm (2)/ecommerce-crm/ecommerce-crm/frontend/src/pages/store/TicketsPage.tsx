import { LifeBuoy } from 'lucide-react';
import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { RequireModule } from '@/components/RequireModule';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, Toolbar, type Column } from '@/components/ui/DataTable';
import { SelectField, optionsFrom } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useTickets, useUpdateTicket } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { TicketItem, TicketPriority, TicketStatus } from '@/types/store.types';
import { formatDateTime } from '@/utils/format';

const STATUSES = ['open', 'in_progress', 'pending_customer', 'resolved', 'closed'] as const satisfies readonly TicketStatus[];
const PRIORITIES = ['urgent', 'high', 'medium', 'low'] as const satisfies readonly TicketPriority[];

const PRIORITY_CLASS: Record<TicketPriority, string> = {
  urgent: 'bg-red-100 text-red-800',
  high: 'bg-amber-100 text-amber-900',
  medium: 'bg-gray-100 text-gray-800',
  low: 'bg-gray-50 text-gray-600',
};

function PriorityBadge({ priority }: { priority: TicketPriority }) {
  return (
    <span className={`inline-flex rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize ${PRIORITY_CLASS[priority]}`}>
      {priority}
    </span>
  );
}

function TicketBody({ ticket, onClose }: { ticket: TicketItem; onClose: () => void }) {
  const update = useUpdateTicket();
  const [status, setStatus] = useState<TicketStatus>(ticket.status);
  const [priority, setPriority] = useState<TicketPriority>(ticket.priority);

  useEffect(() => {
    setStatus(ticket.status);
    setPriority(ticket.priority);
  }, [ticket]);

  const unchanged = status === ticket.status && priority === ticket.priority;
  const onSave = () =>
    update.mutate(
      { id: ticket.id, changes: { status, priority } },
      {
        onSuccess: () => {
          toast.success('Ticket updated');
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    );

  return (
    <div className="space-y-5">
      <dl className="grid grid-cols-1 gap-4 text-sm sm:grid-cols-3">
        <div>
          <dt className="text-gray-500">Customer</dt>
          <dd className="font-semibold text-brand-black">{ticket.customer_name}</dd>
          <dd className="text-gray-700">{ticket.customer_email ?? '—'}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Channel</dt>
          <dd className="capitalize text-brand-black">{ticket.channel}</dd>
        </div>
        <div>
          <dt className="text-gray-500">Opened</dt>
          <dd className="text-brand-black">{formatDateTime(ticket.created_at)}</dd>
        </div>
      </dl>
      <blockquote className="whitespace-pre-wrap rounded-xl bg-gray-50 p-4 text-sm text-gray-800">{ticket.body}</blockquote>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <SelectField label="Status" value={status} onChange={(e) => setStatus(e.target.value as TicketStatus)} options={optionsFrom(STATUSES)} />
        <SelectField
          label="Priority"
          value={priority}
          onChange={(e) => setPriority(e.target.value as TicketPriority)}
          options={optionsFrom(PRIORITIES)}
        />
      </div>
      <div className="flex justify-end">
        <Button onClick={onSave} loading={update.isPending} disabled={unchanged}>
          Save ticket
        </Button>
      </div>
    </div>
  );
}

function TicketsContent() {
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const query = useTickets({ status, priority });
  const [open, setOpen] = useState<TicketItem | null>(null);

  const columns: Column<TicketItem>[] = [
    {
      header: 'Subject',
      render: (row) => (
        <>
          <span className="block font-semibold text-brand-black">{row.subject}</span>
          <span className="block text-xs text-gray-500">{row.customer_name}</span>
        </>
      ),
    },
    { header: 'Priority', render: (row) => <PriorityBadge priority={row.priority} /> },
    { header: 'Status', render: (row) => <StatusBadge status={row.status} color={row.status_color} /> },
    { header: 'Channel', hideOnMobile: true, render: (row) => <span className="capitalize">{row.channel}</span> },
    { header: 'Opened', hideOnMobile: true, render: (row) => formatDateTime(row.created_at) },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <PageIntro title="Support tickets" description="Customer questions, sorted so the most urgent open ones come first." />
      <Toolbar
        filter={{
          label: 'Filter by status',
          value: status,
          onChange: setStatus,
          options: [{ value: '', label: 'All statuses' }, ...optionsFrom(STATUSES)],
        }}
        actions={
          <SelectField
            label="Filter by priority"
            hideLabel
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            options={[{ value: '', label: 'All priorities' }, ...optionsFrom(PRIORITIES)]}
            className="sm:w-44"
          />
        }
      />
      <DataTable
        caption="Support tickets"
        columns={columns}
        rows={query.data}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{
          icon: LifeBuoy,
          title: status || priority ? 'No matching tickets' : 'No support tickets',
          description: status || priority ? 'Try a different filter.' : 'Customer questions will show up here.',
        }}
        onRowClick={setOpen}
        rowLabel={(row) => `Open ticket: ${row.subject}`}
      />
      <Modal open={open !== null} title={open?.subject ?? 'Ticket'} onClose={() => setOpen(null)} size="lg">
        {open ? <TicketBody ticket={open} onClose={() => setOpen(null)} /> : null}
      </Modal>
    </div>
  );
}

export function TicketsPage() {
  return (
    <RequireModule modules={['customerService']}>
      <TicketsContent />
    </RequireModule>
  );
}
