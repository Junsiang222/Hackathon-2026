import { zodResolver } from '@hookform/resolvers/zod';
import { Megaphone, Plus, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { RequireModule } from '@/components/RequireModule';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, Toolbar, type Column } from '@/components/ui/DataTable';
import { SelectField, optionsFrom } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { TextField } from '@/components/ui/TextField';
import { useCampaigns, useDeleteCampaign, useIsSaving, useSaveCampaign } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { CampaignItem, CampaignStatus, CampaignType } from '@/types/store.types';
import { formatDateTime, formatInteger } from '@/utils/format';

const STATUSES = ['draft', 'scheduled', 'running', 'paused', 'completed'] as const satisfies readonly CampaignStatus[];
const TYPES = ['email', 'sms', 'push', 'social'] as const satisfies readonly CampaignType[];
const TYPE_LABEL: Record<CampaignType, string> = { email: 'Email', sms: 'SMS', push: 'Push notification', social: 'Social post' };

const campaignSchema = z.object({
  name: z.string().trim().min(1, 'Give the campaign a name').max(255),
  type: z.enum(TYPES),
  status: z.enum(STATUSES),
  scheduledAt: z.string(),
});
type CampaignValues = z.infer<typeof campaignSchema>;

const EMPTY: CampaignValues = { name: '', type: 'email', status: 'draft', scheduledAt: '' };

/** ISO timestamp → value for <input type="datetime-local"> in local time. */
function toLocalInput(iso: string | null): string {
  if (!iso) return '';
  const date = new Date(iso);
  return new Date(date.getTime() - date.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
}

const valuesFrom = (campaign: CampaignItem): CampaignValues => ({
  name: campaign.name,
  type: campaign.type,
  status: campaign.status,
  scheduledAt: toLocalInput(campaign.scheduled_at),
});

const rate = (part: number, whole: number) => (whole > 0 ? `${Math.round((part / whole) * 100)}%` : '—');

function CampaignForm({ campaign, onClose }: { campaign: CampaignItem | null; onClose: () => void }) {
  const save = useSaveCampaign();
  const remove = useDeleteCampaign();
  const { register, handleSubmit, reset, formState } = useForm<CampaignValues>({
    resolver: zodResolver(campaignSchema),
    defaultValues: campaign ? valuesFrom(campaign) : EMPTY,
  });

  useEffect(() => reset(campaign ? valuesFrom(campaign) : EMPTY), [campaign, reset]);

  const onSubmit = handleSubmit(({ scheduledAt, ...values }) =>
    save.mutate(
      { id: campaign?.id ?? null, input: { ...values, scheduledAt: scheduledAt ? new Date(scheduledAt).toISOString() : null } },
      {
        onSuccess: (saved) => {
          toast.success(
            saved.status === 'completed' && saved.sent_count > 0 && campaign?.sent_count === 0
              ? `Campaign sent to ${formatInteger(saved.sent_count)} customers (demo, no real messages)`
              : campaign
                ? 'Campaign updated'
                : 'Campaign created',
          );
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    ),
  );

  const onDelete = () => {
    if (!campaign || !window.confirm(`Delete campaign "${campaign.name}"?`)) return;
    remove.mutate(campaign.id, {
      onSuccess: () => {
        toast.success('Campaign deleted');
        onClose();
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });
  };

  return (
    <form id="campaign-form" onSubmit={onSubmit} noValidate className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <TextField label="Campaign name" error={formState.errors.name?.message} className="sm:col-span-2" {...register('name')} />
      <SelectField label="Channel" options={TYPES.map((value) => ({ value, label: TYPE_LABEL[value] }))} {...register('type')} />
      <SelectField
        label="Status"
        options={optionsFrom(STATUSES)}
        hint="Running or Completed sends it to your active customers"
        {...register('status')}
      />
      <TextField label="Send date" type="datetime-local" hint="Optional" className="sm:col-span-2" {...register('scheduledAt')} />
      {campaign ? (
        <>
          <dl className="grid grid-cols-3 gap-3 rounded-xl bg-gray-50 p-4 text-sm sm:col-span-2">
            <div>
              <dt className="text-gray-500">Sent</dt>
              <dd className="font-semibold tabular-nums text-brand-black">{formatInteger(campaign.sent_count)}</dd>
            </div>
            <div>
              <dt className="text-gray-500">Open rate</dt>
              <dd className="font-semibold tabular-nums text-brand-black">{rate(campaign.open_count, campaign.sent_count)}</dd>
            </div>
            <div>
              <dt className="text-gray-500">Click rate</dt>
              <dd className="font-semibold tabular-nums text-brand-black">{rate(campaign.click_count, campaign.sent_count)}</dd>
            </div>
          </dl>
          <div className="sm:col-span-2">
            <Button
              type="button"
              variant="ghost"
              onClick={onDelete}
              loading={remove.isPending}
              leftIcon={<Trash2 className="h-4 w-4" aria-hidden="true" />}
              className="text-red-600 hover:bg-red-50"
            >
              Delete campaign
            </Button>
          </div>
        </>
      ) : null}
    </form>
  );
}

function MarketingContent() {
  const [status, setStatus] = useState('');
  const query = useCampaigns({ status });
  const [editing, setEditing] = useState<CampaignItem | null | undefined>(undefined);
  const saving = useIsSaving('campaign');

  const columns: Column<CampaignItem>[] = [
    {
      header: 'Campaign',
      render: (row) => (
        <>
          <span className="block font-semibold text-brand-black">{row.name}</span>
          <span className="block text-xs text-gray-500">{TYPE_LABEL[row.type]}</span>
        </>
      ),
    },
    { header: 'Status', render: (row) => <StatusBadge status={row.status} color={row.status_color} /> },
    { header: 'Send date', hideOnMobile: true, render: (row) => formatDateTime(row.scheduled_at) },
    { header: 'Sent', align: 'right', render: (row) => formatInteger(row.sent_count) },
    { header: 'Opens', align: 'right', hideOnMobile: true, render: (row) => rate(row.open_count, row.sent_count) },
    { header: 'Clicks', align: 'right', hideOnMobile: true, render: (row) => rate(row.click_count, row.sent_count) },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <PageIntro title="Marketing" description="Plan email, SMS, push and social campaigns and see how they perform." />
      <Toolbar
        filter={{
          label: 'Filter by status',
          value: status,
          onChange: setStatus,
          options: [{ value: '', label: 'All statuses' }, ...optionsFrom(STATUSES)],
        }}
        actions={
          <Button onClick={() => setEditing(null)} leftIcon={<Plus className="h-4 w-4" aria-hidden="true" />}>
            New campaign
          </Button>
        }
      />
      <DataTable
        caption="Marketing campaigns"
        columns={columns}
        rows={query.data}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{
          icon: Megaphone,
          title: status ? 'No campaigns with this status' : 'No campaigns yet',
          description: status ? 'Try a different filter.' : 'Create your first campaign to reach your customers.',
        }}
        onRowClick={setEditing}
        rowLabel={(row) => `Edit campaign ${row.name}`}
      />

      <Modal
        open={editing !== undefined}
        title={editing ? editing.name : 'New campaign'}
        onClose={() => setEditing(undefined)}
        footer={
          <>
            <Button variant="outline" onClick={() => setEditing(undefined)}>
              Cancel
            </Button>
            <Button type="submit" form="campaign-form" loading={saving}>
              {editing ? 'Save changes' : 'Create campaign'}
            </Button>
          </>
        }
      >
        {editing !== undefined ? <CampaignForm campaign={editing} onClose={() => setEditing(undefined)} /> : null}
      </Modal>
    </div>
  );
}

export function MarketingPage() {
  return (
    <RequireModule modules={['marketing']}>
      <MarketingContent />
    </RequireModule>
  );
}
