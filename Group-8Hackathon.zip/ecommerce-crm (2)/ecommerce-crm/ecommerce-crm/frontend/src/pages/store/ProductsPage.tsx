import { zodResolver } from '@hookform/resolvers/zod';
import { ImageOff, Package, Plus, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { z } from 'zod';
import { RequireModule } from '@/components/RequireModule';
import { Button } from '@/components/ui/Button';
import { DataTable, PageIntro, Toolbar, useDebounced, type Column } from '@/components/ui/DataTable';
import { SelectField, TextAreaField, optionsFrom } from '@/components/ui/FormFields';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { TextField } from '@/components/ui/TextField';
import { hasModule, useDeleteProduct, useIsSaving, useProducts, useSaveProduct, useStoreSetup } from '@/hooks/useStore';
import { getApiErrorMessage } from '@/lib/axios';
import type { ProductItem, ProductStatus } from '@/types/store.types';
import { formatAmount, toNumber } from '@/utils/format';

const STATUSES = ['active', 'draft', 'archived'] as const satisfies readonly ProductStatus[];

const productSchema = z.object({
  name: z.string().trim().min(1, 'Enter a product name').max(255),
  skuCode: z.string().trim().min(1, 'Enter a SKU').max(64),
  category: z.string().trim().max(100),
  basePrice: z.coerce.number({ invalid_type_error: 'Enter a price' }).min(0, 'Price cannot be negative'),
  // Optional: empty means "not entered".
  costPrice: z
    .string()
    .trim()
    .refine((value) => value === '' || (Number.isFinite(Number(value)) && Number(value) >= 0), 'Enter a cost of 0 or more, or leave it empty'),
  status: z.enum(STATUSES),
  imageUrl: z
    .string()
    .trim()
    .max(2048)
    .refine((value) => value === '' || /^https?:\/\//i.test(value), 'Must start with http:// or https://'),
  description: z.string().trim().max(5000),
  qtyAvailable: z.coerce.number().int('Whole numbers only').min(0, 'Cannot be negative'),
  restockThreshold: z.coerce.number().int('Whole numbers only').min(0, 'Cannot be negative'),
});
type ProductValues = z.infer<typeof productSchema>;

const EMPTY: ProductValues = {
  name: '',
  skuCode: '',
  category: '',
  basePrice: 0,
  costPrice: '',
  status: 'active',
  imageUrl: '',
  description: '',
  qtyAvailable: 0,
  restockThreshold: 10,
};

function valuesFrom(product: ProductItem): ProductValues {
  return {
    name: product.name,
    skuCode: product.sku_code,
    category: product.category ?? '',
    basePrice: toNumber(product.base_price),
    costPrice: product.cost_price === null ? '' : String(toNumber(product.cost_price)),
    status: product.status,
    imageUrl: product.image_url ?? '',
    description: product.description ?? '',
    qtyAvailable: toNumber(product.qty_available),
    restockThreshold: toNumber(product.restock_threshold),
  };
}

function ProductForm({
  product,
  tracksStock,
  onClose,
}: {
  product: ProductItem | null;
  tracksStock: boolean;
  onClose: () => void;
}) {
  const save = useSaveProduct();
  const remove = useDeleteProduct();
  const { register, handleSubmit, reset, formState } = useForm<ProductValues>({
    resolver: zodResolver(productSchema),
    defaultValues: product ? valuesFrom(product) : EMPTY,
  });
  const { errors } = formState;

  useEffect(() => reset(product ? valuesFrom(product) : EMPTY), [product, reset]);

  const onSubmit = handleSubmit((values) => {
    const { qtyAvailable, restockThreshold, costPrice, ...rest } = values;
    save.mutate(
      {
        id: product?.id ?? null,
        input: {
          ...rest,
          costPrice: costPrice === '' ? null : Number(costPrice),
          stock: tracksStock ? { qtyAvailable, restockThreshold } : undefined,
        },
      },
      {
        onSuccess: () => {
          toast.success(product ? 'Product updated' : 'Product added');
          onClose();
        },
        onError: (error) => toast.error(getApiErrorMessage(error)),
      },
    );
  });

  const onDelete = () => {
    if (!product || !window.confirm(`Delete "${product.name}"? This cannot be undone.`)) return;
    remove.mutate(product.id, {
      onSuccess: (result) => {
        toast.success(result.archived ? 'Product has past orders, so it was archived instead' : 'Product deleted');
        onClose();
      },
      onError: (error) => toast.error(getApiErrorMessage(error)),
    });
  };

  return (
    <form id="product-form" onSubmit={onSubmit} noValidate className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <TextField label="Product name" error={errors.name?.message} className="sm:col-span-2" {...register('name')} />
      <TextField label="SKU" error={errors.skuCode?.message} {...register('skuCode')} />
      <TextField label="Category" hint="Optional" error={errors.category?.message} {...register('category')} />
      <TextField
        label="Price"
        type="number"
        inputMode="decimal"
        step="0.01"
        min="0"
        error={errors.basePrice?.message}
        {...register('basePrice')}
      />
      <TextField
        label="Cost price"
        type="number"
        inputMode="decimal"
        step="0.01"
        min="0"
        hint="Optional: what one unit costs you. Private to your store."
        error={errors.costPrice?.message}
        {...register('costPrice')}
      />
      <SelectField
        label="Status"
        options={optionsFrom(STATUSES)}
        hint="Only active products are shown in the online shop"
        error={errors.status?.message}
        {...register('status')}
      />
      {tracksStock ? (
        <>
          <TextField label="Quantity in stock" type="number" min="0" error={errors.qtyAvailable?.message} {...register('qtyAvailable')} />
          <TextField
            label="Low-stock alert at"
            type="number"
            min="0"
            hint="Flag the product when stock falls to this level"
            error={errors.restockThreshold?.message}
            {...register('restockThreshold')}
          />
        </>
      ) : null}
      <TextField
        label="Image URL"
        hint="Optional, e.g. https://…/photo.jpg"
        error={errors.imageUrl?.message}
        className="sm:col-span-2"
        {...register('imageUrl')}
      />
      <TextAreaField label="Description" hint="Optional" error={errors.description?.message} className="sm:col-span-2" {...register('description')} />
      {product ? (
        <div className="sm:col-span-2">
          <Button
            type="button"
            variant="ghost"
            onClick={onDelete}
            loading={remove.isPending}
            leftIcon={<Trash2 className="h-4 w-4" aria-hidden="true" />}
            className="text-red-600 hover:bg-red-50"
          >
            Delete product
          </Button>
        </div>
      ) : null}
    </form>
  );
}

function ProductsContent() {
  const { data: setup } = useStoreSetup();
  const tracksStock = hasModule(setup, ['inventory']);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const debouncedSearch = useDebounced(search);
  const query = useProducts({ search: debouncedSearch, status });
  const [editing, setEditing] = useState<ProductItem | null | undefined>(undefined);
  const saving = useIsSaving('product');

  const columns: Column<ProductItem>[] = [
    {
      header: 'Product',
      render: (row) => (
        <span className="flex items-center gap-3">
          {row.image_url ? (
            <img src={row.image_url} alt="" className="h-10 w-10 shrink-0 rounded-lg object-cover" loading="lazy" />
          ) : (
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gray-100">
              <ImageOff className="h-4 w-4 text-gray-400" aria-hidden="true" />
            </span>
          )}
          <span>
            <span className="block font-semibold text-brand-black">{row.name}</span>
            <span className="block text-xs text-gray-500">{row.sku_code}</span>
          </span>
        </span>
      ),
    },
    { header: 'Category', hideOnMobile: true, render: (row) => row.category ?? '—' },
    { header: 'Status', render: (row) => <StatusBadge status={row.status} color={row.status_color} /> },
    ...(tracksStock
      ? [
          {
            header: 'Stock',
            align: 'right' as const,
            render: (row: ProductItem) => {
              const qty = toNumber(row.qty_available);
              const low = qty <= toNumber(row.restock_threshold);
              return (
                <span className={qty === 0 ? 'font-semibold text-red-600' : low ? 'font-semibold text-amber-700' : ''}>
                  {qty === 0 ? 'Out of stock' : low ? `${qty} · low` : qty}
                </span>
              );
            },
          },
        ]
      : []),
    { header: 'Price', align: 'right', render: (row) => formatAmount(row.base_price) },
    {
      header: 'Cost',
      align: 'right',
      render: (row) => (row.cost_price === null ? <span className="text-gray-400">—</span> : formatAmount(row.cost_price)),
    },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <PageIntro
        title="Products"
        description={
          tracksStock
            ? 'Add products, set prices and keep stock levels up to date.'
            : 'Add the products you sell and set their prices.'
        }
      />
      <Toolbar
        search={{ value: search, onChange: setSearch, placeholder: 'Search by name or SKU' }}
        filter={{
          label: 'Filter by status',
          value: status,
          onChange: setStatus,
          options: [{ value: '', label: 'All statuses' }, ...optionsFrom(STATUSES)],
        }}
        actions={
          <Button onClick={() => setEditing(null)} leftIcon={<Plus className="h-4 w-4" aria-hidden="true" />}>
            Add product
          </Button>
        }
      />
      <DataTable
        caption="Products"
        columns={columns}
        rows={query.data}
        isPending={query.isPending}
        error={query.error}
        onRetry={() => query.refetch()}
        isFetching={query.isFetching}
        empty={{
          icon: Package,
          title: search || status ? 'No matching products' : 'No products yet',
          description: search || status ? 'Try a different search or filter.' : 'Add your first product to start selling.',
        }}
        onRowClick={setEditing}
        rowLabel={(row) => `Edit ${row.name}`}
      />

      <Modal
        open={editing !== undefined}
        title={editing ? `Edit ${editing.name}` : 'Add product'}
        onClose={() => setEditing(undefined)}
        size="lg"
        footer={
          <>
            <Button variant="outline" onClick={() => setEditing(undefined)}>
              Cancel
            </Button>
            <Button type="submit" form="product-form" loading={saving}>
              {editing ? 'Save changes' : 'Add product'}
            </Button>
          </>
        }
      >
        {editing !== undefined ? (
          <ProductForm product={editing} tracksStock={tracksStock} onClose={() => setEditing(undefined)} />
        ) : null}
      </Modal>
    </div>
  );
}

export function ProductsPage() {
  return (
    <RequireModule modules={['inventory', 'storefront']}>
      <ProductsContent />
    </RequireModule>
  );
}
