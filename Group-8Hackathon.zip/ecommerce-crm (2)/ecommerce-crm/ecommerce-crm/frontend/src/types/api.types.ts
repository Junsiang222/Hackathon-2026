export type Role = 'super_admin' | 'admin' | 'staff';

export const INDUSTRIES = ['retail', 'fashion', 'electronics', 'food', 'health', 'other'] as const;
export type Industry = (typeof INDUSTRIES)[number];

export interface ApiSuccess<T> {
  success: true;
  data: T;
}

export interface ApiErrorBody {
  success: false;
  error: {
    code: string;
    message: string;
    details: unknown[];
    requestId: string;
  };
}

export interface SessionUser {
  id: number;
  email: string;
  role: Role;
  tenantId: number;
  tenantUid: string;
  businessName: string;
  /** Signed in with a temporary password: must choose their own first. */
  mustChangePassword?: boolean;
}

export interface AuthResponse {
  accessToken: string;
  expiresIn: number;
  refreshToken?: string; // only returned by /register; browsers use the httpOnly cookie
  user: SessionUser;
}

export interface LoginPayload {
  email: string;
  password: string;
  rememberMe: boolean;
  tenantUid?: string;
}

export interface RegisterPayload {
  email: string;
  password: string;
  businessName: string;
  industry: Industry;
}

export interface WorkspaceChoice {
  tenantUid: string;
  businessName: string;
}

export type TenantStatus = 'active' | 'suspended' | 'cancelled';

export interface Tenant {
  id: number;
  tenantUid: string;
  businessName: string;
  industry: Industry;
  plan: 'starter' | 'growth' | 'enterprise';
  status: TenantStatus;
  statusColor: string;
  registeredAt: string;
  trialEndsAt: string | null;
  layoutCount: number;
  lastLayoutAt: string | null;
  /** True when the setup wizard enabled Storefront, so the store has a public website. */
  hasWebsite: boolean;
  /** Admin/staff logins for the store. Passwords are never readable, only resettable. */
  logins: StoreLogin[];
}

export interface StoreLogin {
  userId: number;
  email: string;
  role: 'admin' | 'staff';
  oauthProvider: 'google' | 'facebook' | null;
  hasPassword: boolean;
  /** Still on the temporary password the super admin created. */
  hasTemporaryPassword?: boolean;
  isActive: boolean;
  lastLoginAt: string | null;
}

export interface ResetPasswordResult {
  email: string;
  temporaryPassword: string;
}

export interface NotificationSummary {
  urgentTickets: number;
  lowStockProducts: number;
  count: number;
}

// Admin (tenant-scoped) resources — rows come back in DB column naming.
export interface OrderRow {
  id: number;
  customer_id: number;
  order_ref: string;
  status: string;
  status_color: string;
  total_amount: string;
  currency: string;
  placed_at: string;
  fulfilled_at: string | null;
}

export interface ProductRow {
  id: number;
  sku_code: string;
  name: string;
  category: string | null;
  base_price: string;
  status: string;
  status_color: string;
  image_url: string | null;
  created_at: string;
}

export interface CustomerRow {
  id: number;
  full_name: string;
  email: string | null;
  phone: string | null;
  acquisition_channel: string | null;
  status: string;
  total_orders: number;
  ltv: string;
  last_active_at: string | null;
  created_at: string;
}

export interface TicketRow {
  id: number;
  customer_id: number;
  assigned_to: number | null;
  subject: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: string;
  status_color: string;
  channel: 'email' | 'chat' | 'phone';
  created_at: string;
  resolved_at: string | null;
}

export type AdminResource = 'orders' | 'products' | 'customers' | 'tickets';

export interface AdminResourceRowMap {
  orders: OrderRow;
  products: ProductRow;
  customers: CustomerRow;
  tickets: TicketRow;
}
