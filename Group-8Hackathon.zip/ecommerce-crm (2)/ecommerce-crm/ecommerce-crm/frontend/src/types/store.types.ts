import type { ChartKind, DashboardModules } from './dashboard.types';

/** The super admin's setup-wizard answers; decide which features a store gets. */
export interface StoreSetup {
  storeName: string;
  modules: DashboardModules;
  analyticsCharts: ChartKind[];
}

export interface StoreOverview {
  active_products: number;
  low_stock: number;
  open_orders: number;
  orders_30d: number;
  revenue_30d: number;
  customers: number;
  new_customers_30d: number;
  live_campaigns: number;
  open_tickets: number;
}

export type ProductStatus = 'active' | 'archived' | 'draft';
export type OrderStatus = 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
export type CustomerStatus = 'active' | 'inactive' | 'blocked';
export type CampaignStatus = 'draft' | 'scheduled' | 'running' | 'paused' | 'completed';
export type CampaignType = 'email' | 'sms' | 'push' | 'social';
export type TicketStatus = 'open' | 'in_progress' | 'pending_customer' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high' | 'urgent';

// Rows use the API's DB column naming. DECIMAL / computed counts may arrive as strings.
export interface ProductItem {
  id: number;
  sku_code: string;
  name: string;
  category: string | null;
  base_price: string;
  /** What one unit costs the store; null = not entered. Never shown to the super admin. */
  cost_price: string | null;
  status: ProductStatus;
  status_color: string;
  image_url: string | null;
  description: string | null;
  qty_available: number | string;
  qty_reserved: number | string;
  restock_threshold: number | string;
  created_at: string;
}

export interface OrderItemLine {
  id: number;
  product_id: number;
  product_name: string;
  sku_code: string;
  qty: number;
  unit_price: string;
  subtotal: string;
}

export interface OrderSummary {
  id: number;
  customer_id: number;
  order_ref: string;
  status: OrderStatus;
  status_color: string;
  total_amount: string;
  currency: string;
  placed_at: string;
  fulfilled_at: string | null;
  customer_name: string;
  customer_email: string | null;
  item_count?: number | string;
}

export interface OrderDetail extends OrderSummary {
  customer_phone: string | null;
  shipping_address: string | null;
  items: OrderItemLine[];
}

export interface CustomerItem {
  id: number;
  full_name: string;
  email: string | null;
  phone: string | null;
  acquisition_channel: string | null;
  status: CustomerStatus;
  total_orders: number;
  ltv: string;
  last_active_at: string | null;
  created_at: string;
}

export interface CampaignItem {
  id: number;
  name: string;
  type: CampaignType;
  status: CampaignStatus;
  status_color: string;
  sent_count: number;
  open_count: number;
  click_count: number;
  scheduled_at: string | null;
  created_at: string;
}

export interface TicketItem {
  id: number;
  customer_id: number;
  subject: string;
  body: string;
  priority: TicketPriority;
  status: TicketStatus;
  status_color: string;
  channel: 'email' | 'chat' | 'phone';
  created_at: string;
  resolved_at: string | null;
  customer_name: string;
  customer_email: string | null;
}

export interface ProductInput {
  skuCode: string;
  name: string;
  category: string;
  basePrice: number;
  costPrice: number | null;
  status: ProductStatus;
  imageUrl: string;
  description: string;
  stock?: { qtyAvailable: number; restockThreshold: number };
}

export interface CustomerInput {
  fullName: string;
  email: string;
  phone: string;
  acquisitionChannel: string;
  status: CustomerStatus;
}

export interface CampaignInput {
  name: string;
  type: CampaignType;
  status: CampaignStatus;
  scheduledAt: string | null;
}
