export type WidgetType = 'LineChart' | 'BarChart' | 'CircleChart';

// Shared across all chart components
export interface WidgetConfig {
  widgetId: string;
  type: WidgetType;
  title: string;
  dataSourceUrl: string; // relative path for TanStack Query fetch
  colSpan: 4 | 6 | 12; // maps to Tailwind col-span classes
  dataKeys: string[]; // non-monetary keys only (count, delta, volume…)
}

export type ChartKind = 'line' | 'bar' | 'circle';

export interface DashboardModules {
  storefront: boolean;
  inventory: boolean;
  orders: boolean;
  customers: boolean;
  marketing: boolean;
  customerService: boolean;
}

export type ModuleKey = keyof DashboardModules;

export interface DashboardGenerationPayload {
  tenantId: number;
  storeName: string;
  modules: DashboardModules;
  analyticsCharts: ChartKind[];
  /** Step 9: description of the public website for the AI to build from. */
  websitePrompt: string;
}

export interface GeneratedLayout {
  layoutId: number;
  config: WidgetConfig[];
  /** The store's admin login. temporaryPassword is set (shown once) when it was just created. */
  adminLogin?: { email: string; temporaryPassword: string | null; created: boolean };
}

export interface DashboardLayout {
  id: number;
  tenantId: number;
  layoutName: string;
  version: number;
  isActive: boolean;
  createdBy: number;
  createdAt: string;
  config: WidgetConfig[];
}

/** One row from an analytics endpoint, after sanitizeWidgetData(). */
export type WidgetDatum = Record<string, unknown>;
