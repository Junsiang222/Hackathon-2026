export type WebsiteTheme = 'green' | 'blue' | 'purple' | 'rose' | 'amber' | 'slate';

/** Older stores: home page copy the AI wrote into the fixed template. */
export interface WebsiteCopy {
  theme: WebsiteTheme;
  heroEyebrow: string;
  heroTitle: string;
  heroSubtitle: string;
  highlights: { title: string; text: string }[];
  aboutTitle: string;
  aboutText: string;
}

/** A complete home page (HTML, CSS and JS) the AI designed freely. */
export interface GeneratedWebsite {
  kind: 'html';
  html: string;
  /** Pexels photos the page asked for, plus "category:<name>" tiles. */
  images?: Record<string, { url: string; alt: string; photographer: string; photographerUrl: string }>;
}

export type WebsiteContent = WebsiteCopy | GeneratedWebsite;

/** Public shop info. `features` mirror the store's setup-wizard answers. */
export interface ShopInfo {
  storeName: string;
  industry: string;
  currency: string;
  features: {
    checkout: boolean;
    stockLevels: boolean;
    contact: boolean;
    orderTracking: boolean;
    /** Shopper register / log in / My account. */
    accounts: boolean;
  };
  /** Null for stores set up before the AI website step existed. */
  website: WebsiteContent | null;
}

export interface ShopProduct {
  id: number;
  name: string;
  category: string | null;
  price: number;
  imageUrl: string | null;
  description: string | null;
  inStock: boolean;
  /** Set when stock is low enough to show "Only N left". */
  lowStockQty: number | null;
  maxQty: number;
}

export interface ShopCatalogue {
  products: ShopProduct[];
  categories: string[];
}

export interface CartLine {
  productId: number;
  name: string;
  price: number;
  imageUrl: string | null;
  qty: number;
  maxQty: number;
}

export interface OrderLine {
  name: string;
  qty: number;
  unitPrice: number;
  subtotal: number;
}

export interface PlacedOrder {
  orderRef: string;
  status: string;
  currency: string;
  total: number;
  items: OrderLine[];
  email: string;
}

export interface TrackedOrder {
  orderRef: string;
  status: string;
  currency: string;
  total: number;
  placedAt: string;
  fulfilledAt: string | null;
  items: OrderLine[];
}

export interface CheckoutPayload {
  customer: { fullName: string; email: string; phone: string };
  shippingAddress: string;
  items: { productId: number; qty: number }[];
  payment: { method: 'demo_card'; last4: string };
}

export interface ShopCustomer {
  fullName: string;
  email: string;
  phone: string | null;
}

export interface ShopAuthResult {
  token: string;
  customer: ShopCustomer;
}

export interface RegisterPayload {
  fullName: string;
  email: string;
  phone: string;
  password: string;
}

export interface AccountOrder {
  orderRef: string;
  status: string;
  total: number;
  currency: string;
  placedAt: string;
  itemCount: number;
}

export interface ShopAccount {
  customer: ShopCustomer;
  memberSince: string;
  orders: AccountOrder[];
}

export interface ContactPayload {
  fullName: string;
  email: string;
  subject: string;
  message: string;
}
