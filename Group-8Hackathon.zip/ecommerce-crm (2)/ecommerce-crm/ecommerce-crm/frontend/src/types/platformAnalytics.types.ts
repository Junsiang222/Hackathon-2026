// Super admin platform analytics. Counts only: the API never sends money
// (no revenue, prices, costs or profit) and these types have no place for it.

export interface StoreMetrics {
  orders: number;
  unitsSold: number;
  cancelledOrRefunded: number;
  buyers: number;
  newCustomers: number;
  pageViews: number;
  addToCarts: number;
  checkoutsStarted: number;
}

export interface StoreOverview {
  tenantId: number;
  tenantUid: string;
  storeName: string;
  industry: string;
  status: string;
  current: StoreMetrics;
  previous: StoreMetrics;
  openTickets: number;
  urgentTickets: number;
  outOfStock: number;
  lowStock: number;
  outOfStockSellers: number;
}

export interface Insight {
  tenantId: number;
  storeName: string;
  severity: 'high' | 'medium' | 'info';
  kind: string;
  message: string;
  recommendation: string;
}

export interface AnalyticsOverview {
  stores: StoreOverview[];
  insights: Insight[];
}

export interface ProductPerformance {
  productId: number;
  name: string;
  category: string | null;
  imageUrl: string | null;
  unitsSold: number;
  orders: number;
  inStock: number | null;
}

export interface MonthComparisonValue {
  value: number;
  mom: number | null;
  yoy: number | null;
  lastMonth: number;
  lastYear: number;
}

export interface StoreDetail {
  store: StoreOverview;
  trend: { date: string; orders: number; unitsSold: number; pageViews: number }[];
  topProducts: ProductPerformance[];
  lowProducts: ProductPerformance[];
  /** [weekday 0=Sunday][hour 0-23] = orders, UTC. */
  peakHours: number[][];
  statusBreakdown: { status: string; orders: number }[];
  retention: {
    buyers: number;
    repeatBuyers: number;
    returningBuyers: number;
    repeatRate: number | null;
    returningRate: number | null;
  };
  itemsPerOrder: number | null;
  conversionRate: number | null;
  inventory: { unitsOnHand: number; turnover: number | null; daysOfCover: number | null };
  tickets: { resolved: number; avgResolutionHours: number | null };
  monthly: { month: string; orders: number; unitsSold: number; newCustomers: number }[];
  monthComparison: {
    month: string;
    orders: MonthComparisonValue;
    unitsSold: MonthComparisonValue;
    newCustomers: MonthComparisonValue;
  };
}

/** Inclusive YYYY-MM-DD days (UTC). */
export interface PeriodRange {
  from: string;
  to: string;
}

export interface AssistantMessage {
  role: 'user' | 'assistant';
  content: string;
}
