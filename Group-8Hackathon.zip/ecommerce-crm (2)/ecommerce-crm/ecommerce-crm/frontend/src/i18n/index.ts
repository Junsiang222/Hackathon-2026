import { useCallback } from 'react';
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { configureFormatting } from '@/utils/format';
import { ms } from './ms';
import { zh } from './zh';

// Dashboard language + display preferences (Settings → Language & display).
// Text is written in English in the code and wrapped in t('…'); the Malay and
// Chinese dictionaries are keyed by that English text. Missing entries fall
// back to English, so an untranslated string is never blank.

export const LANGUAGES = [
  { value: 'en', label: 'English' },
  { value: 'ms', label: 'Bahasa Melayu' },
  { value: 'zh', label: '简体中文' },
] as const;
export type Language = (typeof LANGUAGES)[number]['value'];

export type PeriodPreference = 'today' | '7d' | '30d' | 'month' | '90d';

export interface Preferences {
  /** Shown in the profile menu; null = derived from the email. */
  displayName: string | null;
  language: Language;
  timeDisplay: 'local' | 'utc';
  defaultPeriod: PeriodPreference;
  /** 0 = no auto-refresh. */
  refreshSeconds: 0 | 30 | 60 | 300;
}

export const DEFAULT_PREFERENCES: Preferences = { displayName: null, language: 'en', timeDisplay: 'local', defaultPeriod: '30d', refreshSeconds: 60 };

const DICTIONARIES: Record<Language, Record<string, string>> = { en: {}, ms, zh };
const LOCALES: Record<Language, string | undefined> = { en: undefined, ms: 'ms-MY', zh: 'zh-CN' };

function applyFormatting(preferences: Preferences) {
  configureFormatting({ locale: LOCALES[preferences.language], utc: preferences.timeDisplay === 'utc' });
  document.documentElement.lang = preferences.language === 'zh' ? 'zh-CN' : preferences.language;
}

export type Theme = 'light' | 'dark';

interface PreferencesState extends Preferences {
  /** Dashboard colour theme. Kept in this browser only (the bulb next to the bell). */
  theme: Theme;
  setTheme: (theme: Theme) => void;
  apply: (preferences: Partial<Preferences>) => void;
  /** Back to the default language/display preferences. The theme is a per-browser choice and stays. */
  reset: () => void;
}

/** Kept in the browser too, so the right language shows instantly on reload (the server copy wins once loaded). */
export const usePreferencesStore = create<PreferencesState>()(
  persist(
    (set, get) => ({
      ...DEFAULT_PREFERENCES,
      theme: 'light',
      setTheme: (theme) => set({ theme }),
      apply: (preferences) => {
        set(preferences);
        const { displayName, language, timeDisplay, defaultPeriod, refreshSeconds } = get();
        applyFormatting({ displayName, language, timeDisplay, defaultPeriod, refreshSeconds });
      },
      reset: () => {
        set(DEFAULT_PREFERENCES);
        applyFormatting(DEFAULT_PREFERENCES);
      },
    }),
    {
      name: 'crm.preferences',
      onRehydrateStorage: () => (state) => {
        if (state) applyFormatting(state);
      },
    },
  ),
);

export function translate(language: Language, text: string, vars?: Record<string, string | number>): string {
  const template = DICTIONARIES[language][text] ?? text;
  if (!vars) return template;
  return template.replace(/\{(\w+)\}/g, (match, key: string) => (key in vars ? String(vars[key]) : match));
}

export type TFunction = (text: string, vars?: Record<string, string | number>) => string;

/** t('Some text', { name }) in the current dashboard language. */
export function useT(): TFunction {
  const language = usePreferencesStore((state) => state.language);
  return useCallback((text, vars) => translate(language, text, vars), [language]);
}

/** 'starter' → 'Starter', so stored lower-case values match the capitalised dictionary keys. */
export const capitalize = (value: string) => value.charAt(0).toUpperCase() + value.slice(1);

/** The name shown for the signed-in user: their display name (super admin) or the part of the email before "@". */
export function useDisplayName(email: string | undefined, useSaved: boolean): string {
  const saved = usePreferencesStore((state) => state.displayName);
  if (useSaved && saved) return saved;
  return email ? (email.split('@')[0] ?? email) : '';
}
