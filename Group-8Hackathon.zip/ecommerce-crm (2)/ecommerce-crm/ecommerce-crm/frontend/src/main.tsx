import { QueryClientProvider } from '@tanstack/react-query';
import { MotionConfig } from 'framer-motion';
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { Toaster } from 'react-hot-toast';
import { BrowserRouter, MemoryRouter } from 'react-router-dom';
import { isMockApi } from '@/mocks';
import { App } from './App';
import { queryClient } from './lib/queryClient';
import './index.css';

// The hosted preview runs in a sandboxed frame without real URL paths.
const Router = isMockApi ? MemoryRouter : BrowserRouter;

const container = document.getElementById('root');
if (!container) throw new Error('#root element missing from index.html');

createRoot(container).render(
  <StrictMode>
    <QueryClientProvider client={queryClient}>
      <Router>
        {/* "user" → framer-motion follows the OS reduced-motion setting everywhere. */}
        <MotionConfig reducedMotion="user">
          <App />
        </MotionConfig>
        <Toaster
          position="bottom-center"
          toastOptions={{
            duration: 4000,
            style: { borderRadius: '12px', fontSize: '14px', color: '#0A0A0A' },
            success: {
              style: { background: '#DCFCE7', border: '1px solid #22C55E' },
              iconTheme: { primary: '#15803D', secondary: '#FFFFFF' },
            },
            error: {
              duration: 6000,
              style: { background: '#FEF2F2', border: '1px solid #EF4444' },
              iconTheme: { primary: '#DC2626', secondary: '#FFFFFF' },
            },
          }}
        />
      </Router>
    </QueryClientProvider>
  </StrictMode>,
);
