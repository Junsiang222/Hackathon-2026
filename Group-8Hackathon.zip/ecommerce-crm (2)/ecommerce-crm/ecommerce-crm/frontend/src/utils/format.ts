let integerFormatter = new Intl.NumberFormat(undefined, { maximumFractionDigits: 0 });
let decimalFormatter = new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 });
let dateFormatter = new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' });
let dateTimeFormatter = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' });
let showUtc = false;

/**
 * Settings → Language & display: number/date style for the chosen language,
 * and whether times are shown in the viewer's local time or UTC.
 */
export function configureFormatting({ locale, utc }: { locale: string | undefined; utc: boolean }) {
  showUtc = utc;
  integerFormatter = new Intl.NumberFormat(locale, { maximumFractionDigits: 0 });
  decimalFormatter = new Intl.NumberFormat(locale, { maximumFractionDigits: 1 });
  dateFormatter = new Intl.DateTimeFormat(locale, { month: 'short', day: 'numeric' });
  dateTimeFormatter = new Intl.DateTimeFormat(locale, {
    dateStyle: 'medium',
    timeStyle: 'short',
    ...(utc ? { timeZone: 'UTC' } : {}),
  });
}

export function toNumber(value: unknown): number {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

/** True for keys that hold percentages (rate / pct), e.g. open_rate. */
export function isPercentKey(key: string): boolean {
  return /rate|pct/i.test(key);
}

export function formatInteger(value: unknown): string {
  return integerFormatter.format(Math.round(toNumber(value)));
}

/** Integer for counts, one-decimal percentage for rate/pct keys. Never a currency. */
export function formatMetric(key: string, value: unknown): string {
  return isPercentKey(key) ? `${decimalFormatter.format(toNumber(value))}%` : formatInteger(value);
}

/** 'new_customers' → 'New customers', 'pageViews' → 'Page views' */
export function humanizeKey(key: string): string {
  const spaced = key
    .replace(/([a-z])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .trim()
    .toLowerCase();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

/** Parses 'YYYY-MM-DD' as a calendar date (no timezone shift). */
export function formatShortDate(value: unknown): string {
  if (typeof value !== 'string') return String(value ?? '');
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return value;
  const [, y, m, d] = match;
  return dateFormatter.format(new Date(Number(y), Number(m) - 1, Number(d)));
}

export function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return showUtc ? `${dateTimeFormatter.format(date)} UTC` : dateTimeFormatter.format(date);
}

export function formatCurrency(amount: string | number, currency: string): string {
  try {
    return new Intl.NumberFormat(undefined, { style: 'currency', currency }).format(toNumber(amount));
  } catch {
    return `${toNumber(amount).toFixed(2)} ${currency}`;
  }
}

export function initialsFrom(text: string): string {
  const base = text.split('@')[0] ?? text;
  const parts = base.split(/[.\s_-]+/).filter(Boolean);
  const letters = parts.length > 1 ? `${parts[0]![0]}${parts[1]![0]}` : base.slice(0, 2);
  return letters.toUpperCase();
}

const amountFormatter = new Intl.NumberFormat(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Two-decimal amount without a currency symbol (for rows that have no currency). */
export function formatAmount(amount: string | number): string {
  return amountFormatter.format(toNumber(amount));
}
