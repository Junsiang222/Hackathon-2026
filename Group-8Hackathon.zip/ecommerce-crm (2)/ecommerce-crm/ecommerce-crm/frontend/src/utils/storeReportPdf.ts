import type { Insight, MonthComparisonValue, PeriodRange, ProductPerformance, StoreDetail, StoreMetrics } from '@/types/platformAnalytics.types';

// PDF export of one store's analytics for the chosen period. Counts only, like the page:
// the analytics API never sends money, so neither does the report.

type Rgb = [number, number, number];
// Muted, print-friendly palette: navy for structure, slate for text, colour only for up/down.
const NAVY: Rgb = [30, 41, 59];
const INK: Rgb = [15, 23, 42];
const MUTED: Rgb = [100, 116, 139];
const LINE: Rgb = [226, 232, 240];
const PANEL: Rgb = [248, 250, 252];
const BAR: Rgb = [71, 85, 105];
const UP: Rgb = [21, 94, 63];
const DOWN: Rgb = [153, 27, 27];
const MARGIN = 40;
const DAY_MS = 86_400_000;

const int = (value: number) => Math.round(value).toLocaleString('en-US');
const pct = (ratio: number | null, digits = 1) => (ratio === null ? '—' : `${(ratio * 100).toFixed(digits)}%`);
const ratioChange = (value: number, before: number) => (before === 0 ? null : (value - before) / before);
const change = (value: number, before: number) => {
  const r = ratioChange(value, before);
  return r === null ? (value === 0 ? '0.0%' : 'new') : `${r >= 0 ? '+' : ''}${(r * 100).toFixed(1)}%`;
};
const signed = (ratio: number | null) => (ratio === null ? '—' : `${ratio >= 0 ? '+' : ''}${(ratio * 100).toFixed(1)}%`);
const titleCase = (text: string) => text.charAt(0).toUpperCase() + text.slice(1);
const monthLabel = (month: string) =>
  new Date(`${month}-01T00:00:00Z`).toLocaleDateString('en-US', { month: 'short', year: 'numeric', timeZone: 'UTC' });
const dayLabel = (time: number) =>
  new Date(time).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' });
const conversion = (m: StoreMetrics) => (m.pageViews > 0 ? (m.orders - m.cancelledOrRefunded) / m.pageViews : null);

/** The previous period of the same length, ending the day before `range.from`. */
function previousRange(range: PeriodRange) {
  const from = Date.parse(`${range.from}T00:00:00Z`);
  const to = Date.parse(`${range.to}T00:00:00Z`);
  const days = Math.round((to - from) / DAY_MS) + 1;
  return { from: from - days * DAY_MS, to: from - DAY_MS, current: { from, to } };
}

/** Short plain-language findings for the executive summary. */
function findings(detail: StoreDetail, insights: Insight[]): string[] {
  const { current: now, previous: before } = detail.store;
  const lines: string[] = [];
  const ordersChange = ratioChange(now.orders, before.orders);
  if (ordersChange !== null) {
    lines.push(
      `Orders ${ordersChange >= 0 ? 'rose' : 'fell'} ${Math.abs(ordersChange * 100).toFixed(1)}% to ${int(now.orders)} compared with the previous period.`,
    );
  } else if (now.orders > 0) {
    lines.push(`${int(now.orders)} orders were placed; there were none in the previous period.`);
  }
  const convNow = conversion(now);
  const convBefore = conversion(before);
  if (convNow !== null && convBefore !== null) {
    lines.push(`Conversion moved from ${pct(convBefore, 2)} to ${pct(convNow, 2)} of visits.`);
  }
  const viewsChange = ratioChange(now.pageViews, before.pageViews);
  if (viewsChange !== null && ordersChange !== null && viewsChange - ordersChange > 0.1) {
    lines.push('Traffic grew faster than orders, so more visitors are leaving without buying.');
  }
  if (detail.store.outOfStock + detail.store.lowStock > 0) {
    lines.push(`${detail.store.outOfStock} product(s) are out of stock and ${detail.store.lowStock} are running low.`);
  }
  if (detail.store.urgentTickets > 0) lines.push(`${detail.store.urgentTickets} urgent support ticket(s) are still open.`);
  const high = insights.filter((insight) => insight.severity === 'high').length;
  if (high > 0) lines.push(`${high} high-priority alert(s) need attention (see Alerts & recommendations).`);
  if (lines.length === 0) lines.push('No significant changes or issues in this period.');
  return lines.slice(0, 5);
}

export async function downloadStoreReportPdf(detail: StoreDetail, insights: Insight[], range: PeriodRange) {
  const [{ jsPDF }, { default: autoTable }] = await Promise.all([import('jspdf'), import('jspdf-autotable/es')]);
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const contentWidth = pageWidth - MARGIN * 2;
  const { store } = detail;
  const { current: now, previous: before } = store;
  const periods = previousRange(range);
  const generated = new Date();

  let y = MARGIN;
  const lastY = () => (doc as unknown as { lastAutoTable: { finalY: number } }).lastAutoTable.finalY;
  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - MARGIN - 20) {
      doc.addPage();
      y = MARGIN;
    }
  };
  const text = (value: string, x: number, at: number, size: number, color: Rgb, bold = false, align: 'left' | 'right' = 'left') => {
    doc.setFont('helvetica', bold ? 'bold' : 'normal').setFontSize(size).setTextColor(...color);
    doc.text(value, x, at, { align });
  };
  const heading = (title: string, subtitle?: string) => {
    ensureSpace(80);
    doc.setFillColor(...NAVY).rect(MARGIN, y - 10, 3, 14, 'F');
    text(title, MARGIN + 10, y + 1, 12, INK, true);
    y += 8;
    if (subtitle) {
      text(subtitle, MARGIN + 10, y + 6, 8.5, MUTED);
      y += 12;
    }
  };
  const table = (head: string[], body: (string | number)[][], rightAlignFrom = 1) => {
    const columnStyles: Record<number, { halign: 'right' }> = {};
    for (let i = rightAlignFrom; i < head.length; i += 1) columnStyles[i] = { halign: 'right' };
    autoTable(doc, {
      startY: y,
      head: [head],
      body,
      theme: 'plain',
      margin: { left: MARGIN, right: MARGIN, bottom: MARGIN + 20 },
      styles: { fontSize: 9, cellPadding: 5, textColor: INK, lineColor: LINE, lineWidth: { bottom: 0.5 } },
      headStyles: { fillColor: PANEL, textColor: MUTED, fontStyle: 'bold', fontSize: 8 },
      columnStyles,
    });
    y = lastY() + 24;
  };

  // Cover band
  doc.setFillColor(...NAVY).rect(0, 0, pageWidth, 96, 'F');
  text('STORE ANALYTICS REPORT', MARGIN, 34, 8.5, [148, 163, 184], true);
  text(store.storeName, MARGIN, 60, 22, [255, 255, 255], true);
  text(`${titleCase(store.industry)} · ${titleCase(store.status)}`, MARGIN, 80, 10, [203, 213, 225]);
  text('Confidential – internal use', pageWidth - MARGIN, 34, 8.5, [148, 163, 184], false, 'right');
  y = 120;

  // Report details
  const details: [string, string][] = [
    ['Reporting period', `${dayLabel(periods.current.from)} – ${dayLabel(periods.current.to)}`],
    ['Compared with', `${dayLabel(periods.from)} – ${dayLabel(periods.to)}`],
    ['Generated', generated.toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' })],
  ];
  const detailWidth = contentWidth / details.length;
  details.forEach(([label, value], i) => {
    text(label.toUpperCase(), MARGIN + i * detailWidth, y, 7.5, MUTED, true);
    text(value, MARGIN + i * detailWidth, y + 14, 9.5, INK);
  });
  y += 40;

  // Executive summary: headline cards
  heading('Executive summary');
  y += 6;
  const convNow = conversion(now);
  const convBefore = conversion(before);
  const cards: { label: string; value: string; delta: number | null }[] = [
    { label: 'Orders', value: int(now.orders), delta: ratioChange(now.orders, before.orders) },
    { label: 'Units sold', value: int(now.unitsSold), delta: ratioChange(now.unitsSold, before.unitsSold) },
    { label: 'New customers', value: int(now.newCustomers), delta: ratioChange(now.newCustomers, before.newCustomers) },
    { label: 'Conversion', value: pct(convNow, 2), delta: convNow !== null && convBefore ? ratioChange(convNow, convBefore) : null },
  ];
  const gap = 10;
  const cardWidth = (contentWidth - gap * (cards.length - 1)) / cards.length;
  cards.forEach((card, i) => {
    const x = MARGIN + i * (cardWidth + gap);
    doc.setFillColor(...PANEL).setDrawColor(...LINE).roundedRect(x, y, cardWidth, 62, 4, 4, 'FD');
    text(card.label.toUpperCase(), x + 10, y + 16, 7.5, MUTED, true);
    text(card.value, x + 10, y + 38, 17, INK, true);
    const deltaColor = card.delta === null ? MUTED : card.delta >= 0 ? UP : DOWN;
    text(card.delta === null ? 'no comparison' : `${signed(card.delta)} vs previous`, x + 10, y + 53, 8, deltaColor);
  });
  y += 82;

  text('Key findings', MARGIN, y, 10, INK, true);
  y += 14;
  doc.setFont('helvetica', 'normal').setFontSize(9.5).setTextColor(...INK);
  for (const line of findings(detail, insights)) {
    const wrapped = doc.splitTextToSize(line, contentWidth - 14) as string[];
    ensureSpace(wrapped.length * 13);
    doc.setFillColor(...BAR).circle(MARGIN + 3, y - 3, 1.6, 'F');
    doc.setFont('helvetica', 'normal').setFontSize(9.5).setTextColor(...INK);
    doc.text(wrapped, MARGIN + 12, y);
    y += wrapped.length * 13 + 3;
  }
  y += 18;

  // Daily orders chart (simple bars)
  if (detail.trend.length > 1) {
    heading('Daily orders', 'Orders placed each day in the reporting period');
    const chartHeight = 110;
    ensureSpace(chartHeight + 30);
    const max = Math.max(1, ...detail.trend.map((d) => d.orders));
    const top = y + 6;
    const axisX = MARGIN + 28;
    const plotWidth = contentWidth - 28;
    doc.setDrawColor(...LINE).setLineWidth(0.5);
    [0, 0.5, 1].forEach((f) => {
      const ly = top + chartHeight - f * chartHeight;
      doc.line(axisX, ly, axisX + plotWidth, ly);
      text(int(max * f), axisX - 6, ly + 3, 7, MUTED, false, 'right');
    });
    const slot = plotWidth / detail.trend.length;
    const barWidth = Math.max(1, slot * 0.7);
    doc.setFillColor(...BAR);
    detail.trend.forEach((d, i) => {
      const h = (d.orders / max) * chartHeight;
      if (h > 0) doc.rect(axisX + i * slot + (slot - barWidth) / 2, top + chartHeight - h, barWidth, h, 'F');
    });
    const first = detail.trend[0]?.date ?? '';
    const last = detail.trend[detail.trend.length - 1]?.date ?? '';
    text(first, axisX, top + chartHeight + 12, 7, MUTED);
    text(last, axisX + plotWidth, top + chartHeight + 12, 7, MUTED, false, 'right');
    y = top + chartHeight + 34;
  }

  // Key numbers
  const rows: [string, (m: StoreMetrics) => number][] = [
    ['Orders', (m) => m.orders],
    ['Units sold', (m) => m.unitsSold],
    ['New customers', (m) => m.newCustomers],
    ['Buyers', (m) => m.buyers],
    ['Cancelled / refunded', (m) => m.cancelledOrRefunded],
    ['Page views', (m) => m.pageViews],
    ['Add to carts', (m) => m.addToCarts],
    ['Checkouts started', (m) => m.checkoutsStarted],
  ];
  heading('Key numbers vs previous period');
  table(
    ['Metric', 'This period', 'Previous period', 'Change'],
    rows.map(([label, pick]) => [label, int(pick(now)), int(pick(before)), change(pick(now), pick(before))]),
  );

  // Funnel
  const steps: [string, number][] = [
    ['Visits (page views)', now.pageViews],
    ['Added to cart', now.addToCarts],
    ['Checkout started', now.checkoutsStarted],
    ['Orders placed', now.orders],
  ];
  heading('Sales funnel', 'How many visitors reach each step, and how many continue from the step before');
  table(
    ['Step', 'Count', 'From previous step', 'From visits'],
    steps.map(([label, count], i) => [
      label,
      int(count),
      i === 0 ? '—' : pct(steps[i - 1]?.[1] ? count / steps[i - 1]![1] : null, 1),
      pct(now.pageViews ? count / now.pageViews : null, 2),
    ]),
  );

  heading('Rates & health');
  table(
    ['Measure', 'Value'],
    [
      ['Conversion (valid orders ÷ visits)', pct(detail.conversionRate, 2)],
      ['Repeat buyers', pct(detail.retention.repeatRate, 0)],
      ['Returning buyers', pct(detail.retention.returningRate, 0)],
      ['Items per order', detail.itemsPerOrder?.toFixed(2) ?? '—'],
      ['Cancelled / refunded rate', pct(now.orders ? now.cancelledOrRefunded / now.orders : null, 0)],
      ['Units on hand', int(detail.inventory.unitsOnHand)],
      ['Inventory turnover', detail.inventory.turnover?.toFixed(2) ?? '—'],
      ['Days of stock left', detail.inventory.daysOfCover?.toString() ?? '—'],
      ['Out of stock / low stock products', `${store.outOfStock} / ${store.lowStock}`],
      ['Open tickets (urgent)', `${store.openTickets} (${store.urgentTickets})`],
      ['Tickets resolved', int(detail.tickets.resolved)],
      [
        'Avg. resolution time',
        detail.tickets.avgResolutionHours === null ? '—' : `${detail.tickets.avgResolutionHours.toFixed(1)} h`,
      ],
    ],
  );

  const mc = detail.monthComparison;
  const compareRow = (label: string, v: MonthComparisonValue) => [
    label,
    int(v.value),
    int(v.lastMonth),
    signed(v.mom),
    v.yoy === null ? 'no data' : int(v.lastYear),
    signed(v.yoy),
  ];
  heading(`${monthLabel(mc.month)} compared`, 'Month on month (MoM) and year on year (YoY)');
  table(
    ['Metric', 'This month', 'Last month', 'MoM', 'Last year', 'YoY'],
    [compareRow('Orders', mc.orders), compareRow('Units sold', mc.unitsSold), compareRow('New customers', mc.newCustomers)],
  );

  heading('Alerts & recommendations');
  if (insights.length === 0) {
    text('No alerts for this period.', MARGIN, y + 8, 9.5, MUTED);
    y += 30;
  } else {
    const rank = { high: 0, medium: 1, info: 2 } as const;
    const priority = { high: 'High', medium: 'Medium', info: 'Low' } as const;
    table(
      ['Priority', 'Issue', 'Recommended action'],
      [...insights]
        .sort((a, b) => rank[a.severity] - rank[b.severity])
        .map((insight) => [priority[insight.severity], insight.message, insight.recommendation]),
      3,
    );
  }

  const productRows = (products: ProductPerformance[]) =>
    products.map((p) => [p.name, p.category ?? '—', int(p.unitsSold), int(p.orders), p.inStock === null ? '—' : int(p.inStock)]);
  const productHead = ['Product', 'Category', 'Units sold', 'Orders', 'In stock'];
  heading('Top products');
  if (detail.topProducts.length) table(productHead, productRows(detail.topProducts), 2);
  else y += 14;
  heading('Slowest products');
  if (detail.lowProducts.length) table(productHead, productRows(detail.lowProducts), 2);
  else y += 14;

  heading('Orders by status');
  const statusTotal = detail.statusBreakdown.reduce((acc, s) => acc + s.orders, 0);
  table(
    ['Status', 'Orders', 'Share'],
    detail.statusBreakdown.map((s) => [titleCase(s.status), int(s.orders), pct(statusTotal ? s.orders / statusTotal : null, 0)]),
  );

  heading('Monthly totals');
  table(
    ['Month', 'Orders', 'Units sold', 'New customers'],
    detail.monthly.map((m) => [monthLabel(m.month), int(m.orders), int(m.unitsSold), int(m.newCustomers)]),
  );

  heading('Appendix: daily figures');
  table(
    ['Date', 'Orders', 'Units sold', 'Page views'],
    detail.trend.map((d) => [d.date, int(d.orders), int(d.unitsSold), int(d.pageViews)]),
  );

  heading('Definitions & notes');
  const notes = [
    'All dates and times are in UTC. The comparison period is the same number of days immediately before the reporting period.',
    'Conversion = orders that were not cancelled or refunded ÷ page views.',
    'Repeat buyers placed two or more orders in the period; returning buyers had also ordered before it.',
    'Inventory turnover = units sold ÷ units on hand. Days of stock left = units on hand ÷ average units sold per day.',
    'Store revenue, prices and costs are private to each store and are not included in this report.',
  ];
  doc.setFont('helvetica', 'normal').setFontSize(8.5).setTextColor(...MUTED);
  for (const note of notes) {
    const wrapped = doc.splitTextToSize(note, contentWidth - 12) as string[];
    ensureSpace(wrapped.length * 11 + 4);
    doc.setFont('helvetica', 'normal').setFontSize(8.5).setTextColor(...MUTED);
    doc.text('•', MARGIN + 2, y + 6);
    doc.text(wrapped, MARGIN + 12, y + 6);
    y += wrapped.length * 11 + 4;
  }

  // Header line and footer on every page
  const pages = doc.getNumberOfPages();
  for (let page = 1; page <= pages; page += 1) {
    doc.setPage(page);
    doc.setDrawColor(...LINE).setLineWidth(0.5).line(MARGIN, pageHeight - 32, pageWidth - MARGIN, pageHeight - 32);
    doc.setFont('helvetica', 'normal').setFontSize(7.5).setTextColor(...MUTED);
    doc.text(`${store.storeName} · Store analytics · ${range.from} to ${range.to}`, MARGIN, pageHeight - 20);
    doc.text(`Page ${page} of ${pages}`, pageWidth - MARGIN, pageHeight - 20, { align: 'right' });
  }

  const slug = store.storeName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || `store-${store.tenantId}`;
  doc.save(`${slug}-analytics-${range.from}-to-${range.to}.pdf`);
}
