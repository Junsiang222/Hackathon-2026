/**
 * Keys that may carry monetary values. Mirrors the backend financialStripper
 * pattern; enforced client-side as defence in depth for EVERY role.
 */
export const BLOCKED_KEYS = /price|amount|revenue|profit|margin|cost|ltv|earning|total/i;

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function sanitizeValue(value: unknown, seen = new WeakMap<object, unknown>()): unknown {
  if (Array.isArray(value)) {
    if (seen.has(value)) return seen.get(value);
    const output: unknown[] = [];
    seen.set(value, output);
    for (const item of value) {
      output.push(sanitizeValue(item, seen));
    }
    return output;
  }

  if (isPlainObject(value)) {
    if (seen.has(value)) return seen.get(value);
    const output: Record<string, unknown> = {};
    seen.set(value, output);
    for (const [key, child] of Object.entries(value)) {
      if (BLOCKED_KEYS.test(key)) continue;
      const sanitizedChild = sanitizeValue(child, seen);
      if (sanitizedChild !== undefined) output[key] = sanitizedChild;
    }
    return output;
  }

  return value;
}

export function sanitizeWidgetData(data: Record<string, unknown>[]): Record<string, unknown>[] {
  return data.map((row) => sanitizeValue(row) as Record<string, unknown>);
}

/** Drops any configured data key that would plot a monetary series. */
export function sanitizeDataKeys(keys: readonly string[]): string[] {
  return keys.filter((key) => !BLOCKED_KEYS.test(key));
}
