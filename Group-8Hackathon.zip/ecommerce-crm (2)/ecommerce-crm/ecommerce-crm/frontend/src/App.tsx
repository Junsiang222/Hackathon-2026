import { ShieldAlert } from 'lucide-react';
import { lazy, Suspense } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { LoadingShimmer } from '@/components/LoadingShimmer';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { EmptyState } from '@/components/ui/EmptyState';
import { useBootstrapSession } from '@/hooks/useAuth';
import { AuthLayout } from '@/layouts/AuthLayout';
import { DashboardLayout } from '@/layouts/DashboardLayout';
import { useAuthStore } from '@/store/authStore';

// Route-level code splitting: charts (recharts) only load on the Analytics page.
const AuthPage = lazy(() => import('@/pages/AuthPage').then((m) => ({ default: m.AuthPage })));
const SuperAdminPage = lazy(() => import('@/pages/SuperAdminPage').then((m) => ({ default: m.SuperAdminPage })));
const WebsitesPage = lazy(() => import('@/pages/WebsitesPage').then((m) => ({ default: m.WebsitesPage })));
const PlatformAnalyticsPage = lazy(() =>
  import('@/pages/platform/PlatformAnalyticsPage').then((m) => ({ default: m.PlatformAnalyticsPage })),
);
const SettingsPage = lazy(() => import('@/pages/platform/SettingsPage').then((m) => ({ default: m.SettingsPage })));
const PlatformStorePage = lazy(() => import('@/pages/platform/PlatformStorePage').then((m) => ({ default: m.PlatformStorePage })));
const StoreOverviewPage = lazy(() => import('@/pages/store/StoreOverviewPage').then((m) => ({ default: m.StoreOverviewPage })));
const ProductsPage = lazy(() => import('@/pages/store/ProductsPage').then((m) => ({ default: m.ProductsPage })));
const OrdersPage = lazy(() => import('@/pages/store/OrdersPage').then((m) => ({ default: m.OrdersPage })));
const CustomersPage = lazy(() => import('@/pages/store/CustomersPage').then((m) => ({ default: m.CustomersPage })));
const MarketingPage = lazy(() => import('@/pages/store/MarketingPage').then((m) => ({ default: m.MarketingPage })));
const ExpensesPage = lazy(() => import('@/pages/store/ExpensesPage').then((m) => ({ default: m.ExpensesPage })));
const TicketsPage = lazy(() => import('@/pages/store/TicketsPage').then((m) => ({ default: m.TicketsPage })));
const ShopLayout = lazy(() => import('@/layouts/ShopLayout').then((m) => ({ default: m.ShopLayout })));
const ShopHomePage = lazy(() => import('@/pages/shop/ShopHomePage').then((m) => ({ default: m.ShopHomePage })));
const ShopProductPage = lazy(() => import('@/pages/shop/ShopProductPage').then((m) => ({ default: m.ShopProductPage })));
const ShopCartPage = lazy(() => import('@/pages/shop/ShopCartPage').then((m) => ({ default: m.ShopCartPage })));
const ShopCheckoutPage = lazy(() => import('@/pages/shop/ShopCheckoutPage').then((m) => ({ default: m.ShopCheckoutPage })));
const ShopTrackPage = lazy(() => import('@/pages/shop/ShopTrackPage').then((m) => ({ default: m.ShopTrackPage })));
const ShopContactPage = lazy(() => import('@/pages/shop/ShopContactPage').then((m) => ({ default: m.ShopContactPage })));
const ShopLoginPage = lazy(() => import('@/pages/shop/ShopLoginPage').then((m) => ({ default: m.ShopLoginPage })));
const ShopRegisterPage = lazy(() => import('@/pages/shop/ShopRegisterPage').then((m) => ({ default: m.ShopRegisterPage })));
const ShopAccountPage = lazy(() => import('@/pages/shop/ShopAccountPage').then((m) => ({ default: m.ShopAccountPage })));
const AnalyticsPage = lazy(() => import('@/pages/AnalyticsPage').then((m) => ({ default: m.AnalyticsPage })));

/** /dashboard → the signed-in role's home. */
function RoleHome() {
  const role = useAuthStore((state) => state.role);
  if (role === 'super_admin') return <Navigate to="/dashboard/super-admin" replace />;
  if (role === 'admin') return <Navigate to="/dashboard/admin" replace />;
  return (
    <EmptyState
      icon={ShieldAlert}
      minHeight={320}
      title="No dashboard for your role yet"
      description="Staff accounts don't have a workspace view in this release. Ask your store admin for access."
    />
  );
}

export function App() {
  useBootstrapSession();

  return (
    <Suspense fallback={<LoadingShimmer variant="page" />}>
      <Routes>
        <Route element={<AuthLayout />}>
          <Route path="/auth" element={<AuthPage />} />
        </Route>

        <Route path="/dashboard" element={<ProtectedRoute />}>
          <Route element={<DashboardLayout />}>
            <Route index element={<RoleHome />} />

            <Route element={<ProtectedRoute allowedRoles={['super_admin']} />}>
              <Route path="super-admin" element={<SuperAdminPage />} />
              <Route path="stores" element={<SuperAdminPage view="stores" />} />
              <Route path="websites" element={<WebsitesPage />} />
              {/* Old address of the Websites page. */}
              <Route path="history" element={<Navigate to="/dashboard/websites" replace />} />
              <Route path="platform-analytics" element={<PlatformAnalyticsPage />} />
              <Route path="platform-analytics/:tenantId" element={<PlatformStorePage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>

            <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
              {/* Each page checks the store's setup-wizard answers (RequireModule). */}
              <Route path="admin" element={<StoreOverviewPage />} />
              <Route path="products" element={<ProductsPage />} />
              <Route path="orders" element={<OrdersPage />} />
              <Route path="customers" element={<CustomersPage />} />
              <Route path="marketing" element={<MarketingPage />} />
              <Route path="tickets" element={<TicketsPage />} />
              <Route path="expenses" element={<ExpensesPage />} />
              <Route path="analytics" element={<AnalyticsPage />} />
            </Route>
          </Route>
        </Route>

        {/* Public online shop (shopper login optional). Pages follow the store's setup-wizard answers. */}
        <Route path="/shop/:tenantUid" element={<ShopLayout />}>
          <Route index element={<ShopHomePage />} />
          <Route path="product/:productId" element={<ShopProductPage />} />
          <Route path="cart" element={<ShopCartPage />} />
          <Route path="checkout" element={<ShopCheckoutPage />} />
          <Route path="track" element={<ShopTrackPage />} />
          <Route path="contact" element={<ShopContactPage />} />
          <Route path="login" element={<ShopLoginPage />} />
          <Route path="register" element={<ShopRegisterPage />} />
          <Route path="account" element={<ShopAccountPage />} />
        </Route>

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Suspense>
  );
}
