import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Hosted preview: one self-contained HTML file backed by the in-browser mock API.
export default defineConfig({
  plugins: [react(), viteSingleFile()],
  resolve: {
    alias: [
      { find: /^@\/mocks$/, replacement: fileURLToPath(new URL('./src/mocks/mockApi.ts', import.meta.url)) },
      { find: '@', replacement: fileURLToPath(new URL('./src', import.meta.url)) },
    ],
  },
  build: { outDir: 'dist-preview', emptyOutDir: true },
});
