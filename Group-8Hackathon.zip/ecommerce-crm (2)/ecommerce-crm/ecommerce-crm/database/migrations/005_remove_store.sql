-- The super admin can remove a store from History. Removal is a soft delete
-- (status = 'cancelled'): its website goes offline and its logins stop working,
-- but orders and customers are kept. trg_admins_bu keeps status_color in sync.
USE crm_platform;

GRANT UPDATE (status, status_color) ON crm_platform.admins TO 'crm_super_admin_ro';
