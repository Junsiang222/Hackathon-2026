-- Shoppers can register, log in and log out on every store's online shop.
-- Accounts live on `customers` (one per store and email). Guest checkout keeps
-- working: a guest row simply has no password_hash. The super admin role has
-- no grant on customers, so it can never read these hashes.
USE crm_platform;

ALTER TABLE customers
  ADD COLUMN password_hash      VARCHAR(255) NULL COMMENT 'bcrypt; NULL = guest (no shop account)' AFTER phone,
  ADD COLUMN session_token      CHAR(64)     NULL COMMENT 'SHA-256 of the shop session token; NULL = signed out' AFTER password_hash,
  ADD COLUMN session_expires_at DATETIME     NULL AFTER session_token,
  ADD COLUMN account_created_at DATETIME     NULL COMMENT 'When the shopper registered; earlier guest orders stay private' AFTER session_expires_at,
  ADD COLUMN last_login_at      DATETIME     NULL AFTER account_created_at,
  ADD KEY idx_customers_session (session_token);
