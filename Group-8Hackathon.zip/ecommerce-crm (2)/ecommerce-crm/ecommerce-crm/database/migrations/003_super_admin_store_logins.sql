-- Super admin: see each store's admin login email and reset its password.
-- The super admin role still can NOT read password hashes, session tokens or
-- OAuth tokens: it reads emails through a view and may only OVERWRITE the hash.
USE crm_platform;

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_store_admin_view AS
  SELECT id AS user_id, tenant_id, email, role, oauth_provider,
         password_hash IS NOT NULL AS has_password,  -- a yes/no flag, never the hash
         is_active, last_login_at, created_at
  FROM users
  WHERE role IN ('admin', 'staff');
  -- Intentionally excludes: password_hash, session_token, oauth_* tokens

GRANT SELECT ON crm_platform.super_admin_store_admin_view TO 'crm_super_admin_ro';
-- Password reset: match the row by id/tenant/role, write a new hash, end sessions.
GRANT SELECT (id, tenant_id, role), UPDATE (password_hash, session_token) ON crm_platform.users TO 'crm_super_admin_ro';
