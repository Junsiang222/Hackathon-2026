-- =============================================================================
--  009 — Display name
--
--  The name shown in the dashboard's profile menu (and its avatar initials).
--  Kept with the account's dashboard preferences; NULL = use the email's name.
--
--  Run as a user that can alter tables (e.g. root):
--      mysql -u root -p < database/migrations/009_display_name.sql
-- =============================================================================

USE crm_platform;

SET @has_display_name := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = 'crm_platform' AND TABLE_NAME = 'user_preferences' AND COLUMN_NAME = 'display_name'
);
SET @add_display_name := IF(@has_display_name = 0,
  'ALTER TABLE user_preferences ADD COLUMN display_name VARCHAR(60) NULL COMMENT ''Shown in the profile menu; NULL = derived from the email'' AFTER user_id',
  'SELECT 1');
PREPARE stmt FROM @add_display_name;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
