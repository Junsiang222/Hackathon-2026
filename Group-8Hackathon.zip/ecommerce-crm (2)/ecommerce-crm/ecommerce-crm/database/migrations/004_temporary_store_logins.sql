-- Creating a store's website also creates its first admin login with a
-- temporary password; the client must choose their own at first sign-in.
USE crm_platform;

ALTER TABLE users
  ADD COLUMN must_change_password TINYINT(1) NOT NULL DEFAULT 0
    COMMENT '1 = signed in with a temporary password; must set their own' AFTER password_hash;

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_store_admin_view AS
  SELECT id AS user_id, tenant_id, email, role, oauth_provider,
         password_hash IS NOT NULL AS has_password,  -- a yes/no flag, never the hash
         must_change_password,
         is_active, last_login_at, created_at
  FROM users
  WHERE role IN ('admin', 'staff');

-- Create the first admin login of a store, and flag reset passwords as temporary.
GRANT INSERT (tenant_id, role, email, password_hash, must_change_password) ON crm_platform.users TO 'crm_super_admin_ro';
GRANT UPDATE (password_hash, session_token, must_change_password) ON crm_platform.users TO 'crm_super_admin_ro';
