-- =============================================================================
--  008 — Settings
--
--  1. user_preferences: per-account display preferences for the dashboard
--     (language, time display, default analytics period, auto-refresh).
--     The API only ever reads/writes the row of the signed-in user.
--  2. platform_settings: platform-wide options the super admin controls
--     (language of AI-generated websites, storefront currency). Values are
--     small JSON scalars; nothing financial or personal is stored here.
--
--  Run as a user that can create tables and grant (e.g. root):
--      mysql -u root -p < database/migrations/008_settings.sql
-- =============================================================================

USE crm_platform;

CREATE TABLE IF NOT EXISTS user_preferences (
  user_id          BIGINT UNSIGNED NOT NULL,
  language         ENUM('en','ms','zh') NOT NULL DEFAULT 'en',
  time_display     ENUM('local','utc')  NOT NULL DEFAULT 'local',
  default_period   ENUM('today','7d','30d','month','90d') NOT NULL DEFAULT '30d',
  refresh_seconds  SMALLINT UNSIGNED NOT NULL DEFAULT 60 COMMENT '0 = no auto-refresh',
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (user_id),
  CONSTRAINT fk_user_preferences_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_user_preferences_refresh CHECK (refresh_seconds IN (0, 30, 60, 300))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS platform_settings (
  setting_key    VARCHAR(64)     NOT NULL,
  setting_value  JSON            NOT NULL,
  updated_by     BIGINT UNSIGNED NULL,
  updated_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (setting_key),
  CONSTRAINT fk_platform_settings_user
    FOREIGN KEY (updated_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO platform_settings (setting_key, setting_value) VALUES
  ('website_language', JSON_QUOTE('en')),
  ('store_currency',   JSON_QUOTE('USD'));

-- crm_app_rw already has SELECT/INSERT/UPDATE/DELETE on crm_platform.* (the
-- shop reads the currency through it).
GRANT SELECT, INSERT, UPDATE ON crm_platform.user_preferences  TO 'crm_super_admin_ro';
GRANT SELECT, INSERT, UPDATE ON crm_platform.platform_settings TO 'crm_super_admin_ro';
