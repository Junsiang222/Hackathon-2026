-- =============================================================================
--  007 — Super admin analytics (non-financial) + store cost tracking
--
--  1. Super admin analytics reads five NEW column-restricted views. Like the
--     existing super_admin_* views they carry NO monetary column (no prices,
--     subtotals, totals, ltv, cost, expenses) and NO customer personal data
--     (no names, emails, phones, ticket text). The financial exclusion
--     described in schema.sql section 6 still holds: no super_admin-readable
--     object exposes money.
--
--  2. Store owners can record what things cost them: products.cost_price and
--     a new `expenses` table. Both are FINANCIAL and tenant-only: the super
--     admin role gets no grant on either, and super_admin_product_view lists
--     its columns explicitly, so cost_price never appears there.
--
--  Run as a user that can create views and grant (e.g. root):
--      mysql -u root -p < database/migrations/007_analytics_and_cost_tracking.sql
-- =============================================================================

USE crm_platform;

-- ─── 1. Super admin analytics views (non-financial, no personal data) ─────────

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_order_item_view AS
  SELECT id, tenant_id, order_id, product_id, qty, created_at
  FROM order_items;
  -- Intentionally excludes: unit_price, subtotal (FINANCIAL)

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_inventory_view AS
  SELECT tenant_id, product_id, qty_available, restock_threshold, last_restocked_at
  FROM inventory;

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_customer_view AS
  SELECT id, tenant_id, status, acquisition_channel, created_at, last_active_at
  FROM customers;
  -- Intentionally excludes: ltv (FINANCIAL); full_name, email, phone, password_hash,
  -- session_* (personal data / secrets)

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_ticket_view AS
  SELECT id, tenant_id, priority, status, channel, created_at, resolved_at
  FROM support_tickets;
  -- Intentionally excludes: subject, body (customer messages), customer_id

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_traffic_view AS
  SELECT tenant_id, event_type, entity_type, entity_id, recorded_at
  FROM analytics_logs;
  -- Intentionally excludes: metadata (free-form)

GRANT SELECT ON crm_platform.super_admin_order_item_view TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_inventory_view  TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_customer_view   TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_ticket_view     TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_traffic_view    TO 'crm_super_admin_ro';

-- ─── 2. Store cost tracking (FINANCIAL, tenant-only) ──────────────────────────

-- What one unit costs the store to buy or make (for its own COGS). NULL = not entered.
SET @has_cost_price := (
  SELECT COUNT(*) FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA = 'crm_platform' AND TABLE_NAME = 'products' AND COLUMN_NAME = 'cost_price'
);
SET @add_cost_price := IF(@has_cost_price = 0,
  'ALTER TABLE products ADD COLUMN cost_price DECIMAL(12,4) NULL COMMENT ''FINANCIAL — never exposed to super_admin'' AFTER base_price, ADD CONSTRAINT chk_products_cost_price CHECK (cost_price IS NULL OR cost_price >= 0)',
  'SELECT 1');
PREPARE stmt FROM @add_cost_price;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

CREATE TABLE IF NOT EXISTS expenses (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id    BIGINT UNSIGNED NOT NULL,
  category     ENUM('rent','wages','utilities','marketing','supplies','shipping','software','other') NOT NULL,
  description  VARCHAR(255)    NULL,
  amount       DECIMAL(12,4)   NOT NULL COMMENT 'FINANCIAL — never exposed to super_admin',
  incurred_on  DATE            NOT NULL,
  created_by   BIGINT UNSIGNED NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_expenses_tenant_incurred (tenant_id, incurred_on DESC),   -- also serves fk_expenses_tenant
  KEY idx_expenses_tenant_category (tenant_id, category),
  KEY idx_expenses_created_by (created_by),
  CONSTRAINT fk_expenses_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_expenses_created_by
    FOREIGN KEY (created_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_expenses_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- crm_app_rw already has SELECT/INSERT/UPDATE/DELETE on crm_platform.*.
-- (Intentionally NO grant on expenses or products.cost_price for crm_super_admin_ro.)
