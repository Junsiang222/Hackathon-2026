-- Online shop checkout: where to deliver the order.
USE crm_platform;
ALTER TABLE orders
  ADD COLUMN shipping_address TEXT NULL COMMENT 'Delivery address entered at online checkout' AFTER currency;
