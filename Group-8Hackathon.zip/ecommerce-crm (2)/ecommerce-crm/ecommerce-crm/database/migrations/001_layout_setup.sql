-- Saves the super admin's setup-wizard answers (store name, enabled modules,
-- chart types) with each dashboard layout. The store's website and admin panel
-- only expose the modules enabled here.
USE crm_platform;
ALTER TABLE dashboard_layouts
  ADD COLUMN setup_json JSON NULL COMMENT 'Wizard answers: {storeName, modules, analyticsCharts}' AFTER config_json;
