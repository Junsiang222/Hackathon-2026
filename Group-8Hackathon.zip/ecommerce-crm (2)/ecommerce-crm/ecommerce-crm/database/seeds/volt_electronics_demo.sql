-- =============================================================================
--  DEMO DATA — "Volt Electronics"
--
--  Fills the active store named "Volt Electronics" with realistic demo data
--  for a consumer electronics shop: phones, laptops, audio, smart home and
--  accessories with cost prices and stock, customers, ~320 orders over the last 4 months,
--  campaigns, support tickets, 30 days of storefront traffic and 4 months of
--  operating expenses. Dates are relative to "now", so the 30-day analytics
--  charts and the store's profit view are populated.
--
--  Run (needs CREATE ROUTINE, e.g. as root):
--      mysql -u root -p < database/seeds/volt_electronics_demo.sql
--
--  Safe: all-or-nothing (one transaction), and refuses to run if the store
--  already has products. Customer emails use the reserved example.com domain.
--  Product names are fictional (no real brands). Demo/dev only — never run
--  against production.
-- =============================================================================

-- The file is UTF-8 (dashes, quotes…): read it as such whatever the client default is.
SET NAMES utf8mb4;
USE crm_platform;

DROP PROCEDURE IF EXISTS seed_volt_electronics_demo;

DELIMITER $$
CREATE PROCEDURE seed_volt_electronics_demo()
BEGIN
  DECLARE v_tenant BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_admin BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_product_count INT;
  DECLARE v_customer_count INT;
  DECLARE i INT;
  DECLARE j INT;
  DECLARE v_items INT;
  DECLARE v_age INT;
  DECLARE v_roll DOUBLE;
  DECLARE v_status VARCHAR(20);
  DECLARE v_placed DATETIME;
  DECLARE v_created DATETIME;
  DECLARE v_customer BIGINT UNSIGNED;
  DECLARE v_order BIGINT UNSIGNED;
  DECLARE v_product BIGINT UNSIGNED;
  DECLARE v_price DECIMAL(12,4);
  DECLARE v_qty INT;
  DECLARE v_day INT;
  DECLARE v_views INT;
  DECLARE v_carts INT;
  DECLARE v_checkouts INT;
  DECLARE v_topic INT;
  DECLARE v_month INT;
  DECLARE v_month_start DATE;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    DROP TEMPORARY TABLE IF EXISTS tmp_vlt_products, tmp_vlt_customers, tmp_vlt_seq;
    RESIGNAL;
  END;

  SELECT id INTO v_tenant
    FROM admins
   WHERE LOWER(business_name) = 'volt electronics' AND status = 'active' AND is_platform = 0
   ORDER BY id DESC
   LIMIT 1;
  IF v_tenant IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active store named "Volt Electronics"';
  END IF;
  IF EXISTS (SELECT 1 FROM products WHERE tenant_id = v_tenant) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Volt Electronics already has products; demo data not added';
  END IF;

  -- May be NULL if the store has no login yet; tickets then stay unassigned.
  SELECT id INTO v_admin FROM users WHERE tenant_id = v_tenant AND role = 'admin' ORDER BY id LIMIT 1;

  -- Number helper (1..500) for set-based inserts; a busy day needs ~400 events.
  DROP TEMPORARY TABLE IF EXISTS tmp_vlt_seq;
  CREATE TEMPORARY TABLE tmp_vlt_seq (n INT PRIMARY KEY);
  SET i = 1;
  WHILE i <= 500 DO
    INSERT INTO tmp_vlt_seq VALUES (i);
    SET i = i + 1;
  END WHILE;

  START TRANSACTION;

  -- ─── Products ───────────────────────────────────────────────────────────────
  -- Listed best seller first: order picks favour the first products.
  INSERT INTO products (tenant_id, sku_code, name, category, base_price, cost_price, status, description) VALUES
    (v_tenant, 'VLT-AU-001', 'PulseBuds Pro Wireless Earbuds',   'Audio',        129.00,  52.00, 'active',   'Active noise-cancelling earbuds with 8-hour battery, wireless charging case and IPX4 sweat resistance.'),
    (v_tenant, 'VLT-AC-001', 'FastCharge 65W GaN Charger',       'Accessories',   49.00,  17.00, 'active',   'Compact 3-port USB-C/USB-A charger that powers a laptop, phone and earbuds at once.'),
    (v_tenant, 'VLT-PH-001', 'Nova X5 Smartphone 128GB',         'Phones',       599.00, 410.00, 'active',   '6.4" OLED display, 50 MP triple camera and all-day battery. Unlocked, dual SIM.'),
    (v_tenant, 'VLT-AC-002', 'Braided USB-C Cable (2 m)',        'Accessories',   19.00,   4.20, 'active',   'Nylon-braided 100W USB-C to USB-C cable rated for 10,000+ bends.'),
    (v_tenant, 'VLT-WR-001', 'Stride Fit Smartwatch',            'Wearables',    199.00,  96.00, 'active',   'AMOLED fitness watch with GPS, heart-rate and sleep tracking. 10-day battery.'),
    (v_tenant, 'VLT-LP-001', 'AeroBook 14 Laptop',               'Laptops',      899.00, 640.00, 'active',   '14" 2.8K display, 8-core processor, 16 GB RAM and 512 GB SSD in a 1.2 kg aluminium body.'),
    (v_tenant, 'VLT-AU-002', 'Echo Max Over-Ear Headphones',     'Audio',        249.00, 118.00, 'active',   'Studio-tuned ANC headphones with 40-hour battery and multipoint Bluetooth.'),
    (v_tenant, 'VLT-AC-003', 'PowerCore 20,000 mAh Power Bank',  'Accessories',   59.00,  22.00, 'active',   'High-capacity power bank with 30W USB-C PD. Charges a phone about four times.'),
    (v_tenant, 'VLT-SH-001', 'HomeHub Smart Speaker',            'Smart Home',    89.00,  38.00, 'active',   'Room-filling smart speaker with voice assistant and smart-home controls.'),
    (v_tenant, 'VLT-PH-002', 'Nova X5 Lite 64GB',                'Phones',       349.00, 238.00, 'active',   'Everyday smartphone with a 6.5" display and two-day battery life.'),
    (v_tenant, 'VLT-AC-004', 'Clear Armor Phone Case',           'Accessories',   25.00,   5.50, 'active',   'Slim shock-absorbing clear case for the Nova X5 series.'),
    (v_tenant, 'VLT-SH-002', 'Brightloop Smart Bulb (4 Pack)',   'Smart Home',    45.00,  16.00, 'active',   'Wi-Fi colour bulbs with schedules and app or voice control. E27.'),
    (v_tenant, 'VLT-TB-001', 'Slate 11 Tablet 128GB',            'Tablets',      429.00, 295.00, 'active',   '11" 120 Hz tablet with quad speakers and stylus support.'),
    (v_tenant, 'VLT-AU-003', 'Boom Mini Bluetooth Speaker',      'Audio',         69.00,  26.00, 'active',   'Waterproof pocket speaker with 12-hour playtime and a carabiner clip.'),
    (v_tenant, 'VLT-GM-001', 'ProPad Wireless Controller',       'Gaming',        69.00,  28.00, 'active',   'Low-latency wireless controller for PC and mobile with hall-effect sticks.'),
    (v_tenant, 'VLT-AC-005', 'Tempered Glass Screen Protector',  'Accessories',   15.00,   2.40, 'active',   '9H tempered glass with an easy-align frame. Two in a pack.'),
    (v_tenant, 'VLT-SH-003', 'Guardian 2K Indoor Camera',        'Smart Home',    79.00,  31.00, 'active',   '2K security camera with night vision, two-way audio and motion alerts.'),
    (v_tenant, 'VLT-GM-002', 'RGB Mechanical Keyboard',          'Gaming',       119.00,  48.00, 'active',   'Hot-swappable 75% mechanical keyboard with per-key RGB lighting.'),
    (v_tenant, 'VLT-GM-003', 'Precision Wireless Gaming Mouse',  'Gaming',        79.00,  29.00, 'active',   '26K DPI sensor, 60 g ultralight shell and 70-hour battery.'),
    (v_tenant, 'VLT-LP-002', 'AeroBook 16 Pro Laptop',           'Laptops',     1499.00,1080.00, 'active',   '16" 3K 120 Hz display, 32 GB RAM, 1 TB SSD and a dedicated graphics card for creators.'),
    (v_tenant, 'VLT-AC-006', 'USB-C 7-in-1 Hub',                 'Accessories',   45.00,  15.00, 'active',   'HDMI 4K, SD/microSD, 3× USB-A and 100W pass-through charging.'),
    (v_tenant, 'VLT-WR-002', 'Stride Band Fitness Tracker',      'Wearables',     49.00,  18.00, 'active',   'Slim fitness band with heart-rate tracking and a 14-day battery.'),
    (v_tenant, 'VLT-SV-001', 'VoltCare 2-Year Protection Plan',  'Services',      79.00,  12.00, 'active',   'Extended warranty with accidental damage cover for phones, tablets and laptops.'),
    (v_tenant, 'VLT-SV-002', 'Device Setup & Data Transfer',     'Services',      39.00,   9.00, 'active',   'We set up your new device and move your photos, contacts and apps in store.'),
    (v_tenant, 'VLT-PH-003', 'Nova X6 Ultra 256GB',              'Phones',       999.00, 720.00, 'draft',    'Next-generation flagship with a periscope zoom camera. Pre-orders open soon.'),
    (v_tenant, 'VLT-AU-004', 'PulseBuds (1st Gen)',              'Audio',         79.00,  34.00, 'archived', 'First-generation wireless earbuds. Replaced by PulseBuds Pro.');

  -- Stagger "added" dates so the newest launches (phones, audio) lead the shop.
  UPDATE products
     SET created_at = UTC_TIMESTAMP() - INTERVAL (CASE category
           WHEN 'Phones' THEN 1 WHEN 'Audio' THEN 3 WHEN 'Wearables' THEN 5 WHEN 'Laptops' THEN 7
           WHEN 'Tablets' THEN 10 WHEN 'Smart Home' THEN 13 WHEN 'Gaming' THEN 16
           WHEN 'Accessories' THEN 20 WHEN 'Services' THEN 30 ELSE 90 END) DAY - INTERVAL id MINUTE
   WHERE tenant_id = v_tenant;

  -- Stock: a few low-stock items and one sell-out so the alerts have something to show.
  INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
  SELECT id, tenant_id,
         CASE sku_code
           WHEN 'VLT-PH-001' THEN 3
           WHEN 'VLT-AU-002' THEN 4
           WHEN 'VLT-LP-001' THEN 2
           WHEN 'VLT-TB-001' THEN 0
           WHEN 'VLT-PH-003' THEN 0
           WHEN 'VLT-AU-004' THEN 0
           WHEN 'VLT-SV-001' THEN 999
           WHEN 'VLT-SV-002' THEN 999
           ELSE CASE WHEN category IN ('Phones', 'Laptops', 'Tablets') THEN 8 + FLOOR(RAND() * 20)
                     ELSE 25 + FLOOR(RAND() * 90) END
         END,
         CASE WHEN category = 'Services' THEN 50 WHEN category = 'Accessories' THEN 20 ELSE 6 END,
         UTC_TIMESTAMP() - INTERVAL FLOOR(5 + RAND() * 40) DAY
    FROM products
   WHERE tenant_id = v_tenant;

  DROP TEMPORARY TABLE IF EXISTS tmp_vlt_products;
  CREATE TEMPORARY TABLE tmp_vlt_products (n INT PRIMARY KEY, product_id BIGINT UNSIGNED, price DECIMAL(12,4));
  INSERT INTO tmp_vlt_products (n, product_id, price)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, base_price
    FROM products
   WHERE tenant_id = v_tenant AND status = 'active';
  SELECT COUNT(*) INTO v_product_count FROM tmp_vlt_products;

  -- ─── Customers ──────────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 120 DO
    SET v_age = FLOOR(POW(RAND(), 1.5) * 180);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at, created_at)
    SELECT v_tenant,
           CONCAT(f.name, ' ', l.name),
           CONCAT(LOWER(f.name), '.', LOWER(l.name), i, '@example.com'),
           CONCAT('+1-555-04', LPAD(i, 3, '0')),
           ELT(1 + FLOOR(RAND() * 7), 'instagram', 'tiktok', 'organic', 'referral', 'walk_in', 'paid_social', 'google'),
           IF(RAND() < 0.95, 'active', 'inactive'),
           v_created,
           v_created
      FROM (SELECT ELT(1 + FLOOR(RAND() * 24),
                   'Emma', 'Olivia', 'Ava', 'Sophia', 'Isla', 'Hana', 'Mei', 'Priya', 'Nadia', 'Zara', 'Lily', 'Grace',
                   'Liam', 'Noah', 'Leo', 'Kai', 'Ethan', 'Ryan', 'Arjun', 'Hafiz', 'Jun', 'Mateo', 'Owen', 'Theo') AS name) f,
           (SELECT ELT(1 + FLOOR(RAND() * 16),
                   'Tan', 'Lim', 'Wong', 'Lee', 'Rahman', 'Singh', 'Smith', 'Taylor', 'Garcia', 'Chen',
                   'Ng', 'Kim', 'Patel', 'Martin', 'Nguyen', 'Ismail') AS name) l;
    SET i = i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tmp_vlt_customers;
  CREATE TEMPORARY TABLE tmp_vlt_customers (n INT PRIMARY KEY, customer_id BIGINT UNSIGNED, created_at DATETIME);
  INSERT INTO tmp_vlt_customers (n, customer_id, created_at)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, created_at FROM customers WHERE tenant_id = v_tenant;
  SELECT COUNT(*) INTO v_customer_count FROM tmp_vlt_customers;

  -- ─── Orders + order lines ──────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 320 DO
    SET v_age = FLOOR(POW(RAND(), 1.4) * 120);
    SET v_placed = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 1380) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN v_age <= 2 THEN IF(v_roll < 0.5, 'pending', 'confirmed')
      WHEN v_age <= 6 THEN IF(v_roll < 0.3, 'confirmed', 'shipped')
      WHEN v_roll < 0.88 THEN 'delivered'
      WHEN v_roll < 0.95 THEN 'cancelled'
      ELSE 'refunded'
    END;

    -- A customer who had already signed up when the order was placed.
    SET v_customer = NULL;
    SELECT customer_id INTO v_customer FROM tmp_vlt_customers
     WHERE created_at <= v_placed ORDER BY RAND() LIMIT 1;
    IF v_customer IS NULL THEN
      SELECT customer_id, created_at INTO v_customer, v_created FROM tmp_vlt_customers ORDER BY created_at LIMIT 1;
      SET v_placed = GREATEST(v_placed, v_created);
    END IF;

    INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address,
                        placed_at, fulfilled_at, created_at)
    VALUES (v_tenant, v_customer, CONCAT('VLT', v_tenant, '-', LPAD(i, 5, '0')), v_status, 0, 'USD',
            ELT(1 + FLOOR(RAND() * 8),
                '21 Mercer St, New York, NY 10013',
                '450 Valencia St, Apt 3, San Francisco, CA 94103',
                '1208 Pearl St, Boulder, CO 80302',
                '73 Abbot Kinney Blvd, Venice, CA 90291',
                '19 Wicker Park Ave, Chicago, IL 60622',
                '880 SE Hawthorne Blvd, Portland, OR 97214',
                '31 South Congress Ave, Austin, TX 78704',
                '612 Pike St, Seattle, WA 98101'),
            v_placed,
            IF(v_status = 'delivered', v_placed + INTERVAL (2 + FLOOR(RAND() * 4)) DAY, NULL),
            v_placed);
    SET v_order = LAST_INSERT_ID();

    -- A device often comes with an accessory or two: 1–3 lines.
    SET v_items = 1 + FLOOR(POW(RAND(), 1.8) * 3);
    SET j = 1;
    WHILE j <= v_items DO
      -- Draw once: RAND() inside WHERE would be re-evaluated for every row.
      SET v_qty = 1 + FLOOR(POW(RAND(), 1.3) * v_product_count);
      SELECT product_id, price INTO v_product, v_price FROM tmp_vlt_products WHERE n = v_qty;
      SET v_qty = IF(RAND() < 0.2, 2, 1);
      INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal, created_at)
      VALUES (v_tenant, v_order, v_product, v_qty, v_price, v_qty * v_price, v_placed);
      SET j = j + 1;
    END WHILE;

    UPDATE orders
       SET total_amount = (SELECT SUM(subtotal) FROM order_items WHERE tenant_id = v_tenant AND order_id = v_order)
     WHERE id = v_order;
    SET i = i + 1;
  END WHILE;

  -- Customer totals follow from their orders (cancelled/refunded don't count towards value).
  UPDATE customers c
    JOIN (SELECT customer_id,
                 COUNT(*) AS order_count,
                 SUM(IF(status IN ('cancelled', 'refunded'), 0, total_amount)) AS value,
                 MAX(placed_at) AS last_order
            FROM orders
           WHERE tenant_id = v_tenant
           GROUP BY customer_id) o
      ON o.customer_id = c.id
     SET c.total_orders = o.order_count,
         c.ltv = o.value,
         c.last_active_at = o.last_order
   WHERE c.tenant_id = v_tenant;

  -- Some customers browsed the shop recently without buying.
  UPDATE customers
     SET last_active_at = GREATEST(last_active_at,
                                   UTC_TIMESTAMP() - INTERVAL FLOOR(RAND() * 30) DAY - INTERVAL FLOOR(RAND() * 600) MINUTE)
   WHERE tenant_id = v_tenant AND status = 'active' AND RAND() < 0.4;

  -- ─── Campaigns ──────────────────────────────────────────────────────────────
  INSERT INTO campaigns (tenant_id, name, type, status, audience_segment, sent_count, open_count, click_count,
                         scheduled_at, created_at) VALUES
    (v_tenant, 'Back to School Tech Deals',       'email',  'completed', JSON_OBJECT('segment', 'all_customers'),        2100, 882, 251,
       UTC_TIMESTAMP() - INTERVAL 50 DAY, UTC_TIMESTAMP() - INTERVAL 54 DAY),
    (v_tenant, 'Nova X5 Launch Week',             'social', 'completed', JSON_OBJECT('segment', 'instagram_followers'), 7800, 3420, 815,
       UTC_TIMESTAMP() - INTERVAL 27 DAY, UTC_TIMESTAMP() - INTERVAL 30 DAY),
    (v_tenant, 'Slate 11 Tablet Restock Alert',   'push',   'completed', JSON_OBJECT('segment', 'tablet_waitlist'),       540, 262, 97,
       UTC_TIMESTAMP() - INTERVAL 18 DAY, UTC_TIMESTAMP() - INTERVAL 19 DAY),
    (v_tenant, 'Trade-In Your Old Phone',         'email',  'running',   JSON_OBJECT('segment', 'phone_buyers', 'olderThanMonths', 24), 1150, 503, 141,
       UTC_TIMESTAMP() - INTERVAL 9 DAY, UTC_TIMESTAMP() - INTERVAL 11 DAY),
    (v_tenant, 'Gaming Gear Week on TikTok',      'social', 'running',   JSON_OBJECT('segment', 'tiktok_followers'),     8600, 3510, 668,
       UTC_TIMESTAMP() - INTERVAL 4 DAY, UTC_TIMESTAMP() - INTERVAL 6 DAY),
    (v_tenant, 'In-Store Setup Day Reminder',     'sms',    'completed', JSON_OBJECT('segment', 'local_customers'),       380, 351, 62,
       UTC_TIMESTAMP() - INTERVAL 2 DAY, UTC_TIMESTAMP() - INTERVAL 3 DAY),
    (v_tenant, 'Black Friday Early Access',       'email',  'scheduled', JSON_OBJECT('segment', 'all_customers'),           0,   0,  0,
       UTC_TIMESTAMP() + INTERVAL 14 DAY, UTC_TIMESTAMP() - INTERVAL 1 DAY),
    (v_tenant, 'Holiday Gadget Gift Guide',       'social', 'draft',     NULL,                                              0,   0,  0,
       NULL, UTC_TIMESTAMP() - INTERVAL 5 HOUR);

  -- ─── Support tickets ────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 36 DO
    SET v_age = FLOOR(RAND() * 30);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN i <= 3 THEN 'open'                         -- urgent ones for the notification bell
      WHEN v_age <= 2 THEN ELT(1 + FLOOR(v_roll * 3), 'open', 'in_progress', 'pending_customer')
      WHEN v_roll < 0.7 THEN 'resolved'
      WHEN v_roll < 0.85 THEN 'closed'
      ELSE 'pending_customer'
    END;
    SET v_topic = 1 + FLOOR(RAND() * 9);
    SELECT customer_id INTO v_customer FROM tmp_vlt_customers ORDER BY RAND() LIMIT 1;

    INSERT INTO support_tickets (tenant_id, customer_id, assigned_to, subject, body, priority, status, channel,
                                 created_at, resolved_at)
    VALUES (
      v_tenant, v_customer,
      IF(v_status = 'open', NULL, v_admin),
      ELT(v_topic,
          'Where is my order?',
          'Earbuds only charging one side',
          'Laptop will not turn on',
          'Smartwatch not syncing with my phone',
          'Is the charger compatible with my laptop?',
          'Discount code not applying',
          'When is the Slate 11 Tablet back in stock?',
          'Received the wrong item',
          'Refund not showing yet'),
      ELT(v_topic,
          'My order was marked shipped four days ago but the tracking link still says label created. Can you check?',
          'The left PulseBuds Pro earbud stopped charging in the case after a week. The right one is fine.',
          'My new AeroBook 14 shows a black screen and will not power on even after charging overnight.',
          'The Stride Fit Smartwatch keeps disconnecting from the app and my step count is not syncing.',
          'Will the FastCharge 65W GaN Charger charge a laptop that needs 90W, or just more slowly?',
          'The TECH10 code from your email says it is not valid for items in my cart.',
          'The Slate 11 Tablet has been sold out for a while. Any restock date?',
          'I ordered the Nova X5 128GB but received the Nova X5 Lite instead.',
          'I returned my Echo Max Headphones two weeks ago and the refund has not appeared on my card yet.'),
      CASE WHEN i <= 3 THEN IF(i = 1, 'urgent', 'high')
           ELSE ELT(1 + FLOOR(POW(RAND(), 1.5) * 4), 'low', 'medium', 'high', 'urgent') END,
      v_status,
      ELT(1 + FLOOR(RAND() * 3), 'email', 'chat', 'phone'),
      v_created,
      IF(v_status IN ('resolved', 'closed'),
         LEAST(UTC_TIMESTAMP(), v_created + INTERVAL (2 + FLOOR(RAND() * 46)) HOUR),
         NULL)
    );
    SET i = i + 1;
  END WHILE;

  -- ─── Storefront traffic (last 30 days) ──────────────────────────────────────
  SET v_day = 0;
  WHILE v_day < 30 DO
    SET v_views = 120 + FLOOR(RAND() * 100)
                + IF(DAYOFWEEK(UTC_DATE() - INTERVAL v_day DAY) IN (1, 7), 60, 0)  -- busier weekends
                + FLOOR((30 - v_day) * 1.5);                                       -- gentle growth
    SET v_carts = FLOOR(v_views * (0.09 + RAND() * 0.06));
    SET v_checkouts = FLOOR(v_carts * (0.35 + RAND() * 0.2));

    INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id, recorded_at)
    SELECT v_tenant,
           CASE WHEN s.n <= v_checkouts THEN 'checkout_started'
                WHEN s.n <= v_checkouts + v_carts THEN 'add_to_cart'
                ELSE 'page_view' END,
           'product',
           p.product_id,
           LEAST(UTC_TIMESTAMP(3),
                 CAST(UTC_DATE() - INTERVAL v_day DAY AS DATETIME(3)) + INTERVAL FLOOR(RAND() * 86400) SECOND)
      FROM tmp_vlt_seq s
      JOIN tmp_vlt_products p ON p.n = 1 + (s.n * 7 + v_day) % v_product_count
     WHERE s.n <= v_views + v_carts + v_checkouts;
    SET v_day = v_day + 1;
  END WHILE;

  -- ─── Expenses (current month + 3 previous) ─────────────────────────────────
  SET v_month = 0;
  WHILE v_month < 4 DO
    SET v_month_start = DATE_FORMAT(UTC_DATE() - INTERVAL v_month MONTH, '%Y-%m-01');
    INSERT INTO expenses (tenant_id, category, description, amount, incurred_on, created_by) VALUES
      (v_tenant, 'rent',      'Showroom + warehouse rent',      5200.00,                              v_month_start, v_admin),
      (v_tenant, 'wages',     'Sales + repair staff (4)',       9800.00 + FLOOR(RAND() * 900),        v_month_start, v_admin),
      (v_tenant, 'software',  'Shop, POS and inventory tools',   320.00,                              v_month_start, v_admin),
      (v_tenant, 'utilities', 'Electricity and internet',        540.00 + FLOOR(RAND() * 120),        LEAST(UTC_DATE(), v_month_start + INTERVAL 9 DAY), v_admin),
      (v_tenant, 'marketing', 'Search + social ads',            1400.00 + FLOOR(RAND() * 800),        LEAST(UTC_DATE(), v_month_start + INTERVAL 3 DAY), v_admin),
      (v_tenant, 'shipping',  'Insured courier invoices',        760.00 + FLOOR(RAND() * 300),        LEAST(UTC_DATE(), v_month_start + INTERVAL 14 DAY), v_admin),
      (v_tenant, 'supplies',  'Packaging and anti-static bags',  210.00 + FLOOR(RAND() * 90),         LEAST(UTC_DATE(), v_month_start + INTERVAL 6 DAY), v_admin);
    SET v_month = v_month + 1;
  END WHILE;
  INSERT INTO expenses (tenant_id, category, description, amount, incurred_on, created_by) VALUES
    (v_tenant, 'marketing', 'Nova X5 launch event',            2400.00, UTC_DATE() - INTERVAL 29 DAY, v_admin),
    (v_tenant, 'other',     'Demo-unit display stands',         680.00, UTC_DATE() - INTERVAL 12 DAY, v_admin);

  COMMIT;

  DROP TEMPORARY TABLE IF EXISTS tmp_vlt_products, tmp_vlt_customers, tmp_vlt_seq;

  SELECT v_tenant AS tenant_id,
         (SELECT COUNT(*) FROM products        WHERE tenant_id = v_tenant) AS products,
         (SELECT COUNT(*) FROM customers       WHERE tenant_id = v_tenant) AS customers,
         (SELECT COUNT(*) FROM orders          WHERE tenant_id = v_tenant) AS orders,
         (SELECT COUNT(*) FROM order_items     WHERE tenant_id = v_tenant) AS order_lines,
         (SELECT COUNT(*) FROM campaigns       WHERE tenant_id = v_tenant) AS campaigns,
         (SELECT COUNT(*) FROM support_tickets WHERE tenant_id = v_tenant) AS tickets,
         (SELECT COUNT(*) FROM analytics_logs  WHERE tenant_id = v_tenant) AS traffic_events,
         (SELECT COUNT(*) FROM expenses        WHERE tenant_id = v_tenant) AS expenses;
END$$
DELIMITER ;

CALL seed_volt_electronics_demo();
DROP PROCEDURE IF EXISTS seed_volt_electronics_demo;
