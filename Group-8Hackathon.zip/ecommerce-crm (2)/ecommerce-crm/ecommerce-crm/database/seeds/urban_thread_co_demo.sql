-- =============================================================================
--  DEMO DATA — "Urban Thread Co."
--
--  Fills the active store named "Urban Thread Co." with realistic demo data
--  for a streetwear / everyday clothing shop: a clothing catalogue with cost
--  prices and stock, customers, ~320 orders over the last 4 months,
--  campaigns, support tickets, 30 days of storefront traffic and 4 months of
--  operating expenses. Dates are relative to "now", so the 30-day analytics
--  charts and the store's profit view are populated.
--
--  Run (needs CREATE ROUTINE, e.g. as root):
--      mysql -u root -p < database/seeds/urban_thread_co_demo.sql
--
--  Safe: all-or-nothing (one transaction), and refuses to run if the store
--  already has products. Customer emails use the reserved example.com domain.
--  Product names are fictional (no real brands). Demo/dev only — never run
--  against production.
-- =============================================================================

-- The file is UTF-8 (dashes, quotes…): read it as such whatever the client default is.
SET NAMES utf8mb4;
USE crm_platform;

DROP PROCEDURE IF EXISTS seed_urban_thread_demo;

DELIMITER $$
CREATE PROCEDURE seed_urban_thread_demo()
BEGIN
  DECLARE v_tenant BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_admin BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_product_count INT;
  DECLARE v_customer_count INT;
  DECLARE i INT;
  DECLARE j INT;
  DECLARE v_items INT;
  DECLARE v_age INT;
  DECLARE v_roll DOUBLE;
  DECLARE v_status VARCHAR(20);
  DECLARE v_placed DATETIME;
  DECLARE v_created DATETIME;
  DECLARE v_customer BIGINT UNSIGNED;
  DECLARE v_order BIGINT UNSIGNED;
  DECLARE v_product BIGINT UNSIGNED;
  DECLARE v_price DECIMAL(12,4);
  DECLARE v_qty INT;
  DECLARE v_day INT;
  DECLARE v_views INT;
  DECLARE v_carts INT;
  DECLARE v_checkouts INT;
  DECLARE v_topic INT;
  DECLARE v_month INT;
  DECLARE v_month_start DATE;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    DROP TEMPORARY TABLE IF EXISTS tmp_utc_products, tmp_utc_customers, tmp_utc_seq;
    RESIGNAL;
  END;

  SELECT id INTO v_tenant
    FROM admins
   WHERE LOWER(business_name) IN ('urban thread co.', 'urban thread co') AND status = 'active' AND is_platform = 0
   ORDER BY id DESC
   LIMIT 1;
  IF v_tenant IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active store named "Urban Thread Co."';
  END IF;
  IF EXISTS (SELECT 1 FROM products WHERE tenant_id = v_tenant) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Urban Thread Co. already has products; demo data not added';
  END IF;

  -- May be NULL if the store has no login yet; tickets then stay unassigned.
  SELECT id INTO v_admin FROM users WHERE tenant_id = v_tenant AND role = 'admin' ORDER BY id LIMIT 1;

  -- Number helper (1..500) for set-based inserts; a busy day needs ~400 events.
  DROP TEMPORARY TABLE IF EXISTS tmp_utc_seq;
  CREATE TEMPORARY TABLE tmp_utc_seq (n INT PRIMARY KEY);
  SET i = 1;
  WHILE i <= 500 DO
    INSERT INTO tmp_utc_seq VALUES (i);
    SET i = i + 1;
  END WHILE;

  START TRANSACTION;

  -- ─── Products ───────────────────────────────────────────────────────────────
  -- Listed best seller first: order picks favour the first products.
  INSERT INTO products (tenant_id, sku_code, name, category, base_price, cost_price, status, description) VALUES
    (v_tenant, 'UTC-TS-001', 'Essential Heavyweight Tee',        'T-Shirts',     29.00,  9.50, 'active',   '240 gsm combed cotton tee with a boxy fit and a ribbed crew neck. Black, white, sand and olive. XS–XXL.'),
    (v_tenant, 'UTC-HD-001', 'Everyday Fleece Hoodie',           'Hoodies',      69.00, 24.00, 'active',   'Brushed-back fleece hoodie with a double-layer hood and kangaroo pocket. Relaxed fit. XS–XXL.'),
    (v_tenant, 'UTC-JN-001', 'Straight Leg Selvedge Jeans',      'Denim',        89.00, 34.00, 'active',   '13.5 oz rigid selvedge denim in an indigo rinse. Straight leg, mid rise. Waist 28–38.'),
    (v_tenant, 'UTC-PT-001', 'Relaxed Cargo Pants',              'Pants',        74.00, 26.00, 'active',   'Cotton ripstop cargos with six pockets and an adjustable hem. Black, khaki and stone.'),
    (v_tenant, 'UTC-TS-002', 'Oversized Graphic Tee "City Lines"','T-Shirts',    35.00, 11.00, 'active',   'Oversized cotton tee with a screen-printed city-map back graphic. Washed black.'),
    (v_tenant, 'UTC-OW-001', 'Coach Jacket',                     'Outerwear',   109.00, 41.00, 'active',   'Water-resistant nylon coach jacket with a snap front and mesh lining.'),
    (v_tenant, 'UTC-HD-002', 'Quarter-Zip Sweatshirt',           'Hoodies',      64.00, 22.00, 'active',   'Midweight loopback sweatshirt with a quarter-zip collar. Heather grey and navy.'),
    (v_tenant, 'UTC-SH-001', 'Linen Blend Camp Shirt',           'Shirts',       55.00, 19.00, 'active',   'Breezy linen-cotton short-sleeve shirt with a camp collar. Sage, ecru and rust.'),
    (v_tenant, 'UTC-PT-002', 'Pleated Wide-Leg Trousers',        'Pants',        79.00, 28.00, 'active',   'Drapey twill trousers with front pleats and a wide leg. Charcoal and tan.'),
    (v_tenant, 'UTC-JN-002', 'Denim Trucker Jacket',             'Denim',       119.00, 45.00, 'active',   'Classic trucker jacket in a mid-wash denim with chest flap pockets.'),
    (v_tenant, 'UTC-TS-003', 'Long Sleeve Pocket Tee',           'T-Shirts',     34.00, 11.50, 'active',   'Soft slub-cotton long sleeve with a chest pocket. Layering essential.'),
    (v_tenant, 'UTC-OW-002', 'Puffer Vest',                      'Outerwear',    95.00, 36.00, 'active',   'Lightweight recycled-fill puffer vest that packs into its own pocket.'),
    (v_tenant, 'UTC-SH-002', 'Oxford Button-Down Shirt',         'Shirts',       59.00, 20.00, 'active',   'Garment-washed oxford cotton shirt with a button-down collar. White and light blue.'),
    (v_tenant, 'UTC-WM-001', 'Ribbed Knit Midi Dress',           'Dresses',      72.00, 25.00, 'active',   'Stretch rib-knit midi dress with a scoop neck. Black, oat and mocha.'),
    (v_tenant, 'UTC-WM-002', 'Cropped Boxy Cardigan',            'Knitwear',     68.00, 24.00, 'active',   'Chunky cotton-blend cardigan with horn-look buttons and a cropped boxy cut.'),
    (v_tenant, 'UTC-PT-003', 'Nylon Track Pants',                'Pants',        58.00, 19.00, 'active',   'Lined nylon track pants with side stripes and zip ankles.'),
    (v_tenant, 'UTC-AC-001', 'Six-Panel Washed Cap',             'Accessories',  25.00,  6.50, 'active',   'Garment-washed cotton cap with an embroidered UT logo and brass buckle.'),
    (v_tenant, 'UTC-AC-002', 'Ribbed Beanie',                    'Accessories',  22.00,  5.80, 'active',   'Merino-blend fisherman beanie. One size.'),
    (v_tenant, 'UTC-AC-003', 'Heavy Canvas Tote Bag',            'Accessories',  28.00,  8.00, 'active',   '16 oz canvas tote with an inside zip pocket.'),
    (v_tenant, 'UTC-AC-004', 'Everyday Crew Socks (3 Pack)',     'Accessories',  18.00,  4.50, 'active',   'Combed-cotton crew socks with a cushioned sole. Sizes S–L.'),
    (v_tenant, 'UTC-SH-003', 'Corduroy Overshirt',               'Shirts',       78.00, 29.00, 'active',   'Mid-wale corduroy overshirt with two patch pockets. Wear it as a light jacket.'),
    (v_tenant, 'UTC-OW-003', 'Wool Blend Overcoat',              'Outerwear',   189.00, 78.00, 'active',   'Single-breasted wool-blend overcoat with a notch lapel. Camel and charcoal.'),
    (v_tenant, 'UTC-KD-001', 'Mini Essential Tee (Kids)',        'Kids',         19.00,  6.00, 'active',   'Kids version of our best-selling tee. Ages 2–10.'),
    (v_tenant, 'UTC-KD-002', 'Mini Fleece Hoodie (Kids)',        'Kids',         39.00, 14.00, 'active',   'Soft fleece hoodie for little ones. Ages 2–10.'),
    (v_tenant, 'UTC-OW-004', 'Sherpa Lined Chore Jacket',        'Outerwear',   139.00, 55.00, 'draft',    'Winter chore jacket with a sherpa lining. Arriving next month.'),
    (v_tenant, 'UTC-SW-001', 'Swim Shorts "Summer 26"',          'Swimwear',     42.00, 14.00, 'archived', 'Quick-dry swim shorts from the summer drop. Discontinued.');

  -- Stagger "added" dates so the newest drop (outerwear, knitwear) leads the shop.
  UPDATE products
     SET created_at = UTC_TIMESTAMP() - INTERVAL (CASE category
           WHEN 'Outerwear' THEN 1 WHEN 'Knitwear' THEN 2 WHEN 'Hoodies' THEN 4 WHEN 'Denim' THEN 6
           WHEN 'Shirts' THEN 9 WHEN 'Pants' THEN 11 WHEN 'Dresses' THEN 13 WHEN 'T-Shirts' THEN 16
           WHEN 'Kids' THEN 20 WHEN 'Accessories' THEN 24 ELSE 90 END) DAY - INTERVAL id MINUTE
   WHERE tenant_id = v_tenant;

  -- Stock: a few low-stock items and one sell-out so the alerts have something to show.
  INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
  SELECT id, tenant_id,
         CASE sku_code
           WHEN 'UTC-HD-001' THEN 4
           WHEN 'UTC-JN-001' THEN 6
           WHEN 'UTC-OW-001' THEN 2
           WHEN 'UTC-WM-002' THEN 0
           WHEN 'UTC-SW-001' THEN 0
           WHEN 'UTC-OW-004' THEN 0
           ELSE 20 + FLOOR(RAND() * 80)
         END,
         CASE WHEN category IN ('T-Shirts', 'Accessories') THEN 15 ELSE 8 END,
         UTC_TIMESTAMP() - INTERVAL FLOOR(5 + RAND() * 40) DAY
    FROM products
   WHERE tenant_id = v_tenant;

  DROP TEMPORARY TABLE IF EXISTS tmp_utc_products;
  CREATE TEMPORARY TABLE tmp_utc_products (n INT PRIMARY KEY, product_id BIGINT UNSIGNED, price DECIMAL(12,4));
  INSERT INTO tmp_utc_products (n, product_id, price)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, base_price
    FROM products
   WHERE tenant_id = v_tenant AND status = 'active';
  SELECT COUNT(*) INTO v_product_count FROM tmp_utc_products;

  -- ─── Customers ──────────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 120 DO
    SET v_age = FLOOR(POW(RAND(), 1.5) * 180);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at, created_at)
    SELECT v_tenant,
           CONCAT(f.name, ' ', l.name),
           CONCAT(LOWER(f.name), '.', LOWER(l.name), i, '@example.com'),
           CONCAT('+1-555-03', LPAD(i, 3, '0')),
           ELT(1 + FLOOR(RAND() * 7), 'instagram', 'tiktok', 'organic', 'referral', 'walk_in', 'paid_social', 'google'),
           IF(RAND() < 0.95, 'active', 'inactive'),
           v_created,
           v_created
      FROM (SELECT ELT(1 + FLOOR(RAND() * 24),
                   'Emma', 'Olivia', 'Ava', 'Sophia', 'Isla', 'Hana', 'Mei', 'Priya', 'Nadia', 'Zara', 'Lily', 'Grace',
                   'Liam', 'Noah', 'Leo', 'Kai', 'Ethan', 'Ryan', 'Arjun', 'Hafiz', 'Jun', 'Mateo', 'Owen', 'Theo') AS name) f,
           (SELECT ELT(1 + FLOOR(RAND() * 16),
                   'Tan', 'Lim', 'Wong', 'Lee', 'Rahman', 'Singh', 'Smith', 'Taylor', 'Garcia', 'Chen',
                   'Ng', 'Kim', 'Patel', 'Martin', 'Nguyen', 'Ismail') AS name) l;
    SET i = i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tmp_utc_customers;
  CREATE TEMPORARY TABLE tmp_utc_customers (n INT PRIMARY KEY, customer_id BIGINT UNSIGNED, created_at DATETIME);
  INSERT INTO tmp_utc_customers (n, customer_id, created_at)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, created_at FROM customers WHERE tenant_id = v_tenant;
  SELECT COUNT(*) INTO v_customer_count FROM tmp_utc_customers;

  -- ─── Orders + order lines ──────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 320 DO
    SET v_age = FLOOR(POW(RAND(), 1.4) * 120);
    SET v_placed = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 1380) MINUTE;
    SET v_roll = RAND();
    -- Clothing sees more returns (size/fit) than most categories.
    SET v_status = CASE
      WHEN v_age <= 2 THEN IF(v_roll < 0.5, 'pending', 'confirmed')
      WHEN v_age <= 6 THEN IF(v_roll < 0.3, 'confirmed', 'shipped')
      WHEN v_roll < 0.84 THEN 'delivered'
      WHEN v_roll < 0.91 THEN 'cancelled'
      ELSE 'refunded'
    END;

    -- A customer who had already signed up when the order was placed.
    SET v_customer = NULL;
    SELECT customer_id INTO v_customer FROM tmp_utc_customers
     WHERE created_at <= v_placed ORDER BY RAND() LIMIT 1;
    IF v_customer IS NULL THEN
      SELECT customer_id, created_at INTO v_customer, v_created FROM tmp_utc_customers ORDER BY created_at LIMIT 1;
      SET v_placed = GREATEST(v_placed, v_created);
    END IF;

    INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address,
                        placed_at, fulfilled_at, created_at)
    VALUES (v_tenant, v_customer, CONCAT('UTC', v_tenant, '-', LPAD(i, 5, '0')), v_status, 0, 'USD',
            ELT(1 + FLOOR(RAND() * 8),
                '21 Mercer St, New York, NY 10013',
                '450 Valencia St, Apt 3, San Francisco, CA 94103',
                '1208 Pearl St, Boulder, CO 80302',
                '73 Abbot Kinney Blvd, Venice, CA 90291',
                '19 Wicker Park Ave, Chicago, IL 60622',
                '880 SE Hawthorne Blvd, Portland, OR 97214',
                '31 South Congress Ave, Austin, TX 78704',
                '612 Pike St, Seattle, WA 98101'),
            v_placed,
            IF(v_status = 'delivered', v_placed + INTERVAL (2 + FLOOR(RAND() * 4)) DAY, NULL),
            v_placed);
    SET v_order = LAST_INSERT_ID();

    -- Fashion baskets are bigger: 1–4 lines.
    SET v_items = 1 + FLOOR(POW(RAND(), 1.8) * 4);
    SET j = 1;
    WHILE j <= v_items DO
      -- Draw once: RAND() inside WHERE would be re-evaluated for every row.
      SET v_qty = 1 + FLOOR(POW(RAND(), 1.3) * v_product_count);
      SELECT product_id, price INTO v_product, v_price FROM tmp_utc_products WHERE n = v_qty;
      SET v_qty = IF(RAND() < 0.2, 2, 1);
      INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal, created_at)
      VALUES (v_tenant, v_order, v_product, v_qty, v_price, v_qty * v_price, v_placed);
      SET j = j + 1;
    END WHILE;

    UPDATE orders
       SET total_amount = (SELECT SUM(subtotal) FROM order_items WHERE tenant_id = v_tenant AND order_id = v_order)
     WHERE id = v_order;
    SET i = i + 1;
  END WHILE;

  -- Customer totals follow from their orders (cancelled/refunded don't count towards value).
  UPDATE customers c
    JOIN (SELECT customer_id,
                 COUNT(*) AS order_count,
                 SUM(IF(status IN ('cancelled', 'refunded'), 0, total_amount)) AS value,
                 MAX(placed_at) AS last_order
            FROM orders
           WHERE tenant_id = v_tenant
           GROUP BY customer_id) o
      ON o.customer_id = c.id
     SET c.total_orders = o.order_count,
         c.ltv = o.value,
         c.last_active_at = o.last_order
   WHERE c.tenant_id = v_tenant;

  -- Some customers browsed the shop recently without buying.
  UPDATE customers
     SET last_active_at = GREATEST(last_active_at,
                                   UTC_TIMESTAMP() - INTERVAL FLOOR(RAND() * 30) DAY - INTERVAL FLOOR(RAND() * 600) MINUTE)
   WHERE tenant_id = v_tenant AND status = 'active' AND RAND() < 0.4;

  -- ─── Campaigns ──────────────────────────────────────────────────────────────
  INSERT INTO campaigns (tenant_id, name, type, status, audience_segment, sent_count, open_count, click_count,
                         scheduled_at, created_at) VALUES
    (v_tenant, 'End of Summer Sale: 30% Off',     'email',  'completed', JSON_OBJECT('segment', 'all_customers'),        1820, 801, 236,
       UTC_TIMESTAMP() - INTERVAL 52 DAY, UTC_TIMESTAMP() - INTERVAL 55 DAY),
    (v_tenant, 'Fall Layers Lookbook',            'social', 'completed', JSON_OBJECT('segment', 'instagram_followers'), 6400, 2950, 640,
       UTC_TIMESTAMP() - INTERVAL 28 DAY, UTC_TIMESTAMP() - INTERVAL 31 DAY),
    (v_tenant, 'Heavyweight Tee Restock',         'push',   'completed', JSON_OBJECT('segment', 'tee_waitlist'),          720, 344, 118,
       UTC_TIMESTAMP() - INTERVAL 19 DAY, UTC_TIMESTAMP() - INTERVAL 20 DAY),
    (v_tenant, 'Thread Club: Members Early Access','email', 'running',   JSON_OBJECT('segment', 'vip', 'minOrders', 3),     310, 189, 67,
       UTC_TIMESTAMP() - INTERVAL 8 DAY, UTC_TIMESTAMP() - INTERVAL 10 DAY),
    (v_tenant, 'Outerwear Drop on TikTok',        'social', 'running',   JSON_OBJECT('segment', 'tiktok_followers'),     9100, 3870, 702,
       UTC_TIMESTAMP() - INTERVAL 4 DAY, UTC_TIMESTAMP() - INTERVAL 6 DAY),
    (v_tenant, 'Weekend Pop-Up Reminder',         'sms',    'completed', JSON_OBJECT('segment', 'local_customers'),       430, 396, 71,
       UTC_TIMESTAMP() - INTERVAL 2 DAY, UTC_TIMESTAMP() - INTERVAL 3 DAY),
    (v_tenant, 'Black Friday Preview',            'email',  'scheduled', JSON_OBJECT('segment', 'all_customers'),           0,   0,  0,
       UTC_TIMESTAMP() + INTERVAL 14 DAY, UTC_TIMESTAMP() - INTERVAL 1 DAY),
    (v_tenant, 'Holiday Gift Edit',               'social', 'draft',     NULL,                                              0,   0,  0,
       NULL, UTC_TIMESTAMP() - INTERVAL 5 HOUR);

  -- ─── Support tickets ────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 36 DO
    SET v_age = FLOOR(RAND() * 30);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN i <= 3 THEN 'open'                         -- urgent ones for the notification bell
      WHEN v_age <= 2 THEN ELT(1 + FLOOR(v_roll * 3), 'open', 'in_progress', 'pending_customer')
      WHEN v_roll < 0.7 THEN 'resolved'
      WHEN v_roll < 0.85 THEN 'closed'
      ELSE 'pending_customer'
    END;
    SET v_topic = 1 + FLOOR(RAND() * 9);
    SELECT customer_id INTO v_customer FROM tmp_utc_customers ORDER BY RAND() LIMIT 1;

    INSERT INTO support_tickets (tenant_id, customer_id, assigned_to, subject, body, priority, status, channel,
                                 created_at, resolved_at)
    VALUES (
      v_tenant, v_customer,
      IF(v_status = 'open', NULL, v_admin),
      ELT(v_topic,
          'Where is my order?',
          'Jeans too small, need to exchange',
          'Hoodie shrank after first wash',
          'Can I swap the colour of my tee?',
          'Sizing advice for the Wool Blend Overcoat',
          'Discount code not applying',
          'When is the Cropped Cardigan back in stock?',
          'Received the wrong item',
          'Refund not showing yet'),
      ELT(v_topic,
          'My order was marked shipped four days ago but the tracking link still says label created. Can you check?',
          'The Straight Leg Selvedge Jeans in 30 are too tight in the waist. Can I exchange for a 31?',
          'I washed my Everyday Fleece Hoodie on cold as the label says and it is noticeably shorter now.',
          'I ordered the Essential Heavyweight Tee in white but would rather have sand. Is a swap possible?',
          'I am 180 cm and usually wear M in jackets. Should I size down in the overcoat since it looks roomy?',
          'The FALL15 code from your email says it is not valid for items in my cart.',
          'The Cropped Boxy Cardigan in oat has been sold out for a while. Any restock date?',
          'I ordered Relaxed Cargo Pants in khaki but received the black ones.',
          'I returned my Coach Jacket two weeks ago and the refund has not appeared on my card yet.'),
      CASE WHEN i <= 3 THEN IF(i = 1, 'urgent', 'high')
           ELSE ELT(1 + FLOOR(POW(RAND(), 1.5) * 4), 'low', 'medium', 'high', 'urgent') END,
      v_status,
      ELT(1 + FLOOR(RAND() * 3), 'email', 'chat', 'phone'),
      v_created,
      IF(v_status IN ('resolved', 'closed'),
         LEAST(UTC_TIMESTAMP(), v_created + INTERVAL (2 + FLOOR(RAND() * 46)) HOUR),
         NULL)
    );
    SET i = i + 1;
  END WHILE;

  -- ─── Storefront traffic (last 30 days) ──────────────────────────────────────
  SET v_day = 0;
  WHILE v_day < 30 DO
    SET v_views = 120 + FLOOR(RAND() * 100)
                + IF(DAYOFWEEK(UTC_DATE() - INTERVAL v_day DAY) IN (1, 7), 60, 0)  -- busier weekends
                + FLOOR((30 - v_day) * 1.5);                                       -- gentle growth
    SET v_carts = FLOOR(v_views * (0.09 + RAND() * 0.06));
    SET v_checkouts = FLOOR(v_carts * (0.35 + RAND() * 0.2));

    INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id, recorded_at)
    SELECT v_tenant,
           CASE WHEN s.n <= v_checkouts THEN 'checkout_started'
                WHEN s.n <= v_checkouts + v_carts THEN 'add_to_cart'
                ELSE 'page_view' END,
           'product',
           p.product_id,
           LEAST(UTC_TIMESTAMP(3),
                 CAST(UTC_DATE() - INTERVAL v_day DAY AS DATETIME(3)) + INTERVAL FLOOR(RAND() * 86400) SECOND)
      FROM tmp_utc_seq s
      JOIN tmp_utc_products p ON p.n = 1 + (s.n * 7 + v_day) % v_product_count
     WHERE s.n <= v_views + v_carts + v_checkouts;
    SET v_day = v_day + 1;
  END WHILE;

  -- ─── Expenses (current month + 3 previous) ─────────────────────────────────
  SET v_month = 0;
  WHILE v_month < 4 DO
    SET v_month_start = DATE_FORMAT(UTC_DATE() - INTERVAL v_month MONTH, '%Y-%m-01');
    INSERT INTO expenses (tenant_id, category, description, amount, incurred_on, created_by) VALUES
      (v_tenant, 'rent',      'Studio + stockroom rent',        3200.00,                              v_month_start, v_admin),
      (v_tenant, 'wages',     'Staff wages (3 part-time)',      5400.00 + FLOOR(RAND() * 600),        v_month_start, v_admin),
      (v_tenant, 'software',  'Shop + email tools',              180.00,                              v_month_start, v_admin),
      (v_tenant, 'utilities', 'Electricity and internet',        260.00 + FLOOR(RAND() * 80),         LEAST(UTC_DATE(), v_month_start + INTERVAL 9 DAY), v_admin),
      (v_tenant, 'marketing', 'Instagram + TikTok ads',          700.00 + FLOOR(RAND() * 500),        LEAST(UTC_DATE(), v_month_start + INTERVAL 3 DAY), v_admin),
      (v_tenant, 'shipping',  'Courier invoices',                480.00 + FLOOR(RAND() * 220),        LEAST(UTC_DATE(), v_month_start + INTERVAL 14 DAY), v_admin),
      (v_tenant, 'supplies',  'Mailer bags, tissue and tags',    150.00 + FLOOR(RAND() * 90),         LEAST(UTC_DATE(), v_month_start + INTERVAL 6 DAY), v_admin);
    SET v_month = v_month + 1;
  END WHILE;
  INSERT INTO expenses (tenant_id, category, description, amount, incurred_on, created_by) VALUES
    (v_tenant, 'marketing', 'Fall lookbook photoshoot',        1250.00, UTC_DATE() - INTERVAL 33 DAY, v_admin),
    (v_tenant, 'other',     'Weekend pop-up market stall',      350.00, UTC_DATE() - INTERVAL 2 DAY,  v_admin);

  COMMIT;

  DROP TEMPORARY TABLE IF EXISTS tmp_utc_products, tmp_utc_customers, tmp_utc_seq;

  SELECT v_tenant AS tenant_id,
         (SELECT COUNT(*) FROM products        WHERE tenant_id = v_tenant) AS products,
         (SELECT COUNT(*) FROM customers       WHERE tenant_id = v_tenant) AS customers,
         (SELECT COUNT(*) FROM orders          WHERE tenant_id = v_tenant) AS orders,
         (SELECT COUNT(*) FROM order_items     WHERE tenant_id = v_tenant) AS order_lines,
         (SELECT COUNT(*) FROM campaigns       WHERE tenant_id = v_tenant) AS campaigns,
         (SELECT COUNT(*) FROM support_tickets WHERE tenant_id = v_tenant) AS tickets,
         (SELECT COUNT(*) FROM analytics_logs  WHERE tenant_id = v_tenant) AS traffic_events,
         (SELECT COUNT(*) FROM expenses        WHERE tenant_id = v_tenant) AS expenses;
END$$
DELIMITER ;

CALL seed_urban_thread_demo();
DROP PROCEDURE IF EXISTS seed_urban_thread_demo;
