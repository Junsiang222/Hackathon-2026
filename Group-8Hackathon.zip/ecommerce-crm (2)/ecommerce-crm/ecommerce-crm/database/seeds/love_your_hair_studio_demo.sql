-- =============================================================================
--  DEMO DATA — "Love your Hair Studio"
--
--  Fills the active store named "Love your Hair Studio" with realistic demo
--  data: hair-care products + stock, customers, ~260 orders over the last
--  4 months, campaigns, support tickets and 30 days of storefront traffic.
--  Dates are relative to "now", so the 30-day analytics charts are populated.
--
--  Run (needs CREATE ROUTINE, e.g. as root):
--      mysql -u root -p < database/seeds/love_your_hair_studio_demo.sql
--
--  Safe: all-or-nothing (one transaction), and refuses to run if the store
--  already has products. Customer emails use the reserved example.com domain.
--  Demo/dev only — never run against production.
-- =============================================================================

-- The file is UTF-8 (dashes, °C…): read it as such whatever the client default is.
SET NAMES utf8mb4;
USE crm_platform;

DROP PROCEDURE IF EXISTS seed_love_your_hair_studio_demo;

DELIMITER $$
CREATE PROCEDURE seed_love_your_hair_studio_demo()
BEGIN
  DECLARE v_tenant BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_admin BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_product_count INT;
  DECLARE v_customer_count INT;
  DECLARE i INT;
  DECLARE j INT;
  DECLARE v_items INT;
  DECLARE v_age INT;
  DECLARE v_roll DOUBLE;
  DECLARE v_status VARCHAR(20);
  DECLARE v_placed DATETIME;
  DECLARE v_created DATETIME;
  DECLARE v_customer BIGINT UNSIGNED;
  DECLARE v_order BIGINT UNSIGNED;
  DECLARE v_product BIGINT UNSIGNED;
  DECLARE v_price DECIMAL(12,4);
  DECLARE v_qty INT;
  DECLARE v_day INT;
  DECLARE v_views INT;
  DECLARE v_carts INT;
  DECLARE v_checkouts INT;
  DECLARE v_topic INT;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    DROP TEMPORARY TABLE IF EXISTS tmp_lyh_products, tmp_lyh_customers, tmp_lyh_seq;
    RESIGNAL;
  END;

  SELECT id INTO v_tenant
    FROM admins
   WHERE LOWER(business_name) = 'love your hair studio' AND status = 'active' AND is_platform = 0
   ORDER BY id DESC
   LIMIT 1;
  IF v_tenant IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active store named "Love your Hair Studio"';
  END IF;
  IF EXISTS (SELECT 1 FROM products WHERE tenant_id = v_tenant) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Love your Hair Studio already has products; demo data not added';
  END IF;

  SELECT id INTO v_admin FROM users WHERE tenant_id = v_tenant AND role = 'admin' ORDER BY id LIMIT 1;

  -- Number helper (1..400) for set-based inserts; a busy day needs ~330 events.
  DROP TEMPORARY TABLE IF EXISTS tmp_lyh_seq;
  CREATE TEMPORARY TABLE tmp_lyh_seq (n INT PRIMARY KEY);
  SET i = 1;
  WHILE i <= 400 DO
    INSERT INTO tmp_lyh_seq VALUES (i);
    SET i = i + 1;
  END WHILE;

  START TRANSACTION;

  -- ─── Products ───────────────────────────────────────────────────────────────
  INSERT INTO products (tenant_id, sku_code, name, category, base_price, status, description) VALUES
    (v_tenant, 'LYH-SH-001', 'Argan Oil Repair Shampoo',       'Shampoo',      24.00, 'active',   'Sulphate-free shampoo with Moroccan argan oil for dry, damaged hair. 300 ml.'),
    (v_tenant, 'LYH-SH-002', 'Volume Boost Shampoo',           'Shampoo',      22.00, 'active',   'Lightweight lift for fine hair, with biotin and rice protein. 300 ml.'),
    (v_tenant, 'LYH-CO-001', 'Argan Oil Repair Conditioner',   'Conditioner',  26.00, 'active',   'Rich detangling conditioner that seals in moisture and shine. 300 ml.'),
    (v_tenant, 'LYH-CO-002', 'Colour Protect Conditioner',     'Conditioner',  25.00, 'active',   'Keeps salon colour vibrant for longer with UV filters. 300 ml.'),
    (v_tenant, 'LYH-ST-001', 'Heat Protect Spray',             'Styling',      19.00, 'active',   'Shields hair up to 230°C before blow-drying or straightening. 200 ml.'),
    (v_tenant, 'LYH-ST-002', 'Sea Salt Texture Spray',         'Styling',      18.00, 'active',   'Effortless beach waves with a soft, touchable hold. 150 ml.'),
    (v_tenant, 'LYH-TR-001', 'Keratin Smoothing Mask',         'Treatments',   38.00, 'active',   'Weekly 10-minute mask that tames frizz and restores softness. 200 ml.'),
    (v_tenant, 'LYH-ST-003', 'Matte Clay Pomade',              'Styling',      21.00, 'active',   'Strong hold, zero shine — ideal for short and textured cuts. 85 g.'),
    (v_tenant, 'LYH-TR-002', 'Scalp Detox Scrub',              'Treatments',   32.00, 'active',   'Exfoliating scrub with tea tree and sea salt for a fresh scalp. 250 ml.'),
    (v_tenant, 'LYH-AC-001', 'Silk Scrunchie Set (3)',         'Accessories',  15.00, 'active',   'Mulberry silk scrunchies that prevent creases and breakage.'),
    (v_tenant, 'LYH-TR-003', 'Overnight Bond Repair Serum',    'Treatments',   45.00, 'active',   'Leave-in serum that rebuilds broken bonds while you sleep. 50 ml.'),
    (v_tenant, 'LYH-ST-004', 'Curl Defining Cream',            'Styling',      23.00, 'active',   'Defines curls and coils without crunch, with shea butter. 200 ml.'),
    (v_tenant, 'LYH-TL-001', 'Boar Bristle Paddle Brush',      'Tools',        34.00, 'active',   'Distributes natural oils for smoother, shinier hair.'),
    (v_tenant, 'LYH-GC-001', 'Haircut & Blow-dry Gift Card',   'Gift Cards',   60.00, 'active',   'Treat someone to a cut and blow-dry at the studio. Valid 12 months.'),
    (v_tenant, 'LYH-TL-002', 'Ceramic Straightener',           'Tools',        99.00, 'active',   'Floating ceramic plates, 5 heat settings, auto shut-off.'),
    (v_tenant, 'LYH-TL-003', 'Ionic Hair Dryer',               'Tools',       129.00, 'active',   'Salon-grade 2000 W ionic dryer with diffuser and concentrator.'),
    (v_tenant, 'LYH-SH-003', 'Purple Toning Shampoo',          'Shampoo',      24.00, 'draft',    'Neutralises brassy tones in blonde and silver hair. Coming soon.'),
    (v_tenant, 'LYH-AC-002', 'Travel Size Trio',               'Accessories',  29.00, 'archived', 'Mini shampoo, conditioner and mask. Discontinued.');

  -- Stock: a couple of low-stock items and one sell-out so the alerts have something to show.
  INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
  SELECT id, tenant_id,
         CASE sku_code
           WHEN 'LYH-TR-003' THEN 4
           WHEN 'LYH-TL-003' THEN 2
           WHEN 'LYH-ST-004' THEN 0
           WHEN 'LYH-AC-002' THEN 0
           ELSE 20 + FLOOR(RAND() * 70)
         END,
         CASE WHEN category IN ('Tools', 'Gift Cards') THEN 5 ELSE 10 END,
         UTC_TIMESTAMP() - INTERVAL FLOOR(5 + RAND() * 40) DAY
    FROM products
   WHERE tenant_id = v_tenant;

  -- Active products, ordered best-seller first (order picks are biased to low n).
  DROP TEMPORARY TABLE IF EXISTS tmp_lyh_products;
  CREATE TEMPORARY TABLE tmp_lyh_products (n INT PRIMARY KEY, product_id BIGINT UNSIGNED, price DECIMAL(12,4));
  INSERT INTO tmp_lyh_products (n, product_id, price)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, base_price
    FROM products
   WHERE tenant_id = v_tenant AND status = 'active';
  SELECT COUNT(*) INTO v_product_count FROM tmp_lyh_products;

  -- ─── Customers ──────────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 85 DO
    SET v_age = FLOOR(POW(RAND(), 1.5) * 180);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at, created_at)
    SELECT v_tenant,
           CONCAT(f.name, ' ', l.name),
           CONCAT(LOWER(f.name), '.', LOWER(l.name), i, '@example.com'),
           CONCAT('+1-555-01', LPAD(i, 2, '0')),
           ELT(1 + FLOOR(RAND() * 6), 'instagram', 'organic', 'referral', 'walk_in', 'paid_social', 'google'),
           IF(RAND() < 0.94, 'active', 'inactive'),
           v_created,
           v_created
      FROM (SELECT ELT(1 + FLOOR(RAND() * 20),
                   'Aisha', 'Mei', 'Sofia', 'Hannah', 'Priya', 'Chloe', 'Nur', 'Olivia', 'Grace', 'Emily',
                   'Farah', 'Jasmine', 'Lily', 'Zara', 'Amelia', 'Daniel', 'Ryan', 'Marcus', 'Jason', 'Adam') AS name) f,
           (SELECT ELT(1 + FLOOR(RAND() * 15),
                   'Tan', 'Lim', 'Wong', 'Lee', 'Rahman', 'Kaur', 'Smith', 'Brown', 'Garcia', 'Chen',
                   'Ng', 'Ismail', 'Patel', 'Taylor', 'Nguyen') AS name) l;
    SET i = i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tmp_lyh_customers;
  CREATE TEMPORARY TABLE tmp_lyh_customers (n INT PRIMARY KEY, customer_id BIGINT UNSIGNED, created_at DATETIME);
  INSERT INTO tmp_lyh_customers (n, customer_id, created_at)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, created_at FROM customers WHERE tenant_id = v_tenant;
  SELECT COUNT(*) INTO v_customer_count FROM tmp_lyh_customers;

  -- ─── Orders + order lines ──────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 260 DO
    SET v_age = FLOOR(POW(RAND(), 1.4) * 120);
    SET v_placed = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 1380) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN v_age <= 2 THEN IF(v_roll < 0.5, 'pending', 'confirmed')
      WHEN v_age <= 6 THEN IF(v_roll < 0.3, 'confirmed', 'shipped')
      WHEN v_roll < 0.88 THEN 'delivered'
      WHEN v_roll < 0.95 THEN 'cancelled'
      ELSE 'refunded'
    END;

    -- A customer who had already signed up when the order was placed.
    SET v_customer = NULL;
    SELECT customer_id INTO v_customer FROM tmp_lyh_customers
     WHERE created_at <= v_placed ORDER BY RAND() LIMIT 1;
    IF v_customer IS NULL THEN
      SELECT customer_id, created_at INTO v_customer, v_created FROM tmp_lyh_customers ORDER BY created_at LIMIT 1;
      SET v_placed = GREATEST(v_placed, v_created);
    END IF;

    INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address,
                        placed_at, fulfilled_at, created_at)
    VALUES (v_tenant, v_customer, CONCAT('LYH', v_tenant, '-', LPAD(i, 5, '0')), v_status, 0, 'USD',
            ELT(1 + FLOOR(RAND() * 6),
                '12 Rose Lane, Springfield, IL 62704',
                '88 Harbour View Rd, Apt 4B, Portland, OR 97209',
                '301 Maple Ave, Austin, TX 78701',
                '45 Orchard St, Brooklyn, NY 11201',
                '9 Willow Court, San Diego, CA 92101',
                '220 Pine St, Seattle, WA 98101'),
            v_placed,
            IF(v_status = 'delivered', v_placed + INTERVAL (2 + FLOOR(RAND() * 4)) DAY, NULL),
            v_placed);
    SET v_order = LAST_INSERT_ID();

    SET v_items = 1 + FLOOR(POW(RAND(), 2) * 3);
    SET j = 1;
    WHILE j <= v_items DO
      -- Draw once: RAND() inside WHERE would be re-evaluated for every row.
      SET v_qty = 1 + FLOOR(POW(RAND(), 1.3) * v_product_count);
      SELECT product_id, price INTO v_product, v_price FROM tmp_lyh_products WHERE n = v_qty;
      SET v_qty = IF(RAND() < 0.2, 2, 1);
      INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal, created_at)
      VALUES (v_tenant, v_order, v_product, v_qty, v_price, v_qty * v_price, v_placed);
      SET j = j + 1;
    END WHILE;

    UPDATE orders
       SET total_amount = (SELECT SUM(subtotal) FROM order_items WHERE tenant_id = v_tenant AND order_id = v_order)
     WHERE id = v_order;
    SET i = i + 1;
  END WHILE;

  -- Customer totals follow from their orders (cancelled/refunded don't count towards value).
  UPDATE customers c
    JOIN (SELECT customer_id,
                 COUNT(*) AS order_count,
                 SUM(IF(status IN ('cancelled', 'refunded'), 0, total_amount)) AS value,
                 MAX(placed_at) AS last_order
            FROM orders
           WHERE tenant_id = v_tenant
           GROUP BY customer_id) o
      ON o.customer_id = c.id
     SET c.total_orders = o.order_count,
         c.ltv = o.value,
         c.last_active_at = o.last_order
   WHERE c.tenant_id = v_tenant;

  -- Some customers browsed the shop recently without buying.
  UPDATE customers
     SET last_active_at = GREATEST(last_active_at,
                                   UTC_TIMESTAMP() - INTERVAL FLOOR(RAND() * 30) DAY - INTERVAL FLOOR(RAND() * 600) MINUTE)
   WHERE tenant_id = v_tenant AND status = 'active' AND RAND() < 0.4;

  -- ─── Campaigns ──────────────────────────────────────────────────────────────
  INSERT INTO campaigns (tenant_id, name, type, status, audience_segment, sent_count, open_count, click_count,
                         scheduled_at, created_at) VALUES
    (v_tenant, 'Summer Hair Rescue Sale',        'email',  'completed', JSON_OBJECT('segment', 'all_customers'),        1240, 546, 133,
       UTC_TIMESTAMP() - INTERVAL 26 DAY, UTC_TIMESTAMP() - INTERVAL 30 DAY),
    (v_tenant, 'Keratin Mask Launch',            'social', 'completed', JSON_OBJECT('segment', 'instagram_followers'), 3400, 1452, 291,
       UTC_TIMESTAMP() - INTERVAL 19 DAY, UTC_TIMESTAMP() - INTERVAL 24 DAY),
    (v_tenant, 'VIP Loyalty Thank-you',          'email',  'paused',    JSON_OBJECT('segment', 'vip', 'minOrders', 3),     310, 176, 41,
       UTC_TIMESTAMP() - INTERVAL 14 DAY, UTC_TIMESTAMP() - INTERVAL 16 DAY),
    (v_tenant, 'Refer a Friend: 15% Off',        'email',  'running',   JSON_OBJECT('segment', 'active_customers'),      920, 401, 87,
       UTC_TIMESTAMP() - INTERVAL 10 DAY, UTC_TIMESTAMP() - INTERVAL 12 DAY),
    (v_tenant, 'Weekend Blow-dry Bar Reminder',  'sms',    'completed', JSON_OBJECT('segment', 'local_customers'),       455, 412, 64,
       UTC_TIMESTAMP() - INTERVAL 6 DAY, UTC_TIMESTAMP() - INTERVAL 7 DAY),
    (v_tenant, 'Back in Stock Soon: Curl Cream', 'push',   'completed', JSON_OBJECT('segment', 'curl_cream_buyers'),     620, 254, 72,
       UTC_TIMESTAMP() - INTERVAL 3 DAY, UTC_TIMESTAMP() - INTERVAL 4 DAY),
    (v_tenant, 'Bridal Season Packages',         'email',  'scheduled', JSON_OBJECT('segment', 'all_customers'),           0,   0,  0,
       UTC_TIMESTAMP() + INTERVAL 5 DAY, UTC_TIMESTAMP() - INTERVAL 1 DAY),
    (v_tenant, 'Holiday Gift Card Promo',        'social', 'draft',     NULL,                                              0,   0,  0,
       NULL, UTC_TIMESTAMP() - INTERVAL 2 HOUR);

  -- ─── Support tickets ────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 30 DO
    SET v_age = FLOOR(RAND() * 30);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN i <= 3 THEN 'open'                         -- urgent ones for the notification bell
      WHEN v_age <= 2 THEN ELT(1 + FLOOR(v_roll * 3), 'open', 'in_progress', 'pending_customer')
      WHEN v_roll < 0.7 THEN 'resolved'
      WHEN v_roll < 0.85 THEN 'closed'
      ELSE 'pending_customer'
    END;
    SET v_topic = 1 + FLOOR(RAND() * 8);
    SELECT customer_id INTO v_customer FROM tmp_lyh_customers ORDER BY RAND() LIMIT 1;

    INSERT INTO support_tickets (tenant_id, customer_id, assigned_to, subject, body, priority, status, channel,
                                 created_at, resolved_at)
    VALUES (
      v_tenant, v_customer,
      IF(v_status = 'open', NULL, v_admin),
      ELT(v_topic,
          'Where is my order?',
          'Wrong item in my parcel',
          'Hair dryer stopped working',
          'Can I change my booking time?',
          'Allergic reaction to scalp scrub',
          'Gift card code not working',
          'Which shampoo suits coloured hair?',
          'Request a refund for damaged bottle'),
      ELT(v_topic,
          'My order was marked shipped a few days ago but tracking has not updated. Can you check?',
          'I ordered the Volume Boost Shampoo but received the Argan Oil one instead.',
          'The Ionic Hair Dryer cuts out after a couple of minutes of use. It is under a month old.',
          'I booked a cut and blow-dry for Saturday 10am, could I move it to the afternoon?',
          'My scalp felt itchy and red after using the Scalp Detox Scrub. Is this normal?',
          'The gift card code from my sister shows as invalid at checkout.',
          'I just had balayage done, which shampoo and conditioner would you recommend?',
          'The conditioner bottle arrived cracked and half of it leaked out.'),
      CASE WHEN i <= 3 THEN IF(i = 1, 'urgent', 'high')
           ELSE ELT(1 + FLOOR(POW(RAND(), 1.5) * 4), 'low', 'medium', 'high', 'urgent') END,
      v_status,
      ELT(1 + FLOOR(RAND() * 3), 'email', 'chat', 'phone'),
      v_created,
      IF(v_status IN ('resolved', 'closed'),
         LEAST(UTC_TIMESTAMP(), v_created + INTERVAL (2 + FLOOR(RAND() * 46)) HOUR),
         NULL)
    );
    SET i = i + 1;
  END WHILE;

  -- ─── Storefront traffic (last 30 days) ──────────────────────────────────────
  SET v_day = 0;
  WHILE v_day < 30 DO
    SET v_views = 90 + FLOOR(RAND() * 90)
                + IF(DAYOFWEEK(UTC_DATE() - INTERVAL v_day DAY) IN (1, 7), 50, 0)  -- busier weekends
                + FLOOR((30 - v_day) * 1.5);                                       -- gentle growth
    SET v_carts = FLOOR(v_views * (0.10 + RAND() * 0.06));
    SET v_checkouts = FLOOR(v_carts * (0.35 + RAND() * 0.2));

    INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id, recorded_at)
    SELECT v_tenant,
           CASE WHEN s.n <= v_checkouts THEN 'checkout_started'
                WHEN s.n <= v_checkouts + v_carts THEN 'add_to_cart'
                ELSE 'page_view' END,
           'product',
           p.product_id,
           LEAST(UTC_TIMESTAMP(3),
                 CAST(UTC_DATE() - INTERVAL v_day DAY AS DATETIME(3)) + INTERVAL FLOOR(RAND() * 86400) SECOND)
      FROM tmp_lyh_seq s
      JOIN tmp_lyh_products p ON p.n = 1 + (s.n * 7 + v_day) % v_product_count
     WHERE s.n <= v_views + v_carts + v_checkouts;
    SET v_day = v_day + 1;
  END WHILE;

  COMMIT;

  DROP TEMPORARY TABLE IF EXISTS tmp_lyh_products, tmp_lyh_customers, tmp_lyh_seq;

  SELECT v_tenant AS tenant_id,
         (SELECT COUNT(*) FROM products        WHERE tenant_id = v_tenant) AS products,
         (SELECT COUNT(*) FROM customers       WHERE tenant_id = v_tenant) AS customers,
         (SELECT COUNT(*) FROM orders          WHERE tenant_id = v_tenant) AS orders,
         (SELECT COUNT(*) FROM order_items     WHERE tenant_id = v_tenant) AS order_lines,
         (SELECT COUNT(*) FROM campaigns       WHERE tenant_id = v_tenant) AS campaigns,
         (SELECT COUNT(*) FROM support_tickets WHERE tenant_id = v_tenant) AS tickets,
         (SELECT COUNT(*) FROM analytics_logs  WHERE tenant_id = v_tenant) AS traffic_events;
END$$
DELIMITER ;

CALL seed_love_your_hair_studio_demo();
DROP PROCEDURE IF EXISTS seed_love_your_hair_studio_demo;
