-- =============================================================================
--  DEMO DATA — "Sneaker Hoops"
--
--  Fills the active store named "Sneaker Hoops" with realistic demo data:
--  basketball + street sneakers and gear with stock, customers, ~260 orders
--  over the last 4 months, campaigns, support tickets and 30 days of
--  storefront traffic. Dates are relative to "now", so the 30-day analytics
--  charts are populated.
--
--  Run (needs CREATE ROUTINE, e.g. as root):
--      mysql -u root -p < database/seeds/sneaker_hoops_demo.sql
--
--  Then alert_scenarios_demo.sql replaces this store's activity (orders,
--  customers, tickets, traffic) with the "orders drop / high cancellations /
--  conversion drop" scenario for the super admin's Analytics alerts. Products
--  from this file are kept.
--
--  Safe: all-or-nothing (one transaction), and refuses to run if the store
--  already has products. Customer emails use the reserved example.com domain.
--  Product names are fictional (no real brands). Demo/dev only — never run
--  against production.
-- =============================================================================

-- The file is UTF-8 (dashes, °C…): read it as such whatever the client default is.
SET NAMES utf8mb4;
USE crm_platform;

DROP PROCEDURE IF EXISTS seed_sneaker_hoops_demo;

DELIMITER $$
CREATE PROCEDURE seed_sneaker_hoops_demo()
BEGIN
  DECLARE v_tenant BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_admin BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_product_count INT;
  DECLARE v_customer_count INT;
  DECLARE i INT;
  DECLARE j INT;
  DECLARE v_items INT;
  DECLARE v_age INT;
  DECLARE v_roll DOUBLE;
  DECLARE v_status VARCHAR(20);
  DECLARE v_placed DATETIME;
  DECLARE v_created DATETIME;
  DECLARE v_customer BIGINT UNSIGNED;
  DECLARE v_order BIGINT UNSIGNED;
  DECLARE v_product BIGINT UNSIGNED;
  DECLARE v_price DECIMAL(12,4);
  DECLARE v_qty INT;
  DECLARE v_day INT;
  DECLARE v_views INT;
  DECLARE v_carts INT;
  DECLARE v_checkouts INT;
  DECLARE v_topic INT;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    DROP TEMPORARY TABLE IF EXISTS tmp_snh_products, tmp_snh_customers, tmp_snh_seq;
    RESIGNAL;
  END;

  SELECT id INTO v_tenant
    FROM admins
   WHERE LOWER(business_name) = 'sneaker hoops' AND status = 'active' AND is_platform = 0
   ORDER BY id DESC
   LIMIT 1;
  IF v_tenant IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active store named "Sneaker Hoops"';
  END IF;
  IF EXISTS (SELECT 1 FROM products WHERE tenant_id = v_tenant) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sneaker Hoops already has products; demo data not added';
  END IF;

  SELECT id INTO v_admin FROM users WHERE tenant_id = v_tenant AND role = 'admin' ORDER BY id LIMIT 1;

  -- Number helper (1..400) for set-based inserts; a busy day needs ~330 events.
  DROP TEMPORARY TABLE IF EXISTS tmp_snh_seq;
  CREATE TEMPORARY TABLE tmp_snh_seq (n INT PRIMARY KEY);
  SET i = 1;
  WHILE i <= 400 DO
    INSERT INTO tmp_snh_seq VALUES (i);
    SET i = i + 1;
  END WHILE;

  START TRANSACTION;

  -- ─── Products ───────────────────────────────────────────────────────────────
  INSERT INTO products (tenant_id, sku_code, name, category, base_price, status, description) VALUES
    (v_tenant, 'SNH-BB-001', 'Court Rise Mid Basketball Shoe',   'Basketball',  139.00, 'active',   'Mid-top hoops shoe with responsive foam and herringbone traction for indoor courts.'),
    (v_tenant, 'SNH-BB-002', 'Skyline High-Top Sneaker',         'Basketball',  159.00, 'active',   'Padded high-top with ankle support and a full-length air cushion. Built for big games.'),
    (v_tenant, 'SNH-BB-003', 'Rebound Low Court Shoe',           'Basketball',  119.00, 'active',   'Lightweight low-cut for quick guards: breathable mesh upper, grippy rubber outsole.'),
    (v_tenant, 'SNH-BB-004', 'Outdoor Grind Pro',                'Basketball',  129.00, 'active',   'Extra-durable outsole made for blacktop and outdoor courts.'),
    (v_tenant, 'SNH-LS-001', 'Classic White Leather Sneaker',    'Lifestyle',    99.00, 'active',   'Clean all-white leather low-top that goes with everything.'),
    (v_tenant, 'SNH-LS-002', 'Retro Hoop ''85 Sneaker',          'Lifestyle',   119.00, 'active',   'Throwback court silhouette in suede and leather with a vintage sole.'),
    (v_tenant, 'SNH-LS-003', 'Street Canvas High',               'Lifestyle',    69.00, 'active',   'Everyday canvas high-top with a cushioned insole.'),
    (v_tenant, 'SNH-RN-001', 'Velocity Knit Runner',             'Running',     129.00, 'active',   'Sock-like knit upper and springy foam for daily miles.'),
    (v_tenant, 'SNH-RN-002', 'Cloudstep Trainer',                'Running',     109.00, 'active',   'Soft, stable trainer for runs, gym sessions and long days on your feet.'),
    (v_tenant, 'SNH-KD-001', 'Junior Court Rise (Kids)',         'Kids',         79.00, 'active',   'Kid-size version of the Court Rise with easy hook-and-loop strap.'),
    (v_tenant, 'SNH-KD-002', 'Little Hooper Velcro Sneaker',     'Kids',         55.00, 'active',   'Light, flexible first sneakers for little ballers.'),
    (v_tenant, 'SNH-AP-001', 'Hoops Shooting Shirt',             'Apparel',      45.00, 'active',   'Moisture-wicking long-sleeve warm-up shirt.'),
    (v_tenant, 'SNH-AP-002', 'Mesh Basketball Shorts',           'Apparel',      35.00, 'active',   'Breathable 9" mesh shorts with deep pockets.'),
    (v_tenant, 'SNH-AP-003', 'Elite Crew Socks (3 Pack)',        'Apparel',      18.00, 'active',   'Cushioned crew socks with arch support. Sizes S-XL.'),
    (v_tenant, 'SNH-AC-001', 'Official Size 7 Basketball',       'Accessories',  39.00, 'active',   'Composite leather indoor/outdoor game ball.'),
    (v_tenant, 'SNH-AC-002', 'Sneaker Cleaning Kit',             'Accessories',  24.00, 'active',   'Brush, foam cleaner and microfibre cloth to keep kicks fresh.'),
    (v_tenant, 'SNH-AC-003', 'Drawstring Gym Bag',               'Accessories',  22.00, 'active',   'Water-resistant bag with a separate shoe pocket.'),
    (v_tenant, 'SNH-AC-004', 'Performance Insoles',              'Accessories',  29.00, 'active',   'Shock-absorbing insoles for jumping and hard landings.'),
    (v_tenant, 'SNH-BB-005', 'Court Rise Mid "Night Edition"',   'Basketball',  149.00, 'draft',    'Limited black-and-gold colourway. Coming soon.'),
    (v_tenant, 'SNH-LS-004', 'Summer Slide Sandal',              'Lifestyle',    35.00, 'archived', 'Post-game recovery slide. Discontinued.');

  -- Stagger "added" dates so sneakers are the newest arrivals (the shop lists newest first).
  UPDATE products
     SET created_at = UTC_TIMESTAMP() - INTERVAL (CASE category
           WHEN 'Basketball' THEN 1 WHEN 'Lifestyle' THEN 3 WHEN 'Running' THEN 5
           WHEN 'Kids' THEN 8 WHEN 'Apparel' THEN 12 ELSE 16 END) DAY - INTERVAL id MINUTE
   WHERE tenant_id = v_tenant;

  -- Stock: a couple of low-stock items and one sell-out so the alerts have something to show.
  INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
  SELECT id, tenant_id,
         CASE sku_code
           WHEN 'SNH-BB-002' THEN 3
           WHEN 'SNH-LS-002' THEN 5
           WHEN 'SNH-RN-001' THEN 0
           WHEN 'SNH-LS-004' THEN 0
           ELSE 15 + FLOOR(RAND() * 60)
         END,
         CASE WHEN category IN ('Basketball', 'Running', 'Lifestyle') THEN 8 ELSE 12 END,
         UTC_TIMESTAMP() - INTERVAL FLOOR(5 + RAND() * 40) DAY
    FROM products
   WHERE tenant_id = v_tenant;

  -- Active products, ordered best-seller first (order picks are biased to low n).
  DROP TEMPORARY TABLE IF EXISTS tmp_snh_products;
  CREATE TEMPORARY TABLE tmp_snh_products (n INT PRIMARY KEY, product_id BIGINT UNSIGNED, price DECIMAL(12,4));
  INSERT INTO tmp_snh_products (n, product_id, price)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, base_price
    FROM products
   WHERE tenant_id = v_tenant AND status = 'active';
  SELECT COUNT(*) INTO v_product_count FROM tmp_snh_products;

  -- ─── Customers ──────────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 90 DO
    SET v_age = FLOOR(POW(RAND(), 1.5) * 180);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at, created_at)
    SELECT v_tenant,
           CONCAT(f.name, ' ', l.name),
           CONCAT(LOWER(f.name), '.', LOWER(l.name), i, '@example.com'),
           CONCAT('+1-555-02', LPAD(i, 2, '0')),
           ELT(1 + FLOOR(RAND() * 6), 'instagram', 'organic', 'referral', 'walk_in', 'paid_social', 'google'),
           IF(RAND() < 0.94, 'active', 'inactive'),
           v_created,
           v_created
      FROM (SELECT ELT(1 + FLOOR(RAND() * 20),
                   'Jordan', 'Marcus', 'Ethan', 'Kai', 'Darius', 'Ryan', 'Jason', 'Adam', 'Luca', 'Malik',
                   'Daniel', 'Aiden', 'Wei', 'Arjun', 'Mia', 'Zoe', 'Aisha', 'Chloe', 'Nina', 'Sofia') AS name) f,
           (SELECT ELT(1 + FLOOR(RAND() * 15),
                   'Tan', 'Lim', 'Wong', 'Lee', 'Rahman', 'Singh', 'Smith', 'Johnson', 'Garcia', 'Chen',
                   'Ng', 'Williams', 'Patel', 'Brown', 'Nguyen') AS name) l;
    SET i = i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tmp_snh_customers;
  CREATE TEMPORARY TABLE tmp_snh_customers (n INT PRIMARY KEY, customer_id BIGINT UNSIGNED, created_at DATETIME);
  INSERT INTO tmp_snh_customers (n, customer_id, created_at)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, created_at FROM customers WHERE tenant_id = v_tenant;
  SELECT COUNT(*) INTO v_customer_count FROM tmp_snh_customers;

  -- ─── Orders + order lines ──────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 260 DO
    SET v_age = FLOOR(POW(RAND(), 1.4) * 120);
    SET v_placed = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 1380) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN v_age <= 2 THEN IF(v_roll < 0.5, 'pending', 'confirmed')
      WHEN v_age <= 6 THEN IF(v_roll < 0.3, 'confirmed', 'shipped')
      WHEN v_roll < 0.86 THEN 'delivered'
      WHEN v_roll < 0.94 THEN 'cancelled'
      ELSE 'refunded'
    END;

    -- A customer who had already signed up when the order was placed.
    SET v_customer = NULL;
    SELECT customer_id INTO v_customer FROM tmp_snh_customers
     WHERE created_at <= v_placed ORDER BY RAND() LIMIT 1;
    IF v_customer IS NULL THEN
      SELECT customer_id, created_at INTO v_customer, v_created FROM tmp_snh_customers ORDER BY created_at LIMIT 1;
      SET v_placed = GREATEST(v_placed, v_created);
    END IF;

    INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address,
                        placed_at, fulfilled_at, created_at)
    VALUES (v_tenant, v_customer, CONCAT('SNH', v_tenant, '-', LPAD(i, 5, '0')), v_status, 0, 'USD',
            ELT(1 + FLOOR(RAND() * 6),
                '14 Court St, Chicago, IL 60605',
                '77 Baseline Ave, Apt 2C, Los Angeles, CA 90015',
                '502 Rim Rd, Houston, TX 77002',
                '18 Dunk Ln, Brooklyn, NY 11216',
                '9 Fastbreak Way, Oakland, CA 94607',
                '330 Pine St, Seattle, WA 98101'),
            v_placed,
            IF(v_status = 'delivered', v_placed + INTERVAL (2 + FLOOR(RAND() * 4)) DAY, NULL),
            v_placed);
    SET v_order = LAST_INSERT_ID();

    SET v_items = 1 + FLOOR(POW(RAND(), 2) * 3);
    SET j = 1;
    WHILE j <= v_items DO
      -- Draw once: RAND() inside WHERE would be re-evaluated for every row.
      SET v_qty = 1 + FLOOR(POW(RAND(), 1.3) * v_product_count);
      SELECT product_id, price INTO v_product, v_price FROM tmp_snh_products WHERE n = v_qty;
      SET v_qty = IF(RAND() < 0.15, 2, 1);
      INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal, created_at)
      VALUES (v_tenant, v_order, v_product, v_qty, v_price, v_qty * v_price, v_placed);
      SET j = j + 1;
    END WHILE;

    UPDATE orders
       SET total_amount = (SELECT SUM(subtotal) FROM order_items WHERE tenant_id = v_tenant AND order_id = v_order)
     WHERE id = v_order;
    SET i = i + 1;
  END WHILE;

  -- Customer totals follow from their orders (cancelled/refunded don't count towards value).
  UPDATE customers c
    JOIN (SELECT customer_id,
                 COUNT(*) AS order_count,
                 SUM(IF(status IN ('cancelled', 'refunded'), 0, total_amount)) AS value,
                 MAX(placed_at) AS last_order
            FROM orders
           WHERE tenant_id = v_tenant
           GROUP BY customer_id) o
      ON o.customer_id = c.id
     SET c.total_orders = o.order_count,
         c.ltv = o.value,
         c.last_active_at = o.last_order
   WHERE c.tenant_id = v_tenant;

  -- Some customers browsed the shop recently without buying.
  UPDATE customers
     SET last_active_at = GREATEST(last_active_at,
                                   UTC_TIMESTAMP() - INTERVAL FLOOR(RAND() * 30) DAY - INTERVAL FLOOR(RAND() * 600) MINUTE)
   WHERE tenant_id = v_tenant AND status = 'active' AND RAND() < 0.4;

  -- ─── Campaigns ──────────────────────────────────────────────────────────────
  INSERT INTO campaigns (tenant_id, name, type, status, audience_segment, sent_count, open_count, click_count,
                         scheduled_at, created_at) VALUES
    (v_tenant, 'Back to Court Season Sale',      'email',  'completed', JSON_OBJECT('segment', 'all_customers'),        1380, 598, 162,
       UTC_TIMESTAMP() - INTERVAL 27 DAY, UTC_TIMESTAMP() - INTERVAL 31 DAY),
    (v_tenant, 'Skyline High-Top Drop',          'social', 'completed', JSON_OBJECT('segment', 'instagram_followers'), 4200, 1890, 412,
       UTC_TIMESTAMP() - INTERVAL 20 DAY, UTC_TIMESTAMP() - INTERVAL 23 DAY),
    (v_tenant, 'Hoopers Club Thank-you',         'email',  'paused',    JSON_OBJECT('segment', 'vip', 'minOrders', 3),     280, 161, 44,
       UTC_TIMESTAMP() - INTERVAL 15 DAY, UTC_TIMESTAMP() - INTERVAL 17 DAY),
    (v_tenant, 'Refer a Teammate: 10% Off',      'email',  'running',   JSON_OBJECT('segment', 'active_customers'),      960, 415, 93,
       UTC_TIMESTAMP() - INTERVAL 9 DAY, UTC_TIMESTAMP() - INTERVAL 11 DAY),
    (v_tenant, 'Weekend 3-on-3 Tournament',      'sms',    'completed', JSON_OBJECT('segment', 'local_customers'),       510, 463, 88,
       UTC_TIMESTAMP() - INTERVAL 5 DAY, UTC_TIMESTAMP() - INTERVAL 6 DAY),
    (v_tenant, 'Velocity Runner Restock Alert',  'push',   'completed', JSON_OBJECT('segment', 'runner_waitlist'),       640, 287, 79,
       UTC_TIMESTAMP() - INTERVAL 2 DAY, UTC_TIMESTAMP() - INTERVAL 3 DAY),
    (v_tenant, 'Night Edition Launch',           'email',  'scheduled', JSON_OBJECT('segment', 'all_customers'),           0,   0,  0,
       UTC_TIMESTAMP() + INTERVAL 6 DAY, UTC_TIMESTAMP() - INTERVAL 1 DAY),
    (v_tenant, 'Holiday Gift Guide',             'social', 'draft',     NULL,                                              0,   0,  0,
       NULL, UTC_TIMESTAMP() - INTERVAL 3 HOUR);

  -- ─── Support tickets ────────────────────────────────────────────────────────
  SET i = 1;
  WHILE i <= 30 DO
    SET v_age = FLOOR(RAND() * 30);
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 600) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN i <= 3 THEN 'open'                         -- urgent ones for the notification bell
      WHEN v_age <= 2 THEN ELT(1 + FLOOR(v_roll * 3), 'open', 'in_progress', 'pending_customer')
      WHEN v_roll < 0.7 THEN 'resolved'
      WHEN v_roll < 0.85 THEN 'closed'
      ELSE 'pending_customer'
    END;
    SET v_topic = 1 + FLOOR(RAND() * 8);
    SELECT customer_id INTO v_customer FROM tmp_snh_customers ORDER BY RAND() LIMIT 1;

    INSERT INTO support_tickets (tenant_id, customer_id, assigned_to, subject, body, priority, status, channel,
                                 created_at, resolved_at)
    VALUES (
      v_tenant, v_customer,
      IF(v_status = 'open', NULL, v_admin),
      ELT(v_topic,
          'Where is my order?',
          'Wrong size delivered',
          'Sole separating after two weeks',
          'Can I exchange for a different colour?',
          'Size guide question for Skyline High-Top',
          'Discount code not working',
          'When is the Velocity Runner back in stock?',
          'Box arrived damaged'),
      ELT(v_topic,
          'My order was marked shipped a few days ago but tracking has not updated. Can you check?',
          'I ordered a US 10 Court Rise Mid but received a US 9. I need to swap it before Saturday.',
          'The sole on my Outdoor Grind Pro is starting to peel at the toe after only two weeks of play.',
          'I bought the Classic White Leather Sneaker but would prefer it in black. Is an exchange possible?',
          'I am usually a 10.5 in running shoes. Should I size up for the Skyline High-Top?',
          'The REFER10 code from my friend shows as invalid at checkout.',
          'The Velocity Knit Runner in US 9 has been sold out for a while. Any restock date?',
          'The shoebox was crushed in delivery. The shoes look fine but they were meant as a gift.'),
      CASE WHEN i <= 3 THEN IF(i = 1, 'urgent', 'high')
           ELSE ELT(1 + FLOOR(POW(RAND(), 1.5) * 4), 'low', 'medium', 'high', 'urgent') END,
      v_status,
      ELT(1 + FLOOR(RAND() * 3), 'email', 'chat', 'phone'),
      v_created,
      IF(v_status IN ('resolved', 'closed'),
         LEAST(UTC_TIMESTAMP(), v_created + INTERVAL (2 + FLOOR(RAND() * 46)) HOUR),
         NULL)
    );
    SET i = i + 1;
  END WHILE;

  -- ─── Storefront traffic (last 30 days) ──────────────────────────────────────
  SET v_day = 0;
  WHILE v_day < 30 DO
    SET v_views = 100 + FLOOR(RAND() * 90)
                + IF(DAYOFWEEK(UTC_DATE() - INTERVAL v_day DAY) IN (1, 7), 50, 0)  -- busier weekends
                + FLOOR((30 - v_day) * 1.5);                                       -- gentle growth
    SET v_carts = FLOOR(v_views * (0.10 + RAND() * 0.06));
    SET v_checkouts = FLOOR(v_carts * (0.35 + RAND() * 0.2));

    INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id, recorded_at)
    SELECT v_tenant,
           CASE WHEN s.n <= v_checkouts THEN 'checkout_started'
                WHEN s.n <= v_checkouts + v_carts THEN 'add_to_cart'
                ELSE 'page_view' END,
           'product',
           p.product_id,
           LEAST(UTC_TIMESTAMP(3),
                 CAST(UTC_DATE() - INTERVAL v_day DAY AS DATETIME(3)) + INTERVAL FLOOR(RAND() * 86400) SECOND)
      FROM tmp_snh_seq s
      JOIN tmp_snh_products p ON p.n = 1 + (s.n * 7 + v_day) % v_product_count
     WHERE s.n <= v_views + v_carts + v_checkouts;
    SET v_day = v_day + 1;
  END WHILE;

  COMMIT;

  DROP TEMPORARY TABLE IF EXISTS tmp_snh_products, tmp_snh_customers, tmp_snh_seq;

  SELECT v_tenant AS tenant_id,
         (SELECT COUNT(*) FROM products        WHERE tenant_id = v_tenant) AS products,
         (SELECT COUNT(*) FROM customers       WHERE tenant_id = v_tenant) AS customers,
         (SELECT COUNT(*) FROM orders          WHERE tenant_id = v_tenant) AS orders,
         (SELECT COUNT(*) FROM order_items     WHERE tenant_id = v_tenant) AS order_lines,
         (SELECT COUNT(*) FROM campaigns       WHERE tenant_id = v_tenant) AS campaigns,
         (SELECT COUNT(*) FROM support_tickets WHERE tenant_id = v_tenant) AS tickets,
         (SELECT COUNT(*) FROM analytics_logs  WHERE tenant_id = v_tenant) AS traffic_events;
END$$
DELIMITER ;

CALL seed_sneaker_hoops_demo();
DROP PROCEDURE IF EXISTS seed_sneaker_hoops_demo;
