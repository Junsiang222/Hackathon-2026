-- =============================================================================
--  DEMO DATA — analytics alert scenarios
--
--  Gives the super admin's Analytics page different stories to show:
--
--    Badminton      growing fast: orders spike (+~150%), its 3 best sellers are
--                   sold out, and 4 urgent support tickets are waiting.
--                   → alerts: Orders spike · Out of stock (3) · Urgent tickets
--    Sneaker Hoops  struggling: visitors keep coming but orders fall ~45%, and
--                   ~30% of orders are cancelled/refunded (sizes, soles).
--                   → alerts: Orders drop · High cancellations · Conversion drop
--
--  The stories are built around the default 30-day view (this 30 days vs the 30
--  before), with a few more months of history for the trend and monthly charts.
--  Dates are relative to "now", so run it again later to refresh the scenario.
--
--  What it changes:
--    * Badminton: adds its products (badminton gear + court/coaching services),
--      stock, cost prices, campaigns and expenses if it has no products yet.
--    * Both stores: REPLACES the demo activity: orders, order lines, demo
--      customers (@example.com, no shop account), support tickets and product
--      traffic events. Products, product photos, shopper accounts, real page
--      visits and logins are kept.
--
--  Run (needs CREATE ROUTINE, e.g. as root):
--      mysql -u root -p < database/seeds/alert_scenarios_demo.sql
--  Demo/dev only — never run against production.
-- =============================================================================

-- The file is UTF-8 (dashes, °C…): read it as such whatever the client default is.
SET NAMES utf8mb4;
USE crm_platform;

DROP PROCEDURE IF EXISTS seed_store_activity;

DELIMITER $$
-- Rebuilds one store's demo activity for a scenario.
--   p_*_daily     average orders per day in that window (weekends get p_weekend x)
--   p_*_cancel    share of orders cancelled or refunded
--   p_*_views     average product page views per day
--   p_peak        'evening' or 'lunch': when orders are placed
--   p_urgent_open urgent tickets still open now
-- Reads the session's tmp_seed_topics (n, subject, body) for ticket wording.
CREATE PROCEDURE seed_store_activity(
  IN p_tenant BIGINT UNSIGNED, IN p_prefix VARCHAR(10),
  IN p_old_days INT, IN p_old_daily DOUBLE, IN p_prev_daily DOUBLE, IN p_curr_daily DOUBLE,
  IN p_old_cancel DOUBLE, IN p_prev_cancel DOUBLE, IN p_curr_cancel DOUBLE,
  IN p_old_views DOUBLE, IN p_prev_views DOUBLE, IN p_curr_views DOUBLE,
  IN p_weekend DOUBLE, IN p_peak VARCHAR(10), IN p_customers INT, IN p_urgent_open INT
)
BEGIN
  DECLARE v_admin BIGINT UNSIGNED DEFAULT NULL;
  DECLARE v_product_count INT;
  DECLARE v_topic_count INT;
  DECLARE i INT;
  DECLARE j INT;
  DECLARE d INT;
  DECLARE v_n INT;
  DECLARE v_items INT;
  DECLARE v_pick INT;
  DECLARE v_qty INT;
  DECLARE v_age INT;
  DECLARE v_hour INT;
  DECLARE v_rate DOUBLE;
  DECLARE v_cancel DOUBLE;
  DECLARE v_roll DOUBLE;
  DECLARE v_status VARCHAR(20);
  DECLARE v_day DATETIME;
  DECLARE v_placed DATETIME;
  DECLARE v_created DATETIME;
  DECLARE v_customer BIGINT UNSIGNED;
  DECLARE v_order BIGINT UNSIGNED;
  DECLARE v_product BIGINT UNSIGNED;
  DECLARE v_price DECIMAL(12,4);
  DECLARE v_views INT;
  DECLARE v_carts INT;
  DECLARE v_checkouts INT;
  DECLARE v_seq INT DEFAULT 0;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;
    DROP TEMPORARY TABLE IF EXISTS tmp_seed_products, tmp_seed_customers, tmp_seed_seq;
    RESIGNAL;
  END;

  SELECT id INTO v_admin FROM users WHERE tenant_id = p_tenant AND role = 'admin' ORDER BY id LIMIT 1;
  SELECT COUNT(*) INTO v_topic_count FROM tmp_seed_topics;

  DROP TEMPORARY TABLE IF EXISTS tmp_seed_seq;
  CREATE TEMPORARY TABLE tmp_seed_seq (n INT PRIMARY KEY);
  SET i = 1;
  WHILE i <= 900 DO
    INSERT INTO tmp_seed_seq VALUES (i);
    SET i = i + 1;
  END WHILE;

  START TRANSACTION;

  -- ─── Clear the previous demo activity (keeps real shoppers and visits) ───────
  DELETE FROM support_tickets WHERE tenant_id = p_tenant;
  DELETE FROM orders WHERE tenant_id = p_tenant AND order_ref LIKE CONCAT(p_prefix, p_tenant, '-%');
  DELETE c FROM customers c
   WHERE c.tenant_id = p_tenant AND c.email LIKE '%@example.com' AND c.password_hash IS NULL
     AND NOT EXISTS (SELECT 1 FROM orders o WHERE o.tenant_id = c.tenant_id AND o.customer_id = c.id);
  DELETE FROM analytics_logs WHERE tenant_id = p_tenant AND entity_type = 'product';

  -- Active products, best sellers first (picks are biased to low n).
  DROP TEMPORARY TABLE IF EXISTS tmp_seed_products;
  CREATE TEMPORARY TABLE tmp_seed_products (n INT PRIMARY KEY, product_id BIGINT UNSIGNED, price DECIMAL(12,4));
  INSERT INTO tmp_seed_products (n, product_id, price)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, base_price FROM products WHERE tenant_id = p_tenant AND status = 'active';
  SELECT COUNT(*) INTO v_product_count FROM tmp_seed_products;
  IF v_product_count = 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Store has no active products to sell';
  END IF;

  -- ─── Customers (more of them joined recently in a growing store) ────────────
  SET i = 1;
  WHILE i <= p_customers DO
    SET v_age = FLOOR(POW(RAND(), 1.3) * (p_old_days + 60));
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(RAND() * 900) MINUTE;
    INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at, created_at)
    SELECT p_tenant,
           CONCAT(f.name, ' ', l.name),
           CONCAT(LOWER(f.name), '.', LOWER(l.name), '.', LOWER(p_prefix), i, '@example.com'),
           CONCAT('+60-12-', LPAD(FLOOR(RAND() * 10000000), 7, '0')),
           ELT(1 + FLOOR(RAND() * 6), 'instagram', 'organic', 'referral', 'walk_in', 'paid_social', 'google'),
           IF(RAND() < 0.95, 'active', 'inactive'),
           v_created,
           v_created
      FROM (SELECT ELT(1 + FLOOR(RAND() * 20),
                   'Wei', 'Jun', 'Hafiz', 'Aisyah', 'Mei', 'Kumar', 'Siti', 'Daniel', 'Chloe', 'Arif',
                   'Nurul', 'Ethan', 'Li', 'Priya', 'Zara', 'Ryan', 'Farid', 'Grace', 'Jason', 'Amira') AS name) f,
           (SELECT ELT(1 + FLOOR(RAND() * 15),
                   'Tan', 'Lim', 'Wong', 'Lee', 'Rahman', 'Singh', 'Ng', 'Chong', 'Ismail', 'Chen',
                   'Teo', 'Yusof', 'Goh', 'Abdullah', 'Ong') AS name) l;
    SET i = i + 1;
  END WHILE;

  DROP TEMPORARY TABLE IF EXISTS tmp_seed_customers;
  CREATE TEMPORARY TABLE tmp_seed_customers (n INT PRIMARY KEY, customer_id BIGINT UNSIGNED, created_at DATETIME);
  INSERT INTO tmp_seed_customers (n, customer_id, created_at)
  SELECT ROW_NUMBER() OVER (ORDER BY id), id, created_at FROM customers WHERE tenant_id = p_tenant;

  -- ─── Orders, day by day ─────────────────────────────────────────────────────
  SET d = p_old_days + 59;
  WHILE d >= 0 DO
    SET v_day = CAST(UTC_DATE() - INTERVAL d DAY AS DATETIME);
    SET v_rate = CASE WHEN d < 30 THEN p_curr_daily WHEN d < 60 THEN p_prev_daily ELSE p_old_daily END;
    SET v_cancel = CASE WHEN d < 30 THEN p_curr_cancel WHEN d < 60 THEN p_prev_cancel ELSE p_old_cancel END;
    IF DAYOFWEEK(v_day) IN (1, 7) THEN SET v_rate = v_rate * p_weekend; END IF;
    SET v_n = FLOOR(v_rate * (0.6 + RAND() * 0.8) + RAND());

    SET j = 1;
    WHILE j <= v_n DO
      SET v_hour = IF(p_peak = 'evening',
                      ELT(1 + FLOOR(RAND() * 12), 8, 10, 12, 17, 18, 19, 19, 20, 20, 20, 21, 22),
                      ELT(1 + FLOOR(RAND() * 12), 9, 10, 11, 12, 12, 12, 13, 13, 14, 16, 20, 21));
      SET v_placed = LEAST(UTC_TIMESTAMP() - INTERVAL 5 MINUTE,
                           v_day + INTERVAL v_hour HOUR + INTERVAL FLOOR(RAND() * 60) MINUTE);
      SET v_roll = RAND();
      SET v_status = CASE
        WHEN v_roll < v_cancel THEN IF(RAND() < 0.6, 'cancelled', 'refunded')
        WHEN d <= 1 THEN IF(RAND() < 0.5, 'pending', 'confirmed')
        WHEN d <= 5 THEN IF(RAND() < 0.35, 'confirmed', 'shipped')
        ELSE 'delivered'
      END;

      SET v_customer = NULL;
      SELECT customer_id INTO v_customer FROM tmp_seed_customers WHERE created_at <= v_placed ORDER BY RAND() LIMIT 1;
      IF v_customer IS NULL THEN
        SELECT customer_id, created_at INTO v_customer, v_created FROM tmp_seed_customers ORDER BY created_at LIMIT 1;
        SET v_placed = GREATEST(v_placed, v_created);
      END IF;

      SET v_seq = v_seq + 1;
      INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address,
                          placed_at, fulfilled_at, created_at)
      VALUES (p_tenant, v_customer, CONCAT(p_prefix, p_tenant, '-', LPAD(v_seq, 5, '0')), v_status, 0, 'USD',
              ELT(1 + FLOOR(RAND() * 6),
                  '12 Jalan Bukit Bintang, 55100 Kuala Lumpur',
                  '8 Jalan SS2/24, 47300 Petaling Jaya, Selangor',
                  '45 Lebuh Chulia, 10200 George Town, Penang',
                  '21 Jalan Tebrau, 80000 Johor Bahru, Johor',
                  '3 Jalan Ipoh Garden, 31400 Ipoh, Perak',
                  '17 Persiaran Gurney, 10250 George Town, Penang'),
              v_placed,
              IF(v_status = 'delivered', v_placed + INTERVAL (2 + FLOOR(RAND() * 3)) DAY, NULL),
              v_placed);
      SET v_order = LAST_INSERT_ID();

      SET v_items = 1 + FLOOR(POW(RAND(), 2.2) * 3);
      SET i = 1;
      WHILE i <= v_items DO
        -- Draw once: RAND() inside WHERE would be re-evaluated per row.
        SET v_pick = 1 + FLOOR(POW(RAND(), 1.7) * v_product_count);
        SELECT product_id, price INTO v_product, v_price FROM tmp_seed_products WHERE n = v_pick;
        SET v_qty = IF(RAND() < 0.18, 2, 1);
        INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal, created_at)
        VALUES (p_tenant, v_order, v_product, v_qty, v_price, v_qty * v_price, v_placed);
        SET i = i + 1;
      END WHILE;

      UPDATE orders
         SET total_amount = (SELECT SUM(subtotal) FROM order_items WHERE tenant_id = p_tenant AND order_id = v_order)
       WHERE id = v_order;
      SET j = j + 1;
    END WHILE;

    -- ─── That day's product traffic ───────────────────────────────────────────
    SET v_rate = CASE WHEN d < 30 THEN p_curr_views WHEN d < 60 THEN p_prev_views ELSE p_old_views END;
    IF DAYOFWEEK(v_day) IN (1, 7) THEN SET v_rate = v_rate * 1.2; END IF;
    SET v_views = FLOOR(v_rate * (0.8 + RAND() * 0.4));
    SET v_carts = FLOOR(v_views * (0.08 + RAND() * 0.05));
    SET v_checkouts = FLOOR(v_carts * (0.35 + RAND() * 0.2));
    INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id, recorded_at)
    SELECT p_tenant,
           CASE WHEN s.n <= v_checkouts THEN 'checkout_started'
                WHEN s.n <= v_checkouts + v_carts THEN 'add_to_cart'
                ELSE 'page_view' END,
           'product',
           p.product_id,
           LEAST(UTC_TIMESTAMP(3) - INTERVAL 1 MINUTE,
                 CAST(v_day AS DATETIME(3)) + INTERVAL FLOOR(RAND() * 86400) SECOND)
      FROM tmp_seed_seq s
      JOIN tmp_seed_products p ON p.n = 1 + (s.n * 7 + d) % v_product_count
     WHERE s.n <= LEAST(900, v_views + v_carts + v_checkouts);

    SET d = d - 1;
  END WHILE;

  -- Customer totals follow from their orders (cancelled/refunded don't count towards value).
  UPDATE customers c
    JOIN (SELECT customer_id, COUNT(*) AS order_count,
                 SUM(IF(status IN ('cancelled', 'refunded'), 0, total_amount)) AS value,
                 MAX(placed_at) AS last_order
            FROM orders WHERE tenant_id = p_tenant GROUP BY customer_id) o ON o.customer_id = c.id
     SET c.total_orders = o.order_count, c.ltv = o.value, c.last_active_at = o.last_order
   WHERE c.tenant_id = p_tenant;

  -- ─── Support tickets: the urgent ones still open, the rest mostly resolved ──
  SET i = 1;
  WHILE i <= p_urgent_open + 22 DO
    SET v_age = IF(i <= p_urgent_open, FLOOR(RAND() * 3), FLOOR(RAND() * 30));
    SET v_created = UTC_TIMESTAMP() - INTERVAL v_age DAY - INTERVAL FLOOR(60 + RAND() * 600) MINUTE;
    SET v_roll = RAND();
    SET v_status = CASE
      WHEN i <= p_urgent_open THEN 'open'
      WHEN v_age <= 2 THEN ELT(1 + FLOOR(v_roll * 3), 'open', 'in_progress', 'pending_customer')
      WHEN v_roll < 0.75 THEN 'resolved'
      WHEN v_roll < 0.9 THEN 'closed'
      ELSE 'pending_customer'
    END;
    SET v_pick = 1 + FLOOR(RAND() * v_topic_count);
    SELECT customer_id INTO v_customer FROM tmp_seed_customers ORDER BY RAND() LIMIT 1;
    INSERT INTO support_tickets (tenant_id, customer_id, assigned_to, subject, body, priority, status, channel,
                                 created_at, resolved_at)
    SELECT p_tenant, v_customer, IF(v_status = 'open', NULL, v_admin), t.subject, t.body,
           -- Non-urgent tickets never draw 'urgent', so the urgent count is exactly p_urgent_open.
           IF(i <= p_urgent_open, 'urgent', ELT(1 + FLOOR(POW(RAND(), 1.4) * 3), 'low', 'medium', 'high')),
           v_status, ELT(1 + FLOOR(RAND() * 3), 'email', 'chat', 'phone'), v_created,
           IF(v_status IN ('resolved', 'closed'), LEAST(UTC_TIMESTAMP(), v_created + INTERVAL (2 + FLOOR(RAND() * 40)) HOUR), NULL)
      FROM tmp_seed_topics t WHERE t.n = v_pick;
    SET i = i + 1;
  END WHILE;

  COMMIT;
  DROP TEMPORARY TABLE IF EXISTS tmp_seed_products, tmp_seed_customers, tmp_seed_seq;
END$$
DELIMITER ;

-- =============================================================================
-- Badminton: products (once), then the "growing fast" scenario
-- =============================================================================
SET @badminton := (SELECT id FROM admins WHERE LOWER(business_name) = 'badminton' AND status = 'active' AND is_platform = 0 ORDER BY id DESC LIMIT 1);

DROP PROCEDURE IF EXISTS seed_badminton_catalogue;
DELIMITER $$
CREATE PROCEDURE seed_badminton_catalogue(IN p_tenant BIGINT UNSIGNED)
BEGIN
  IF p_tenant IS NULL THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'No active store named "Badminton"';
  END IF;
  IF NOT EXISTS (SELECT 1 FROM products WHERE tenant_id = p_tenant) THEN
    -- Listed best seller first: order picks favour the first products.
    INSERT INTO products (tenant_id, sku_code, name, category, base_price, cost_price, status, description) VALUES
      (p_tenant, 'BDM-SH-001', 'Tournament Feather Shuttles (12)', 'Shuttlecocks', 42.00, 24.00, 'active', 'Goose-feather shuttles with a stable, true flight. Speed 77. Tube of 12.'),
      (p_tenant, 'BDM-RK-001', 'AeroStrike 88 Racket', 'Rackets', 189.00, 102.00, 'active', 'Head-heavy graphite racket for powerful smashes. 4U, strung at 26 lbs.'),
      (p_tenant, 'BDM-FW-001', 'CourtGrip Badminton Shoe', 'Footwear', 129.00, 64.00, 'active', 'Gum-rubber sole for sharp lunges and quick recovery on indoor courts.'),
      (p_tenant, 'BDM-SV-001', 'Court Booking – 1 Hour', 'Court & Coaching', 25.00, 8.00, 'active', 'One hour on a cushioned indoor court. Rackets available to borrow.'),
      (p_tenant, 'BDM-RK-002', 'Feather Pro 70 Racket', 'Rackets', 149.00, 78.00, 'active', 'Even-balance all-rounder with a fast swing. 5U, strung at 24 lbs.'),
      (p_tenant, 'BDM-SH-002', 'Training Nylon Shuttles (6)', 'Shuttlecocks', 15.00, 6.50, 'active', 'Durable nylon shuttles for drills and casual games.'),
      (p_tenant, 'BDM-ST-001', 'PowerString 66 (10 m)', 'Strings & Grips', 14.00, 5.00, 'active', 'Repulsion string with a crisp hitting sound. 0.66 mm.'),
      (p_tenant, 'BDM-ST-002', 'Overgrip Pack (3)', 'Strings & Grips', 12.00, 4.20, 'active', 'Tacky, sweat-absorbing overgrips. Assorted colours.'),
      (p_tenant, 'BDM-SV-002', 'Beginner Coaching Session', 'Court & Coaching', 60.00, 28.00, 'active', 'One-to-one hour with a certified coach: grip, footwork and basic strokes.'),
      (p_tenant, 'BDM-BG-001', 'Pro Racket Bag (6R)', 'Bags', 79.00, 38.00, 'active', 'Thermal-lined compartment for up to six rackets, plus a shoe pocket.'),
      (p_tenant, 'BDM-AP-001', 'Dry-Fit Club Jersey', 'Apparel', 35.00, 14.00, 'active', 'Light, quick-drying jersey in club colours.'),
      (p_tenant, 'BDM-FW-002', 'Lightstep Indoor Shoe', 'Footwear', 99.00, 49.00, 'active', 'Light and cushioned shoe for club players.'),
      (p_tenant, 'BDM-AP-002', 'Court Shorts', 'Apparel', 29.00, 11.00, 'active', 'Stretch shorts with deep pockets for shuttles.'),
      (p_tenant, 'BDM-RK-003', 'Junior Swift Racket', 'Rackets', 59.00, 27.00, 'active', 'Lighter, shorter racket for players aged 6 to 12.'),
      (p_tenant, 'BDM-SV-003', 'Kids Coaching (4 Weeks)', 'Court & Coaching', 160.00, 70.00, 'active', 'Four Saturday group sessions for young players.'),
      (p_tenant, 'BDM-BG-002', 'Court Backpack', 'Bags', 55.00, 24.00, 'active', 'Everyday backpack with a racket sleeve.'),
      (p_tenant, 'BDM-AP-003', 'Sports Socks (3 Pairs)', 'Apparel', 15.00, 5.00, 'active', 'Cushioned socks that grip inside the shoe.'),
      (p_tenant, 'BDM-RK-004', 'AeroStrike 88 "Night Edition"', 'Rackets', 209.00, 115.00, 'draft', 'Limited black-and-orange edition. Coming soon.');

    INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
    SELECT id, tenant_id,
           CASE WHEN category = 'Court & Coaching' THEN 500 ELSE 12 + FLOOR(RAND() * 50) END,
           CASE WHEN category = 'Court & Coaching' THEN 20 ELSE 8 END,
           UTC_TIMESTAMP() - INTERVAL FLOOR(10 + RAND() * 40) DAY
      FROM products WHERE tenant_id = p_tenant;

    -- Fresh to oldest in the shop: gear first, services after.
    UPDATE products
       SET created_at = UTC_TIMESTAMP() - INTERVAL (CASE category
             WHEN 'Rackets' THEN 2 WHEN 'Footwear' THEN 4 WHEN 'Shuttlecocks' THEN 6
             WHEN 'Strings & Grips' THEN 9 WHEN 'Bags' THEN 12 WHEN 'Apparel' THEN 15 ELSE 20 END) DAY - INTERVAL id MINUTE
     WHERE tenant_id = p_tenant;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM campaigns WHERE tenant_id = p_tenant) THEN
    INSERT INTO campaigns (tenant_id, name, type, status, audience_segment, sent_count, open_count, click_count, scheduled_at, created_at) VALUES
      (p_tenant, 'Grand Opening Week',             'social', 'completed', JSON_OBJECT('segment', 'local_followers'), 2600, 1180, 342, UTC_TIMESTAMP() - INTERVAL 27 DAY, UTC_TIMESTAMP() - INTERVAL 30 DAY),
      (p_tenant, 'Bring a Friend: Free Court Hour', 'email',  'running',   JSON_OBJECT('segment', 'all_customers'),    640,  301,  96, UTC_TIMESTAMP() - INTERVAL 12 DAY, UTC_TIMESTAMP() - INTERVAL 14 DAY),
      (p_tenant, 'Kids Coaching Term 2',           'email',  'scheduled', JSON_OBJECT('segment', 'parents'),            0,    0,   0, UTC_TIMESTAMP() + INTERVAL 5 DAY, UTC_TIMESTAMP() - INTERVAL 1 DAY),
      (p_tenant, 'Shuttle Restock Alert',          'push',   'draft',     NULL,                                         0,    0,   0, NULL, UTC_TIMESTAMP() - INTERVAL 3 HOUR);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM expenses WHERE tenant_id = p_tenant) THEN
    INSERT INTO expenses (tenant_id, category, description, amount, incurred_on) VALUES
      (p_tenant, 'rent',      'Hall rent (4 courts)',        4800.00, DATE_FORMAT(UTC_DATE(), '%Y-%m-01')),
      (p_tenant, 'wages',     'Coaches and front desk',      6200.00, DATE_FORMAT(UTC_DATE(), '%Y-%m-01')),
      (p_tenant, 'utilities', 'Electricity and air-con',      950.00, UTC_DATE() - INTERVAL 5 DAY),
      (p_tenant, 'marketing', 'Grand opening social ads',     600.00, UTC_DATE() - INTERVAL 28 DAY),
      (p_tenant, 'supplies',  'Shuttle restock (40 tubes)',  1050.00, UTC_DATE() - INTERVAL 9 DAY),
      (p_tenant, 'rent',      'Hall rent (4 courts)',        4800.00, DATE_FORMAT(UTC_DATE() - INTERVAL 1 MONTH, '%Y-%m-01')),
      (p_tenant, 'wages',     'Coaches and front desk',      5600.00, DATE_FORMAT(UTC_DATE() - INTERVAL 1 MONTH, '%Y-%m-01'));
  END IF;
END$$
DELIMITER ;
CALL seed_badminton_catalogue(@badminton);
DROP PROCEDURE IF EXISTS seed_badminton_catalogue;

DROP TEMPORARY TABLE IF EXISTS tmp_seed_topics;
CREATE TEMPORARY TABLE tmp_seed_topics (n INT PRIMARY KEY, subject VARCHAR(255), body TEXT);
INSERT INTO tmp_seed_topics VALUES
  (1, 'Shuttles out of stock?', 'Your Tournament Feather Shuttles have been sold out all week. We have a league match on Saturday. When are they back?'),
  (2, 'Racket I ordered is not shipping', 'I paid for the AeroStrike 88 four days ago and it still says confirmed. Is it actually in stock?'),
  (3, 'Need size 42 CourtGrip shoes', 'Can you tell me when the CourtGrip shoe in size 42 is back? It shows sold out.'),
  (4, 'Court booking clash', 'I booked court 2 for 8pm Friday but someone else was already playing. Please help.'),
  (5, 'Coaching schedule question', 'Is the beginner coaching available on weekday evenings?'),
  (6, 'Restringing service?', 'Do you restring rackets in store, and how long does it take?'),
  (7, 'Kids coaching age', 'My son is 6. Can he join the kids coaching sessions?'),
  (8, 'Invoice for club order', 'Our club bought 10 tubes of shuttles. Can you send an invoice with our club name?');

CALL seed_store_activity(
  @badminton, 'BDM',
  60,   0.5, 1.0, 2.6,     -- older / previous 30 days / this 30 days: orders per day (spike ≈ +150%)
  0.05, 0.05, 0.05,        -- cancelled or refunded share
  45,   60,  140,          -- product page views per day
  1.5, 'evening', 90, 4    -- busy weekends, evening peak, 90 customers, 4 urgent tickets open
);

-- Sold out: the three best sellers ran out after the rush (they sold this month).
UPDATE inventory i JOIN products p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
   SET i.qty_available = 0, i.last_restocked_at = UTC_TIMESTAMP() - INTERVAL 26 DAY
 WHERE i.tenant_id = @badminton AND p.sku_code IN ('BDM-SH-001', 'BDM-RK-001', 'BDM-FW-001');
-- Running low, so the low-stock alerts have something too.
UPDATE inventory i JOIN products p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
   SET i.qty_available = 4
 WHERE i.tenant_id = @badminton AND p.sku_code IN ('BDM-RK-002', 'BDM-SH-002');

-- =============================================================================
-- Sneaker Hoops: the "visitors stay, buyers leave" scenario
-- =============================================================================
SET @sneakers := (SELECT id FROM admins WHERE LOWER(business_name) = 'sneaker hoops' AND status = 'active' AND is_platform = 0 ORDER BY id DESC LIMIT 1);

DROP TEMPORARY TABLE IF EXISTS tmp_seed_topics;
CREATE TEMPORARY TABLE tmp_seed_topics (n INT PRIMARY KEY, subject VARCHAR(255), body TEXT);
INSERT INTO tmp_seed_topics VALUES
  (1, 'Wrong size delivered', 'I ordered a US 10 Court Rise Mid but received a US 9. I need to swap it before Saturday.'),
  (2, 'Sole separating after a week', 'The sole on my Outdoor Grind Pro is peeling at the toe after one week. I want a refund.'),
  (3, 'Sizes run small', 'Your Skyline High-Top runs a full size small. I had to return it. Please fix the size guide.'),
  (4, 'Refund still not received', 'I returned my order two weeks ago and still have not received my refund.'),
  (5, 'Checkout keeps failing', 'Payment failed three times at checkout, so I gave up. Is something wrong with the site?'),
  (6, 'Colour looks different from photo', 'The Retro Hoop sneaker is much darker than in the photos. I want to return it.'),
  (7, 'Where is my order?', 'My order was marked shipped five days ago but tracking has not moved.'),
  (8, 'Cancel my order', 'Please cancel my order, I found the same shoe cheaper elsewhere.');

CALL seed_store_activity(
  @sneakers, 'SNH',
  90,   2.6, 3.2, 1.7,     -- orders per day: steady, then down ≈ 45% this month
  0.07, 0.08, 0.30,        -- cancellations jump to ≈ 30%
  120,  150, 175,          -- visitors still rising: conversion falls
  1.2, 'lunch', 110, 2     -- lunchtime peak, 110 customers, 2 urgent tickets (below the alert)
);

-- Everything restocked, so the story is about buyers, not stock.
UPDATE inventory i JOIN products p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
   SET i.qty_available = GREATEST(i.qty_available, 18 + FLOOR(RAND() * 30)), i.last_restocked_at = UTC_TIMESTAMP() - INTERVAL 3 DAY
 WHERE i.tenant_id = @sneakers AND p.status = 'active';

DROP TEMPORARY TABLE IF EXISTS tmp_seed_topics;
DROP PROCEDURE IF EXISTS seed_store_activity;

-- Summary
SELECT a.business_name AS store,
       (SELECT COUNT(*) FROM products p WHERE p.tenant_id = a.id AND p.status = 'active') AS products,
       (SELECT COUNT(*) FROM orders o WHERE o.tenant_id = a.id AND o.placed_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY) AS orders_last_30d,
       (SELECT COUNT(*) FROM orders o WHERE o.tenant_id = a.id AND o.placed_at >= UTC_TIMESTAMP() - INTERVAL 60 DAY AND o.placed_at < UTC_TIMESTAMP() - INTERVAL 30 DAY) AS orders_prev_30d,
       (SELECT COUNT(*) FROM orders o WHERE o.tenant_id = a.id) AS orders_total,
       (SELECT COUNT(*) FROM support_tickets t WHERE t.tenant_id = a.id AND t.priority = 'urgent' AND t.status IN ('open','in_progress','pending_customer')) AS urgent_open
  FROM admins a WHERE a.id IN (@badminton, @sneakers);
