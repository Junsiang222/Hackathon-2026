-- =============================================================================
--  Multi-Tenant E-commerce CRM — Production Schema
--  Target: MySQL 8.0.16+ (CHECK constraints, expression defaults, DESC indexes,
--          roles). Verified against MySQL 8.4 LTS.
--
--  Run with the mysql CLI in batch mode (DELIMITER directives are CLI syntax):
--      mysql -u root -p < database/schema.sql
--  Batch mode aborts on the first error (do NOT pass --force), so a failed
--  statement stops the script instead of leaving later objects half-built.
-- =============================================================================
--
--  TRANSACTION / ERROR-HANDLING MODEL
--  ----------------------------------
--  MySQL cannot roll back DDL: every CREATE/ALTER/DROP issues an implicit
--  COMMIT, so wrapping DDL in START TRANSACTION gives a false sense of safety.
--  This script therefore uses the strongest guarantees MySQL actually offers:
--
--    1. DDL is idempotent (IF NOT EXISTS / CREATE OR REPLACE / DROP ... IF
--       EXISTS before re-create), so a script that aborted half-way can simply
--       be re-run after the cause is fixed.
--    2. All DML (the seed block) runs inside ONE real transaction in a stored
--       procedure with an EXIT HANDLER FOR SQLEXCEPTION that issues ROLLBACK
--       and RESIGNALs the original error, so seed data is all-or-nothing.
--    3. Batch-mode mysql aborts on the first error (see header).
--
--  REFERENTIAL-ACTION POLICY
--  -------------------------
--  * tenant_id -> admins.id is ON DELETE RESTRICT everywhere. Tenants are
--    soft-deleted (status = 'cancelled'); a hard delete must be a deliberate,
--    audited purge job, never a side effect of one DELETE statement.
--  * Child rows that have no meaning without their parent CASCADE
--    (order_items -> orders, inventory -> products).
--  * Anything that is financial or audit history RESTRICTs.
--  * Composite FKs on (tenant_id, <id>) make cross-tenant references
--    structurally impossible: an order can only point at a customer of the
--    SAME tenant, an order line only at a product of the SAME tenant, etc.
--
--  SUPER-ADMIN FINANCIAL ISOLATION (see section 6)
--  -----------------------------------------------
--  The super_admin application role connects with a dedicated MySQL account
--  that holds the `crm_super_admin_ro` role. That role is granted NOTHING on
--  orders, order_items, products, customers or any other table holding a
--  monetary DECIMAL column; it can read only the two column-restricted views.
-- =============================================================================

SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;
SET time_zone = '+00:00';               -- all DATETIMEs are stored as UTC
SET SESSION sql_mode = 'STRICT_ALL_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION,ONLY_FULL_GROUP_BY';

CREATE DATABASE IF NOT EXISTS crm_platform
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE crm_platform;

-- =============================================================================
-- 0. STATUS COLOUR MAPPING
--    Active/Paid -> #22C55E   Warning/Pending -> #DCFCE7   Structural -> #15803D
--    Column DEFAULTs encode the colour of each table's initial status; the
--    triggers in section 5 keep status_color in sync when status changes.
-- =============================================================================

DROP FUNCTION IF EXISTS fn_status_color;

DELIMITER $$
CREATE FUNCTION fn_status_color(p_status VARCHAR(32))
RETURNS VARCHAR(10)
DETERMINISTIC
NO SQL
COMMENT 'Maps any status enum value to its UI badge colour'
BEGIN
  RETURN CASE
    -- Active / Paid
    WHEN p_status IN ('active', 'confirmed', 'shipped', 'delivered', 'running', 'resolved')
      THEN '#22C55E'
    -- Warning / Pending
    WHEN p_status IN ('pending', 'suspended', 'draft', 'scheduled', 'paused',
                      'open', 'in_progress', 'pending_customer')
      THEN '#DCFCE7'
    -- Structural / terminal (cancelled, refunded, completed, closed, archived, ...)
    ELSE '#15803D'
  END;
END$$
DELIMITER ;

-- =============================================================================
-- 1. MULTI-TENANT DIRECTORY
-- =============================================================================

CREATE TABLE IF NOT EXISTS admins (
  id              BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT,
  tenant_uid      VARCHAR(36)      NOT NULL DEFAULT (UUID()),
  business_name   VARCHAR(255)     NOT NULL,
  industry        ENUM('retail','fashion','electronics','food','health','other') NOT NULL,
  plan            ENUM('starter','growth','enterprise') NOT NULL DEFAULT 'starter',
  status          ENUM('active','suspended','cancelled') NOT NULL DEFAULT 'active',
  status_color    VARCHAR(10)      NOT NULL DEFAULT '#22C55E',   -- 'active' => Active/Paid
  -- Marks the single internal row that owns platform staff (super_admins).
  -- Excluded from tenant listings and from dashboard generation.
  is_platform     TINYINT(1)       NOT NULL DEFAULT 0,
  registered_at   DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  trial_ends_at   DATETIME         NULL,
  created_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_admins_tenant_uid (tenant_uid),
  KEY idx_admins_status_created (status, created_at DESC),
  KEY idx_admins_trial_ends (trial_ends_at),
  CONSTRAINT chk_admins_status_color CHECK (status_color REGEXP '^#[0-9A-Fa-f]{6}$'),
  CONSTRAINT chk_admins_is_platform  CHECK (is_platform IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='One row per tenant (merchant business)';

-- =============================================================================
-- 2. AUTHENTICATION
-- =============================================================================

CREATE TABLE IF NOT EXISTS users (
  id                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id            BIGINT UNSIGNED NOT NULL,
  role                 ENUM('super_admin','admin','staff') NOT NULL,
  email                VARCHAR(320)    NOT NULL,
  password_hash        VARCHAR(255)    NULL COMMENT 'bcrypt/argon2; NULL for pure OAuth users',
  must_change_password TINYINT(1)      NOT NULL DEFAULT 0 COMMENT '1 = signed in with a temporary password; must set their own',
  oauth_provider       ENUM('google','facebook') NULL,
  oauth_provider_id    VARCHAR(255)    NULL,
  -- SECURITY: provider tokens are credentials. Encrypt at the application
  -- layer (envelope encryption / KMS) before writing; never store plaintext.
  oauth_access_token   TEXT            NULL,
  oauth_refresh_token  TEXT            NULL,
  oauth_token_expiry   DATETIME        NULL,
  -- The API stores SHA-256(refresh token) here, never the raw token, so a
  -- leaked row cannot be replayed as a session.
  session_token        VARCHAR(512)    NULL COMMENT 'Hash of the active opaque refresh token',
  last_login_at        DATETIME        NULL,
  last_logout_at       DATETIME        NULL,
  is_active            TINYINT(1)      NOT NULL DEFAULT 1,
  created_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_email_per_tenant (tenant_id, email),        -- also serves fk_users_tenant
  UNIQUE KEY uq_users_tenant_id (tenant_id, id),             -- target for same-tenant composite FKs
  UNIQUE KEY uq_users_oauth_identity (oauth_provider, oauth_provider_id),
  KEY idx_users_session_token (session_token),
  KEY idx_users_email (email),                               -- login lookup across tenants
  CONSTRAINT fk_users_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    -- RESTRICT: user accounts are deactivated (is_active = 0), never removed
    -- implicitly by deleting their tenant.
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_users_has_credential
    CHECK (password_hash IS NOT NULL OR oauth_provider IS NOT NULL),
  CONSTRAINT chk_users_oauth_pair
    CHECK ((oauth_provider IS NULL) = (oauth_provider_id IS NULL)),
  CONSTRAINT chk_users_is_active CHECK (is_active IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 3. AI DASHBOARD LAYOUTS
-- =============================================================================

CREATE TABLE IF NOT EXISTS dashboard_layouts (
  id           BIGINT UNSIGNED   NOT NULL AUTO_INCREMENT,
  tenant_id    BIGINT UNSIGNED   NOT NULL,
  layout_name  VARCHAR(100)      NOT NULL,
  config_json  JSON              NOT NULL COMMENT 'AI-compiled WidgetConfig[]',
  setup_json   JSON              NULL     COMMENT 'Wizard answers: {storeName, modules, analyticsCharts}',
  version      SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  is_active    TINYINT(1)        NOT NULL DEFAULT 1,
  created_by   BIGINT UNSIGNED   NOT NULL,
  created_at   DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_layouts_tenant_version (tenant_id, version),   -- also serves fk_layouts_tenant
  KEY idx_layouts_tenant_active (tenant_id, is_active, version DESC),
  KEY idx_layouts_created_by (created_by),
  CONSTRAINT fk_layouts_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,               -- tenant policy (see header)
  CONSTRAINT fk_layouts_created_by
    FOREIGN KEY (created_by) REFERENCES users (id)
    -- RESTRICT: authorship is audit data. Plain (non-composite) FK because the
    -- author is platform staff who belong to the platform tenant, not this one.
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_layouts_config_is_array CHECK (JSON_TYPE(config_json) = 'ARRAY'),
  CONSTRAINT chk_layouts_is_active CHECK (is_active IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 4. CORE MODULAR TABLES
-- =============================================================================

-- ---------------------------------------------------------------- customers --
CREATE TABLE IF NOT EXISTS customers (
  id                   BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id            BIGINT UNSIGNED NOT NULL,
  full_name            VARCHAR(255)    NOT NULL,
  email                VARCHAR(320)    NULL,
  phone                VARCHAR(32)     NULL,
  -- Online shop account (NULL password_hash = guest). Never exposed to super_admin.
  password_hash        VARCHAR(255)    NULL COMMENT 'bcrypt; NULL = guest (no shop account)',
  session_token        CHAR(64)        NULL COMMENT 'SHA-256 of the shop session token; NULL = signed out',
  session_expires_at   DATETIME        NULL,
  account_created_at   DATETIME        NULL COMMENT 'When the shopper registered; earlier guest orders stay private',
  last_login_at        DATETIME        NULL,
  acquisition_channel VARCHAR(50)     NULL COMMENT 'e.g. organic, paid_social, referral',
  -- Lifecycle status (added so the required (tenant_id, status) index has a
  -- meaningful column to cover).
  status               ENUM('active','inactive','blocked') NOT NULL DEFAULT 'active',
  total_orders         INT UNSIGNED    NOT NULL DEFAULT 0,
  ltv                  DECIMAL(12,4)   NOT NULL DEFAULT 0.0000 COMMENT 'FINANCIAL — never exposed to super_admin',
  last_active_at       DATETIME        NULL,
  created_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at           DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_customers_tenant_id (tenant_id, id),          -- target for composite FKs
  UNIQUE KEY uq_customers_tenant_email (tenant_id, email),
  KEY idx_customers_tenant_status (tenant_id, status),        -- also serves fk_customers_tenant
  KEY idx_customers_tenant_created (tenant_id, created_at DESC),
  KEY idx_customers_tenant_last_active (tenant_id, last_active_at DESC),
  KEY idx_customers_session (session_token),
  CONSTRAINT fk_customers_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_customers_ltv CHECK (ltv >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------- products --
CREATE TABLE IF NOT EXISTS products (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id    BIGINT UNSIGNED NOT NULL,
  sku_code     VARCHAR(64)     NOT NULL,
  name         VARCHAR(255)    NOT NULL,
  category     VARCHAR(100)    NULL,
  base_price   DECIMAL(12,4)   NOT NULL COMMENT 'FINANCIAL — never exposed to super_admin',
  cost_price   DECIMAL(12,4)   NULL     COMMENT 'FINANCIAL — never exposed to super_admin',
  status       ENUM('active','archived','draft') NOT NULL DEFAULT 'draft',
  status_color VARCHAR(10)     NOT NULL DEFAULT '#DCFCE7',      -- 'draft' => Warning/Pending
  image_url    VARCHAR(2048)   NULL,
  description  TEXT            NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_products_tenant_id (tenant_id, id),           -- target for composite FKs
  UNIQUE KEY uq_products_tenant_sku (tenant_id, sku_code),    -- also serves fk_products_tenant
  KEY idx_products_tenant_status (tenant_id, status),
  KEY idx_products_tenant_category (tenant_id, category),
  CONSTRAINT fk_products_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_products_base_price CHECK (base_price >= 0),
  CONSTRAINT chk_products_cost_price CHECK (cost_price IS NULL OR cost_price >= 0),
  CONSTRAINT chk_products_status_color CHECK (status_color REGEXP '^#[0-9A-Fa-f]{6}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- inventory --
CREATE TABLE IF NOT EXISTS inventory (
  id                 BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  product_id         BIGINT UNSIGNED NOT NULL,
  tenant_id          BIGINT UNSIGNED NOT NULL,
  qty_available      INT UNSIGNED    NOT NULL DEFAULT 0,
  qty_reserved       INT UNSIGNED    NOT NULL DEFAULT 0,
  restock_threshold  INT UNSIGNED    NOT NULL DEFAULT 10,
  last_restocked_at  DATETIME        NULL,
  created_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_inventory_product (product_id),               -- exactly one stock row per product
  KEY idx_inventory_tenant_product (tenant_id, product_id),   -- serves fk_inventory_product + fk_inventory_tenant
  KEY idx_inventory_tenant_qty (tenant_id, qty_available),    -- low-stock scans
  CONSTRAINT fk_inventory_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_inventory_product
    FOREIGN KEY (tenant_id, product_id) REFERENCES products (tenant_id, id)
    -- CASCADE: a stock row is meaningless once its product is gone. (Products
    -- with sales history cannot be deleted anyway — see fk_order_items_product.)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------------- orders --
CREATE TABLE IF NOT EXISTS orders (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id     BIGINT UNSIGNED NOT NULL,
  customer_id   BIGINT UNSIGNED NOT NULL,
  order_ref     VARCHAR(32)     NOT NULL,
  status        ENUM('pending','confirmed','shipped','delivered','cancelled','refunded') NOT NULL DEFAULT 'pending',
  status_color  VARCHAR(10)     NOT NULL DEFAULT '#DCFCE7',     -- 'pending' => Warning/Pending
  total_amount  DECIMAL(12,4)   NOT NULL DEFAULT 0.0000 COMMENT 'FINANCIAL — never exposed to super_admin',
  currency      CHAR(3)         NOT NULL DEFAULT 'USD' COMMENT 'ISO 4217',
  shipping_address TEXT         NULL     COMMENT 'Delivery address entered at online checkout',
  placed_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fulfilled_at  DATETIME        NULL,
  created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  UNIQUE KEY uq_orders_order_ref (order_ref),
  UNIQUE KEY uq_orders_tenant_id (tenant_id, id),             -- target for composite FKs
  KEY idx_orders_tenant_status (tenant_id, status),           -- also serves fk_orders_tenant
  KEY idx_orders_tenant_created (tenant_id, created_at DESC),
  KEY idx_orders_tenant_placed (tenant_id, placed_at),        -- analytics time series
  KEY idx_orders_tenant_customer (tenant_id, customer_id),    -- serves fk_orders_customer
  CONSTRAINT fk_orders_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_orders_customer
    FOREIGN KEY (tenant_id, customer_id) REFERENCES customers (tenant_id, id)
    -- RESTRICT: orders are financial records; a customer with order history
    -- must be anonymised, not deleted.
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_orders_total CHECK (total_amount >= 0),
  CONSTRAINT chk_orders_currency CHECK (currency REGEXP '^[A-Z]{3}$'),
  CONSTRAINT chk_orders_fulfilled CHECK (fulfilled_at IS NULL OR fulfilled_at >= placed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------- order_items --
CREATE TABLE IF NOT EXISTS order_items (
  id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  -- Denormalised tenant_id exists only so both FKs below can be composite
  -- (tenant_id, ...) and therefore same-tenant by construction.
  tenant_id   BIGINT UNSIGNED NOT NULL,
  order_id    BIGINT UNSIGNED NOT NULL,
  product_id  BIGINT UNSIGNED NOT NULL,
  qty         INT UNSIGNED    NOT NULL,
  unit_price  DECIMAL(12,4)   NOT NULL COMMENT 'FINANCIAL — never exposed to super_admin',
  subtotal    DECIMAL(12,4)   NOT NULL COMMENT 'FINANCIAL — never exposed to super_admin',
  created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_order_items_order (tenant_id, order_id),            -- serves fk_order_items_order + tenant
  KEY idx_order_items_product (tenant_id, product_id),        -- serves fk_order_items_product
  CONSTRAINT fk_order_items_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_order_items_order
    FOREIGN KEY (tenant_id, order_id) REFERENCES orders (tenant_id, id)
    -- CASCADE: line items have no meaning without their order header.
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_order_items_product
    FOREIGN KEY (tenant_id, product_id) REFERENCES products (tenant_id, id)
    -- RESTRICT: preserves sales history; sold products are archived instead.
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_order_items_qty CHECK (qty > 0),
  CONSTRAINT chk_order_items_unit_price CHECK (unit_price >= 0),
  CONSTRAINT chk_order_items_subtotal CHECK (subtotal = qty * unit_price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------- campaigns --
CREATE TABLE IF NOT EXISTS campaigns (
  id                BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id         BIGINT UNSIGNED NOT NULL,
  name              VARCHAR(255)    NOT NULL,
  type              ENUM('email','sms','push','social') NOT NULL,
  status            ENUM('draft','scheduled','running','paused','completed') NOT NULL DEFAULT 'draft',
  status_color      VARCHAR(10)     NOT NULL DEFAULT '#DCFCE7',  -- 'draft' => Warning/Pending
  audience_segment  JSON            NULL COMMENT 'Segment filter definition',
  sent_count        INT UNSIGNED    NOT NULL DEFAULT 0,
  open_count        INT UNSIGNED    NOT NULL DEFAULT 0,
  click_count       INT UNSIGNED    NOT NULL DEFAULT 0,
  scheduled_at      DATETIME        NULL,
  created_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_campaigns_tenant_status (tenant_id, status),        -- also serves fk_campaigns_tenant
  KEY idx_campaigns_tenant_scheduled (tenant_id, scheduled_at),
  KEY idx_campaigns_tenant_created (tenant_id, created_at DESC),
  CONSTRAINT fk_campaigns_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_campaigns_segment CHECK (audience_segment IS NULL OR JSON_TYPE(audience_segment) = 'OBJECT')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------- support_tickets --
CREATE TABLE IF NOT EXISTS support_tickets (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id     BIGINT UNSIGNED NOT NULL,
  customer_id   BIGINT UNSIGNED NOT NULL,
  assigned_to   BIGINT UNSIGNED NULL,
  subject       VARCHAR(255)    NOT NULL,
  body          TEXT            NOT NULL,
  priority      ENUM('low','medium','high','urgent') NOT NULL DEFAULT 'medium',
  status        ENUM('open','in_progress','pending_customer','resolved','closed') NOT NULL DEFAULT 'open',
  status_color  VARCHAR(10)     NOT NULL DEFAULT '#DCFCE7',      -- 'open' => Warning/Pending
  channel       ENUM('email','chat','phone') NOT NULL,
  created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  resolved_at   DATETIME        NULL,

  PRIMARY KEY (id),
  KEY idx_tickets_tenant_status (tenant_id, status),          -- also serves fk_tickets_tenant
  KEY idx_tickets_tenant_created (tenant_id, created_at DESC),
  KEY idx_tickets_tenant_priority (tenant_id, priority, status),
  KEY idx_tickets_tenant_customer (tenant_id, customer_id),   -- serves fk_tickets_customer
  KEY idx_tickets_assigned_to (assigned_to),                  -- serves fk_tickets_assigned_to
  CONSTRAINT fk_tickets_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_tickets_customer
    FOREIGN KEY (tenant_id, customer_id) REFERENCES customers (tenant_id, id)
    -- RESTRICT: tickets are part of the customer's service history.
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_tickets_assigned_to
    FOREIGN KEY (assigned_to) REFERENCES users (id)
    -- SET NULL: if a staff account is removed the ticket returns to the
    -- unassigned queue instead of blocking the delete or vanishing. A
    -- composite FK can't be used with SET NULL (tenant_id is NOT NULL), so the
    -- same-tenant rule is enforced by trg_tickets_bi / trg_tickets_bu.
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_tickets_resolved CHECK (resolved_at IS NULL OR resolved_at >= created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------- analytics_logs --
-- High-volume append-only event stream. At scale, move to RANGE partitioning
-- on recorded_at (which requires dropping the FK — partitioned InnoDB tables
-- cannot have foreign keys) or ship events to a columnar store.
CREATE TABLE IF NOT EXISTS analytics_logs (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id    BIGINT UNSIGNED NOT NULL,
  event_type   VARCHAR(100)    NOT NULL COMMENT 'e.g. page_view, add_to_cart, checkout_started',
  entity_type  VARCHAR(50)     NULL     COMMENT 'e.g. product, order, customer',
  entity_id    BIGINT UNSIGNED NULL,
  metadata     JSON            NULL,
  recorded_at  DATETIME(3)     NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  PRIMARY KEY (id),
  -- This table has no status / created_at columns: event_type is its
  -- "status" dimension and recorded_at its creation timestamp, so these are
  -- the required (tenant_id, status) and (tenant_id, created_at DESC) indexes.
  KEY idx_analytics_tenant_event (tenant_id, event_type, recorded_at),   -- also serves fk_analytics_tenant
  KEY idx_analytics_tenant_recorded (tenant_id, recorded_at DESC),
  KEY idx_analytics_entity (tenant_id, entity_type, entity_id),
  CONSTRAINT fk_analytics_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT chk_analytics_metadata CHECK (metadata IS NULL OR JSON_TYPE(metadata) = 'OBJECT')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------- expenses --
-- What running the store costs (rent, wages, …), entered by the store admin.
-- FINANCIAL and tenant-only: the super admin role has no grant on it.
CREATE TABLE IF NOT EXISTS expenses (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tenant_id    BIGINT UNSIGNED NOT NULL,
  category     ENUM('rent','wages','utilities','marketing','supplies','shipping','software','other') NOT NULL,
  description  VARCHAR(255)    NULL,
  amount       DECIMAL(12,4)   NOT NULL COMMENT 'FINANCIAL — never exposed to super_admin',
  incurred_on  DATE            NOT NULL,
  created_by   BIGINT UNSIGNED NULL,
  created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (id),
  KEY idx_expenses_tenant_incurred (tenant_id, incurred_on DESC),   -- also serves fk_expenses_tenant
  KEY idx_expenses_tenant_category (tenant_id, category),
  KEY idx_expenses_created_by (created_by),
  CONSTRAINT fk_expenses_tenant
    FOREIGN KEY (tenant_id) REFERENCES admins (id)
    ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_expenses_created_by
    FOREIGN KEY (created_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT chk_expenses_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------- user_preferences --
-- Per-account dashboard preferences (language, time display, analytics defaults).
CREATE TABLE IF NOT EXISTS user_preferences (
  user_id          BIGINT UNSIGNED NOT NULL,
  display_name     VARCHAR(60)     NULL COMMENT 'Shown in the profile menu; NULL = derived from the email',
  language         ENUM('en','ms','zh') NOT NULL DEFAULT 'en',
  time_display     ENUM('local','utc')  NOT NULL DEFAULT 'local',
  default_period   ENUM('today','7d','30d','month','90d') NOT NULL DEFAULT '30d',
  refresh_seconds  SMALLINT UNSIGNED NOT NULL DEFAULT 60 COMMENT '0 = no auto-refresh',
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (user_id),
  CONSTRAINT fk_user_preferences_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT chk_user_preferences_refresh CHECK (refresh_seconds IN (0, 30, 60, 300))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------- platform_settings --
-- Platform-wide options set by the super admin (AI website language, storefront currency).
CREATE TABLE IF NOT EXISTS platform_settings (
  setting_key    VARCHAR(64)     NOT NULL,
  setting_value  JSON            NOT NULL,
  updated_by     BIGINT UNSIGNED NULL,
  updated_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  PRIMARY KEY (setting_key),
  CONSTRAINT fk_platform_settings_user
    FOREIGN KEY (updated_by) REFERENCES users (id)
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO platform_settings (setting_key, setting_value) VALUES
  ('website_language', JSON_QUOTE('en')),
  ('store_currency',   JSON_QUOTE('USD'));

-- ---------------------------------------------------- stripped_fields_audit --
-- Written by the API's financialStripper middleware whenever it removes a
-- monetary-looking key from a super_admin response. Any row here means an
-- upstream layer leaked and should be investigated.
CREATE TABLE IF NOT EXISTS stripped_fields_audit (
  id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id   VARCHAR(36)     NOT NULL,
  user_id      BIGINT UNSIGNED NULL,
  http_method  VARCHAR(10)     NOT NULL,
  route        VARCHAR(255)    NOT NULL,
  field_path   VARCHAR(512)    NOT NULL,
  stripped_at  DATETIME(3)     NOT NULL DEFAULT CURRENT_TIMESTAMP(3),

  PRIMARY KEY (id),
  KEY idx_stripped_audit_time (stripped_at DESC),
  KEY idx_stripped_audit_user (user_id),                      -- serves fk_stripped_audit_user
  CONSTRAINT fk_stripped_audit_user
    FOREIGN KEY (user_id) REFERENCES users (id)
    -- SET NULL: the audit trail must outlive the account that triggered it.
    ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =============================================================================
-- 5. TRIGGERS — status_color sync + same-tenant ticket assignment
-- =============================================================================

DROP TRIGGER IF EXISTS trg_admins_bi;
DROP TRIGGER IF EXISTS trg_admins_bu;
DROP TRIGGER IF EXISTS trg_products_bi;
DROP TRIGGER IF EXISTS trg_products_bu;
DROP TRIGGER IF EXISTS trg_orders_bi;
DROP TRIGGER IF EXISTS trg_orders_bu;
DROP TRIGGER IF EXISTS trg_campaigns_bi;
DROP TRIGGER IF EXISTS trg_campaigns_bu;
DROP TRIGGER IF EXISTS trg_tickets_bi;
DROP TRIGGER IF EXISTS trg_tickets_bu;

DELIMITER $$

CREATE TRIGGER trg_admins_bi BEFORE INSERT ON admins FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$
CREATE TRIGGER trg_admins_bu BEFORE UPDATE ON admins FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$

CREATE TRIGGER trg_products_bi BEFORE INSERT ON products FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$
CREATE TRIGGER trg_products_bu BEFORE UPDATE ON products FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$

CREATE TRIGGER trg_orders_bi BEFORE INSERT ON orders FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$
CREATE TRIGGER trg_orders_bu BEFORE UPDATE ON orders FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$

CREATE TRIGGER trg_campaigns_bi BEFORE INSERT ON campaigns FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$
CREATE TRIGGER trg_campaigns_bu BEFORE UPDATE ON campaigns FOR EACH ROW
  SET NEW.status_color = fn_status_color(NEW.status)$$

CREATE TRIGGER trg_tickets_bi BEFORE INSERT ON support_tickets FOR EACH ROW
BEGIN
  IF NEW.assigned_to IS NOT NULL AND NOT EXISTS (
       SELECT 1 FROM users u WHERE u.id = NEW.assigned_to AND u.tenant_id = NEW.tenant_id
     ) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'support_tickets.assigned_to must belong to the same tenant';
  END IF;
  SET NEW.status_color = fn_status_color(NEW.status);
END$$

CREATE TRIGGER trg_tickets_bu BEFORE UPDATE ON support_tickets FOR EACH ROW
BEGIN
  IF NEW.assigned_to IS NOT NULL
     AND NOT (NEW.assigned_to <=> OLD.assigned_to AND NEW.tenant_id = OLD.tenant_id)
     AND NOT EXISTS (
       SELECT 1 FROM users u WHERE u.id = NEW.assigned_to AND u.tenant_id = NEW.tenant_id
     ) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'support_tickets.assigned_to must belong to the same tenant';
  END IF;
  SET NEW.status_color = fn_status_color(NEW.status);
END$$

DELIMITER ;

-- =============================================================================
-- 6. STRICT DATA SECURITY & ISOLATION — SUPER ADMIN VIEWS
--
--  These are the ONLY order/product data surfaces the super_admin role can
--  read. SQL SECURITY DEFINER lets the restricted role read the view without
--  holding any privilege on the underlying base tables.
--
--  FINANCIAL EXCLUSION (deliberate, do not "fix"):
--    * orders.total_amount        — excluded from super_admin_order_view
--    * products.base_price        — excluded from super_admin_product_view
--    * order_items.unit_price / subtotal, customers.ltv
--                                 — no view exists; role has no grant
--  No view, stored procedure or function in this schema joins any of those
--  columns into a super_admin-readable object. Adding one requires a security
--  review.
-- =============================================================================

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_order_view AS
  SELECT id, tenant_id, customer_id, order_ref, status, currency,
         placed_at, fulfilled_at
  FROM orders;
  -- Intentionally excludes: total_amount (FINANCIAL)

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_product_view AS
  SELECT id, tenant_id, sku_code, name, category, status, image_url
  FROM products;
  -- Intentionally excludes: base_price (FINANCIAL)

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_store_admin_view AS
  SELECT id AS user_id, tenant_id, email, role, oauth_provider,
         password_hash IS NOT NULL AS has_password,  -- a yes/no flag, never the hash
         must_change_password,
         is_active, last_login_at, created_at
  FROM users
  WHERE role IN ('admin', 'staff');
  -- Intentionally excludes: password_hash, session_token, oauth_* tokens

-- Platform analytics (counts only): no money, no customer personal data.
CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_order_item_view AS
  SELECT id, tenant_id, order_id, product_id, qty, created_at
  FROM order_items;
  -- Intentionally excludes: unit_price, subtotal (FINANCIAL)

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_inventory_view AS
  SELECT tenant_id, product_id, qty_available, restock_threshold, last_restocked_at
  FROM inventory;

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_customer_view AS
  SELECT id, tenant_id, status, acquisition_channel, created_at, last_active_at
  FROM customers;
  -- Intentionally excludes: ltv (FINANCIAL); full_name, email, phone, password_hash, session_*

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_ticket_view AS
  SELECT id, tenant_id, priority, status, channel, created_at, resolved_at
  FROM support_tickets;
  -- Intentionally excludes: subject, body (customer messages), customer_id

CREATE OR REPLACE
  ALGORITHM = MERGE
  SQL SECURITY DEFINER
  VIEW super_admin_traffic_view AS
  SELECT tenant_id, event_type, entity_type, entity_id, recorded_at
  FROM analytics_logs;
  -- Intentionally excludes: metadata (free-form)

-- =============================================================================
-- 7. DATABASE ROLES
--
--  crm_app_rw         — tenant-scoped API traffic (admin / staff routes, auth).
--  crm_super_admin_ro — super_admin API traffic. Grants are an explicit
--                       allow-list; it has NO privilege on orders,
--                       order_items, products, customers, inventory,
--                       campaigns, support_tickets or analytics_logs; on users
--                       only what a password reset needs (never the hash).
--
--  Create the login accounts outside this script so no password is ever
--  committed to source control, e.g.:
--    CREATE USER 'crm_app'@'%'        IDENTIFIED BY '<secret>';
--    CREATE USER 'crm_superadmin'@'%' IDENTIFIED BY '<secret>';
--    GRANT crm_app_rw         TO 'crm_app'@'%';
--    GRANT crm_super_admin_ro TO 'crm_superadmin'@'%';
--    SET DEFAULT ROLE ALL TO 'crm_app'@'%', 'crm_superadmin'@'%';
-- =============================================================================

CREATE ROLE IF NOT EXISTS 'crm_app_rw', 'crm_super_admin_ro';

GRANT SELECT, INSERT, UPDATE, DELETE ON crm_platform.* TO 'crm_app_rw';
GRANT EXECUTE ON FUNCTION crm_platform.fn_status_color TO 'crm_app_rw';

-- Super admin allow-list -------------------------------------------------------
GRANT SELECT ON crm_platform.super_admin_order_view   TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_product_view TO 'crm_super_admin_ro';
-- Tenant directory: contains no monetary columns.
GRANT SELECT ON crm_platform.admins                   TO 'crm_super_admin_ro';
-- Removing a store is a soft delete (status = 'cancelled').
GRANT UPDATE (status, status_color) ON crm_platform.admins TO 'crm_super_admin_ro';
-- AI layout generation: read history, insert new versions, flip is_active.
GRANT SELECT, INSERT ON crm_platform.dashboard_layouts TO 'crm_super_admin_ro';
GRANT UPDATE (is_active) ON crm_platform.dashboard_layouts TO 'crm_super_admin_ro';
-- financialStripper audit trail (write-only).
GRANT INSERT ON crm_platform.stripped_fields_audit    TO 'crm_super_admin_ro';
-- Store logins: read emails via the view; reset a password by OVERWRITING the
-- hash (it can never read one) and clearing the session.
GRANT SELECT ON crm_platform.super_admin_store_admin_view TO 'crm_super_admin_ro';
GRANT SELECT (id, tenant_id, role), UPDATE (password_hash, session_token, must_change_password) ON crm_platform.users TO 'crm_super_admin_ro';
-- A new store's first admin login (temporary password) is created with its website.
GRANT INSERT (tenant_id, role, email, password_hash, must_change_password) ON crm_platform.users TO 'crm_super_admin_ro';
-- Platform analytics: counts only, through the money-free views above.
GRANT SELECT ON crm_platform.super_admin_order_item_view TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_inventory_view  TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_customer_view   TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_ticket_view     TO 'crm_super_admin_ro';
GRANT SELECT ON crm_platform.super_admin_traffic_view    TO 'crm_super_admin_ro';
-- Settings: own dashboard preferences and platform-wide options.
GRANT SELECT, INSERT, UPDATE ON crm_platform.user_preferences  TO 'crm_super_admin_ro';
GRANT SELECT, INSERT, UPDATE ON crm_platform.platform_settings TO 'crm_super_admin_ro';
-- (Intentionally NO other grant on users, and none on orders, order_items, products, customers,
--  inventory, campaigns, support_tickets, analytics_logs or expenses.)

-- =============================================================================
-- 8. SEED — local development bootstrap ONLY
--
--  Creates: 1 platform row (owner of staff accounts), 2 demo tenants,
--           1 super_admin user.
--  Dev login:  superadmin@crm.local  /  ChangeMe!SuperAdmin2026
--  The hash below is bcrypt (cost 12) of that password. Never run this block
--  against production; rotate or delete the account in any shared env.
--
--  Atomic: runs in one transaction; any error rolls everything back and the
--  original error is re-raised (so batch-mode mysql aborts with it).
--  Idempotent: fixed tenant_uids + INSERT IGNORE make re-runs a no-op.
-- =============================================================================

DROP PROCEDURE IF EXISTS sp_seed_dev;

DELIMITER $$
CREATE PROCEDURE sp_seed_dev()
BEGIN
  DECLARE v_platform_id BIGINT UNSIGNED;

  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
    ROLLBACK;     -- undo every seed row written so far
    RESIGNAL;     -- surface the original error to the client
  END;

  START TRANSACTION;

  INSERT IGNORE INTO admins (tenant_uid, business_name, industry, plan, status, is_platform)
  VALUES ('00000000-0000-4000-8000-000000000001', 'CRM Platform Operations', 'other', 'enterprise', 'active', 1);

  INSERT IGNORE INTO admins (tenant_uid, business_name, industry, plan, status, trial_ends_at)
  VALUES
    ('11111111-1111-4111-8111-111111111111', 'Urban Thread Co.', 'fashion',     'growth',  'active', NULL),
    ('22222222-2222-4222-8222-222222222222', 'Volt Electronics', 'electronics', 'starter', 'active', UTC_TIMESTAMP() + INTERVAL 14 DAY);

  SELECT id INTO v_platform_id
  FROM admins WHERE tenant_uid = '00000000-0000-4000-8000-000000000001';

  INSERT IGNORE INTO users (tenant_id, role, email, password_hash, is_active)
  VALUES (
    v_platform_id,
    'super_admin',
    'superadmin@crm.local',
    '$2b$12$4nWnq0oTJfWnuG4MBhTBSuBLtZuLKGfM61tFmNEMJAsoblRdKD/d6',
    1
  );

  COMMIT;
END$$
DELIMITER ;

CALL sp_seed_dev();
DROP PROCEDURE IF EXISTS sp_seed_dev;

-- ============================================================ end of script ==
