# Verdant CRM — multi-tenant e-commerce CRM

```
database/schema.sql   MySQL 8 DDL: tables, triggers, super-admin views, DB roles, dev seed
backend/              Express + TypeScript API (auth, superadmin, admin, dashboard modules)
frontend/             React 18 + Vite + Tailwind 3 + Framer Motion 11 + Recharts client
```

## 1. Database

```bash
mysql -u root -p < database/schema.sql          # idempotent; safe to re-run
```

Then create the two login accounts (passwords never live in the repo):

```sql
CREATE USER 'crm_app'@'%'        IDENTIFIED BY '<secret>';
CREATE USER 'crm_superadmin'@'%' IDENTIFIED BY '<secret>';
GRANT crm_app_rw         TO 'crm_app'@'%';
GRANT crm_super_admin_ro TO 'crm_superadmin'@'%';
SET DEFAULT ROLE ALL TO 'crm_app'@'%', 'crm_superadmin'@'%';
```

`crm_superadmin` can read only `admins`, `dashboard_layouts` and the two
`super_admin_*` views. MySQL itself rejects any query it makes against
`orders`, `products`, `order_items` or `customers`, including joins through the views.

## 2. API

```bash
cd backend
cp .env.example .env    # fill DB passwords, two 64-byte JWT secrets, OPENAI_API_KEY
npm install
npm run dev             # http://localhost:4000
```

## 3. Web app

```bash
cd frontend
npm install
npm run dev             # http://localhost:5173 (proxies /api → :4000)
```

Dev super-admin login (from the seed): `superadmin@crm.local` / `ChangeMe!SuperAdmin2026`.
Rotate it anywhere that isn't your laptop.

## Financial isolation: three independent layers

1. **Database:** the super-admin MySQL account has no grant on any table with a money column.
2. **API:** `financialStripper` removes `price|amount|revenue|profit|margin|cost|ltv|total|earning` keys
   from every super-admin response and logs each one to `stripped_fields_audit`.
3. **Client:** `sanitizeWidgetData()` strips the same keys before any chart renders, for every role.
   AI-generated widgets are also re-validated against an allowlisted data-source catalog on the server.
