import rateLimit from 'express-rate-limit';
import { buildErrorEnvelope } from '../utils/apiResponse';

const ONE_MINUTE_MS = 60 * 1000;

function limiter(limit: number, message: string) {
  return rateLimit({
    windowMs: ONE_MINUTE_MS,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res, _next, options) => {
      res
        .status(options.statusCode)
        .json(buildErrorEnvelope({ code: 'RATE_LIMITED', message, details: [] }, req.id));
    },
  });
}

/** 10 requests per minute per IP on every /auth route (brute-force protection). */
export const authRateLimiter = limiter(10, 'Too many authentication attempts. Try again in a minute.');

/** Public shop writes (checkout, contact form): no login, so keep bots in check. */
export const shopWriteLimiter = limiter(20, 'Too many requests from this device. Please wait a minute and try again.');

/** Coarse ceiling for all other API traffic. */
export const apiRateLimiter = limiter(300, 'Too many requests. Slow down and try again shortly.');
