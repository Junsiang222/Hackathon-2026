import type { NextFunction, Request, RequestHandler, Response } from 'express';
import type { Role } from '../config/constants';
import { ForbiddenError, UnauthorizedError } from '../utils/errors';
import { verifyAccessToken, type AccessTokenPayload } from '../utils/jwtHelper';
import { createTenantDb } from '../utils/tenantScopedDb';

function readBearerToken(req: Request): string {
  const header = req.headers.authorization;
  if (!header) throw new UnauthorizedError('Missing Authorization header');

  const [scheme, token, ...rest] = header.split(' ');
  if (scheme !== 'Bearer' || !token || rest.length > 0) {
    throw new UnauthorizedError('Authorization header must be "Bearer <token>"');
  }
  return token;
}

function authenticateAs(role: Role, req: Request): AccessTokenPayload {
  const payload = verifyAccessToken(readBearerToken(req));
  if (payload.role !== role) {
    throw new ForbiddenError(`This endpoint requires the ${role} role`);
  }
  return payload;
}

/** Accepts only `super_admin` tokens and attaches the decoded payload. */
export const verifySuperAdmin: RequestHandler = (req: Request, _res: Response, next: NextFunction) => {
  try {
    req.user = authenticateAs('super_admin', req);
    next();
  } catch (error) {
    next(error);
  }
};

/**
 * Accepts only `admin` tokens. Besides attaching req.user it attaches
 * req.tenantDb — a DB helper pinned to the token's tenantId. Downstream
 * handlers query through it, so a request can never read or write another
 * tenant's rows even if a handler forgets a WHERE clause.
 */
export const verifyAdmin: RequestHandler = (req: Request, _res: Response, next: NextFunction) => {
  try {
    const payload = authenticateAs('admin', req);
    req.user = payload;
    req.tenantDb = createTenantDb(payload.tenantId);
    next();
  } catch (error) {
    next(error);
  }
};

/** Narrowing helpers for controllers that sit behind the middlewares above. */
export function requireUser(req: Request): AccessTokenPayload {
  if (!req.user) throw new UnauthorizedError();
  return req.user;
}

export function requireTenantDb(req: Request) {
  if (!req.tenantDb) throw new UnauthorizedError();
  return req.tenantDb;
}
