import type { ErrorRequestHandler, RequestHandler } from 'express';
import { ZodError } from 'zod';
import { env } from '../config/env';
import { buildErrorEnvelope } from '../utils/apiResponse';
import {
  AppError,
  BadRequestError,
  ConflictError,
  ForbiddenError,
  InternalError,
  NotFoundError,
  ValidationError,
} from '../utils/errors';

interface MysqlError {
  code?: string;
  errno?: number;
  sqlMessage?: string;
}

function isMysqlError(error: unknown): error is MysqlError {
  return typeof error === 'object' && error !== null && 'errno' in error && 'code' in error;
}

function fromZod(error: ZodError): ValidationError {
  const details = error.issues.map((issue) => ({
    path: issue.path.join('.'),
    message: issue.message,
    code: issue.code,
  }));
  const first = details[0];
  const message = first ? (first.path ? `${first.path}: ${first.message}` : first.message) : 'Validation failed';
  return new ValidationError(message, details);
}

function normalise(error: unknown): AppError {
  if (error instanceof AppError) return error;
  if (error instanceof ZodError) return fromZod(error);

  // body-parser: malformed JSON or oversized payload
  if (typeof error === 'object' && error !== null && 'type' in error) {
    const type = (error as { type: string }).type;
    if (type === 'entity.parse.failed') return new BadRequestError('Request body is not valid JSON');
    if (type === 'entity.too.large') return new BadRequestError('Request body is too large');
  }

  if (isMysqlError(error)) {
    if (error.code === 'ER_DUP_ENTRY') return new ConflictError('A record with these values already exists');
    // SIGNAL SQLSTATE '45000' from a schema trigger: a business rule, safe to show.
    if (error.code === 'ER_SIGNAL_EXCEPTION' && error.sqlMessage) return new ValidationError(error.sqlMessage);
    // FK violation on a client-supplied id (e.g. assigning a ticket to a missing user).
    if (error.code === 'ER_NO_REFERENCED_ROW_2') return new ValidationError('A referenced record does not exist');
    // A super_admin query touched a table outside its grant — the DB-level
    // financial isolation working as designed. Never leak the SQL message.
    if (error.code === 'ER_TABLEACCESS_DENIED_ERROR' || error.code === 'ER_COLUMNACCESS_DENIED_ERROR') {
      return new ForbiddenError('Access to this data is not permitted for your role');
    }
  }

  return new InternalError();
}

export const notFoundHandler: RequestHandler = (req, _res, next) => {
  next(new NotFoundError(`Route ${req.method} ${req.path} does not exist`));
};

export const globalErrorHandler: ErrorRequestHandler = (error, req, res, _next) => {
  const appError = normalise(error);

  if (appError.statusCode >= 500) {
    console.error(`[${req.id}] ${req.method} ${req.originalUrl} failed:`, error);
  } else if (env.NODE_ENV !== 'production') {
    console.warn(`[${req.id}] ${appError.statusCode} ${appError.code}: ${appError.message}`);
  }

  if (res.headersSent) {
    res.end();
    return;
  }

  res.status(appError.statusCode).json(buildErrorEnvelope(appError, req.id));
};
