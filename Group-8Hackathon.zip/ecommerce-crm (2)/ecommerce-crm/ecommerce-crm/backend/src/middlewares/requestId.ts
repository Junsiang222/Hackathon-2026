import type { RequestHandler } from 'express';
import { v4 as uuidv4, validate as isUuid } from 'uuid';

/**
 * Assigns every request a correlation id. An inbound X-Request-Id is honoured
 * only if it is a well-formed UUID (so it can't be used for log injection).
 */
export const requestId: RequestHandler = (req, res, next) => {
  const inbound = req.header('x-request-id');
  req.id = inbound && isUuid(inbound) ? inbound : uuidv4();
  res.setHeader('X-Request-Id', req.id);
  next();
};
