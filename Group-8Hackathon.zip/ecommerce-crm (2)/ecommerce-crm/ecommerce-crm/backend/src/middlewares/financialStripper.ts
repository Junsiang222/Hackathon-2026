import type { Request, RequestHandler, Response } from 'express';
import { superAdminPool } from '../config/db';
import { FINANCIAL_KEY_PATTERN } from '../config/constants';

/**
 * LAST line of defence for super_admin routes (the first is the DB layer:
 * the super-admin MySQL account can only read column-restricted views).
 *
 * Wraps res.json() so that, after the handler resolves, the outgoing body is
 * walked recursively and every key matching FINANCIAL_KEY_PATTERN is dropped.
 * Each dropped key is logged and written to stripped_fields_audit. A row in
 * that table means an upstream layer leaked and must be investigated.
 *
 * Mount ONLY on routers whose every route is super_admin-only.
 */
export const financialStripper: RequestHandler = (req, res, next) => {
  const originalJson = res.json.bind(res) as Response['json'];

  res.json = ((body: unknown) => {
    const strippedPaths: string[] = [];
    const sanitized = stripFinancialKeys(body, '$', strippedPaths, new WeakMap());

    if (strippedPaths.length > 0) {
      console.warn(
        `[security][${req.id}] financialStripper removed ${strippedPaths.length} field(s) from ` +
          `${req.method} ${req.originalUrl}: ${strippedPaths.join(', ')}`,
      );
      void recordStrippedFields(req, strippedPaths);
    }

    return originalJson(sanitized);
  }) as Response['json'];

  next();
};

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (typeof value !== 'object' || value === null) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}

/** Returns a sanitized deep copy; never mutates the handler's objects. */
export function stripFinancialKeys(
  value: unknown,
  path: string,
  strippedPaths: string[],
  seen: WeakMap<object, unknown>,
): unknown {
  if (Array.isArray(value)) {
    if (seen.has(value)) return seen.get(value);
    const output: unknown[] = [];
    seen.set(value, output);
    for (let index = 0; index < value.length; index += 1) {
      output.push(stripFinancialKeys(value[index], `${path}[${index}]`, strippedPaths, seen));
    }
    return output;
  }

  if (isPlainObject(value)) {
    if (seen.has(value)) return seen.get(value);
    const output: Record<string, unknown> = {};
    seen.set(value, output);
    for (const [key, child] of Object.entries(value)) {
      const childPath = `${path}.${key}`;
      if (FINANCIAL_KEY_PATTERN.test(key)) {
        strippedPaths.push(childPath);
        continue;
      }
      const sanitizedChild = stripFinancialKeys(child, childPath, strippedPaths, seen);
      if (sanitizedChild !== undefined) {
        output[key] = sanitizedChild;
      }
    }
    return output;
  }

  // Primitives, Dates, Buffers etc. carry no keys of their own.
  return value;
}

let auditTableMissing = false;

async function recordStrippedFields(req: Request, paths: string[]): Promise<void> {
  if (auditTableMissing) return;

  const rows = paths.map((fieldPath) => [
    req.id,
    req.user?.userId ?? null,
    req.method,
    req.originalUrl.slice(0, 255),
    fieldPath.slice(0, 512),
  ]);

  try {
    // Bulk VALUES ? expansion is a mysql2 query()-level placeholder feature;
    // every value is still escaped by the driver.
    await superAdminPool.query(
      'INSERT INTO stripped_fields_audit (request_id, user_id, http_method, route, field_path) VALUES ?',
      [rows],
    );
  } catch (error) {
    if ((error as { code?: string }).code === 'ER_NO_SUCH_TABLE') {
      auditTableMissing = true;
      console.warn('[security] stripped_fields_audit table not present; DB audit disabled');
      return;
    }
    console.error('[security] failed to write stripped_fields_audit:', error);
  }
}
