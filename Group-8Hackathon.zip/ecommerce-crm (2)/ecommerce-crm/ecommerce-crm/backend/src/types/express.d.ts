import type { AccessTokenPayload } from '../utils/jwtHelper';
import type { TenantDb } from '../utils/tenantScopedDb';

declare global {
  namespace Express {
    interface Request {
      /** Correlation id, echoed in the X-Request-Id header and error envelopes. */
      id: string;
      /** Set by verifySuperAdmin / verifyAdmin. */
      user?: AccessTokenPayload;
      /** Set by verifyAdmin: every query through it is pinned to req.user.tenantId. */
      tenantDb?: TenantDb;
    }
  }
}

export {};
