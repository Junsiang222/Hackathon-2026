import mysql, { type Pool, type PoolConnection, type PoolOptions } from 'mysql2/promise';
import { env } from './env';

const baseOptions: PoolOptions = {
  host: env.DB_HOST,
  port: env.DB_PORT,
  database: env.DB_NAME,
  connectionLimit: env.DB_POOL_LIMIT,
  waitForConnections: true,
  queueLimit: 0,
  enableKeepAlive: true,
  charset: 'utf8mb4_unicode_ci',
  timezone: 'Z',
  supportBigNumbers: true,
  bigNumberStrings: false,
  // Lets tenant-scoped SQL use `:tenantId`; positional `?` arrays still work.
  namedPlaceholders: true,
  // Never allow multiple statements per call — closes off stacked-query injection.
  multipleStatements: false,
};

/**
 * Pool for tenant-scoped API traffic and authentication.
 * The MySQL account must hold the `crm_app_rw` role.
 */
export const pool: Pool = mysql.createPool({
  ...baseOptions,
  user: env.DB_APP_USER,
  password: env.DB_APP_PASSWORD,
});

/**
 * Pool used EXCLUSIVELY by super_admin routes. Its MySQL account holds the
 * `crm_super_admin_ro` role, which can read only the column-restricted
 * super_admin_* views plus non-financial tables. Even a buggy query here
 * cannot read total_amount / base_price / unit_price / subtotal / ltv —
 * MySQL rejects it with ER_TABLEACCESS_DENIED_ERROR.
 */
export const superAdminPool: Pool = mysql.createPool({
  ...baseOptions,
  user: env.DB_SUPERADMIN_USER,
  password: env.DB_SUPERADMIN_PASSWORD,
});

/**
 * Runs `work` inside a transaction on a dedicated connection.
 * Commits on success, rolls back on any thrown error, always releases.
 */
export async function withTransaction<T>(
  targetPool: Pool,
  work: (connection: PoolConnection) => Promise<T>,
): Promise<T> {
  const connection = await targetPool.getConnection();
  try {
    await connection.beginTransaction();
    const result = await work(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function verifyDatabaseConnectivity(): Promise<void> {
  await Promise.all([pool.query('SELECT 1'), superAdminPool.query('SELECT 1')]);
}

export async function closePools(): Promise<void> {
  await Promise.allSettled([pool.end(), superAdminPool.end()]);
}
