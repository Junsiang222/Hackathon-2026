import 'dotenv/config';
import { z } from 'zod';

const MIN_SECRET_BYTES = 64; // 512 bits for HS256

const secret = (name: string) =>
  z
    .string({ required_error: `${name} is required` })
    .refine((value) => Buffer.byteLength(value, 'utf8') >= MIN_SECRET_BYTES, {
      message: `${name} must be at least ${MIN_SECRET_BYTES} bytes (512 bits)`,
    });

const booleanFromString = z
  .enum(['true', 'false'])
  .default('false')
  .transform((value) => value === 'true');

const envSchema = z
  .object({
    NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
    PORT: z.coerce.number().int().positive().default(4000),
    TRUST_PROXY: z.coerce.number().int().min(0).default(0),

    DB_HOST: z.string().min(1),
    DB_PORT: z.coerce.number().int().positive().default(3306),
    DB_NAME: z.string().min(1),
    DB_POOL_LIMIT: z.coerce.number().int().positive().default(10),
    DB_APP_USER: z.string().min(1),
    DB_APP_PASSWORD: z.string().min(1),
    DB_SUPERADMIN_USER: z.string().min(1),
    DB_SUPERADMIN_PASSWORD: z.string().min(1),

    JWT_ACCESS_SECRET: secret('JWT_ACCESS_SECRET'),
    JWT_REFRESH_SECRET: secret('JWT_REFRESH_SECRET'),
    JWT_ISSUER: z.string().min(1).default('crm-platform-api'),
    JWT_AUDIENCE: z.string().min(1).default('crm-platform-web'),

    CORS_ORIGINS: z
      .string()
      .min(1)
      .transform((value) =>
        value
          .split(',')
          .map((origin) => origin.trim())
          .filter(Boolean),
      )
      .refine((origins) => origins.every((origin) => origin !== '*'), {
        message: 'CORS_ORIGINS must be an explicit allowlist (no "*")',
      }),
    COOKIE_SECURE: booleanFromString,

    OPENAI_API_KEY: z.string().min(1, 'OPENAI_API_KEY is required'),
    OPENAI_MODEL: z.string().min(1).default('gpt-4o'),
    // Optional: any OpenAI-compatible endpoint (Gemini, Groq, OpenRouter, ...).
    OPENAI_BASE_URL: z.string().url().optional(),
    // Optional photo keys for the AI website and automatic product photos
    // (Unsplash is used when both are set).
    UNSPLASH_ACCESS_KEY: z
      .string()
      .optional()
      .transform((value) => value?.trim() || undefined),
    PEXELS_API_KEY: z
      .string()
      .optional()
      .transform((value) => value?.trim() || undefined),

    OAUTH_MOCK_ENABLED: booleanFromString,
  })
  .refine((env) => env.JWT_ACCESS_SECRET !== env.JWT_REFRESH_SECRET, {
    message: 'JWT_ACCESS_SECRET and JWT_REFRESH_SECRET must differ',
    path: ['JWT_REFRESH_SECRET'],
  })
  .refine((env) => !(env.NODE_ENV === 'production' && env.OAUTH_MOCK_ENABLED), {
    message: 'OAUTH_MOCK_ENABLED must be false in production',
    path: ['OAUTH_MOCK_ENABLED'],
  })
  .refine((env) => !(env.NODE_ENV === 'production' && !env.COOKIE_SECURE), {
    message: 'COOKIE_SECURE must be true in production',
    path: ['COOKIE_SECURE'],
  });

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  const problems = parsed.error.issues
    .map((issue) => `  - ${issue.path.join('.') || 'env'}: ${issue.message}`)
    .join('\n');
  // Fail fast: never boot with a partial or insecure configuration.
  console.error(`Invalid environment configuration:\n${problems}`);
  process.exit(1);
}

export const env = parsed.data;
export type Env = typeof env;
