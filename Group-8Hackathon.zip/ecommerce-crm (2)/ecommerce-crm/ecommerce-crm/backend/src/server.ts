import { env } from './config/env';
import { closePools, verifyDatabaseConnectivity } from './config/db';
import { createApp } from './app';

async function main(): Promise<void> {
  await verifyDatabaseConnectivity();

  const app = createApp();
  const server = app.listen(env.PORT, () => {
    console.log(`CRM API listening on :${env.PORT} (${env.NODE_ENV})`);
  });

  const shutdown = (signal: string) => {
    console.log(`${signal} received, draining connections…`);
    server.close(async () => {
      await closePools();
      process.exit(0);
    });
    // Hard stop if in-flight requests don't finish in time.
    setTimeout(() => process.exit(1), 10_000).unref();
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

process.on('unhandledRejection', (reason) => {
  console.error('Unhandled promise rejection:', reason);
});

main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
