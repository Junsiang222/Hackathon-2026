import cookieParser from 'cookie-parser';
import cors from 'cors';
import express, { type Express } from 'express';
import helmet from 'helmet';
import { API_PREFIX, ANALYTICS_SOURCES, FINANCIAL_KEY_PATTERN } from './config/constants';
import { env } from './config/env';
import { globalErrorHandler, notFoundHandler } from './middlewares/errorHandler';
import { apiRateLimiter } from './middlewares/rateLimiter';
import { requestId } from './middlewares/requestId';
import { adminRouter } from './modules/admin/admin.routes';
import { authRouter } from './modules/auth/auth.routes';
import { dashboardRouter } from './modules/dashboard/dashboard.routes';
import { shopRouter } from './modules/shop/shop.routes';
import { superAdminRouter } from './modules/superadmin/superadmin.routes';

// Boot-time guard: the AI widget catalog must never contain a monetary key.
for (const [url, source] of Object.entries(ANALYTICS_SOURCES)) {
  const leaked = source.dataKeys.filter((key) => FINANCIAL_KEY_PATTERN.test(key));
  if (leaked.length > 0) throw new Error(`ANALYTICS_SOURCES[${url}] exposes monetary keys: ${leaked.join(', ')}`);
}

export function createApp(): Express {
  const app = express();

  app.set('trust proxy', env.TRUST_PROXY);
  app.disable('x-powered-by');

  app.use(requestId);

  // JSON-only API: nothing here should ever be rendered as a document,
  // framed, or allowed to load sub-resources.
  app.use(
    helmet({
      contentSecurityPolicy: {
        useDefaults: false,
        directives: {
          defaultSrc: ["'none'"],
          baseUri: ["'none'"],
          formAction: ["'none'"],
          frameAncestors: ["'none'"],
        },
      },
      crossOriginResourcePolicy: { policy: 'same-site' },
      referrerPolicy: { policy: 'no-referrer' },
      strictTransportSecurity: { maxAge: 63072000, includeSubDomains: true, preload: true },
    }),
  );

  const allowedOrigins = new Set(env.CORS_ORIGINS);
  app.use(
    cors({
      // Explicit allowlist. Requests without an Origin header (curl, server to
      // server) aren't subject to CORS and pass through; disallowed browser
      // origins simply get no CORS headers.
      origin: (origin, callback) => callback(null, !origin || allowedOrigins.has(origin)),
      credentials: true,
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
      allowedHeaders: ['Authorization', 'Content-Type', 'X-Request-Id', 'X-Shop-Session'],
      exposedHeaders: ['X-Request-Id', 'RateLimit', 'RateLimit-Policy'],
      maxAge: 600,
    }),
  );

  app.use(express.json({ limit: '100kb' }));
  app.use(cookieParser());

  app.get('/health', (_req, res) => {
    res.json({ success: true, data: { status: 'ok' } });
  });

  app.use(`${API_PREFIX}/auth`, authRouter);
  app.use(API_PREFIX, apiRateLimiter);
  app.use(`${API_PREFIX}/superadmin`, superAdminRouter);
  app.use(`${API_PREFIX}/admin`, adminRouter);
  app.use(`${API_PREFIX}/dashboard`, dashboardRouter);
  app.use(`${API_PREFIX}/shop`, shopRouter);

  app.use(notFoundHandler);
  app.use(globalErrorHandler);

  return app;
}
