import { createHash, randomUUID, timingSafeEqual } from 'node:crypto';
import jwt, { type JwtPayload } from 'jsonwebtoken';
import { z } from 'zod';
import { env } from '../config/env';
import { ACCESS_TOKEN_TTL_SECONDS, REFRESH_TOKEN_TTL_SECONDS, ROLES, type Role } from '../config/constants';
import { UnauthorizedError } from './errors';

const ALGORITHM = 'HS256' as const;

export interface AccessTokenPayload {
  userId: number;
  tenantId: number;
  role: Role;
}

const accessClaimsSchema = z.object({
  userId: z.number().int().positive(),
  tenantId: z.number().int().positive(),
  role: z.enum(ROLES),
});

const refreshClaimsSchema = z.object({
  sub: z.string().regex(/^\d+$/),
  jti: z.string().uuid(),
  rm: z.boolean(),
});

export interface RefreshTokenClaims {
  userId: number;
  rememberMe: boolean;
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign({ ...payload }, env.JWT_ACCESS_SECRET, {
    algorithm: ALGORITHM,
    expiresIn: ACCESS_TOKEN_TTL_SECONDS,
    issuer: env.JWT_ISSUER,
    audience: env.JWT_AUDIENCE,
    subject: String(payload.userId),
  });
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  try {
    const decoded = jwt.verify(token, env.JWT_ACCESS_SECRET, {
      algorithms: [ALGORITHM],
      issuer: env.JWT_ISSUER,
      audience: env.JWT_AUDIENCE,
    });
    const claims = accessClaimsSchema.parse(decoded);
    return { userId: claims.userId, tenantId: claims.tenantId, role: claims.role };
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      throw new UnauthorizedError('Access token expired', 'TOKEN_EXPIRED');
    }
    throw new UnauthorizedError('Invalid access token', 'INVALID_TOKEN');
  }
}

/**
 * Refresh tokens are signed JWTs (so expiry is enforced cryptographically)
 * AND their SHA-256 hash is stored in users.session_token (so they can be
 * revoked and rotated). A token is valid only if both checks pass.
 */
export function signRefreshToken(userId: number, rememberMe: boolean): string {
  return jwt.sign({ rm: rememberMe }, env.JWT_REFRESH_SECRET, {
    algorithm: ALGORITHM,
    expiresIn: REFRESH_TOKEN_TTL_SECONDS,
    issuer: env.JWT_ISSUER,
    audience: env.JWT_AUDIENCE,
    subject: String(userId),
    jwtid: randomUUID(),
  });
}

export function verifyRefreshToken(
  token: string,
  options: { ignoreExpiration?: boolean } = {},
): RefreshTokenClaims {
  try {
    const decoded = jwt.verify(token, env.JWT_REFRESH_SECRET, {
      algorithms: [ALGORITHM],
      issuer: env.JWT_ISSUER,
      audience: env.JWT_AUDIENCE,
      ignoreExpiration: options.ignoreExpiration ?? false,
    }) as JwtPayload;
    const claims = refreshClaimsSchema.parse(decoded);
    return { userId: Number(claims.sub), rememberMe: claims.rm };
  } catch {
    throw new UnauthorizedError('Invalid or expired session', 'INVALID_SESSION');
  }
}

export function hashToken(token: string): string {
  return createHash('sha256').update(token, 'utf8').digest('hex');
}

/** Constant-time comparison of two hex digests. */
export function tokenHashesMatch(a: string | null, b: string): boolean {
  if (!a || a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
}
