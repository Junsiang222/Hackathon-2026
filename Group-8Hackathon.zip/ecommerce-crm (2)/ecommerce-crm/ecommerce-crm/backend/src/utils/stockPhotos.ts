import { env } from '../config/env';

// Stock photos for the AI website and automatic product photos, from Unsplash
// (https://unsplash.com/developers) or Pexels (https://www.pexels.com/api/),
// whichever key is set (Unsplash wins). Every lookup degrades to null: a
// missing photo must never fail website generation or product creation.
//
// Free tiers are small (Unsplash: 50 searches/hour), so results are cached,
// and once the provider says the quota is spent no more searches are sent
// until it has had time to reset.

export type PhotoOrientation = 'landscape' | 'portrait' | 'square';

export interface StockPhoto {
  url: string;
  alt: string;
  photographer: string;
  photographerUrl: string;
}

interface SearchOptions {
  orientation?: PhotoOrientation;
  width?: number;
  /** Photo ids already on the page, so the same photo isn't shown twice. */
  used?: Set<string>;
}

interface Candidate {
  id: string;
  /** Rendition URL without a width, which is added per use. */
  baseUrl: string;
  /** Extra URL params for square crops (Unsplash only). */
  squareCrop: boolean;
  alt: string;
  photographer: string;
  photographerUrl: string;
}

const TIMEOUT_MS = 8_000;
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
/** When the quota runs out, wait this long before trying again. */
const QUOTA_PAUSE_MS = 15 * 60 * 1000;
/** Keep a few searches spare for website photos, which matter most. */
const RESERVED_FOR_WEBSITE = 8;
const UTM = 'utm_source=ecommerce_crm&utm_medium=referral';

const cache = new Map<string, { at: number; candidates: Candidate[] }>();
let pausedUntil = 0;
/** Searches left this hour, as last reported by the provider (null = unknown). */
let remaining: number | null = null;

export const stockPhotoProvider = (): 'Unsplash' | 'Pexels' | null =>
  env.UNSPLASH_ACCESS_KEY ? 'Unsplash' : env.PEXELS_API_KEY ? 'Pexels' : null;

export const stockPhotosEnabled = () => stockPhotoProvider() !== null;

/** For Settings → System status: searches left this hour (null = not known yet) and whether searching is paused. */
export const photoQuota = () => ({ remaining, paused: Date.now() < pausedUntil });

/** False when background jobs (product photos) should leave the remaining quota alone. */
export const hasSpareQuota = () =>
  stockPhotosEnabled() && Date.now() >= pausedUntil && (remaining === null || remaining > RESERVED_FOR_WEBSITE);

async function getJson<T>(url: string, authorization: string, label: string): Promise<T | null> {
  if (Date.now() < pausedUntil) return null;
  try {
    const response = await fetch(url, { headers: { Authorization: authorization }, signal: AbortSignal.timeout(TIMEOUT_MS) });
    const left = response.headers.get('x-ratelimit-remaining');
    if (left !== null && left !== '') remaining = Number(left);
    if (response.status === 403 || response.status === 429 || remaining === 0) {
      pausedUntil = Date.now() + QUOTA_PAUSE_MS;
      console.warn(`${stockPhotoProvider()} photo quota used up; pausing photo searches for 15 minutes.`);
    }
    if (!response.ok) {
      console.warn(`${label} failed: HTTP ${response.status}`);
      return null;
    }
    return (await response.json()) as T;
  } catch (error) {
    console.warn(`${label} failed:`, error);
    return null;
  }
}

interface UnsplashPhoto {
  id: string;
  alt_description: string | null;
  urls: { raw: string };
  user: { name: string; links: { html: string } };
}

async function searchUnsplash(key: string, query: string, orientation?: PhotoOrientation): Promise<Candidate[] | null> {
  const params = new URLSearchParams({ query, per_page: '10', content_filter: 'high' });
  if (orientation) params.set('orientation', orientation === 'square' ? 'squarish' : orientation);
  const body = await getJson<{ results?: UnsplashPhoto[] }>(
    `https://api.unsplash.com/search/photos?${params}`,
    `Client-ID ${key}`,
    `Unsplash search "${query}"`,
  );
  if (!body) return null;
  return (body.results ?? []).map((photo) => ({
    id: `unsplash:${photo.id}`,
    baseUrl: `${photo.urls.raw}&auto=format&fit=max&q=80`,
    squareCrop: true,
    alt: photo.alt_description?.trim() || query,
    photographer: photo.user.name,
    photographerUrl: `${photo.user.links.html}?${UTM}`,
  }));
}

interface PexelsPhoto {
  id: number;
  alt: string | null;
  photographer: string;
  photographer_url: string;
  src: { original: string };
}

async function searchPexels(key: string, query: string, orientation?: PhotoOrientation): Promise<Candidate[] | null> {
  const params = new URLSearchParams({ query, per_page: '10' });
  if (orientation) params.set('orientation', orientation);
  const body = await getJson<{ photos?: PexelsPhoto[] }>(
    `https://api.pexels.com/v1/search?${params}`,
    key,
    `Pexels search "${query}"`,
  );
  if (!body) return null;
  return (body.photos ?? []).map((photo) => ({
    id: `pexels:${photo.id}`,
    baseUrl: `${photo.src.original}?auto=compress&cs=tinysrgb`,
    squareCrop: false,
    alt: photo.alt?.trim() || query,
    photographer: photo.photographer,
    photographerUrl: photo.photographer_url,
  }));
}

/** Search results for a query, from the cache when possible. Null when the search failed. */
async function search(query: string, orientation?: PhotoOrientation): Promise<Candidate[] | null> {
  const key = `${stockPhotoProvider()}|${orientation ?? ''}|${query.toLowerCase()}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.candidates;

  const candidates = env.UNSPLASH_ACCESS_KEY
    ? await searchUnsplash(env.UNSPLASH_ACCESS_KEY, query, orientation)
    : env.PEXELS_API_KEY
      ? await searchPexels(env.PEXELS_API_KEY, query, orientation)
      : null;
  if (candidates) cache.set(key, { at: Date.now(), candidates });
  return candidates;
}

/** Best match for `query` that isn't already in `used`. */
export async function findPhoto(query: string, options: SearchOptions = {}): Promise<StockPhoto | null> {
  const trimmed = query.trim().slice(0, 100);
  if (!trimmed || !stockPhotosEnabled()) return null;

  const candidates = (await search(trimmed, options.orientation)) ?? [];
  const photo = candidates.find((candidate) => !options.used?.has(candidate.id)) ?? candidates[0];
  if (!photo) return null;
  options.used?.add(photo.id);

  const width = options.width ?? 800;
  const crop = options.orientation === 'square' && photo.squareCrop ? `&h=${width}&fit=crop` : '';
  return {
    url: `${photo.baseUrl}&w=${width}${crop}`,
    alt: photo.alt,
    photographer: photo.photographer,
    photographerUrl: photo.photographerUrl,
  };
}

/** A product photo: by name first, then by category (only when the name search found nothing). */
export async function findProductPhoto(
  product: { name: string; category: string | null },
  used?: Set<string>,
): Promise<StockPhoto | null> {
  return (
    (await findPhoto(product.name, { orientation: 'square', width: 800, used })) ??
    (product.category && hasSpareQuota()
      ? await findPhoto(product.category, { orientation: 'square', width: 800, used })
      : null)
  );
}
