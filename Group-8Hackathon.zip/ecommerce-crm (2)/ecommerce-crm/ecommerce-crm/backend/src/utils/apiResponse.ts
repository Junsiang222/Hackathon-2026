import type { Response } from 'express';
import type { AppError } from './errors';

export interface SuccessEnvelope<T> {
  success: true;
  data: T;
}

export interface ErrorEnvelope {
  success: false;
  error: {
    code: string;
    message: string;
    details: unknown[];
    requestId: string;
  };
}

export function sendSuccess<T>(res: Response, data: T, statusCode = 200): Response {
  const body: SuccessEnvelope<T> = { success: true, data };
  return res.status(statusCode).json(body);
}

export function buildErrorEnvelope(
  error: Pick<AppError, 'code' | 'message' | 'details'>,
  requestId: string,
): ErrorEnvelope {
  return {
    success: false,
    error: {
      code: error.code,
      message: error.message,
      details: error.details,
      requestId,
    },
  };
}
