import type { RowDataPacket } from 'mysql2/promise';
import { pool } from '../config/db';

// Platform-wide options the super admin sets in Settings (migration 008).
// Read by the shop and the AI website generator through the app pool; cached
// for a minute and cleared in-process whenever Settings saves them.

export const UI_LANGUAGES = ['en', 'ms', 'zh'] as const;
export type UiLanguage = (typeof UI_LANGUAGES)[number];

export const LANGUAGE_NAMES: Record<UiLanguage, string> = {
  en: 'English',
  ms: 'Bahasa Melayu (Malay)',
  zh: 'Simplified Chinese (简体中文)',
};

/** Storefront currencies. Prices are stored as plain numbers; this sets the unit shoppers see. */
export const STORE_CURRENCIES = ['USD', 'MYR', 'SGD', 'IDR', 'THB', 'PHP', 'EUR', 'GBP', 'AUD'] as const;
export type StoreCurrency = (typeof STORE_CURRENCIES)[number];

export interface PlatformSettings {
  websiteLanguage: UiLanguage;
  storeCurrency: StoreCurrency;
}

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettings = { websiteLanguage: 'en', storeCurrency: 'USD' };

const CACHE_MS = 60_000;
let cached: { at: number; value: PlatformSettings } | null = null;

export function clearPlatformSettingsCache() {
  cached = null;
}

/** Parses stored rows, falling back to the defaults for anything missing or invalid. */
export function settingsFromRows(rows: { setting_key: string; setting_value: unknown }[]): PlatformSettings {
  const value = (key: string) => {
    const raw = rows.find((row) => row.setting_key === key)?.setting_value;
    if (typeof raw !== 'string') return raw;
    try {
      return JSON.parse(raw);
    } catch {
      return raw;
    }
  };
  const language = value('website_language');
  const currency = value('store_currency');
  return {
    websiteLanguage: (UI_LANGUAGES as readonly unknown[]).includes(language)
      ? (language as UiLanguage)
      : DEFAULT_PLATFORM_SETTINGS.websiteLanguage,
    storeCurrency: (STORE_CURRENCIES as readonly unknown[]).includes(currency)
      ? (currency as StoreCurrency)
      : DEFAULT_PLATFORM_SETTINGS.storeCurrency,
  };
}

export async function getPlatformSettings(): Promise<PlatformSettings> {
  if (cached && Date.now() - cached.at < CACHE_MS) return cached.value;
  try {
    const [rows] = await pool.query<RowDataPacket[]>('SELECT setting_key, setting_value FROM platform_settings');
    cached = { at: Date.now(), value: settingsFromRows(rows as { setting_key: string; setting_value: unknown }[]) };
  } catch (error) {
    // Before migration 008 the table doesn't exist: behave as before.
    console.warn('Reading platform settings failed; using defaults:', (error as Error).message);
    cached = { at: Date.now(), value: DEFAULT_PLATFORM_SETTINGS };
  }
  return cached.value;
}
