import type { RowDataPacket } from 'mysql2';
import { pool } from '../config/db';

/**
 * Tables that carry a tenant_id column, with the columns callers may select,
 * filter or sort on. Identifiers are only ever taken from this compile-time
 * allowlist; every VALUE goes through a placeholder.
 */
const TENANT_TABLE_COLUMNS = {
  products: ['id', 'sku_code', 'name', 'category', 'base_price', 'status', 'status_color', 'image_url', 'created_at', 'updated_at'],
  orders: ['id', 'customer_id', 'order_ref', 'status', 'status_color', 'total_amount', 'currency', 'placed_at', 'fulfilled_at', 'created_at'],
  customers: ['id', 'full_name', 'email', 'phone', 'acquisition_channel', 'status', 'total_orders', 'ltv', 'last_active_at', 'created_at'],
  support_tickets: ['id', 'customer_id', 'assigned_to', 'subject', 'priority', 'status', 'status_color', 'channel', 'created_at', 'resolved_at'],
  campaigns: ['id', 'name', 'type', 'status', 'status_color', 'sent_count', 'open_count', 'click_count', 'scheduled_at', 'created_at'],
  dashboard_layouts: ['id', 'layout_name', 'config_json', 'version', 'is_active', 'created_by', 'created_at'],
} as const;

export type TenantTable = keyof typeof TENANT_TABLE_COLUMNS;
export type TenantColumn<T extends TenantTable> = (typeof TENANT_TABLE_COLUMNS)[T][number];

export interface FindManyOptions<T extends TenantTable> {
  columns?: readonly TenantColumn<T>[];
  where?: Partial<Record<TenantColumn<T>, string | number | null>>;
  orderBy?: { column: TenantColumn<T>; direction: 'ASC' | 'DESC' };
  limit?: number;
  offset?: number;
}

export type NamedParams = Record<string, unknown>;

export interface TenantDb {
  readonly tenantId: number;
  /**
   * Runs hand-written SQL. The statement MUST reference `:tenantId`; the value
   * is injected here and cannot be supplied (or overridden) by the caller.
   */
  query<T extends RowDataPacket>(sql: string, params?: NamedParams): Promise<T[]>;
  /** Runs an INSERT/UPDATE/DELETE under the same `:tenantId` contract. */
  execute(sql: string, params?: NamedParams): Promise<{ affectedRows: number; insertId: number }>;
  /** SELECT with `WHERE tenant_id = ?` appended automatically. */
  findMany<T extends TenantTable, R extends RowDataPacket = RowDataPacket>(
    table: T,
    options?: FindManyOptions<T>,
  ): Promise<R[]>;
}

const TENANT_PLACEHOLDER = /:tenantId\b/;

function assertTenantScoped(sql: string, params: NamedParams): void {
  if (!TENANT_PLACEHOLDER.test(sql)) {
    // Programming error, not user error: fail closed rather than run an
    // unscoped statement that could read another tenant's rows.
    throw new Error('Tenant-scoped SQL must constrain rows with :tenantId');
  }
  if (Object.prototype.hasOwnProperty.call(params, 'tenantId')) {
    throw new Error('tenantId is injected by TenantDb and must not be passed by callers');
  }
}

function assertColumn(table: TenantTable, column: string): void {
  if (!(TENANT_TABLE_COLUMNS[table] as readonly string[]).includes(column)) {
    throw new Error(`Column "${column}" is not allowlisted for ${table}`);
  }
}

const MAX_PAGE_SIZE = 200;

export function createTenantDb(tenantId: number): TenantDb {
  if (!Number.isSafeInteger(tenantId) || tenantId <= 0) {
    throw new Error('createTenantDb requires a positive integer tenantId');
  }

  return Object.freeze({
    tenantId,

    async query<T extends RowDataPacket>(sql: string, params: NamedParams = {}): Promise<T[]> {
      assertTenantScoped(sql, params);
      const [rows] = await pool.execute<T[]>(sql, { ...params, tenantId });
      return rows;
    },

    async execute(sql: string, params: NamedParams = {}) {
      assertTenantScoped(sql, params);
      const [result] = await pool.execute(sql, { ...params, tenantId });
      const header = result as { affectedRows: number; insertId: number };
      return { affectedRows: header.affectedRows, insertId: header.insertId };
    },

    async findMany<T extends TenantTable, R extends RowDataPacket = RowDataPacket>(
      table: T,
      options: FindManyOptions<T> = {},
    ): Promise<R[]> {
      const columns = options.columns ?? TENANT_TABLE_COLUMNS[table];
      columns.forEach((column) => assertColumn(table, column));

      const params: NamedParams = {};
      const conditions = ['`tenant_id` = :tenantId'];
      for (const [column, value] of Object.entries(options.where ?? {})) {
        if (value === undefined) continue;
        assertColumn(table, column);
        if (value === null) {
          conditions.push(`\`${column}\` IS NULL`);
        } else {
          params[`w_${column}`] = value;
          conditions.push(`\`${column}\` = :w_${column}`);
        }
      }

      let sql = `SELECT ${columns.map((c) => `\`${c}\``).join(', ')} FROM \`${table}\` WHERE ${conditions.join(' AND ')}`;

      if (options.orderBy) {
        assertColumn(table, options.orderBy.column);
        const direction = options.orderBy.direction === 'ASC' ? 'ASC' : 'DESC';
        sql += ` ORDER BY \`${options.orderBy.column}\` ${direction}`;
      }

      const limit = Math.min(Math.max(Math.trunc(options.limit ?? 50), 1), MAX_PAGE_SIZE);
      const offset = Math.max(Math.trunc(options.offset ?? 0), 0);
      // Prepared-statement LIMIT/OFFSET parameters must be sent as strings.
      params.limit = String(limit);
      params.offset = String(offset);
      sql += ' LIMIT :limit OFFSET :offset';

      const [rows] = await pool.execute<R[]>(sql, { ...params, tenantId });
      return rows;
    },
  });
}
