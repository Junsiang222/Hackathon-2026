import OpenAI from 'openai';
import { env } from '../../config/env';

let client: OpenAI | null = null;

/** Shared OpenAI-compatible client for the setup wizard's AI calls. */
export function openai(): OpenAI {
  client ??= new OpenAI({
    apiKey: env.OPENAI_API_KEY,
    baseURL: env.OPENAI_BASE_URL,
    // Thinking models (e.g. Gemini) can take well over 30s on this prompt.
    timeout: 90_000,
    maxRetries: 1,
  });
  return client;
}
