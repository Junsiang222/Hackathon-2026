import vm from 'node:vm';
import { env } from '../../config/env';
import { UpstreamError } from '../../utils/errors';
import { findPhoto, stockPhotoProvider, stockPhotosEnabled, type PhotoOrientation } from '../../utils/stockPhotos';
import { getPlatformSettings, LANGUAGE_NAMES } from '../../utils/platformSettings';
import type { GeneratedWebsite, WebsiteImage } from '../admin/storeSetup';
import { openai } from './aiClient';

export interface WebsiteRequest {
  storeName: string;
  industry: string;
  websitePrompt: string;
  /** Shop features the page may link to; it must not promise the others. */
  features: { checkout: boolean; contact: boolean; orderTracking: boolean; stockLevels: boolean };
  /** The store's product categories today (may be empty for a new store). */
  categories: string[];
}

/** Upper bound on the stored page. A rich single-file page is well under this. */
const MAX_HTML_LENGTH = 400_000;
const MAX_PLANNED_IMAGES = 14;
const MAX_CATEGORY_IMAGES = 8;

// The page runs in a sandboxed iframe on its own opaque origin, so it can't
// touch the shopper's session. The brief describes the look of a modern
// e-commerce home page; the model decides the brand-specific details.
const SYSTEM_WEBSITE_TEMPLATE = `You are a senior e-commerce web designer and front-end developer.
Build the home page of an online shop as ONE complete, self-contained HTML document.

Write ALL text shoppers read (navigation, headings, buttons, labels, empty states, footer) in the
language given as websiteLanguage in the request, even if the owner's description is in another
language. Keep store, product and category names exactly as given.

The owner's description (ownerDescription in the request) is your brief: follow it closely for
who the shop is for, its personality, colours and what to highlight. Where it is silent, make
confident choices that fit the brand and industry.

# Look and feel
A polished, modern, premium storefront in the style of leading e-commerce sites: clean white or
warm off-white background, generous whitespace, a centred container (max-width ~1280px), large
rounded corners (16-24px), soft shadows, crisp typography from Google Fonts (e.g. an elegant serif
or bold sans display font for headings with a clean sans for body), one strong brand accent colour
plus a deep brand colour for dark sections, smooth hover effects and subtle entrance animations.
Use inline SVG icons (simple line icons). Fully responsive: rails scroll horizontally on phones,
grids collapse to 2 columns, the nav becomes a menu button.

# Page structure (top to bottom)
1. Announcement bar: thin strip in the deep brand colour with 2-3 short messages separated by
   dividers, each with a small icon (see Honesty for what they may say).
2. Header: store-name wordmark with a small icon logo; nav links (Home, Shop, Categories, plus
   Track order / Contact when enabled); a rounded search field with a search button; account
   icon (when accounts is enabled) and cart icon with a live count badge (when checkout is
   enabled).
3. Hero: a large rounded banner with a big lifestyle photo, a bold 2-line headline, a short
   subtitle, a primary "Shop now" button and a secondary outline button. Float 2-3 small white
   product cards (photo, name, price of real products) over the photo, like a magazine collage.
   REQUIRED: the hero must always show the "hero" photo. Put data-shop-hero on the hero section and
   data-shop-bg="hero" on the element that shows the photo (or use <img data-shop-image="hero">).
   Do not apply the hero photo only through your own JavaScript or CSS variables.
4. Benefits strip: 3-4 icon + title + one-line items in a row.
5. "Shop by category": a row of rounded photo tiles (shop.categoryImage(name)) with the category
   name and "Shop now →". Clicking filters the product section and scrolls to it.
6. "New arrivals": a horizontal product rail with left/right arrow buttons, using the first
   products in shop.data.products (they are newest first). Product card: square photo on a soft
   grey background with a small badge in the corner when relevant ("Only N left" when
   lowStockQty is set, "Sold out" when !inStock), name, price, and a round dark cart button.
7. "Featured picks": 3 wide horizontal cards (photo left; name, short description, price and a
   "Quick add" button right).
8. Two promo banners side by side: one light/tinted, one dark, each with a photo, a small
   kicker, a headline about a category or the brand, and a button.
9. Brand story: a split section (photo + "About {storeName}" text written from the brief).
10. "All products": search box + category chips + sort (featured / price low-high / high-low)
    and a responsive product grid with the same card design.
11. Footer in the deep brand colour: logo + one-line tagline, link columns (Shop: categories;
    Help: the enabled shop pages), and a bottom bar with the copyright and the line "{{photoCredit}}".

# Photos
You cannot generate images yourself. Instead, declare every photo the page needs (hero, promo
banners, brand story, benefit or background art) in ONE block inside <head>:
<script type="application/json" id="shop-images">
{ "hero": { "query": "woman with glossy healthy hair smiling", "orientation": "landscape" },
  "promo-1": { "query": "hair salon styling station", "orientation": "landscape" } }
</script>
- At most ${MAX_PLANNED_IMAGES} entries. Keys: lowercase letters, digits and dashes.
- query: 2-6 plain English words describing a REAL stock photograph that fits this brand and
  industry (it is searched on a stock-photo site, so no art styles, no text, no logos).
- orientation: "landscape", "portrait" or "square".
Then use them with shop.image("hero") in JavaScript, or in markup with
<img data-shop-image="hero" alt="..."> or <div data-shop-bg="hero"></div> (sets the background
image; give it background-size: cover). Category tiles use shop.categoryImage(name) and product
cards use shop.productImage(product): both always return a usable URL. Set object-fit: cover.

# The shop API
A global \`shop\` object exists before your scripts run:
  shop.data = {
    storeName, industry, currency,
    features: { checkout, contact, orderTracking, accounts },   // booleans
    categories: string[],
    products: [{ id, name, category, price, imageUrl, description, inStock, lowStockQty }]
  }
  shop.formatPrice(amount)        -> "$12.00" in the shop's currency
  shop.image(key)                 -> URL of a declared photo (a placeholder if none was found)
  shop.categoryImage(name)        -> URL for a category tile
  shop.productImage(product)      -> URL for a product photo
  shop.addToCart(productId, qty?) -> adds to the cart (only when features.checkout)
  shop.go(page, productId?)       -> page: "home" | "product" | "cart" | "checkout" | "track"
                                     | "contact" | "login" | "account"
  shop.onCartChange(fn)           -> fn(itemCount) now and whenever the cart changes

Rules:
- Render every product, category and price from shop.data with JavaScript; never hard-code
  them. The catalogue may be empty (show a friendly "New products are coming soon" state), small
  or large. When there are no categories, hide the category section.
- Clicking a product card opens shop.go("product", id); cart buttons call shop.addToCart and are
  disabled when the product is sold out. Use shop.go(...) for every link to a shop page, and only
  link to pages whose feature is enabled ("cart"/"checkout" need checkout, "track" needs
  orderTracking, "contact" needs contact, "login"/"account" need accounts).
- Search and category filtering happen client-side over shop.data.
- localStorage, sessionStorage and cookies are unavailable. External links need target="_blank".
- No newsletter or email sign-up forms (there is nothing to receive them).

# Honesty
This is a real shop, so everything a shopper reads must be true:
- Never invent ratings, stars, review counts, testimonials, customer counts, discounts, sale
  percentages, countdown timers, "best seller" claims, shipping thresholds, return periods,
  awards or contact details. Only mention offers or policies that ownerDescription states.
- Announcement and benefit messages may use what the shop really offers, e.g. secure checkout
  (when checkout is enabled), order tracking, friendly support via the contact page, or claims
  taken from ownerDescription.

Keep the whole document under about 35,000 characters: concise CSS, no code comments, and render
repeated items (products, categories, cards) with JavaScript loops instead of repeating markup.

Output ONLY the HTML document, starting with <!doctype html>. No explanations, no markdown fences.`;

/** Models sometimes wrap the page in a ```html fence or add a sentence around it. */
export function extractHtml(content: string): string | null {
  const fenced = /```(?:html)?\s*([\s\S]*?)```/i.exec(content);
  let html = (fenced?.[1] ?? content).trim();
  const start = html.search(/<!doctype html|<html[\s>]/i);
  if (start > 0) html = html.slice(start);
  const end = html.toLowerCase().lastIndexOf('</html>');
  if (end !== -1) html = html.slice(0, end + '</html>'.length);
  if (!/<(html|body|div|main|section)[\s>]/i.test(html) || html.length < 200) return null;
  return html.length > MAX_HTML_LENGTH ? null : html;
}

interface PlannedImage {
  key: string;
  query: string;
  orientation: PhotoOrientation;
}

const ORIENTATIONS: readonly PhotoOrientation[] = ['landscape', 'portrait', 'square'];

/** The page's `<script id="shop-images">` photo list. Model output: anything malformed is skipped. */
export function extractImagePlan(html: string): PlannedImage[] {
  const match = /<script[^>]*id=["']shop-images["'][^>]*>([\s\S]*?)<\/script>/i.exec(html);
  if (!match) return [];
  let raw: unknown;
  try {
    raw = JSON.parse(match[1] ?? '');
  } catch {
    return [];
  }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return [];

  const plan: PlannedImage[] = [];
  for (const [key, value] of Object.entries(raw)) {
    if (!/^[a-z0-9-]{1,40}$/.test(key) || !value || typeof value !== 'object') continue;
    const { query, orientation } = value as { query?: unknown; orientation?: unknown };
    if (typeof query !== 'string' || !query.trim()) continue;
    plan.push({
      key,
      query: query.trim().slice(0, 100),
      orientation: ORIENTATIONS.includes(orientation as PhotoOrientation) ? (orientation as PhotoOrientation) : 'landscape',
    });
    if (plan.length === MAX_PLANNED_IMAGES) break;
  }
  return plan;
}

// ─── Script check + repair ───────────────────────────────────────────────────
// One typo in the page's JavaScript stops the whole script, so products,
// photos and buttons silently never render. Every inline classic script is
// parsed (never run) here, and a broken one is sent back to the model once.

interface InlineScript {
  /** The full `<script ...>...</script>` text as it appears in the page. */
  tag: string;
  code: string;
}

function inlineScripts(html: string): InlineScript[] {
  return [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)]
    .filter(([, attrs = '']) => {
      if (/\bsrc\s*=/i.test(attrs)) return false;
      const type = /\btype\s*=\s*["']?([^"'\s>]+)/i.exec(attrs)?.[1]?.toLowerCase();
      // Only classic scripts: modules can't be parsed as a function body, JSON/templates aren't JS.
      return !type || type === 'text/javascript' || type === 'application/javascript';
    })
    .map(([tag, , code = '']) => ({ tag, code }));
}

/** Syntax error message for `code`, or null when it parses. Nothing is executed. */
export function scriptSyntaxError(code: string): string | null {
  try {
    new vm.Script(code);
    return null;
  } catch (error) {
    return error instanceof Error ? error.message : String(error);
  }
}

const SYSTEM_SCRIPT_REPAIR = `You fix JavaScript syntax errors in a web page's script.
You get the script and the parser's error message. Return ONLY the corrected script: same code,
same behaviour, with the syntax error(s) fixed. No <script> tags, no explanations, no markdown fences.`;

async function repairScript(code: string, error: string): Promise<string | null> {
  try {
    const completion = await openai().chat.completions.create(
      {
        model: env.OPENAI_MODEL,
        messages: [
          { role: 'system', content: SYSTEM_SCRIPT_REPAIR },
          { role: 'user', content: `Parser error: ${error}\n\nScript:\n${code}` },
        ],
      },
      { timeout: 60_000, maxRetries: 0 },
    );
    const fixed = completion.choices[0]?.message?.content ?? '';
    const unfenced = (/```(?:javascript|js)?\s*([\s\S]*?)```/i.exec(fixed)?.[1] ?? fixed).trim();
    return unfenced && !scriptSyntaxError(unfenced) ? unfenced : null;
  } catch (repairError) {
    console.error('OpenAI script repair failed:', repairError);
    return null;
  }
}

/** Returns the page with every inline script parsing cleanly, or null when a script couldn't be repaired. */
async function withWorkingScripts(html: string): Promise<string | null> {
  let page = html;
  for (const script of inlineScripts(html)) {
    const error = scriptSyntaxError(script.code);
    if (!error) continue;
    console.warn(`AI website script has a syntax error (${error}); asking the model to fix it.`);
    const fixed = await repairScript(script.code, error);
    if (!fixed) return null;
    page = page.replace(script.tag, () => script.tag.replace(script.code, () => `\n${fixed}\n`));
  }
  return page;
}

/** Generic industries add nothing to a photo search ("Kids retail"). */
const GENERIC_INDUSTRIES = new Set(['retail', 'other', 'general']);

/**
 * Finds every planned photo plus one per category, skipping keys `existing`
 * already has. One search at a time, page photos first: if the photo quota
 * runs out part-way, the hero and banners are the ones that made it.
 * Photos that can't be found are left out.
 */
/**
 * Simpler searches to try when the hero's own query finds nothing: its first words, the first
 * category, the industry, and finally a generic shopping photo. The hero must never be empty.
 */
function heroFallbackQueries(query: string | undefined, context: { industry: string; categories: string[] }): string[] {
  const words = (query ?? '').split(/s+/).filter(Boolean);
  const industry = GENERIC_INDUSTRIES.has(context.industry.toLowerCase()) ? '' : context.industry;
  return [
    words.slice(0, 3).join(' '),
    words.slice(0, 2).join(' '),
    context.categories[0] ?? '',
    industry ? `${industry} shop` : '',
    'shopping lifestyle',
  ].filter((candidate, index, all) => candidate && candidate !== query && all.indexOf(candidate) === index);
}

async function findWebsiteImages(
  plan: PlannedImage[],
  context: { industry: string; categories: string[] },
  existing: Record<string, WebsiteImage> = {},
): Promise<Record<string, WebsiteImage>> {
  const images = { ...existing };
  if (!stockPhotosEnabled()) return images;
  const industry = GENERIC_INDUSTRIES.has(context.industry.toLowerCase()) ? '' : ` ${context.industry}`;
  // The hero always gets a photo, first in line, even if the page forgot to ask for one.
  const heroPlan = plan.find((item) => item.key === 'hero');
  plan = [
    heroPlan ?? { key: 'hero', query: `${context.categories[0] ?? ''}${industry}`.trim() || 'shopping lifestyle', orientation: 'landscape' },
    ...plan.filter((item) => item.key !== 'hero'),
  ];
  const lookups: { key: string; query: string; orientation: PhotoOrientation; width: number }[] = [
    ...plan.map((item) => ({ ...item, width: item.orientation === 'landscape' ? 1600 : 900 })),
    ...context.categories.slice(0, MAX_CATEGORY_IMAGES).map((name) => ({
      key: `category:${name}`,
      query: `${name}${industry}`,
      orientation: 'portrait' as const,
      width: 700,
    })),
  ];

  const used = new Set<string>();
  for (const { key, query, orientation, width } of lookups) {
    if (images[key]) continue;
    const photo = await findPhoto(query, { orientation, width, used });
    if (photo) images[key] = photo;
  }
  for (const query of images.hero ? [] : heroFallbackQueries(plan[0]?.query, context)) {
    const photo = await findPhoto(query, { orientation: 'landscape', width: 1600, used });
    if (photo) {
      images.hero = photo;
      break;
    }
  }
  return images;
}

/** Fills in the photos an existing AI page is missing (e.g. after the photo quota ran out), without redesigning it. */
export async function refreshWebsiteImages(
  website: GeneratedWebsite,
  context: { industry: string; categories: string[] },
): Promise<GeneratedWebsite> {
  const images = await findWebsiteImages(extractImagePlan(website.html), context, website.images ?? {});
  return { ...website, images };
}

// A full page takes the model ~1.5-3 minutes. It is streamed, so a slow but
// working model isn't cut off by one fixed deadline: generation only stops when
// no text arrives for IDLE_MS, or after MAX_PAGE_MS in total. Page + script
// repair (60s) + photos stays inside the browser's 6-minute request timeout.
const IDLE_MS = 90_000;
const MAX_PAGE_MS = 240_000;

export async function generateWebsiteWithAI(request: WebsiteRequest): Promise<GeneratedWebsite> {
  let content = '';
  const controller = new AbortController();
  let reason: 'idle' | 'too_long' | null = null;
  const stop = (why: 'idle' | 'too_long') => {
    reason = why;
    controller.abort();
  };
  const total = setTimeout(() => stop('too_long'), MAX_PAGE_MS);
  let idle = setTimeout(() => stop('idle'), IDLE_MS);
  try {
    const stream = await openai().chat.completions.create(
      {
        model: env.OPENAI_MODEL,
        stream: true,
        messages: [
          {
            role: 'system',
            content: SYSTEM_WEBSITE_TEMPLATE.replace('{{photoCredit}}', `Photos from ${stockPhotoProvider() ?? 'Unsplash'}`),
          },
          {
            role: 'user',
            content: JSON.stringify({
              task: 'Design and build the shop home page.',
              storeName: request.storeName,
              industry: request.industry,
              enabledFeatures: Object.entries(request.features)
                .filter(([, enabled]) => enabled)
                .map(([feature]) => feature),
              currentCategories: request.categories,
              ownerDescription: request.websitePrompt,
              // Set platform-wide in the super admin's Settings.
              websiteLanguage: LANGUAGE_NAMES[(await getPlatformSettings()).websiteLanguage],
            }),
          },
        ],
      },
      { signal: controller.signal, timeout: MAX_PAGE_MS, maxRetries: 0 },
    );
    for await (const part of stream) {
      clearTimeout(idle);
      idle = setTimeout(() => stop('idle'), IDLE_MS);
      content += part.choices[0]?.delta?.content ?? '';
    }
  } catch (error) {
    console.error(`OpenAI website generation failed${reason ? ` (${reason}, ${content.length} chars received)` : ''}:`, error);
    throw new UpstreamError(
      reason === 'too_long'
        ? 'The AI took too long to design the website. Please try again.'
        : reason === 'idle'
          ? 'The AI stopped responding while designing the website. Please try again.'
          : 'The AI website builder is unavailable. Please try again.',
    );
  } finally {
    clearTimeout(total);
    clearTimeout(idle);
  }

  if (!content) throw new UpstreamError('The AI website builder returned an empty response');

  const draft = extractHtml(content);
  if (!draft) throw new UpstreamError('The AI website builder returned no usable page. Please try again.');
  const html = await withWorkingScripts(draft);
  if (!html) throw new UpstreamError('The AI website had a code error it could not fix. Please try again.');
  const images = await findWebsiteImages(extractImagePlan(html), request);
  return { kind: 'html', html, images };
}
