import type { Request, Response } from 'express';
import { z } from 'zod';
import { CHART_KINDS } from '../../config/constants';
import { requireUser } from '../../middlewares/auth';
import { password } from '../auth/auth.controller';
import { sendSuccess } from '../../utils/apiResponse';
import * as analytics from './analytics.service';
import { askAnalyticsAssistant } from './analyticsAssistant';
import * as service from './superadmin.service';
import * as settings from './settings.service';
import { STORE_CURRENCIES, UI_LANGUAGES } from '../../utils/platformSettings';
import { createTenantDb } from '../../utils/tenantScopedDb';
import { changeOwnPassword as changePassword } from '../admin/admin.manage.service';

export const generateDashboardSchema = z
  .object({
    tenantId: z.number().int().positive(),
    storeName: z.string().trim().min(2, 'storeName must be at least 2 characters').max(80),
    modules: z
      .object({
        storefront: z.boolean(),
        inventory: z.boolean(),
        orders: z.boolean(),
        customers: z.boolean(),
        marketing: z.boolean(),
        customerService: z.boolean(),
      })
      .strict()
      .refine((modules) => Object.values(modules).some(Boolean), {
        message: 'enable at least one module',
      }),
    analyticsCharts: z
      .array(z.enum(CHART_KINDS))
      .min(1, 'select at least one chart type')
      .max(CHART_KINDS.length)
      .refine((charts) => new Set(charts).size === charts.length, 'chart types must be unique'),
    websitePrompt: z.string().trim().max(1000, 'Keep the website description under 1000 characters').default(''),
  })
  .strict()
  // Only stores with a Storefront get a public website to describe.
  .refine((payload) => !payload.modules.storefront || payload.websitePrompt.length >= 10, {
    path: ['websitePrompt'],
    message: 'Describe the website in at least 10 characters',
  });

export type DashboardGenerationPayload = z.infer<typeof generateDashboardSchema>;

const tenantParamsSchema = z.object({ tenantId: z.coerce.number().int().positive() });

const paginationSchema = z.object({
  limit: z.coerce.number().int().min(1).max(200).default(50),
  offset: z.coerce.number().int().min(0).default(0),
});

export async function listTenants(_req: Request, res: Response) {
  return sendSuccess(res, await service.listTenants());
}

export async function listTenantOrders(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  const { limit, offset } = paginationSchema.parse(req.query);
  return sendSuccess(res, await service.listTenantOrders(tenantId, limit, offset));
}

export async function listTenantProducts(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  const { limit, offset } = paginationSchema.parse(req.query);
  return sendSuccess(res, await service.listTenantProducts(tenantId, limit, offset));
}

export async function listTenantLayouts(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  return sendSuccess(res, await service.listTenantLayouts(tenantId));
}

export async function resetStoreLoginPassword(req: Request, res: Response) {
  const { tenantId, userId } = z
    .object({ tenantId: z.coerce.number().int().positive(), userId: z.coerce.number().int().positive() })
    .parse(req.params);
  const body = z
    .object({ newPassword: password, mustChangePassword: z.boolean().default(false) })
    .strict()
    .parse(req.body);
  return sendSuccess(res, await service.resetStoreLoginPassword(tenantId, userId, body));
}

export async function createFirstAdminLogin(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  res.set('Cache-Control', 'no-store');
  return sendSuccess(res, await service.createFirstAdminLogin(tenantId), 201);
}

export async function removeTenant(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  return sendSuccess(res, await service.removeTenant(tenantId));
}

export async function generateDashboard(req: Request, res: Response) {
  const payload = generateDashboardSchema.parse(req.body);
  const user = requireUser(req);
  const result = await service.generateDashboard(payload, user.userId);
  // May carry a new store admin's temporary password: never cache it.
  res.set('Cache-Control', 'no-store');
  return sendSuccess(res, result, 201);
}

export async function getTenantWebsite(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  return sendSuccess(res, await service.getTenantWebsite(tenantId));
}

export async function regenerateWebsite(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  const { websitePrompt } = z
    .object({ websitePrompt: z.string().trim().max(1000, 'Keep the website description under 1000 characters').optional() })
    .strict()
    .parse(req.body ?? {});
  const user = requireUser(req);
  return sendSuccess(res, await service.regenerateWebsite(tenantId, websitePrompt, user.userId), 201);
}

export async function refreshWebsitePhotos(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  const user = requireUser(req);
  return sendSuccess(res, await service.refreshWebsitePhotos(tenantId, user.userId));
}

// ─── Platform analytics (counts only, no money) ──────────────────────────────

const MAX_RANGE_DAYS = 400;
const isoDate = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');

/** `from`/`to` are inclusive calendar days (UTC); default: the last 30 days. */
const periodSchema = z
  .object({ from: isoDate.optional(), to: isoDate.optional() })
  .transform(({ from, to }, ctx) => {
    const today = new Date();
    const end = to ? new Date(`${to}T00:00:00Z`) : new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));
    const start = from ? new Date(`${from}T00:00:00Z`) : new Date(end.getTime() - 29 * 86_400_000);
    const exclusiveEnd = new Date(end.getTime() + 86_400_000);
    const days = (exclusiveEnd.getTime() - start.getTime()) / 86_400_000;
    if (Number.isNaN(days) || days < 1 || days > MAX_RANGE_DAYS) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['from'], message: `Pick a range of 1 to ${MAX_RANGE_DAYS} days` });
      return z.NEVER;
    }
    return { from: start, to: exclusiveEnd };
  });

export async function analyticsOverview(req: Request, res: Response) {
  const period = periodSchema.parse(req.query);
  const [stores, language] = await Promise.all([
    analytics.storesOverview(period),
    settings.getLanguage(requireUser(req).userId),
  ]);
  return sendSuccess(res, { stores, insights: analytics.detectAnomalies(stores, language) });
}

export async function analyticsStore(req: Request, res: Response) {
  const { tenantId } = tenantParamsSchema.parse(req.params);
  return sendSuccess(res, await analytics.storeDetail(tenantId, periodSchema.parse(req.query)));
}

export async function analyticsAssistant(req: Request, res: Response) {
  const body = z
    .object({
      question: z.string().trim().min(2, 'Ask a question').max(1000, 'Keep the question under 1000 characters'),
      history: z
        .array(z.object({ role: z.enum(['user', 'assistant']), content: z.string().max(4000) }).strict())
        .max(20)
        .default([]),
      from: isoDate.optional(),
      to: isoDate.optional(),
    })
    .strict()
    .parse(req.body);
  const period = periodSchema.parse({ from: body.from, to: body.to });
  const language = await settings.getLanguage(requireUser(req).userId);
  return sendSuccess(res, { answer: await askAnalyticsAssistant(body.question, body.history, period, language) });
}

// ─── Settings ────────────────────────────────────────────────────────────────

export async function getSettings(req: Request, res: Response) {
  const user = requireUser(req);
  const [preferences, platform] = await Promise.all([
    settings.getPreferences(user.userId),
    settings.getPlatformSettingsForAdmin(),
  ]);
  return sendSuccess(res, { preferences, platform });
}

export async function savePreferences(req: Request, res: Response) {
  const body = z
    .object({
      // Empty (or only spaces) clears it, so the email's name is shown again.
      displayName: z
        .string()
        .trim()
        .max(60, 'Keep the name under 60 characters')
        .transform((value) => value.replace(/\s+/g, ' ') || null)
        .nullable(),
      language: z.enum(UI_LANGUAGES),
      timeDisplay: z.enum(['local', 'utc']),
      defaultPeriod: z.enum(settings.PERIODS),
      refreshSeconds: z.union([z.literal(0), z.literal(30), z.literal(60), z.literal(300)]),
    })
    .partial()
    .strict()
    .parse(req.body);
  return sendSuccess(res, await settings.savePreferences(requireUser(req).userId, body));
}

export async function savePlatformSettings(req: Request, res: Response) {
  const body = z
    .object({ websiteLanguage: z.enum(UI_LANGUAGES), storeCurrency: z.enum(STORE_CURRENCIES) })
    .partial()
    .strict()
    .parse(req.body);
  return sendSuccess(res, await settings.savePlatformSettings(body, requireUser(req).userId));
}

/** The super admin's own password. Goes through the platform tenant's scoped connection. */
export async function changeOwnPassword(req: Request, res: Response) {
  const body = z
    .object({ currentPassword: z.string().min(1, 'Enter your current password').max(1024), newPassword: password })
    .strict()
    .parse(req.body);
  const user = requireUser(req);
  return sendSuccess(
    res,
    await changePassword(createTenantDb(user.tenantId), user.userId, body.currentPassword, body.newPassword),
  );
}

export async function systemStatus(_req: Request, res: Response) {
  return sendSuccess(res, await settings.systemStatus());
}

export async function testAi(_req: Request, res: Response) {
  return sendSuccess(res, await settings.testAi());
}

export async function testPhotos(_req: Request, res: Response) {
  return sendSuccess(res, await settings.testPhotos());
}
