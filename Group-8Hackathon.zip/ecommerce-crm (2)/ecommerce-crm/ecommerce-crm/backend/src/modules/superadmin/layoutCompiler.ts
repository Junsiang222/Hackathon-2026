import { v4 as uuidv4 } from 'uuid';
import { z } from 'zod';
import { env } from '../../config/env';
import {
  ANALYTICS_SOURCES,
  CHART_KIND_TO_WIDGET_TYPE,
  FINANCIAL_KEY_PATTERN,
  MAX_WIDGETS_PER_LAYOUT,
  SYSTEM_LAYOUT_TEMPLATE,
  WIDGET_TYPES,
  type ChartKind,
  type DashboardModule,
  type WidgetType,
} from '../../config/constants';
import { UpstreamError, ValidationError } from '../../utils/errors';
import type { WidgetConfig } from '../dashboard/dashboard.types';
import { openai } from './aiClient';

export interface LayoutRequest {
  storeName: string;
  modules: Record<DashboardModule, boolean>;
  analyticsCharts: ChartKind[];
  /** Step 9's description of the business/website; empty when Storefront is off. */
  websitePrompt?: string;
  industry?: string;
}

interface AllowedSource {
  url: string;
  description: string;
  dataKeys: readonly string[];
  supportedCharts: WidgetType[];
}

/** Data sources the requested modules + chart types allow, as shown to the model. */
export function resolveAllowedSources(request: LayoutRequest): AllowedSource[] {
  const requested = new Set(request.analyticsCharts);

  return Object.entries(ANALYTICS_SOURCES)
    .filter(([, source]) => request.modules[source.module])
    .map(([url, source]) => ({
      url,
      description: source.description,
      dataKeys: source.dataKeys,
      supportedCharts: source.supportedCharts
        .filter((kind) => requested.has(kind))
        .map((kind) => CHART_KIND_TO_WIDGET_TYPE[kind]),
    }))
    .filter((source) => source.supportedCharts.length > 0);
}

export function compileLayoutPrompt(request: LayoutRequest, sources: AllowedSource[]): string {
  const chartTypes = [...new Set(request.analyticsCharts.map((kind) => CHART_KIND_TO_WIDGET_TYPE[kind]))];
  const substitutions: Record<string, string> = {
    storeName: JSON.stringify(request.storeName),
    chartTypes: JSON.stringify(chartTypes),
    dataSources: JSON.stringify(sources),
    maxWidgets: String(MAX_WIDGETS_PER_LAYOUT),
  };
  return SYSTEM_LAYOUT_TEMPLATE.replace(/\{\{(\w+)\}\}/g, (match, token: string) => substitutions[token] ?? match);
}

const rawWidgetSchema = z.object({
  type: z.string(),
  title: z.string(),
  dataSourceUrl: z.string(),
  colSpan: z.coerce.number(),
  dataKeys: z.array(z.string()),
});

const rawResponseSchema = z.object({ widgets: z.array(z.unknown()) });

/**
 * Model output is untrusted. Every widget is re-validated against the
 * allowlisted catalog; anything that doesn't fit is dropped, ids are minted
 * here, and monetary keys can never survive.
 */
export function normaliseWidgets(raw: unknown, sources: AllowedSource[]): WidgetConfig[] {
  const parsed = rawResponseSchema.safeParse(raw);
  if (!parsed.success) return [];

  const sourceByUrl = new Map(sources.map((source) => [source.url, source]));
  const widgets: WidgetConfig[] = [];

  for (const candidate of parsed.data.widgets) {
    const widget = rawWidgetSchema.safeParse(candidate);
    if (!widget.success) continue;

    const { type, dataSourceUrl } = widget.data;
    const source = sourceByUrl.get(dataSourceUrl);
    if (!source) continue;
    if (!(WIDGET_TYPES as readonly string[]).includes(type)) continue;
    const widgetType = type as WidgetType;
    if (!source.supportedCharts.includes(widgetType)) continue;

    const dataKeys = [...new Set(widget.data.dataKeys)]
      .filter((key) => source.dataKeys.includes(key) && !FINANCIAL_KEY_PATTERN.test(key))
      .slice(0, 4);
    if (dataKeys.length === 0) continue;

    const title = widget.data.title.trim().slice(0, 60);
    if (!title || FINANCIAL_KEY_PATTERN.test(title)) continue;

    const requestedSpan = widget.data.colSpan;
    const colSpan: WidgetConfig['colSpan'] =
      requestedSpan === 4 || requestedSpan === 6 || requestedSpan === 12
        ? requestedSpan
        : widgetType === 'CircleChart'
          ? 4
          : 6;

    widgets.push({ widgetId: uuidv4(), type: widgetType, title, dataSourceUrl, colSpan, dataKeys });
    if (widgets.length === MAX_WIDGETS_PER_LAYOUT) break;
  }

  return widgets;
}

export async function compileLayoutWithAI(request: LayoutRequest): Promise<WidgetConfig[]> {
  const sources = resolveAllowedSources(request);
  if (sources.length === 0) {
    throw new ValidationError('Enable at least one module that supports the selected chart types', [
      { path: 'modules', message: 'No data source matches the enabled modules and chart types' },
    ]);
  }

  const systemPrompt = compileLayoutPrompt(request, sources);

  let content: string | null | undefined;
  try {
    const completion = await openai().chat.completions.create({
      model: env.OPENAI_MODEL,
      response_format: { type: 'json_object' },
      // No temperature: gpt-6-luna only accepts the default (1).
      messages: [
        { role: 'system', content: systemPrompt },
        {
          role: 'user',
          content: JSON.stringify({
            task: 'Compile the dashboard layout as JSON.',
            storeName: request.storeName,
            industry: request.industry,
            businessDescription: request.websitePrompt || undefined,
            enabledModules: Object.entries(request.modules)
              .filter(([, enabled]) => enabled)
              .map(([module]) => module),
            analyticsCharts: request.analyticsCharts,
          }),
        },
      ],
    });
    content = completion.choices[0]?.message?.content;
  } catch (error) {
    console.error('OpenAI layout compilation failed:', error);
    throw new UpstreamError('The AI layout engine is unavailable. Please try again.');
  }

  if (!content) throw new UpstreamError('The AI layout engine returned an empty response');

  let raw: unknown;
  try {
    raw = JSON.parse(content);
  } catch {
    throw new UpstreamError('The AI layout engine returned malformed JSON');
  }

  const widgets = normaliseWidgets(raw, sources);
  if (widgets.length === 0) {
    throw new UpstreamError('The AI layout engine returned no usable widgets. Please try again.');
  }
  return widgets;
}
