import type { RowDataPacket } from 'mysql2/promise';
import { env } from '../../config/env';
import { superAdminPool } from '../../config/db';
import {
  clearPlatformSettingsCache,
  settingsFromRows,
  type PlatformSettings,
  type UiLanguage,
} from '../../utils/platformSettings';
import { findPhoto, photoQuota, stockPhotoProvider } from '../../utils/stockPhotos';
import { openai } from './aiClient';

// Super admin Settings. Preferences are per account (always the signed-in
// user's own row); platform settings apply to every store.

export const PERIODS = ['today', '7d', '30d', 'month', '90d'] as const;
export const REFRESH_SECONDS = [0, 30, 60, 300] as const;

export interface Preferences {
  /** Shown in the profile menu; null = derived from the email. */
  displayName: string | null;
  language: UiLanguage;
  timeDisplay: 'local' | 'utc';
  defaultPeriod: (typeof PERIODS)[number];
  refreshSeconds: (typeof REFRESH_SECONDS)[number];
}

export const DEFAULT_PREFERENCES: Preferences = { displayName: null, language: 'en', timeDisplay: 'local', defaultPeriod: '30d', refreshSeconds: 60 };

export async function getPreferences(userId: number): Promise<Preferences> {
  try {
    const [rows] = await superAdminPool.execute<RowDataPacket[]>(
      'SELECT display_name, language, time_display, default_period, refresh_seconds FROM user_preferences WHERE user_id = ?',
      [userId],
    );
    const row = rows[0];
    if (!row) return DEFAULT_PREFERENCES;
    return {
      displayName: row.display_name === null ? null : String(row.display_name),
      language: row.language as UiLanguage,
      timeDisplay: row.time_display as Preferences['timeDisplay'],
      defaultPeriod: row.default_period as Preferences['defaultPeriod'],
      refreshSeconds: Number(row.refresh_seconds) as Preferences['refreshSeconds'],
    };
  } catch (error) {
    // Before migration 008: everything keeps working with the defaults.
    console.warn('Reading preferences failed; using defaults:', (error as Error).message);
    return DEFAULT_PREFERENCES;
  }
}

/** The signed-in super admin's dashboard language (used by the AI assistant and alerts). */
export async function getLanguage(userId: number): Promise<UiLanguage> {
  return (await getPreferences(userId)).language;
}

export async function savePreferences(userId: number, changes: Partial<Preferences>): Promise<Preferences> {
  const next = { ...(await getPreferences(userId)), ...changes };
  await superAdminPool.execute(
    `INSERT INTO user_preferences (user_id, display_name, language, time_display, default_period, refresh_seconds)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), language = VALUES(language),
                             time_display = VALUES(time_display), default_period = VALUES(default_period),
                             refresh_seconds = VALUES(refresh_seconds)`,
    [userId, next.displayName, next.language, next.timeDisplay, next.defaultPeriod, next.refreshSeconds],
  );
  return next;
}

export async function getPlatformSettingsForAdmin(): Promise<PlatformSettings> {
  const [rows] = await superAdminPool.execute<RowDataPacket[]>('SELECT setting_key, setting_value FROM platform_settings');
  return settingsFromRows(rows as { setting_key: string; setting_value: unknown }[]);
}

export async function savePlatformSettings(changes: Partial<PlatformSettings>, userId: number): Promise<PlatformSettings> {
  const entries: [string, string][] = [];
  if (changes.websiteLanguage) entries.push(['website_language', changes.websiteLanguage]);
  if (changes.storeCurrency) entries.push(['store_currency', changes.storeCurrency]);
  for (const [key, value] of entries) {
    await superAdminPool.execute(
      `INSERT INTO platform_settings (setting_key, setting_value, updated_by)
       VALUES (?, JSON_QUOTE(?), ?)
       ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)`,
      [key, value, userId],
    );
  }
  clearPlatformSettingsCache();
  return getPlatformSettingsForAdmin();
}

// ─── System status ───────────────────────────────────────────────────────────

const aiHost = () => {
  try {
    return new URL(env.OPENAI_BASE_URL ?? 'https://api.openai.com/v1').host;
  } catch {
    return 'unknown';
  }
};

export async function systemStatus() {
  let database = { ok: true, ms: 0 };
  const started = Date.now();
  try {
    await superAdminPool.query('SELECT 1');
    database = { ok: true, ms: Date.now() - started };
  } catch {
    database = { ok: false, ms: Date.now() - started };
  }
  return {
    database,
    ai: { model: env.OPENAI_MODEL, host: aiHost() },
    photos: { provider: stockPhotoProvider(), ...photoQuota() },
  };
}

/** A tiny real request to the AI model, so the admin can tell "slow" from "broken". */
export async function testAi() {
  const started = Date.now();
  try {
    const completion = await openai().chat.completions.create(
      { model: env.OPENAI_MODEL, messages: [{ role: 'user', content: 'Reply with the single word OK.' }] },
      { timeout: 30_000, maxRetries: 0 },
    );
    const reply = completion.choices[0]?.message?.content?.trim() ?? '';
    return { ok: reply.length > 0, ms: Date.now() - started, message: reply ? 'The AI model answered.' : 'The AI model returned an empty answer.' };
  } catch (error) {
    const status = (error as { status?: number }).status;
    const message =
      status === 401
        ? 'The API key was rejected (401). Check OPENAI_API_KEY.'
        : status === 404
          ? 'The model was not found (404). Check OPENAI_MODEL and OPENAI_BASE_URL.'
          : status === 429
            ? 'The AI provider is rate-limiting or out of credit (429).'
            : (error as Error).name.includes('Timeout')
              ? 'No answer within 30 seconds.'
              : (error as Error).message;
    return { ok: false, ms: Date.now() - started, message };
  }
}

/** One photo search (answered from the cache when possible, so it rarely costs quota). */
export async function testPhotos() {
  const provider = stockPhotoProvider();
  if (!provider) return { ok: false, message: 'No photo key is set. Add UNSPLASH_ACCESS_KEY to backend/.env.', ...photoQuota() };
  const photo = await findPhoto('storefront', { orientation: 'landscape', width: 400 });
  const quota = photoQuota();
  return {
    ok: Boolean(photo),
    message: photo
      ? `${provider} answered.`
      : quota.paused
        ? `The ${provider} hourly limit is used up. Searches resume automatically.`
        : `${provider} did not return a photo. Check the key in backend/.env.`,
    ...quota,
  };
}
