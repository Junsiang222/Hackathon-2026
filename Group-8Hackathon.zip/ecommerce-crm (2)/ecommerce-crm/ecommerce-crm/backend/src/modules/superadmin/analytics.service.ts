import type { RowDataPacket } from 'mysql2/promise';
import { superAdminPool } from '../../config/db';
import { NotFoundError } from '../../utils/errors';
import type { UiLanguage } from '../../utils/platformSettings';

// Platform analytics for the super admin. Counts only: every query reads the
// money-free super_admin_* views (migration 007), so no price, amount or cost
// can reach this module, let alone the response. Field names also avoid the
// words financialStripper removes (total, amount, price, …).

export interface Period {
  from: Date;
  /** Exclusive end. */
  to: Date;
}

export interface StoreMetrics {
  orders: number;
  /** Units in orders that weren't cancelled or refunded. */
  unitsSold: number;
  cancelledOrRefunded: number;
  /** Distinct customers who ordered. */
  buyers: number;
  newCustomers: number;
  pageViews: number;
  addToCarts: number;
  checkoutsStarted: number;
}

export interface StoreOverview {
  tenantId: number;
  tenantUid: string;
  storeName: string;
  industry: string;
  status: string;
  current: StoreMetrics;
  previous: StoreMetrics;
  openTickets: number;
  urgentTickets: number;
  outOfStock: number;
  lowStock: number;
  /** Out-of-stock products that sold in the period: lost sales. */
  outOfStockSellers: number;
}

const DAY_MS = 86_400_000;
const VALID_ORDER = "o.status NOT IN ('cancelled', 'refunded')";

const emptyMetrics = (): StoreMetrics => ({
  orders: 0,
  unitsSold: 0,
  cancelledOrRefunded: 0,
  buyers: 0,
  newCustomers: 0,
  pageViews: 0,
  addToCarts: 0,
  checkoutsStarted: 0,
});

/** The same-length window right before `period`. */
export function previousPeriod(period: Period): Period {
  const length = period.to.getTime() - period.from.getTime();
  return { from: new Date(period.from.getTime() - length), to: period.from };
}

async function rows(sql: string, params: unknown[]): Promise<RowDataPacket[]> {
  const [result] = await superAdminPool.query<RowDataPacket[]>(sql, params);
  return result;
}

const num = (value: unknown) => Number(value ?? 0);

interface TenantRow {
  id: number;
  tenantUid: string;
  storeName: string;
  industry: string;
  status: string;
}

async function listStores(tenantId?: number): Promise<TenantRow[]> {
  const result = await rows(
    `SELECT id, tenant_uid, business_name, industry, status
       FROM admins
      WHERE is_platform = 0 AND status <> 'cancelled' ${tenantId ? 'AND id = ?' : ''}
      ORDER BY business_name`,
    tenantId ? [tenantId] : [],
  );
  return result.map((row) => ({
    id: Number(row.id),
    tenantUid: String(row.tenant_uid),
    storeName: String(row.business_name),
    industry: String(row.industry),
    status: String(row.status),
  }));
}

/** Per-store metrics for one period, keyed by tenant id. */
async function metricsByStore(period: Period, tenantIds: number[]): Promise<Map<number, StoreMetrics>> {
  const result = new Map<number, StoreMetrics>(tenantIds.map((id) => [id, emptyMetrics()]));
  if (tenantIds.length === 0) return result;
  const range = [period.from, period.to, tenantIds];
  const get = (id: unknown) => result.get(Number(id));

  const [orders, units, customers, traffic] = await Promise.all([
    rows(
      `SELECT o.tenant_id,
              COUNT(*) AS orders,
              SUM(o.status IN ('cancelled', 'refunded')) AS cancelled_or_refunded,
              COUNT(DISTINCT o.customer_id) AS buyers
         FROM super_admin_order_view o
        WHERE o.placed_at >= ? AND o.placed_at < ? AND o.tenant_id IN (?)
        GROUP BY o.tenant_id`,
      range,
    ),
    rows(
      `SELECT o.tenant_id, SUM(oi.qty) AS units
         FROM super_admin_order_view o
         JOIN super_admin_order_item_view oi ON oi.order_id = o.id AND oi.tenant_id = o.tenant_id
        WHERE o.placed_at >= ? AND o.placed_at < ? AND o.tenant_id IN (?) AND ${VALID_ORDER}
        GROUP BY o.tenant_id`,
      range,
    ),
    rows(
      `SELECT tenant_id, COUNT(*) AS new_customers
         FROM super_admin_customer_view
        WHERE created_at >= ? AND created_at < ? AND tenant_id IN (?)
        GROUP BY tenant_id`,
      range,
    ),
    rows(
      `SELECT tenant_id, event_type, COUNT(*) AS events
         FROM super_admin_traffic_view
        WHERE recorded_at >= ? AND recorded_at < ? AND tenant_id IN (?)
          AND event_type IN ('page_view', 'add_to_cart', 'checkout_started')
        GROUP BY tenant_id, event_type`,
      range,
    ),
  ]);

  for (const row of orders) {
    const metrics = get(row.tenant_id);
    if (!metrics) continue;
    metrics.orders = num(row.orders);
    metrics.cancelledOrRefunded = num(row.cancelled_or_refunded);
    metrics.buyers = num(row.buyers);
  }
  for (const row of units) {
    const metrics = get(row.tenant_id);
    if (metrics) metrics.unitsSold = num(row.units);
  }
  for (const row of customers) {
    const metrics = get(row.tenant_id);
    if (metrics) metrics.newCustomers = num(row.new_customers);
  }
  for (const row of traffic) {
    const metrics = get(row.tenant_id);
    if (!metrics) continue;
    if (row.event_type === 'page_view') metrics.pageViews = num(row.events);
    if (row.event_type === 'add_to_cart') metrics.addToCarts = num(row.events);
    if (row.event_type === 'checkout_started') metrics.checkoutsStarted = num(row.events);
  }
  return result;
}

/** Tickets and stock right now, plus out-of-stock products that sold in the period. */
async function healthByStore(period: Period, tenantIds: number[]) {
  const result = new Map(
    tenantIds.map((id) => [id, { openTickets: 0, urgentTickets: 0, outOfStock: 0, lowStock: 0, outOfStockSellers: 0 }]),
  );
  if (tenantIds.length === 0) return result;

  const [tickets, stock, sellers] = await Promise.all([
    rows(
      `SELECT tenant_id,
              COUNT(*) AS open_tickets,
              SUM(priority = 'urgent') AS urgent_tickets
         FROM super_admin_ticket_view
        WHERE status IN ('open', 'in_progress', 'pending_customer') AND tenant_id IN (?)
        GROUP BY tenant_id`,
      [tenantIds],
    ),
    rows(
      `SELECT i.tenant_id,
              SUM(i.qty_available = 0) AS out_of_stock,
              SUM(i.qty_available > 0 AND i.qty_available <= i.restock_threshold) AS low_stock
         FROM super_admin_inventory_view i
         JOIN super_admin_product_view p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
        WHERE p.status = 'active' AND i.tenant_id IN (?)
        GROUP BY i.tenant_id`,
      [tenantIds],
    ),
    rows(
      `SELECT i.tenant_id, COUNT(DISTINCT i.product_id) AS sellers
         FROM super_admin_inventory_view i
         JOIN super_admin_product_view p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
         JOIN super_admin_order_item_view oi ON oi.product_id = i.product_id AND oi.tenant_id = i.tenant_id
         JOIN super_admin_order_view o ON o.id = oi.order_id AND o.tenant_id = oi.tenant_id
        WHERE p.status = 'active' AND i.qty_available = 0
          AND o.placed_at >= ? AND o.placed_at < ? AND i.tenant_id IN (?)
        GROUP BY i.tenant_id`,
      [period.from, period.to, tenantIds],
    ),
  ]);

  for (const row of tickets) {
    const health = result.get(Number(row.tenant_id));
    if (!health) continue;
    health.openTickets = num(row.open_tickets);
    health.urgentTickets = num(row.urgent_tickets);
  }
  for (const row of stock) {
    const health = result.get(Number(row.tenant_id));
    if (!health) continue;
    health.outOfStock = num(row.out_of_stock);
    health.lowStock = num(row.low_stock);
  }
  for (const row of sellers) {
    const health = result.get(Number(row.tenant_id));
    if (health) health.outOfStockSellers = num(row.sellers);
  }
  return result;
}

export async function storesOverview(period: Period, tenantId?: number): Promise<StoreOverview[]> {
  const stores = await listStores(tenantId);
  const ids = stores.map((store) => store.id);
  const [current, previous, health] = await Promise.all([
    metricsByStore(period, ids),
    metricsByStore(previousPeriod(period), ids),
    healthByStore(period, ids),
  ]);
  return stores.map((store) => ({
    tenantId: store.id,
    tenantUid: store.tenantUid,
    storeName: store.storeName,
    industry: store.industry,
    status: store.status,
    current: current.get(store.id) ?? emptyMetrics(),
    previous: previous.get(store.id) ?? emptyMetrics(),
    ...health.get(store.id)!,
  }));
}

// ─── Store drill-down ────────────────────────────────────────────────────────

const isoDay = (date: Date) => date.toISOString().slice(0, 10);
const isoMonth = (date: Date) => date.toISOString().slice(0, 7);
const round = (value: number, digits = 2) => Math.round(value * 10 ** digits) / 10 ** digits;

export async function storeDetail(tenantId: number, period: Period) {
  const [overview] = await storesOverview(period, tenantId);
  if (!overview) throw new NotFoundError('This store does not exist or has been removed');
  const range = [tenantId, period.from, period.to];

  // Calendar months for month-over-month and year-over-year: the last 13 full months plus this one.
  const now = new Date();
  const monthsFrom = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 13, 1));

  const [daily, dailyUnits, dailyTraffic, products, heatmap, statuses, buyers, stock, tickets, monthly, monthlyUnits, monthlyCustomers] =
    await Promise.all([
      rows(
        `SELECT DATE(placed_at) AS day, COUNT(*) AS orders
           FROM super_admin_order_view
          WHERE tenant_id = ? AND placed_at >= ? AND placed_at < ?
          GROUP BY DATE(placed_at)`,
        range,
      ),
      rows(
        `SELECT DATE(o.placed_at) AS day, SUM(oi.qty) AS units
           FROM super_admin_order_view o
           JOIN super_admin_order_item_view oi ON oi.order_id = o.id AND oi.tenant_id = o.tenant_id
          WHERE o.tenant_id = ? AND o.placed_at >= ? AND o.placed_at < ? AND ${VALID_ORDER}
          GROUP BY DATE(o.placed_at)`,
        range,
      ),
      rows(
        `SELECT DATE(recorded_at) AS day, COUNT(*) AS views
           FROM super_admin_traffic_view
          WHERE tenant_id = ? AND recorded_at >= ? AND recorded_at < ? AND event_type = 'page_view'
          GROUP BY DATE(recorded_at)`,
        range,
      ),
      rows(
        `SELECT p.id, p.name, p.category, p.image_url,
                COALESCE(s.units, 0) AS units, COALESCE(s.orders, 0) AS orders,
                i.qty_available
           FROM super_admin_product_view p
           LEFT JOIN (
                SELECT oi.product_id, SUM(oi.qty) AS units, COUNT(DISTINCT oi.order_id) AS orders
                  FROM super_admin_order_item_view oi
                  JOIN super_admin_order_view o ON o.id = oi.order_id AND o.tenant_id = oi.tenant_id
                 WHERE o.tenant_id = ? AND o.placed_at >= ? AND o.placed_at < ? AND ${VALID_ORDER}
                 GROUP BY oi.product_id
           ) s ON s.product_id = p.id
           LEFT JOIN super_admin_inventory_view i ON i.product_id = p.id AND i.tenant_id = p.tenant_id
          WHERE p.tenant_id = ? AND p.status = 'active'
          ORDER BY units DESC, p.name`,
        [...range, tenantId],
      ),
      rows(
        `SELECT DAYOFWEEK(placed_at) AS dow, HOUR(placed_at) AS hour, COUNT(*) AS orders
           FROM super_admin_order_view
          WHERE tenant_id = ? AND placed_at >= ? AND placed_at < ?
          GROUP BY DAYOFWEEK(placed_at), HOUR(placed_at)`,
        range,
      ),
      rows(
        `SELECT status, COUNT(*) AS orders
           FROM super_admin_order_view
          WHERE tenant_id = ? AND placed_at >= ? AND placed_at < ?
          GROUP BY status`,
        range,
      ),
      rows(
        `SELECT o.customer_id,
                COUNT(*) AS orders_in_period,
                EXISTS (SELECT 1 FROM super_admin_order_view b
                         WHERE b.tenant_id = o.tenant_id AND b.customer_id = o.customer_id AND b.placed_at < ?) AS ordered_before
           FROM super_admin_order_view o
          WHERE o.tenant_id = ? AND o.placed_at >= ? AND o.placed_at < ? AND ${VALID_ORDER}
          GROUP BY o.customer_id, o.tenant_id`,
        [period.from, ...range],
      ),
      rows(
        `SELECT COALESCE(SUM(i.qty_available), 0) AS on_hand
           FROM super_admin_inventory_view i
           JOIN super_admin_product_view p ON p.id = i.product_id AND p.tenant_id = i.tenant_id
          WHERE i.tenant_id = ? AND p.status = 'active'`,
        [tenantId],
      ),
      rows(
        `SELECT COUNT(*) AS resolved,
                AVG(TIMESTAMPDIFF(MINUTE, created_at, resolved_at)) / 60 AS avg_hours
           FROM super_admin_ticket_view
          WHERE tenant_id = ? AND resolved_at >= ? AND resolved_at < ?`,
        range,
      ),
      rows(
        `SELECT DATE_FORMAT(placed_at, '%Y-%m') AS month, COUNT(*) AS orders
           FROM super_admin_order_view
          WHERE tenant_id = ? AND placed_at >= ?
          GROUP BY DATE_FORMAT(placed_at, '%Y-%m')`,
        [tenantId, monthsFrom],
      ),
      rows(
        `SELECT DATE_FORMAT(o.placed_at, '%Y-%m') AS month, SUM(oi.qty) AS units
           FROM super_admin_order_view o
           JOIN super_admin_order_item_view oi ON oi.order_id = o.id AND oi.tenant_id = o.tenant_id
          WHERE o.tenant_id = ? AND o.placed_at >= ? AND ${VALID_ORDER}
          GROUP BY DATE_FORMAT(o.placed_at, '%Y-%m')`,
        [tenantId, monthsFrom],
      ),
      rows(
        `SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS customers
           FROM super_admin_customer_view
          WHERE tenant_id = ? AND created_at >= ?
          GROUP BY DATE_FORMAT(created_at, '%Y-%m')`,
        [tenantId, monthsFrom],
      ),
    ]);

  // Daily trend with every day present (zero when nothing happened).
  const byDay = (list: RowDataPacket[], field: string) =>
    new Map(list.map((row) => [isoDay(new Date(row.day)), num(row[field])]));
  const ordersByDay = byDay(daily, 'orders');
  const unitsByDay = byDay(dailyUnits, 'units');
  const viewsByDay = byDay(dailyTraffic, 'views');
  const trend: { date: string; orders: number; unitsSold: number; pageViews: number }[] = [];
  for (let t = period.from.getTime(); t < period.to.getTime(); t += DAY_MS) {
    const date = isoDay(new Date(t));
    trend.push({
      date,
      orders: ordersByDay.get(date) ?? 0,
      unitsSold: unitsByDay.get(date) ?? 0,
      pageViews: viewsByDay.get(date) ?? 0,
    });
  }

  const productList = products.map((row) => ({
    productId: Number(row.id),
    name: String(row.name),
    category: row.category === null ? null : String(row.category),
    imageUrl: row.image_url === null ? null : String(row.image_url),
    unitsSold: num(row.units),
    orders: num(row.orders),
    inStock: row.qty_available === null ? null : num(row.qty_available),
  }));

  // Orders by weekday (0 = Sunday) and hour, UTC.
  const peak = Array.from({ length: 7 }, () => Array<number>(24).fill(0));
  for (const row of heatmap) peak[num(row.dow) - 1]![num(row.hour)] = num(row.orders);

  const buyerCount = buyers.length;
  const repeatBuyers = buyers.filter((row) => num(row.orders_in_period) >= 2).length;
  const returningBuyers = buyers.filter((row) => num(row.ordered_before) === 1).length;
  const validOrders = overview.current.orders - overview.current.cancelledOrRefunded;
  const days = Math.max(1, (period.to.getTime() - period.from.getTime()) / DAY_MS);
  const onHand = num(stock[0]?.on_hand);

  // Month-over-month / year-over-year on the last full month.
  const monthMap = (list: RowDataPacket[], field: string) => new Map(list.map((row) => [String(row.month), num(row[field])]));
  const ordersByMonth = monthMap(monthly, 'orders');
  const unitsByMonth = monthMap(monthlyUnits, 'units');
  const customersByMonth = monthMap(monthlyCustomers, 'customers');
  const monthKey = (offset: number) => isoMonth(new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + offset, 1)));
  const months = Array.from({ length: 14 }, (_, index) => monthKey(index - 13));
  const compare = (map: Map<string, number>) => {
    const value = map.get(monthKey(-1)) ?? 0;
    const lastMonth = map.get(monthKey(-2)) ?? 0;
    const lastYear = map.get(monthKey(-13)) ?? 0;
    return { value, mom: change(value, lastMonth), yoy: change(value, lastYear), lastMonth, lastYear };
  };

  return {
    store: overview,
    trend,
    topProducts: productList.slice(0, 5),
    lowProducts: [...productList].sort((a, b) => a.unitsSold - b.unitsSold || a.name.localeCompare(b.name)).slice(0, 5),
    peakHours: peak,
    statusBreakdown: statuses.map((row) => ({ status: String(row.status), orders: num(row.orders) })),
    retention: {
      buyers: buyerCount,
      repeatBuyers,
      returningBuyers,
      /** Share of this period's buyers who ordered 2+ times in it. */
      repeatRate: buyerCount ? round(repeatBuyers / buyerCount, 3) : null,
      /** Share of this period's buyers who had also ordered before it. */
      returningRate: buyerCount ? round(returningBuyers / buyerCount, 3) : null,
    },
    itemsPerOrder: validOrders > 0 ? round(overview.current.unitsSold / validOrders) : null,
    conversionRate: overview.current.pageViews > 0 ? round(validOrders / overview.current.pageViews, 4) : null,
    inventory: {
      unitsOnHand: onHand,
      /** Units sold in the period ÷ units on hand now (approximate: no stock history is kept). */
      turnover: onHand > 0 ? round(overview.current.unitsSold / onHand) : null,
      /** How many days current stock lasts at this period's sales pace. */
      daysOfCover: overview.current.unitsSold > 0 ? Math.round(onHand / (overview.current.unitsSold / days)) : null,
    },
    tickets: {
      resolved: num(tickets[0]?.resolved),
      avgResolutionHours: tickets[0]?.avg_hours === null ? null : round(num(tickets[0]?.avg_hours), 1),
    },
    monthly: months.map((month) => ({
      month,
      orders: ordersByMonth.get(month) ?? 0,
      unitsSold: unitsByMonth.get(month) ?? 0,
      newCustomers: customersByMonth.get(month) ?? 0,
    })),
    monthComparison: {
      month: monthKey(-1),
      orders: compare(ordersByMonth),
      unitsSold: compare(unitsByMonth),
      newCustomers: compare(customersByMonth),
    },
  };
}

/** Percentage change, or null when there's nothing to compare against. */
export function change(value: number, before: number): number | null {
  if (before === 0) return value === 0 ? 0 : null;
  return round(((value - before) / before) * 100, 1);
}

// ─── Anomalies ───────────────────────────────────────────────────────────────

export interface Insight {
  tenantId: number;
  storeName: string;
  severity: 'high' | 'medium' | 'info';
  kind: 'orders_drop' | 'orders_spike' | 'cancellations' | 'conversion_drop' | 'stockouts' | 'urgent_tickets' | 'no_orders';
  message: string;
  recommendation: string;
}

const pct = (value: number) => `${Math.abs(Math.round(value))}%`;

interface AlertParams {
  store: string;
  before: number;
  now: number;
  change: string;
  rate: string;
  rateBefore: string;
  count: number;
}

type AlertText = (p: AlertParams) => { message: string; recommendation: string };

/** Alert wording in each dashboard language (Settings → Language). */
const ALERTS: Record<UiLanguage, Record<Insight['kind'], AlertText>> = {
  en: {
    no_orders: (p) => ({
      message: `${p.store} had no orders this period (${p.before} the period before).`,
      recommendation: 'Check the shop is online and checkout works, then look for a stock or listing problem.',
    }),
    orders_drop: (p) => ({
      message: `${p.store}'s orders fell ${p.change} (${p.before} → ${p.now}).`,
      recommendation:
        'Compare traffic and conversion: fewer visitors points to marketing, fewer buyers per visit points to stock, prices or the shop page.',
    }),
    orders_spike: (p) => ({
      message: `${p.store}'s orders rose ${p.change} (${p.before} → ${p.now}).`,
      recommendation: 'Find out what drove it (campaign, product, season) and make sure stock keeps up.',
    }),
    cancellations: (p) => ({
      message: `${p.rate} of ${p.store}'s orders were cancelled or refunded (${p.rateBefore} before).`,
      recommendation: 'Review recent support tickets and product descriptions for wrong sizes, damage or delivery issues.',
    }),
    conversion_drop: (p) => ({
      message: `${p.store}'s conversion fell ${p.change}: visitors are coming but fewer are buying.`,
      recommendation: 'Check for sold-out best sellers, broken pages or a recent change to the shop.',
    }),
    stockouts: (p) => ({
      message:
        p.count === 1
          ? `${p.store} has 1 product that sold this period but is now out of stock.`
          : `${p.store} has ${p.count} products that sold this period but are now out of stock.`,
      recommendation: 'Ask the store to restock these first: they are losing sales every day.',
    }),
    urgent_tickets: (p) => ({
      message: `${p.store} has ${p.count} urgent support tickets open.`,
      recommendation: 'Check the store is responding to customers; slow replies lead to refunds and lost repeat buyers.',
    }),
  },
  ms: {
    no_orders: (p) => ({
      message: `${p.store} tiada pesanan dalam tempoh ini (${p.before} dalam tempoh sebelumnya).`,
      recommendation: 'Pastikan kedai dalam talian dan pembayaran berfungsi, kemudian semak masalah stok atau senarai produk.',
    }),
    orders_drop: (p) => ({
      message: `Pesanan ${p.store} turun ${p.change} (${p.before} → ${p.now}).`,
      recommendation:
        'Bandingkan trafik dan kadar penukaran: kurang pelawat menunjukkan isu pemasaran, kurang pembeli setiap lawatan menunjukkan isu stok, harga atau halaman kedai.',
    }),
    orders_spike: (p) => ({
      message: `Pesanan ${p.store} naik ${p.change} (${p.before} → ${p.now}).`,
      recommendation: 'Kenal pasti puncanya (kempen, produk, musim) dan pastikan stok mencukupi.',
    }),
    cancellations: (p) => ({
      message: `${p.rate} pesanan ${p.store} dibatalkan atau dipulangkan (${p.rateBefore} sebelum ini).`,
      recommendation: 'Semak tiket sokongan terkini dan penerangan produk untuk saiz salah, kerosakan atau masalah penghantaran.',
    }),
    conversion_drop: (p) => ({
      message: `Kadar penukaran ${p.store} turun ${p.change}: pelawat datang tetapi kurang yang membeli.`,
      recommendation: 'Semak produk laris yang habis stok, halaman rosak atau perubahan terkini pada kedai.',
    }),
    stockouts: (p) => ({
      message: `${p.store} mempunyai ${p.count} produk yang terjual dalam tempoh ini tetapi kini kehabisan stok.`,
      recommendation: 'Minta kedai menambah stok produk ini dahulu: jualan hilang setiap hari.',
    }),
    urgent_tickets: (p) => ({
      message: `${p.store} mempunyai ${p.count} tiket sokongan segera yang masih terbuka.`,
      recommendation: 'Pastikan kedai membalas pelanggan; balasan lambat menyebabkan bayaran balik dan pembeli tidak kembali.',
    }),
  },
  zh: {
    no_orders: (p) => ({
      message: `${p.store} 在此期间没有订单（上一期间为 ${p.before} 笔）。`,
      recommendation: '请确认店铺在线且结账功能正常，然后检查库存或商品上架问题。',
    }),
    orders_drop: (p) => ({
      message: `${p.store} 的订单下降了 ${p.change}（${p.before} → ${p.now}）。`,
      recommendation: '对比流量和转化率：访客减少说明是营销问题，访客购买减少说明是库存、价格或店铺页面问题。',
    }),
    orders_spike: (p) => ({
      message: `${p.store} 的订单增长了 ${p.change}（${p.before} → ${p.now}）。`,
      recommendation: '找出增长原因（活动、商品、季节），并确保库存跟得上。',
    }),
    cancellations: (p) => ({
      message: `${p.store} 有 ${p.rate} 的订单被取消或退款（之前为 ${p.rateBefore}）。`,
      recommendation: '查看最近的客服工单和商品描述，排查尺码错误、商品损坏或配送问题。',
    }),
    conversion_drop: (p) => ({
      message: `${p.store} 的转化率下降了 ${p.change}：有访客，但购买的人变少了。`,
      recommendation: '检查热销商品是否售罄、页面是否出错，或店铺最近是否有改动。',
    }),
    stockouts: (p) => ({
      message: `${p.store} 有 ${p.count} 件本期有销量的商品现已缺货。`,
      recommendation: '请店铺优先补货：每天都在流失销量。',
    }),
    urgent_tickets: (p) => ({
      message: `${p.store} 有 ${p.count} 个紧急客服工单尚未处理。`,
      recommendation: '确认店铺是否及时回复顾客；回复慢会导致退款和回头客流失。',
    }),
  },
};

/** Rule-based checks on the overview numbers. Plain language, no money involved. */
export function detectAnomalies(stores: StoreOverview[], language: UiLanguage = 'en'): Insight[] {
  const texts = ALERTS[language];
  const insights: Insight[] = [];
  for (const store of stores) {
    const { current: now, previous: before, storeName, tenantId } = store;
    const add = (severity: Insight['severity'], kind: Insight['kind'], params: Partial<AlertParams>) =>
      insights.push({
        tenantId,
        storeName,
        severity,
        kind,
        ...texts[kind]({ store: storeName, before: before.orders, now: now.orders, change: '', rate: '', rateBefore: '', count: 0, ...params }),
      });

    const orderChange = change(now.orders, before.orders);
    if (now.orders === 0 && before.orders >= 5) {
      add('high', 'no_orders', {});
    } else if (orderChange !== null && orderChange <= -30 && before.orders >= 10) {
      add('high', 'orders_drop', { change: pct(orderChange) });
    } else if (orderChange !== null && orderChange >= 50 && now.orders >= 10) {
      add('info', 'orders_spike', { change: pct(orderChange) });
    }

    const cancelRate = now.orders >= 5 ? now.cancelledOrRefunded / now.orders : 0;
    const cancelRateBefore = before.orders >= 5 ? before.cancelledOrRefunded / before.orders : 0;
    if (cancelRate >= 0.15 || (cancelRate - cancelRateBefore >= 0.1 && now.cancelledOrRefunded >= 3)) {
      add(cancelRate >= 0.25 ? 'high' : 'medium', 'cancellations', {
        rate: pct(cancelRate * 100),
        rateBefore: pct(cancelRateBefore * 100),
      });
    }

    const validNow = now.orders - now.cancelledOrRefunded;
    const validBefore = before.orders - before.cancelledOrRefunded;
    const convNow = now.pageViews >= 200 ? validNow / now.pageViews : null;
    const convBefore = before.pageViews >= 200 ? validBefore / before.pageViews : null;
    if (convNow !== null && convBefore !== null && convBefore > 0) {
      const convChange = change(convNow, convBefore);
      if (convChange !== null && convChange <= -30) add('medium', 'conversion_drop', { change: pct(convChange) });
    }

    if (store.outOfStockSellers > 0) {
      add(store.outOfStockSellers >= 3 ? 'high' : 'medium', 'stockouts', { count: store.outOfStockSellers });
    }

    if (store.urgentTickets >= 3) add('medium', 'urgent_tickets', { count: store.urgentTickets });
  }
  const rank = { high: 0, medium: 1, info: 2 };
  return insights.sort((a, b) => rank[a.severity] - rank[b.severity]);
}
