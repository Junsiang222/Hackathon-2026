import { Router } from 'express';
import { verifySuperAdmin } from '../../middlewares/auth';
import { financialStripper } from '../../middlewares/financialStripper';
import { asyncWrapper } from '../../utils/asyncWrapper';
import * as controller from './superadmin.controller';

export const superAdminRouter = Router();

// Order matters: authenticate first, then wrap res.json for every route below.
superAdminRouter.use(verifySuperAdmin, financialStripper);

superAdminRouter.get('/tenants', asyncWrapper(controller.listTenants));
superAdminRouter.get('/settings', asyncWrapper(controller.getSettings));
superAdminRouter.put('/settings/preferences', asyncWrapper(controller.savePreferences));
superAdminRouter.put('/settings/platform', asyncWrapper(controller.savePlatformSettings));
superAdminRouter.post('/settings/password', asyncWrapper(controller.changeOwnPassword));
superAdminRouter.get('/settings/status', asyncWrapper(controller.systemStatus));
superAdminRouter.post('/settings/test/ai', asyncWrapper(controller.testAi));
superAdminRouter.post('/settings/test/photos', asyncWrapper(controller.testPhotos));
superAdminRouter.get('/analytics/overview', asyncWrapper(controller.analyticsOverview));
superAdminRouter.get('/analytics/stores/:tenantId', asyncWrapper(controller.analyticsStore));
superAdminRouter.post('/analytics/assistant', asyncWrapper(controller.analyticsAssistant));
superAdminRouter.delete('/tenants/:tenantId', asyncWrapper(controller.removeTenant));
superAdminRouter.get('/tenants/:tenantId/orders', asyncWrapper(controller.listTenantOrders));
superAdminRouter.get('/tenants/:tenantId/products', asyncWrapper(controller.listTenantProducts));
superAdminRouter.get('/tenants/:tenantId/layouts', asyncWrapper(controller.listTenantLayouts));
superAdminRouter.post('/generate-dashboard', asyncWrapper(controller.generateDashboard));
superAdminRouter.get('/tenants/:tenantId/website', asyncWrapper(controller.getTenantWebsite));
superAdminRouter.post('/tenants/:tenantId/website/regenerate', asyncWrapper(controller.regenerateWebsite));
superAdminRouter.post('/tenants/:tenantId/website/refresh-photos', asyncWrapper(controller.refreshWebsitePhotos));
superAdminRouter.post('/tenants/:tenantId/logins', asyncWrapper(controller.createFirstAdminLogin));
superAdminRouter.post(
  '/tenants/:tenantId/logins/:userId/reset-password',
  asyncWrapper(controller.resetStoreLoginPassword),
);
