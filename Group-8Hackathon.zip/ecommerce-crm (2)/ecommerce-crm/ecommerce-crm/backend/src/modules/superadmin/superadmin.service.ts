import { randomInt } from 'node:crypto';
import bcrypt from 'bcrypt';
import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { BCRYPT_SALT_ROUNDS } from '../../config/constants';
import { superAdminPool, withTransaction } from '../../config/db';
import { ConflictError, NotFoundError, ValidationError } from '../../utils/errors';
import { parseWidgetConfig, type DashboardLayout, type WidgetConfig } from '../dashboard/dashboard.types';
import { createTenantDb } from '../../utils/tenantScopedDb';
import { fillMissingProductPhotos } from '../admin/admin.manage.service';
import { setupFromLayout, type GeneratedWebsite } from '../admin/storeSetup';
import { compileLayoutWithAI, type LayoutRequest } from './layoutCompiler';
import { extractImagePlan, generateWebsiteWithAI, refreshWebsiteImages } from './websiteGenerator';
import { hasSpareQuota, stockPhotosEnabled } from '../../utils/stockPhotos';

// Every query in this file runs on superAdminPool, whose MySQL account can
// only see admins, dashboard_layouts and the super_admin_* views. Monetary
// columns are unreachable here by construction, not by convention.

interface TenantRow extends RowDataPacket {
  id: number;
  tenant_uid: string;
  business_name: string;
  industry: string;
  plan: string;
  status: string;
  status_color: string;
  registered_at: Date;
  trial_ends_at: Date | null;
  layout_count: number;
  last_layout_at: Date | null;
  active_layout_name: string | null;
  active_setup_json: string | null;
  active_config_json: string | null;
}

interface StoreLoginRow extends RowDataPacket {
  user_id: number;
  tenant_id: number;
  email: string;
  role: 'admin' | 'staff';
  oauth_provider: 'google' | 'facebook' | null;
  has_password: number;
  must_change_password: number;
  is_active: number;
  last_login_at: Date | null;
}

/** Store admin/staff login emails, grouped by tenant. Read through a view without any password column. */
async function storeLoginsByTenant() {
  const [rows] = await superAdminPool.execute<StoreLoginRow[]>(
    `SELECT user_id, tenant_id, email, role, oauth_provider, has_password, must_change_password, is_active,
            last_login_at
       FROM super_admin_store_admin_view
      ORDER BY FIELD(role, 'admin', 'staff'), created_at`,
  );
  const byTenant = new Map<number, ReturnType<typeof toLogin>[]>();
  for (const row of rows) byTenant.set(row.tenant_id, [...(byTenant.get(row.tenant_id) ?? []), toLogin(row)]);
  return byTenant;
}

function toLogin(row: StoreLoginRow) {
  return {
    userId: row.user_id,
    email: row.email,
    role: row.role,
    oauthProvider: row.oauth_provider,
    hasPassword: Number(row.has_password) === 1,
    hasTemporaryPassword: Number(row.must_change_password) === 1,
    isActive: row.is_active === 1,
    lastLoginAt: row.last_login_at,
  };
}

export async function listTenants() {
  const logins = await storeLoginsByTenant();
  const [rows] = await superAdminPool.execute<TenantRow[]>(
    `SELECT a.id, a.tenant_uid, a.business_name, a.industry, a.plan, a.status, a.status_color,
            a.registered_at, a.trial_ends_at,
            COUNT(d.id)       AS layout_count,
            MAX(d.created_at) AS last_layout_at,
            MAX(active.layout_name) AS active_layout_name,
            MAX(active.setup_json)  AS active_setup_json,
            MAX(active.config_json) AS active_config_json
       FROM admins a
       LEFT JOIN dashboard_layouts active
              ON active.tenant_id = a.id AND active.is_active = 1
       LEFT JOIN dashboard_layouts d ON d.tenant_id = a.id
      WHERE a.is_platform = 0
      GROUP BY a.id
      ORDER BY a.registered_at DESC, a.id DESC`,
  );

  return rows.map((row) => ({
    id: row.id,
    tenantUid: row.tenant_uid,
    businessName: row.business_name,
    industry: row.industry,
    plan: row.plan,
    status: row.status,
    statusColor: row.status_color,
    registeredAt: row.registered_at,
    trialEndsAt: row.trial_ends_at,
    layoutCount: Number(row.layout_count),
    lastLayoutAt: row.last_layout_at,
    // A public website exists when the setup wizard enabled "Storefront".
    hasWebsite:
      row.active_layout_name !== null &&
      setupFromLayout({
        layout_name: row.active_layout_name,
        setup_json: row.active_setup_json,
        config_json: row.active_config_json ?? '[]',
      }).modules.storefront,
    logins: logins.get(row.id) ?? [],
  }));
}

// ─── Store login password reset ──────────────────────────────────────────────

// No look-alike characters (0/O, 1/l/I), so the password is easy to read out.
const UPPER = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const LOWER = 'abcdefghijkmnpqrstuvwxyz';
const DIGIT = '23456789';
const pick = (chars: string) => chars[randomInt(chars.length)]!;

/** e.g. "Kp7m-Qx2r-Wd9t": 14 chars, always has upper, lower and a digit (meets the sign-up policy). */
function generatePassword(): string {
  return Array.from({ length: 3 }, () => pick(UPPER) + pick(LOWER) + pick(DIGIT) + pick(LOWER)).join('-');
}

type FirstAdminLogin =
  | { kind: 'create'; email: string; temporaryPassword: string; passwordHash: string }
  | { kind: 'existing'; email: string };

/** "Love your hair studio" → "loveyourhairstudio.admin@verdant-store.local" (numbered if taken). */
async function uniqueAdminEmail(storeName: string): Promise<string> {
  const slug = storeName.toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 40) || 'store';
  const [rows] = await superAdminPool.execute<StoreLoginRow[]>(
    'SELECT email FROM super_admin_store_admin_view WHERE email LIKE ?',
    [`${slug}%@verdant-store.local`],
  );
  const taken = new Set(rows.map((row) => row.email));
  for (let n = 1; ; n += 1) {
    const email = `${slug}${n === 1 ? '' : n}.admin@verdant-store.local`;
    if (!taken.has(email)) return email;
  }
}

async function prepareFirstAdminLogin(tenantId: number, storeName: string): Promise<FirstAdminLogin> {
  const [admins] = await superAdminPool.execute<StoreLoginRow[]>(
    "SELECT email FROM super_admin_store_admin_view WHERE tenant_id = ? AND role = 'admin' ORDER BY created_at LIMIT 1",
    [tenantId],
  );
  if (admins[0]) return { kind: 'existing', email: admins[0].email };

  const temporaryPassword = generatePassword();
  return {
    kind: 'create',
    email: await uniqueAdminEmail(storeName),
    temporaryPassword,
    passwordHash: await bcrypt.hash(temporaryPassword, BCRYPT_SALT_ROUNDS),
  };
}

/** For stores whose website was created before logins were generated automatically. */
export async function createFirstAdminLogin(tenantId: number) {
  const tenant = await assertTenantExists(tenantId);
  const login = await prepareFirstAdminLogin(tenantId, tenant.businessName);
  if (login.kind === 'existing') throw new ConflictError(`This store already has an admin login: ${login.email}`);
  try {
    await superAdminPool.execute(
      `INSERT INTO users (tenant_id, role, email, password_hash, must_change_password) VALUES (?, 'admin', ?, ?, 1)`,
      [tenantId, login.email, login.passwordHash],
    );
  } catch (error) {
    if ((error as { code?: string }).code === 'ER_DUP_ENTRY') throw new ConflictError('That login was just created. Refresh the page.');
    throw error;
  }
  return { email: login.email, temporaryPassword: login.temporaryPassword };
}

/**
 * Sets the password the super admin chose for a store login and signs it out
 * everywhere. Only its bcrypt hash is stored; the super admin role can never
 * read hashes. Optionally the owner must pick their own at next login.
 */
export async function resetStoreLoginPassword(
  tenantId: number,
  userId: number,
  input: { newPassword: string; mustChangePassword: boolean },
) {
  const [rows] = await superAdminPool.execute<StoreLoginRow[]>(
    'SELECT user_id, email FROM super_admin_store_admin_view WHERE tenant_id = ? AND user_id = ?',
    [tenantId, userId],
  );
  const login = rows[0];
  if (!login) throw new NotFoundError('This store login does not exist');

  const passwordHash = await bcrypt.hash(input.newPassword, BCRYPT_SALT_ROUNDS);
  const [result] = await superAdminPool.execute<ResultSetHeader>(
    `UPDATE users SET password_hash = ?, session_token = NULL, must_change_password = ?
      WHERE id = ? AND tenant_id = ? AND role IN ('admin', 'staff')`,
    [passwordHash, input.mustChangePassword ? 1 : 0, userId, tenantId],
  );
  if (result.affectedRows === 0) throw new NotFoundError('This store login does not exist');
  // The super admin typed the password, so it is not sent back.
  return { email: login.email, mustChangePassword: input.mustChangePassword };
}

/**
 * Removes a store: soft delete (status = 'cancelled'), as the schema requires.
 * Its website goes offline and its logins are signed out and can't sign in
 * again; orders, customers and layouts are kept.
 */
export async function removeTenant(tenantId: number) {
  const tenant = await assertTenantExists(tenantId);
  if (tenant.status === 'cancelled') throw new ConflictError('This store has already been removed');

  await withTransaction(superAdminPool, async (connection) => {
    await connection.execute(
      "UPDATE admins SET status = 'cancelled' WHERE id = ? AND is_platform = 0",
      [tenantId],
    );
    await connection.execute(
      "UPDATE users SET session_token = NULL WHERE tenant_id = ? AND role IN ('admin', 'staff')",
      [tenantId],
    );
  });
  return { removed: true, businessName: tenant.businessName };
}

async function assertTenantExists(
  tenantId: number,
): Promise<{ businessName: string; status: string; industry: string }> {
  const [rows] = await superAdminPool.execute<RowDataPacket[]>(
    'SELECT business_name, status, industry FROM admins WHERE id = ? AND is_platform = 0',
    [tenantId],
  );
  const row = rows[0];
  if (!row) throw new NotFoundError(`Tenant ${tenantId} does not exist`);
  return { businessName: row.business_name as string, status: row.status as string, industry: row.industry as string };
}

export async function listTenantOrders(tenantId: number, limit: number, offset: number) {
  await assertTenantExists(tenantId);
  // super_admin_order_view intentionally has no total_amount column.
  const [rows] = await superAdminPool.execute<RowDataPacket[]>(
    `SELECT id, customer_id, order_ref, status, currency, placed_at, fulfilled_at
       FROM super_admin_order_view
      WHERE tenant_id = ?
      ORDER BY placed_at DESC, id DESC
      LIMIT ? OFFSET ?`,
    [tenantId, String(limit), String(offset)],
  );
  return rows.map((row) => ({
    id: row.id,
    customerId: row.customer_id,
    orderRef: row.order_ref,
    status: row.status,
    currency: row.currency,
    placedAt: row.placed_at,
    fulfilledAt: row.fulfilled_at,
  }));
}

export async function listTenantProducts(tenantId: number, limit: number, offset: number) {
  await assertTenantExists(tenantId);
  // super_admin_product_view intentionally has no base_price column.
  const [rows] = await superAdminPool.execute<RowDataPacket[]>(
    `SELECT id, sku_code, name, category, status, image_url
       FROM super_admin_product_view
      WHERE tenant_id = ?
      ORDER BY id DESC
      LIMIT ? OFFSET ?`,
    [tenantId, String(limit), String(offset)],
  );
  return rows.map((row) => ({
    id: row.id,
    skuCode: row.sku_code,
    name: row.name,
    category: row.category,
    status: row.status,
    imageUrl: row.image_url,
  }));
}

/**
 * Gives the store's products without an image a stock photo. Runs in the
 * background AFTER the website's own photos were found, so the two don't
 * compete for the small photo quota, and never delays or fails generation. It
 * uses the tenant's own scoped connection (superAdminPool can't write
 * products) and only touches id, name, category and image_url.
 */
function startProductPhotoFill(tenantId: number) {
  fillMissingProductPhotos(createTenantDb(tenantId)).catch((error) =>
    console.error(`Filling product photos for tenant ${tenantId} failed:`, error),
  );
}

/** Categories of the store's active products, for the AI website's category tiles. */
async function listTenantCategories(tenantId: number): Promise<string[]> {
  const [rows] = await superAdminPool.execute<RowDataPacket[]>(
    `SELECT DISTINCT category
       FROM super_admin_product_view
      WHERE tenant_id = ? AND status = 'active' AND category IS NOT NULL
      ORDER BY category
      LIMIT 50`,
    [tenantId],
  );
  return rows.map((row) => String(row.category));
}

interface LayoutRow extends RowDataPacket {
  id: number;
  tenant_id: number;
  layout_name: string;
  config_json: WidgetConfig[] | string;
  version: number;
  is_active: number;
  created_by: number;
  created_at: Date;
}

function toLayout(row: LayoutRow): DashboardLayout {
  return {
    id: row.id,
    tenantId: row.tenant_id,
    layoutName: row.layout_name,
    version: row.version,
    isActive: row.is_active === 1,
    createdBy: row.created_by,
    createdAt: row.created_at.toISOString(),
    config: parseWidgetConfig(row.config_json),
  };
}

export async function listTenantLayouts(tenantId: number): Promise<DashboardLayout[]> {
  await assertTenantExists(tenantId);
  const [rows] = await superAdminPool.execute<LayoutRow[]>(
    `SELECT id, tenant_id, layout_name, config_json, version, is_active, created_by, created_at
       FROM dashboard_layouts
      WHERE tenant_id = ?
      ORDER BY version DESC
      LIMIT 50`,
    [tenantId],
  );
  return rows.map(toLayout);
}

export interface GenerateDashboardInput extends LayoutRequest {
  tenantId: number;
  /** Step 9: the super admin's description of the public website. */
  websitePrompt: string;
}

const MAX_VERSION_RETRIES = 3;
const DASHBOARD_EXISTS_MESSAGE = 'This store already has a dashboard. See it in Websites.';

export async function generateDashboard(input: GenerateDashboardInput, requestedBy: number) {
  const tenant = await assertTenantExists(input.tenantId);
  if (tenant.status === 'cancelled') {
    throw new ValidationError('Cannot generate a dashboard for a cancelled tenant', [
      { path: 'tenantId', message: 'Tenant is cancelled' },
    ]);
  }

  // One dashboard per store: checked before the (slow, billed) AI call, and
  // again inside the transaction to catch a concurrent generation.
  const [existing] = await superAdminPool.execute<RowDataPacket[]>(
    'SELECT 1 FROM dashboard_layouts WHERE tenant_id = ? LIMIT 1',
    [input.tenantId],
  );
  if (existing.length > 0) throw new ConflictError(DASHBOARD_EXISTS_MESSAGE);

  // A store with no admin yet gets one with a temporary password, created in
  // the same transaction as the website so there is never one without the other.
  const newLogin = await prepareFirstAdminLogin(input.tenantId, input.storeName);

  // Network calls happen BEFORE any transaction is opened. The website is only
  // generated when the store has one (Storefront enabled).
  const [config, website] = await Promise.all([
    compileLayoutWithAI({ ...input, industry: tenant.industry }),
    input.modules.storefront
      ? generateWebsiteWithAI({
          storeName: input.storeName,
          industry: tenant.industry,
          websitePrompt: input.websitePrompt,
          features: {
            checkout: input.modules.orders,
            contact: input.modules.customerService,
            orderTracking: input.modules.orders,
            stockLevels: input.modules.inventory,
          },
          categories: await listTenantCategories(input.tenantId),
        })
      : Promise.resolve(undefined),
  ]);
  if (website) startProductPhotoFill(input.tenantId);

  for (let attempt = 1; ; attempt += 1) {
    try {
      const layoutId = await withTransaction(superAdminPool, async (connection) => {
        const [versionRows] = await connection.execute<RowDataPacket[]>(
          'SELECT COALESCE(MAX(version), 0) + 1 AS next_version FROM dashboard_layouts WHERE tenant_id = ?',
          [input.tenantId],
        );
        const version = Number(versionRows[0]?.next_version ?? 1);
        if (version > 1) throw new ConflictError(DASHBOARD_EXISTS_MESSAGE);
        const layoutName = `${input.storeName} · v${version}`.slice(0, 100);

        const [insert] = await connection.execute<ResultSetHeader>(
          `INSERT INTO dashboard_layouts (tenant_id, layout_name, config_json, setup_json, version, is_active, created_by)
           VALUES (?, ?, ?, ?, ?, 1, ?)`,
          [
            input.tenantId,
            layoutName,
            JSON.stringify(config),
            // Wizard answers: decide which features the store's site and admin panel get.
            JSON.stringify({
              storeName: input.storeName,
              modules: input.modules,
              analyticsCharts: input.analyticsCharts,
              websitePrompt: input.websitePrompt,
              website,
            }),
            version,
            requestedBy,
          ],
        );

        // Exactly one active layout per tenant: the newest.
        await connection.execute(
          'UPDATE dashboard_layouts SET is_active = 0 WHERE tenant_id = ? AND id <> ? AND is_active = 1',
          [input.tenantId, insert.insertId],
        );

        if (newLogin.kind === 'create') {
          await connection.execute(
            `INSERT INTO users (tenant_id, role, email, password_hash, must_change_password)
             VALUES (?, 'admin', ?, ?, 1)`,
            [input.tenantId, newLogin.email, newLogin.passwordHash],
          );
        }
        return insert.insertId;
      });

      const adminLogin =
        newLogin.kind === 'create'
          ? { email: newLogin.email, temporaryPassword: newLogin.temporaryPassword, created: true }
          : { email: newLogin.email, temporaryPassword: null, created: false };
      return { layoutId, config, website: website ?? null, adminLogin };
    } catch (error) {
      // uq_layouts_tenant_version: a concurrent generation took this version
      // number. Recompute and retry rather than holding a lock across calls.
      const isVersionRace = (error as { code?: string }).code === 'ER_DUP_ENTRY';
      if (!isVersionRace || attempt >= MAX_VERSION_RETRIES) throw error;
    }
  }
}

// ─── Website regeneration ────────────────────────────────────────────────────

interface ActiveLayoutRow extends RowDataPacket {
  id: number;
  layout_name: string;
  config_json: unknown;
  setup_json: unknown;
}

async function getActiveSetupRow(tenantId: number) {
  const [rows] = await superAdminPool.execute<ActiveLayoutRow[]>(
    `SELECT id, layout_name, config_json, setup_json
       FROM dashboard_layouts
      WHERE tenant_id = ? AND is_active = 1
      ORDER BY version DESC
      LIMIT 1`,
    [tenantId],
  );
  const row = rows[0];
  if (!row) throw new NotFoundError('This store has no website yet. Create it from Tenant workspaces.');
  return { row, setup: setupFromLayout(row as Parameters<typeof setupFromLayout>[0]) };
}

/** The saved step 9 description, to prefill the regenerate dialog. */
export async function getTenantWebsite(tenantId: number) {
  await assertTenantExists(tenantId);
  const { setup } = await getActiveSetupRow(tenantId);
  return {
    hasWebsite: setup.modules.storefront,
    websitePrompt: setup.websitePrompt ?? '',
    isAiDesigned: Boolean(setup.website && 'html' in setup.website),
  };
}

type ActiveSetup = Awaited<ReturnType<typeof getActiveSetupRow>>;

/**
 * The super admin role can't edit layout rows, so a website change is saved as
 * a new layout version carrying the same dashboard widgets, and the previous
 * version is archived (it stays visible on the Websites page).
 */
async function saveWebsiteVersion(
  tenantId: number,
  { row, setup }: ActiveSetup,
  changes: { websitePrompt: string; website: GeneratedWebsite },
  requestedBy: number,
): Promise<number> {
  const configJson = typeof row.config_json === 'string' ? row.config_json : JSON.stringify(row.config_json);
  try {
    return await withTransaction(superAdminPool, async (connection) => {
      const [versionRows] = await connection.execute<RowDataPacket[]>(
        'SELECT COALESCE(MAX(version), 0) + 1 AS next_version FROM dashboard_layouts WHERE tenant_id = ?',
        [tenantId],
      );
      const version = Number(versionRows[0]?.next_version ?? 1);
      const [insert] = await connection.execute<ResultSetHeader>(
        `INSERT INTO dashboard_layouts (tenant_id, layout_name, config_json, setup_json, version, is_active, created_by)
         VALUES (?, ?, ?, ?, ?, 1, ?)`,
        [
          tenantId,
          `${setup.storeName} · v${version}`.slice(0, 100),
          configJson,
          JSON.stringify({ ...setup, ...changes }),
          version,
          requestedBy,
        ],
      );
      await connection.execute(
        'UPDATE dashboard_layouts SET is_active = 0 WHERE tenant_id = ? AND id <> ? AND is_active = 1',
        [tenantId, insert.insertId],
      );
      return insert.insertId;
    });
  } catch (error) {
    if ((error as { code?: string }).code === 'ER_DUP_ENTRY') {
      throw new ConflictError('Another update to this store finished at the same time. Please try again.');
    }
    throw error;
  }
}

/** How many photos the page asked for that are still missing. */
function photoSummary(website: GeneratedWebsite) {
  const wanted = extractImagePlan(website.html).map((item) => item.key);
  const images = website.images ?? {};
  return {
    imageCount: Object.keys(images).length,
    missingPhotos: wanted.filter((key) => !images[key]).length,
    photoSearchAvailable: hasSpareQuota(),
  };
}

async function activeStorefront(tenantId: number) {
  const tenant = await assertTenantExists(tenantId);
  if (tenant.status === 'cancelled') throw new ConflictError('This store has been removed');
  const active = await getActiveSetupRow(tenantId);
  if (!active.setup.modules.storefront) throw new ConflictError('This store has no website (Storefront is off)');
  return { tenant, active };
}

/** Builds a new AI home page for a store that already has one. */
export async function regenerateWebsite(tenantId: number, websitePrompt: string | undefined, requestedBy: number) {
  const { tenant, active } = await activeStorefront(tenantId);
  const { setup } = active;

  const prompt = (websitePrompt ?? setup.websitePrompt ?? '').trim();
  if (prompt.length < 10) {
    throw new ValidationError('Describe the website in at least 10 characters', [
      { path: 'websitePrompt', message: 'Describe the website in at least 10 characters' },
    ]);
  }

  const website = await generateWebsiteWithAI({
    storeName: setup.storeName,
    industry: tenant.industry,
    websitePrompt: prompt,
    features: {
      checkout: setup.modules.orders,
      contact: setup.modules.customerService,
      orderTracking: setup.modules.orders,
      stockLevels: setup.modules.inventory,
    },
    categories: await listTenantCategories(tenantId),
  });
  startProductPhotoFill(tenantId);

  const layoutId = await saveWebsiteVersion(tenantId, active, { websitePrompt: prompt, website }, requestedBy);
  return { layoutId, ...photoSummary(website) };
}

/**
 * Finds the photos the current AI page is still missing (and product photos),
 * without asking the AI to redesign it. Cheap: no AI call, and photos the page
 * already has aren't searched again.
 */
export async function refreshWebsitePhotos(tenantId: number, requestedBy: number) {
  const { tenant, active } = await activeStorefront(tenantId);
  const current = active.setup.website;
  if (!current || !('html' in current)) {
    throw new ConflictError('This store still uses the old template. Use Regenerate website first.');
  }
  if (!stockPhotosEnabled()) {
    throw new ConflictError('No photo key is set. Add UNSPLASH_ACCESS_KEY to backend/.env and restart the backend.');
  }

  const before = Object.keys(current.images ?? {}).length;
  const website = await refreshWebsiteImages(current, {
    industry: tenant.industry,
    categories: await listTenantCategories(tenantId),
  });
  startProductPhotoFill(tenantId);

  const added = Object.keys(website.images ?? {}).length - before;
  const layoutId =
    added > 0
      ? await saveWebsiteVersion(
          tenantId,
          active,
          { websitePrompt: active.setup.websitePrompt ?? '', website },
          requestedBy,
        )
      : null;
  return { layoutId, added, ...photoSummary(website) };
}
