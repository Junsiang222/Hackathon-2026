import type { Request, Response } from 'express';
import { z } from 'zod';
import { password } from '../auth/auth.controller';
import { sendSuccess } from '../../utils/apiResponse';
import * as accounts from './shop.account.service';
import * as service from './shop.service';

const shopParams = z.object({ tenantUid: z.string().uuid('Unknown shop') });
const shopFor = (req: Request) => service.resolveShop(shopParams.parse(req.params).tenantUid);

const email = z.string().trim().toLowerCase().email('Enter a valid email').max(320);

/** Shopper session token (shop accounts), separate from the staff Authorization header. */
const sessionToken = (req: Request) => req.get('X-Shop-Session') || undefined;

const optionalPhone = z
  .string()
  .trim()
  .max(32)
  .transform((value) => (value === '' ? null : value))
  .nullable()
  .default(null);

export async function info(req: Request, res: Response) {
  return sendSuccess(res, await service.shopInfo(await shopFor(req)));
}

export async function listProducts(req: Request, res: Response) {
  const filters = z
    .object({
      search: z.string().trim().min(1).max(100).optional(),
      category: z.string().trim().min(1).max(100).optional(),
    })
    .parse(req.query);
  return sendSuccess(res, await service.listProducts(await shopFor(req), filters));
}

export async function getProduct(req: Request, res: Response) {
  const { productId } = z.object({ productId: z.coerce.number().int().positive() }).parse(req.params);
  return sendSuccess(res, await service.getProduct(await shopFor(req), productId));
}

export async function recordEvent(req: Request, res: Response) {
  const body = z
    .object({ type: z.enum(service.SHOP_EVENTS), productId: z.number().int().positive().nullable().default(null) })
    .strict()
    .parse(req.body);
  await service.recordEvent(await shopFor(req), body.type, body.productId);
  return sendSuccess(res, { recorded: true }, 201);
}

const checkoutBody = z
  .object({
    customer: z
      .object({
        fullName: z.string().trim().min(1, 'Enter your name').max(255),
        email,
        phone: optionalPhone,
      })
      .strict(),
    shippingAddress: z.string().trim().min(5, 'Enter a delivery address').max(1000),
    items: z
      .array(z.object({ productId: z.number().int().positive(), qty: z.number().int().min(1).max(99) }).strict())
      .min(1, 'Your cart is empty')
      .max(50),
    // Demo payment only: the card itself is checked in the browser and never sent here.
    payment: z.object({ method: z.literal('demo_card'), last4: z.string().regex(/^\d{4}$/) }).strict(),
  })
  .strict();

export async function checkout(req: Request, res: Response) {
  const { payment: _payment, ...input } = checkoutBody.parse(req.body);
  const shop = await shopFor(req);
  // A stale session falls back to guest checkout rather than blocking the order.
  const account = await accounts.findSessionCustomer(shop, sessionToken(req));
  return sendSuccess(res, await service.checkout(shop, input, account), 201);
}

// ─── Shopper accounts ────────────────────────────────────────────────────────

export async function register(req: Request, res: Response) {
  const body = z
    .object({
      fullName: z.string().trim().min(1, 'Enter your name').max(255),
      email,
      phone: optionalPhone,
      password,
    })
    .strict()
    .parse(req.body);
  res.set('Cache-Control', 'no-store');
  return sendSuccess(res, await accounts.register(await shopFor(req), body), 201);
}

export async function login(req: Request, res: Response) {
  const body = z.object({ email, password: z.string().min(1, 'Enter your password').max(200) }).strict().parse(req.body);
  res.set('Cache-Control', 'no-store');
  return sendSuccess(res, await accounts.login(await shopFor(req), body.email, body.password));
}

export async function logout(req: Request, res: Response) {
  return sendSuccess(res, await accounts.logout(await shopFor(req), sessionToken(req)));
}

export async function account(req: Request, res: Response) {
  res.set('Cache-Control', 'no-store');
  return sendSuccess(res, await accounts.account(await shopFor(req), sessionToken(req)));
}

export async function trackOrder(req: Request, res: Response) {
  const { orderRef } = z.object({ orderRef: z.string().trim().min(1).max(32) }).parse(req.params);
  const query = z.object({ email }).parse(req.query);
  return sendSuccess(res, await service.trackOrder(await shopFor(req), orderRef.toUpperCase(), query.email));
}

export async function contact(req: Request, res: Response) {
  const body = z
    .object({
      fullName: z.string().trim().min(1, 'Enter your name').max(255),
      email,
      subject: z.string().trim().min(3, 'Add a short subject').max(255),
      message: z.string().trim().min(10, 'Tell us a little more (at least 10 characters)').max(5000),
    })
    .strict()
    .parse(req.body);
  return sendSuccess(res, await service.contact(await shopFor(req), body), 201);
}
