import { randomBytes } from 'node:crypto';
import bcrypt from 'bcrypt';
import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { BCRYPT_SALT_ROUNDS } from '../../config/constants';
import { pool, withTransaction } from '../../config/db';
import { ConflictError, ForbiddenError, UnauthorizedError } from '../../utils/errors';
import { hashToken } from '../../utils/jwtHelper';
import type { Shop } from './shop.service';

// Shopper accounts for every store's online shop: register, log in, log out
// and "My account". Separate from staff logins (users table): a shopper
// account belongs to one store and can never reach the admin dashboard.
//
// Sessions are opaque random tokens sent in the X-Shop-Session header. Only
// their SHA-256 is stored, so a database leak can't be replayed. One session
// per shopper: logging in elsewhere signs the old device out.

const SESSION_DAYS = 30;

// account_created_at uses CURRENT_TIMESTAMP(), the same clock as the
// orders.placed_at default, because "My orders" compares the two.

export interface ShopCustomer {
  fullName: string;
  email: string;
  phone: string | null;
}

interface CustomerRow extends RowDataPacket {
  id: number;
  full_name: string;
  email: string;
  phone: string | null;
  status: 'active' | 'inactive' | 'blocked';
  password_hash: string | null;
  account_created_at: Date | null;
}

const toCustomer = (row: CustomerRow): ShopCustomer => ({ fullName: row.full_name, email: row.email, phone: row.phone });

/** Compared against when the email is unknown, so a miss takes as long as a wrong password. */
let dummyHash: Promise<string> | null = null;
const getDummyHash = () => (dummyHash ??= bcrypt.hash(randomBytes(16).toString('hex'), BCRYPT_SALT_ROUNDS));

async function startSession(shop: Shop, customerId: number, isLogin: boolean): Promise<string> {
  const token = randomBytes(32).toString('base64url');
  await pool.execute(
    `UPDATE customers
        SET session_token = ?, session_expires_at = UTC_TIMESTAMP() + INTERVAL ${SESSION_DAYS} DAY,
            last_active_at = UTC_TIMESTAMP()${isLogin ? ', last_login_at = UTC_TIMESTAMP()' : ''}
      WHERE tenant_id = ? AND id = ?`,
    [hashToken(token), shop.tenantId, customerId],
  );
  return token;
}

export interface RegisterInput extends ShopCustomer {
  password: string;
}

/**
 * Creates a shop account. A shopper who checked out as a guest before can
 * register with the same email: their customer record gains a password.
 */
export async function register(shop: Shop, input: RegisterInput) {
  const passwordHash = await bcrypt.hash(input.password, BCRYPT_SALT_ROUNDS);

  const customerId = await withTransaction(pool, async (connection) => {
    const [rows] = await connection.execute<CustomerRow[]>(
      'SELECT id, status, password_hash FROM customers WHERE tenant_id = ? AND email = ? FOR UPDATE',
      [shop.tenantId, input.email],
    );
    const existing = rows[0];
    if (existing?.password_hash) throw new ConflictError('An account with this email already exists. Log in instead.');
    if (existing?.status === 'blocked') throw new ForbiddenError('This shop cannot create an account for this email');

    if (existing) {
      await connection.execute(
        `UPDATE customers
            SET full_name = ?, phone = COALESCE(?, phone), password_hash = ?, account_created_at = CURRENT_TIMESTAMP()
          WHERE tenant_id = ? AND id = ?`,
        [input.fullName, input.phone, passwordHash, shop.tenantId, existing.id],
      );
      return existing.id;
    }
    const [insert] = await connection.execute<ResultSetHeader>(
      `INSERT INTO customers (tenant_id, full_name, email, phone, password_hash, account_created_at,
                              acquisition_channel, status, last_active_at)
       VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP(), 'storefront', 'active', UTC_TIMESTAMP())`,
      [shop.tenantId, input.fullName, input.email, input.phone, passwordHash],
    );
    return insert.insertId;
  });

  const token = await startSession(shop, customerId, true);
  return { token, customer: { fullName: input.fullName, email: input.email, phone: input.phone } };
}

export async function login(shop: Shop, email: string, password: string) {
  const [rows] = await pool.execute<CustomerRow[]>(
    `SELECT id, full_name, email, phone, status, password_hash
       FROM customers WHERE tenant_id = ? AND email = ?`,
    [shop.tenantId, email],
  );
  const row = rows[0];
  const matches = await bcrypt.compare(password, row?.password_hash ?? (await getDummyHash()));
  if (!row?.password_hash || !matches) throw new UnauthorizedError('Wrong email or password', 'INVALID_CREDENTIALS');
  if (row.status === 'blocked') throw new ForbiddenError('This account has been blocked by the shop');

  const token = await startSession(shop, row.id, true);
  return { token, customer: toCustomer(row) };
}

/** The signed-in shopper, or null when the token is missing, unknown or expired. */
export async function findSessionCustomer(shop: Shop, token: string | undefined) {
  if (!token || token.length > 100) return null;
  const [rows] = await pool.execute<CustomerRow[]>(
    `SELECT id, full_name, email, phone, status, password_hash, account_created_at
       FROM customers
      WHERE tenant_id = ? AND session_token = ? AND session_expires_at > UTC_TIMESTAMP()
        AND password_hash IS NOT NULL`,
    [shop.tenantId, hashToken(token)],
  );
  const row = rows[0];
  return row && row.status !== 'blocked' ? row : null;
}

export async function requireSessionCustomer(shop: Shop, token: string | undefined) {
  const customer = await findSessionCustomer(shop, token);
  if (!customer) throw new UnauthorizedError('Please log in again', 'SESSION_EXPIRED');
  return customer;
}

export async function logout(shop: Shop, token: string | undefined) {
  const customer = await findSessionCustomer(shop, token);
  if (customer) {
    await pool.execute(
      'UPDATE customers SET session_token = NULL, session_expires_at = NULL WHERE tenant_id = ? AND id = ?',
      [shop.tenantId, customer.id],
    );
  }
  return { loggedOut: true };
}

/**
 * Profile + orders. Only orders placed since the account was created are
 * listed: without email verification, registering with someone's email must
 * not reveal their earlier guest orders (those stay behind "Track order").
 */
export async function account(shop: Shop, token: string | undefined) {
  const customer = await requireSessionCustomer(shop, token);
  const [orders] = await pool.execute<RowDataPacket[]>(
    `SELECT o.order_ref, o.status, o.total_amount, o.currency, o.placed_at,
            COALESCE(SUM(oi.qty), 0) AS item_count
       FROM orders o
       LEFT JOIN order_items oi ON oi.tenant_id = o.tenant_id AND oi.order_id = o.id
      WHERE o.tenant_id = ? AND o.customer_id = ? AND o.placed_at >= ?
      GROUP BY o.id
      ORDER BY o.placed_at DESC, o.id DESC
      LIMIT 50`,
    [shop.tenantId, customer.id, customer.account_created_at],
  );
  return {
    customer: toCustomer(customer),
    memberSince: customer.account_created_at,
    orders: orders.map((order) => ({
      orderRef: order.order_ref as string,
      status: order.status as string,
      total: Number(order.total_amount),
      currency: order.currency as string,
      placedAt: order.placed_at as Date,
      itemCount: Number(order.item_count),
    })),
  };
}
