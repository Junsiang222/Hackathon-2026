import { randomBytes } from 'node:crypto';
import type { ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { pool, withTransaction } from '../../config/db';
import { ConflictError, ForbiddenError, NotFoundError, ValidationError } from '../../utils/errors';
import { createTenantDb, type TenantDb } from '../../utils/tenantScopedDb';
import { getPlatformSettings } from '../../utils/platformSettings';
import { getStoreSetup, type StoreSetup } from '../admin/storeSetup';

// Public online shop. Login is optional (shopper accounts: shop.account.service.ts);
// guests can still check out. A store is addressed by its tenant_uid and only
// exists when the super admin enabled "Storefront" in the store's setup wizard.
// Other features follow the same answers: checkout needs "Orders & Checkout",
// stock limits need "Inventory", the contact form needs "Support Desk".

export interface Shop {
  tenantId: number;
  db: TenantDb;
  setup: StoreSetup;
  industry: string;
}

interface TenantRow extends RowDataPacket {
  id: number;
  business_name: string;
  industry: string;
  status: string;
}

export async function resolveShop(tenantUid: string): Promise<Shop> {
  const [rows] = await pool.execute<TenantRow[]>(
    'SELECT id, business_name, industry, status FROM admins WHERE tenant_uid = ? AND is_platform = 0',
    [tenantUid],
  );
  const tenant = rows[0];
  if (!tenant || tenant.status !== 'active') throw new NotFoundError('This shop does not exist');

  const db = createTenantDb(tenant.id);
  const setup = await getStoreSetup(db);
  if (!setup?.modules.storefront) throw new NotFoundError('This store does not have an online shop');
  return { tenantId: tenant.id, db, setup, industry: tenant.industry };
}

function requireShopModule(shop: Shop, module: 'orders' | 'customerService', what: string) {
  if (!shop.setup.modules[module]) throw new ForbiddenError(`This shop does not offer ${what}`);
}

export async function shopInfo(shop: Shop) {
  return {
    storeName: shop.setup.storeName,
    industry: shop.industry,
    // Set platform-wide in the super admin's Settings.
    currency: (await getPlatformSettings()).storeCurrency,
    features: {
      checkout: shop.setup.modules.orders,
      stockLevels: shop.setup.modules.inventory,
      contact: shop.setup.modules.customerService,
      orderTracking: shop.setup.modules.orders,
      // Every storefront gets shopper register / log in / log out / My account.
      accounts: true,
    },
    // AI-written home page copy from setup step 9; null for older stores.
    website: shop.setup.website ?? null,
  };
}

// ─── Catalogue ───────────────────────────────────────────────────────────────

interface ProductRow extends RowDataPacket {
  id: number;
  name: string;
  category: string | null;
  base_price: string;
  image_url: string | null;
  description: string | null;
  qty_available: number | string | null;
  restock_threshold: number | string | null;
}

/** Stock is only revealed when the store tracks inventory. */
function toPublicProduct(shop: Shop, row: ProductRow) {
  const tracks = shop.setup.modules.inventory;
  const qty = Number(row.qty_available ?? 0);
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    price: Number(row.base_price),
    imageUrl: row.image_url,
    description: row.description,
    inStock: tracks ? qty > 0 : true,
    // "Only 3 left" hint when stock is at or under the store's alert level.
    lowStockQty: tracks && qty > 0 && qty <= Number(row.restock_threshold ?? 0) ? qty : null,
    maxQty: tracks ? Math.min(qty, 99) : 99,
  };
}

const PUBLIC_PRODUCT_SELECT = `
  SELECT p.id, p.name, p.category, p.base_price, p.image_url, p.description,
         i.qty_available, i.restock_threshold
    FROM products p
    LEFT JOIN inventory i ON i.tenant_id = p.tenant_id AND i.product_id = p.id
   WHERE p.tenant_id = :tenantId AND p.status = 'active'`;

export async function listProducts(shop: Shop, filters: { search?: string; category?: string }) {
  const rows = await shop.db.query<ProductRow>(
    `${PUBLIC_PRODUCT_SELECT}
       AND (:category IS NULL OR p.category = :category)
       AND (:search IS NULL OR p.name LIKE :search OR p.description LIKE :search)
     ORDER BY p.created_at DESC, p.id DESC
     LIMIT 200`,
    { category: filters.category ?? null, search: filters.search ? `%${filters.search}%` : null },
  );
  const categories = await shop.db.query<RowDataPacket>(
    `SELECT DISTINCT category FROM products
      WHERE tenant_id = :tenantId AND status = 'active' AND category IS NOT NULL
      ORDER BY category`,
  );
  return {
    products: rows.map((row) => toPublicProduct(shop, row)),
    categories: categories.map((row) => String(row.category)),
  };
}

export async function getProduct(shop: Shop, productId: number) {
  const [row] = await shop.db.query<ProductRow>(`${PUBLIC_PRODUCT_SELECT} AND p.id = :productId`, { productId });
  if (!row) throw new NotFoundError('This product is not available');
  return toPublicProduct(shop, row);
}

// ─── Storefront analytics ────────────────────────────────────────────────────

export const SHOP_EVENTS = ['page_view', 'add_to_cart', 'checkout_started'] as const;

/** Feeds the "storefront" analytics chart on the admin dashboard. */
export async function recordEvent(shop: Shop, type: (typeof SHOP_EVENTS)[number], productId: number | null) {
  await shop.db.execute(
    `INSERT INTO analytics_logs (tenant_id, event_type, entity_type, entity_id)
     VALUES (:tenantId, :type, :entityType, :productId)`,
    { type, entityType: productId ? 'product' : null, productId },
  );
}

// ─── Checkout ────────────────────────────────────────────────────────────────

export interface CheckoutInput {
  customer: { fullName: string; email: string; phone: string | null };
  shippingAddress: string;
  items: { productId: number; qty: number }[];
}

function newOrderRef(): string {
  return `WEB-${Date.now().toString(36).toUpperCase()}-${randomBytes(3).toString('hex').toUpperCase()}`;
}

/**
 * Places an order paid with the demo card. One transaction: lock the products,
 * check stock, upsert the customer, write the order + items, take the stock,
 * and update the customer's order count and lifetime value.
 */
export async function checkout(shop: Shop, input: CheckoutInput, account: { id: number; email: string } | null = null) {
  requireShopModule(shop, 'orders', 'online checkout');
  const tracksStock = shop.setup.modules.inventory;

  // Merge duplicate lines for the same product.
  const wanted = new Map<number, number>();
  for (const item of input.items) wanted.set(item.productId, (wanted.get(item.productId) ?? 0) + item.qty);
  const productIds = [...wanted.keys()];

  return withTransaction(pool, async (connection) => {
    const placeholders = productIds.map(() => '?').join(', ');
    const [products] = await connection.query<ProductRow[]>(
      `SELECT p.id, p.name, p.base_price, i.qty_available
         FROM products p
         LEFT JOIN inventory i ON i.tenant_id = p.tenant_id AND i.product_id = p.id
        WHERE p.tenant_id = ? AND p.status = 'active' AND p.id IN (${placeholders})
        FOR UPDATE`,
      [shop.tenantId, ...productIds],
    );
    const byId = new Map(products.map((product) => [product.id, product]));

    const missing = productIds.filter((id) => !byId.has(id));
    if (missing.length > 0) {
      throw new ValidationError('Some items in your cart are no longer available', [
        { path: 'items', message: 'Remove unavailable items and try again', productIds: missing },
      ]);
    }
    if (tracksStock) {
      const short = productIds
        .map((id) => byId.get(id)!)
        .filter((product) => Number(product.qty_available ?? 0) < wanted.get(product.id)!);
      if (short.length > 0) {
        throw new ConflictError(
          `Not enough stock for: ${short.map((p) => `${p.name} (${Number(p.qty_available ?? 0)} left)`).join(', ')}`,
        );
      }
    }

    const lines = productIds.map((id) => {
      const product = byId.get(id)!;
      const qty = wanted.get(id)!;
      const unitPrice = Number(product.base_price);
      return { productId: id, name: product.name, qty, unitPrice, subtotal: Math.round(qty * unitPrice * 10000) / 10000 };
    });
    const total = Math.round(lines.reduce((sum, line) => sum + line.subtotal, 0) * 10000) / 10000;

    // Signed-in shopper: the order goes on their account (the account email wins).
    // Guest: upsert by (tenant, email); LAST_INSERT_ID(id) returns the existing row's id on a duplicate.
    let customerId: number;
    if (account) {
      await connection.execute(
        `UPDATE customers SET full_name = :fullName, phone = COALESCE(:phone, phone), last_active_at = UTC_TIMESTAMP()
          WHERE tenant_id = :tenantId AND id = :customerId`,
        { tenantId: shop.tenantId, customerId: account.id, fullName: input.customer.fullName, phone: input.customer.phone },
      );
      customerId = account.id;
    } else {
      const [customerResult] = await connection.execute<ResultSetHeader>(
        `INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status, last_active_at)
         VALUES (:tenantId, :fullName, :email, :phone, 'storefront', 'active', UTC_TIMESTAMP())
         ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id),
                                 full_name = VALUES(full_name),
                                 phone = COALESCE(VALUES(phone), phone),
                                 last_active_at = UTC_TIMESTAMP()`,
        { tenantId: shop.tenantId, ...input.customer },
      );
      customerId = customerResult.insertId;
    }
    const [[customer]] = await connection.execute<RowDataPacket[]>(
      'SELECT status FROM customers WHERE tenant_id = :tenantId AND id = :customerId',
      { tenantId: shop.tenantId, customerId },
    );
    if (customer?.status === 'blocked') throw new ForbiddenError('This shop cannot accept orders from this account');

    const orderRef = newOrderRef();
    const currency = (await getPlatformSettings()).storeCurrency;
    const [orderResult] = await connection.execute<ResultSetHeader>(
      `INSERT INTO orders (tenant_id, customer_id, order_ref, status, total_amount, currency, shipping_address)
       VALUES (:tenantId, :customerId, :orderRef, 'confirmed', :total, :currency, :shippingAddress)`,
      { tenantId: shop.tenantId, customerId, orderRef, total, currency, shippingAddress: input.shippingAddress },
    );

    for (const line of lines) {
      await connection.execute(
        `INSERT INTO order_items (tenant_id, order_id, product_id, qty, unit_price, subtotal)
         VALUES (:tenantId, :orderId, :productId, :qty, :unitPrice, :subtotal)`,
        { tenantId: shop.tenantId, orderId: orderResult.insertId, ...line },
      );
      if (tracksStock) {
        await connection.execute(
          `UPDATE inventory SET qty_available = qty_available - :qty
            WHERE tenant_id = :tenantId AND product_id = :productId`,
          { tenantId: shop.tenantId, productId: line.productId, qty: line.qty },
        );
      }
    }

    await connection.execute(
      `UPDATE customers SET total_orders = total_orders + 1, ltv = ltv + :total
        WHERE tenant_id = :tenantId AND id = :customerId`,
      { tenantId: shop.tenantId, customerId, total },
    );

    return {
      orderRef,
      status: 'confirmed',
      currency,
      total,
      items: lines.map(({ name, qty, unitPrice, subtotal }) => ({ name, qty, unitPrice, subtotal })),
      email: account?.email ?? input.customer.email,
    };
  });
}

// ─── Order tracking ──────────────────────────────────────────────────────────

/** Needs both the order number and the email used at checkout. */
export async function trackOrder(shop: Shop, orderRef: string, email: string) {
  requireShopModule(shop, 'orders', 'order tracking');
  const [order] = await shop.db.query<RowDataPacket>(
    `SELECT o.id, o.order_ref, o.status, o.total_amount, o.currency, o.placed_at, o.fulfilled_at
       FROM orders o
       JOIN customers c ON c.tenant_id = o.tenant_id AND c.id = o.customer_id
      WHERE o.tenant_id = :tenantId AND o.order_ref = :orderRef AND LOWER(c.email) = LOWER(:email)`,
    { orderRef, email },
  );
  if (!order) throw new NotFoundError('No order matches that order number and email');
  const items = await shop.db.query<RowDataPacket>(
    `SELECT p.name, oi.qty, oi.unit_price, oi.subtotal
       FROM order_items oi
       JOIN products p ON p.tenant_id = oi.tenant_id AND p.id = oi.product_id
      WHERE oi.tenant_id = :tenantId AND oi.order_id = :orderId
      ORDER BY oi.id`,
    { orderId: order.id },
  );
  return {
    orderRef: order.order_ref,
    status: order.status,
    currency: order.currency,
    total: Number(order.total_amount),
    placedAt: order.placed_at,
    fulfilledAt: order.fulfilled_at,
    items: items.map((item) => ({
      name: item.name,
      qty: Number(item.qty),
      unitPrice: Number(item.unit_price),
      subtotal: Number(item.subtotal),
    })),
  };
}

// ─── Contact form → support ticket ───────────────────────────────────────────

export interface ContactInput {
  fullName: string;
  email: string;
  subject: string;
  message: string;
}

export async function contact(shop: Shop, input: ContactInput) {
  requireShopModule(shop, 'customerService', 'a contact form');
  return withTransaction(pool, async (connection) => {
    const [customerResult] = await connection.execute<ResultSetHeader>(
      `INSERT INTO customers (tenant_id, full_name, email, acquisition_channel, status, last_active_at)
       VALUES (:tenantId, :fullName, :email, 'storefront', 'active', UTC_TIMESTAMP())
       ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), last_active_at = UTC_TIMESTAMP()`,
      { tenantId: shop.tenantId, fullName: input.fullName, email: input.email },
    );
    const [ticket] = await connection.execute<ResultSetHeader>(
      `INSERT INTO support_tickets (tenant_id, customer_id, subject, body, priority, status, channel)
       VALUES (:tenantId, :customerId, :subject, :message, 'medium', 'open', 'email')`,
      { tenantId: shop.tenantId, customerId: customerResult.insertId, subject: input.subject, message: input.message },
    );
    return { ticketId: ticket.insertId };
  });
}
