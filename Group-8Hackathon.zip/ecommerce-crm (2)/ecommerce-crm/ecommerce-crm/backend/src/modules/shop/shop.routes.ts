import { Router } from 'express';
import { authRateLimiter, shopWriteLimiter } from '../../middlewares/rateLimiter';
import { asyncWrapper } from '../../utils/asyncWrapper';
import * as controller from './shop.controller';

/**
 * Public online shop. Every route resolves the store by its tenant_uid. No staff
 * authentication; shopper accounts use the X-Shop-Session header (optional at checkout).
 */
export const shopRouter = Router();

shopRouter.get('/:tenantUid', asyncWrapper(controller.info));
shopRouter.get('/:tenantUid/products', asyncWrapper(controller.listProducts));
shopRouter.get('/:tenantUid/products/:productId', asyncWrapper(controller.getProduct));
shopRouter.post('/:tenantUid/events', asyncWrapper(controller.recordEvent));
shopRouter.post('/:tenantUid/checkout', shopWriteLimiter, asyncWrapper(controller.checkout));
shopRouter.get('/:tenantUid/orders/:orderRef', shopWriteLimiter, asyncWrapper(controller.trackOrder));
shopRouter.post('/:tenantUid/contact', shopWriteLimiter, asyncWrapper(controller.contact));

// Shopper accounts (register / log in / log out / My account).
shopRouter.post('/:tenantUid/account/register', authRateLimiter, asyncWrapper(controller.register));
shopRouter.post('/:tenantUid/account/login', authRateLimiter, asyncWrapper(controller.login));
shopRouter.post('/:tenantUid/account/logout', asyncWrapper(controller.logout));
shopRouter.get('/:tenantUid/account', asyncWrapper(controller.account));
