import { createHash, randomUUID } from 'node:crypto';
import bcrypt from 'bcrypt';
import type { PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { pool, withTransaction } from '../../config/db';
import {
  ACCESS_TOKEN_TTL_SECONDS,
  BCRYPT_SALT_ROUNDS,
  TRIAL_PERIOD_DAYS,
  type Industry,
  type Role,
} from '../../config/constants';
import { ConflictError, ForbiddenError, UnauthorizedError } from '../../utils/errors';
import {
  hashToken,
  signAccessToken,
  signRefreshToken,
  tokenHashesMatch,
  verifyRefreshToken,
} from '../../utils/jwtHelper';

export type OAuthProvider = 'google' | 'facebook';

export interface SessionUser {
  id: number;
  email: string;
  role: Role;
  tenantId: number;
  tenantUid: string;
  businessName: string;
  /** Signed in with a temporary password: must choose their own before using the panel. */
  mustChangePassword: boolean;
}

export interface AuthResult {
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
  rememberMe: boolean;
  user: SessionUser;
}

interface UserRow extends RowDataPacket {
  id: number;
  tenant_id: number;
  role: Role;
  email: string;
  password_hash: string | null;
  must_change_password: number;
  session_token: string | null;
  is_active: number;
  tenant_status: 'active' | 'suspended' | 'cancelled';
  tenant_uid: string;
  business_name: string;
}

const USER_WITH_TENANT_SELECT = `
  SELECT u.id, u.tenant_id, u.role, u.email, u.password_hash, u.must_change_password, u.session_token, u.is_active,
         a.status AS tenant_status, a.tenant_uid, a.business_name
  FROM users u
  INNER JOIN admins a ON a.id = u.tenant_id`;

// Compared against when no account matches so response time doesn't reveal
// whether an email is registered. Same cost factor as real hashes.
const DUMMY_BCRYPT_HASH = bcrypt.hashSync(randomUUID(), BCRYPT_SALT_ROUNDS);

function toSessionUser(row: UserRow): SessionUser {
  return {
    id: row.id,
    email: row.email,
    role: row.role,
    tenantId: row.tenant_id,
    tenantUid: row.tenant_uid,
    businessName: row.business_name,
    mustChangePassword: Number(row.must_change_password) === 1,
  };
}

function assertCanSignIn(row: UserRow): void {
  if (!row.is_active) throw new ForbiddenError('This account has been deactivated', 'ACCOUNT_DISABLED');
  if (row.tenant_status !== 'active') {
    throw new ForbiddenError(`This workspace is ${row.tenant_status}`, 'TENANT_INACTIVE');
  }
}

/**
 * Issues an access token + rotated refresh token and persists the refresh
 * token's hash. Only one refresh token is valid per user at a time, so a new
 * sign-in invalidates sessions elsewhere.
 */
async function issueSession(
  executor: Pick<PoolConnection, 'execute'>,
  user: SessionUser,
  rememberMe: boolean,
  options: { markLogin: boolean },
): Promise<AuthResult> {
  const accessToken = signAccessToken({ userId: user.id, tenantId: user.tenantId, role: user.role });
  const refreshToken = signRefreshToken(user.id, rememberMe);

  const sql = options.markLogin
    ? 'UPDATE users SET session_token = ?, last_login_at = UTC_TIMESTAMP() WHERE id = ?'
    : 'UPDATE users SET session_token = ? WHERE id = ?';
  await executor.execute(sql, [hashToken(refreshToken), user.id]);

  return { accessToken, expiresIn: ACCESS_TOKEN_TTL_SECONDS, refreshToken, rememberMe, user };
}

async function createTenantWithAdmin(
  connection: PoolConnection,
  input: {
    businessName: string;
    industry: Industry;
    email: string;
    passwordHash: string | null;
    oauth?: { provider: OAuthProvider; providerUserId: string };
  },
): Promise<SessionUser> {
  const [tenantResult] = await connection.execute<ResultSetHeader>(
    `INSERT INTO admins (business_name, industry, plan, status, trial_ends_at)
     VALUES (?, ?, 'starter', 'active', UTC_TIMESTAMP() + INTERVAL ? DAY)`,
    [input.businessName, input.industry, TRIAL_PERIOD_DAYS],
  );
  const tenantId = tenantResult.insertId;

  const [userResult] = await connection.execute<ResultSetHeader>(
    `INSERT INTO users (tenant_id, role, email, password_hash, oauth_provider, oauth_provider_id, is_active)
     VALUES (?, 'admin', ?, ?, ?, ?, 1)`,
    [tenantId, input.email, input.passwordHash, input.oauth?.provider ?? null, input.oauth?.providerUserId ?? null],
  );

  const [rows] = await connection.execute<UserRow[]>(`${USER_WITH_TENANT_SELECT} WHERE u.id = ?`, [
    userResult.insertId,
  ]);
  const row = rows[0];
  if (!row) throw new Error('Newly created user could not be read back');
  return toSessionUser(row);
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function register(input: {
  email: string;
  password: string;
  businessName: string;
  industry: Industry;
}): Promise<AuthResult> {
  const passwordHash = await bcrypt.hash(input.password, BCRYPT_SALT_ROUNDS);

  // admins row + users row + session are one atomic unit.
  return withTransaction(pool, async (connection) => {
    const user = await createTenantWithAdmin(connection, { ...input, passwordHash });
    return issueSession(connection, user, true, { markLogin: true });
  });
}

export async function login(input: {
  email: string;
  password: string;
  tenantUid?: string;
  rememberMe: boolean;
}): Promise<AuthResult> {
  const params: (string | number)[] = [input.email];
  let sql = `${USER_WITH_TENANT_SELECT} WHERE u.email = ? AND u.password_hash IS NOT NULL`;
  if (input.tenantUid) {
    sql += ' AND a.tenant_uid = ?';
    params.push(input.tenantUid);
  }
  sql += ' ORDER BY u.id LIMIT 20';

  const [candidates] = await pool.execute<UserRow[]>(sql, params);

  if (candidates.length === 0) {
    await bcrypt.compare(input.password, DUMMY_BCRYPT_HASH);
    throw new UnauthorizedError('Invalid email or password', 'INVALID_CREDENTIALS');
  }

  const matches: UserRow[] = [];
  for (const candidate of candidates) {
    if (candidate.password_hash && (await bcrypt.compare(input.password, candidate.password_hash))) {
      matches.push(candidate);
    }
  }

  if (matches.length === 0) {
    throw new UnauthorizedError('Invalid email or password', 'INVALID_CREDENTIALS');
  }

  // Emails are unique per tenant, not globally. If the same credentials open
  // several workspaces, the client must say which one (tenantUid).
  if (matches.length > 1) {
    throw new ConflictError(
      'This email belongs to more than one workspace. Choose a workspace to continue.',
      'TENANT_SELECTION_REQUIRED',
      matches.map((row) => ({ tenantUid: row.tenant_uid, businessName: row.business_name })),
    );
  }

  const row = matches[0]!;
  assertCanSignIn(row);
  return issueSession(pool, toSessionUser(row), input.rememberMe, { markLogin: true });
}

export async function refresh(refreshToken: string | undefined): Promise<AuthResult> {
  if (!refreshToken) throw new UnauthorizedError('No active session', 'INVALID_SESSION');

  const claims = verifyRefreshToken(refreshToken);
  const [rows] = await pool.execute<UserRow[]>(`${USER_WITH_TENANT_SELECT} WHERE u.id = ?`, [claims.userId]);
  const row = rows[0];
  if (!row) throw new UnauthorizedError('No active session', 'INVALID_SESSION');

  if (!tokenHashesMatch(row.session_token, hashToken(refreshToken))) {
    // A correctly signed but superseded token: either a stale tab or a stolen
    // token being replayed after rotation. Revoke the session to be safe.
    if (row.session_token !== null) {
      await pool.execute('UPDATE users SET session_token = NULL WHERE id = ?', [row.id]);
    }
    throw new UnauthorizedError('Session is no longer valid', 'INVALID_SESSION');
  }

  assertCanSignIn(row);
  // Rotate: the presented refresh token is single-use.
  return issueSession(pool, toSessionUser(row), claims.rememberMe, { markLogin: false });
}

export async function logout(refreshToken: string | undefined): Promise<void> {
  if (!refreshToken) return;

  let userId: number;
  try {
    // An expired-but-genuine token is still allowed to end its own session.
    userId = verifyRefreshToken(refreshToken, { ignoreExpiration: true }).userId;
  } catch {
    return; // Nothing we issued; the cookie is cleared by the controller anyway.
  }

  await pool.execute(
    `UPDATE users
        SET session_token = NULL, last_logout_at = UTC_TIMESTAMP()
      WHERE id = ? AND session_token = ?`,
    [userId, hashToken(refreshToken)],
  );
}

/**
 * MOCKED OAuth sign-in. Derives a stable fake identity from the mock token so
 * the same browser keeps landing in the same workspace.
 */
export async function oauthLogin(provider: OAuthProvider, mockOAuthToken: string): Promise<AuthResult> {
  // TODO(oauth): replace this block with real verification:
  //   google   → verify the ID token with google-auth-library
  //              (OAuth2Client.verifyIdToken, audience = GOOGLE_CLIENT_ID) and
  //              read `sub`, `email`, `email_verified` from the payload.
  //   facebook → exchange/inspect the access token via
  //              GET https://graph.facebook.com/debug_token (app access token),
  //              confirm app_id + is_valid, then GET /me?fields=id,email.
  //   Reject unverified emails. Encrypt provider tokens before persisting them
  //   to users.oauth_access_token / oauth_refresh_token (see schema notes).
  const digest = createHash('sha256').update(`${provider}:${mockOAuthToken}`).digest('hex');
  const profile = {
    providerUserId: `mock_${digest.slice(0, 32)}`,
    email: `${provider}.${digest.slice(0, 10)}@mock-oauth.local`,
  };
  // END TODO(oauth)

  const [existing] = await pool.execute<UserRow[]>(
    `${USER_WITH_TENANT_SELECT} WHERE u.oauth_provider = ? AND u.oauth_provider_id = ?`,
    [provider, profile.providerUserId],
  );

  const found = existing[0];
  if (found) {
    assertCanSignIn(found);
    return issueSession(pool, toSessionUser(found), true, { markLogin: true });
  }

  // First sign-in with this identity: provision a workspace, like /register.
  const providerLabel = provider === 'google' ? 'Google' : 'Facebook';
  return withTransaction(pool, async (connection) => {
    const user = await createTenantWithAdmin(connection, {
      businessName: `${providerLabel} Demo Store`,
      industry: 'other',
      email: profile.email,
      passwordHash: null,
      oauth: { provider, providerUserId: profile.providerUserId },
    });
    return issueSession(connection, user, true, { markLogin: true });
  });
}
