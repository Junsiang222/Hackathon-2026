import type { CookieOptions, Request, Response } from 'express';
import { z } from 'zod';
import { env } from '../../config/env';
import {
  INDUSTRIES,
  REFRESH_COOKIE_NAME,
  REFRESH_COOKIE_PATH,
  REFRESH_TOKEN_TTL_SECONDS,
} from '../../config/constants';
import { sendSuccess } from '../../utils/apiResponse';
import * as authService from './auth.service';

// bcrypt only uses the first 72 bytes of a password; reject longer input
// instead of silently truncating it.
export const password = z
  .string()
  .min(12, 'password must be at least 12 characters')
  .refine((value) => Buffer.byteLength(value, 'utf8') <= 72, 'password must be at most 72 bytes')
  .refine((value) => /[a-z]/.test(value) && /[A-Z]/.test(value) && /\d/.test(value), {
    message: 'password must contain upper-case, lower-case and a number',
  });

const email = z.string().trim().toLowerCase().email('email must be a valid address').max(320);

export const registerSchema = z
  .object({
    email,
    password,
    businessName: z.string().trim().min(2, 'businessName is required').max(255),
    industry: z.enum(INDUSTRIES),
  })
  .strict();

export const loginSchema = z
  .object({
    email,
    password: z.string().min(1, 'password is required').max(1024),
    tenantUid: z.string().uuid().optional(),
    rememberMe: z.boolean().default(false),
  })
  .strict();

export const oauthSchema = z
  .object({
    mockOAuthToken: z.string().trim().min(8, 'mockOAuthToken is required').max(2048),
  })
  .strict();

function refreshCookieOptions(rememberMe: boolean): CookieOptions {
  return {
    httpOnly: true,
    secure: env.COOKIE_SECURE,
    sameSite: 'strict',
    path: REFRESH_COOKIE_PATH,
    // Without "remember me" the cookie is session-scoped (dies with the
    // browser); the token inside still expires after 7 days either way.
    ...(rememberMe ? { maxAge: REFRESH_TOKEN_TTL_SECONDS * 1000 } : {}),
  };
}

function readRefreshCookie(req: Request): string | undefined {
  const value: unknown = req.cookies?.[REFRESH_COOKIE_NAME];
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function respondWithSession(
  res: Response,
  result: authService.AuthResult,
  options: { statusCode?: number; exposeRefreshToken?: boolean } = {},
) {
  res.cookie(REFRESH_COOKIE_NAME, result.refreshToken, refreshCookieOptions(result.rememberMe));
  return sendSuccess(
    res,
    {
      accessToken: result.accessToken,
      expiresIn: result.expiresIn,
      // Only /register returns the refresh token in the body (per API
      // contract). Browser clients should rely on the httpOnly cookie.
      ...(options.exposeRefreshToken ? { refreshToken: result.refreshToken } : {}),
      user: result.user,
    },
    options.statusCode ?? 200,
  );
}

export async function register(req: Request, res: Response) {
  const body = registerSchema.parse(req.body);
  const result = await authService.register(body);
  return respondWithSession(res, result, { statusCode: 201, exposeRefreshToken: true });
}

export async function login(req: Request, res: Response) {
  const body = loginSchema.parse(req.body);
  const result = await authService.login(body);
  return respondWithSession(res, result);
}

export async function refresh(req: Request, res: Response) {
  try {
    const result = await authService.refresh(readRefreshCookie(req));
    return respondWithSession(res, result);
  } catch (error) {
    res.clearCookie(REFRESH_COOKIE_NAME, refreshCookieOptions(false));
    throw error;
  }
}

export async function logout(req: Request, res: Response) {
  await authService.logout(readRefreshCookie(req));
  res.clearCookie(REFRESH_COOKIE_NAME, refreshCookieOptions(false));
  return sendSuccess(res, { loggedOut: true });
}

export function oauth(provider: authService.OAuthProvider) {
  return async (req: Request, res: Response) => {
    const { mockOAuthToken } = oauthSchema.parse(req.body);
    const result = await authService.oauthLogin(provider, mockOAuthToken);
    return respondWithSession(res, result);
  };
}
