import { Router, type RequestHandler } from 'express';
import { env } from '../../config/env';
import { authRateLimiter } from '../../middlewares/rateLimiter';
import { asyncWrapper } from '../../utils/asyncWrapper';
import { NotFoundError } from '../../utils/errors';
import * as controller from './auth.controller';

export const authRouter = Router();

authRouter.use(authRateLimiter);

authRouter.post('/register', asyncWrapper(controller.register));
authRouter.post('/login', asyncWrapper(controller.login));
authRouter.post('/logout', asyncWrapper(controller.logout));
authRouter.post('/refresh', asyncWrapper(controller.refresh));

// MOCKED providers — only reachable when OAUTH_MOCK_ENABLED=true (never in
// production; env.ts refuses to boot with that combination).
const oauthMockGate: RequestHandler = (_req, _res, next) => {
  next(env.OAUTH_MOCK_ENABLED ? undefined : new NotFoundError('OAuth sign-in is not available'));
};

authRouter.post('/oauth/google', oauthMockGate, asyncWrapper(controller.oauth('google')));
authRouter.post('/oauth/facebook', oauthMockGate, asyncWrapper(controller.oauth('facebook')));
