import type { Request, Response } from 'express';
import { z } from 'zod';
import { ANALYTICS_METRICS } from '../../config/constants';
import { requireTenantDb } from '../../middlewares/auth';
import { sendSuccess } from '../../utils/apiResponse';
import * as service from './admin.service';

const ticketStatus = z.enum(['open', 'in_progress', 'pending_customer', 'resolved', 'closed']);
const ticketPriority = z.enum(['low', 'medium', 'high', 'urgent']);

const ticketParams = z.object({ ticketId: z.coerce.number().int().positive() });
export const updateTicketSchema = z
  .object({
    status: ticketStatus.optional(),
    priority: ticketPriority.optional(),
    assignedTo: z.number().int().positive().nullable().optional(),
  })
  .strict()
  .refine((body) => Object.keys(body).length > 0, { message: 'provide at least one field to update' });

const analyticsParams = z.object({ metric: z.enum(ANALYTICS_METRICS) });

export async function updateTicket(req: Request, res: Response) {
  const { ticketId } = ticketParams.parse(req.params);
  const changes = updateTicketSchema.parse(req.body);
  return sendSuccess(res, await service.updateTicket(requireTenantDb(req), ticketId, changes));
}

export async function notificationSummary(req: Request, res: Response) {
  return sendSuccess(res, await service.notificationSummary(requireTenantDb(req)));
}

export async function analytics(req: Request, res: Response) {
  const { metric } = analyticsParams.parse(req.params);
  return sendSuccess(res, await service.analytics(requireTenantDb(req), metric));
}
