import type { NextFunction, Request, Response } from 'express';
import type { RowDataPacket } from 'mysql2/promise';
import {
  ANALYTICS_SOURCES,
  CHART_KINDS,
  DASHBOARD_MODULES,
  type ChartKind,
  type DashboardModule,
} from '../../config/constants';
import { ForbiddenError } from '../../utils/errors';
import type { TenantDb } from '../../utils/tenantScopedDb';

export const WEBSITE_THEMES = ['green', 'blue', 'purple', 'rose', 'amber', 'slate'] as const;
export type WebsiteTheme = (typeof WEBSITE_THEMES)[number];

/** Older stores: shop copy the AI wrote into the fixed home page template. */
export interface WebsiteCopy {
  theme: WebsiteTheme;
  heroEyebrow: string;
  heroTitle: string;
  heroSubtitle: string;
  highlights: { title: string; text: string }[];
  aboutTitle: string;
  aboutText: string;
}

/**
 * A complete home page (HTML, CSS and JS) the AI designed freely. The
 * storefront runs it in a sandboxed iframe and hands it the catalogue.
 */
export interface GeneratedWebsite {
  kind: 'html';
  html: string;
  /**
   * Photos the page asked for, found on Pexels at generation time. Keys are
   * the page's own names ("hero", "promo-1") plus "category:<name>".
   */
  images?: Record<string, WebsiteImage>;
}

export interface WebsiteImage {
  url: string;
  alt: string;
  photographer: string;
  photographerUrl: string;
}

export type WebsiteContent = WebsiteCopy | GeneratedWebsite;

/** The super admin's setup-wizard answers for a store. */
export interface StoreSetup {
  storeName: string;
  modules: Record<DashboardModule, boolean>;
  analyticsCharts: ChartKind[];
  /** Step 9's description, and the website the AI generated from it. Absent on older stores. */
  websitePrompt?: string;
  website?: WebsiteContent;
}

/** The columns of a dashboard_layouts row needed to work out the store's setup. */
export interface SetupSource {
  layout_name: string;
  setup_json: StoreSetup | string | null;
  config_json: { type?: string; dataSourceUrl?: string }[] | string;
}

type SetupRow = SetupSource & RowDataPacket;

const WIDGET_TYPE_TO_CHART: Record<string, ChartKind> = { LineChart: 'line', BarChart: 'bar', CircleChart: 'circle' };

const parse = <T>(value: T | string): T => (typeof value === 'string' ? (JSON.parse(value) as T) : value);

/**
 * Layouts generated before setup_json existed only carry widgets: infer the
 * enabled modules from the data sources those widgets read.
 */
function inferSetup(row: SetupSource): StoreSetup {
  const widgets = parse(row.config_json);
  const modules = Object.fromEntries(DASHBOARD_MODULES.map((m) => [m, false])) as Record<DashboardModule, boolean>;
  const charts = new Set<ChartKind>();
  for (const widget of widgets) {
    const source = widget.dataSourceUrl ? ANALYTICS_SOURCES[widget.dataSourceUrl] : undefined;
    if (source) modules[source.module] = true;
    const chart = widget.type ? WIDGET_TYPE_TO_CHART[widget.type] : undefined;
    if (chart) charts.add(chart);
  }
  return {
    storeName: row.layout_name.replace(/\s*·\s*v\d+$/, ''),
    modules,
    analyticsCharts: CHART_KINDS.filter((kind) => charts.has(kind)),
  };
}

/** The active layout's setup, or null while the store has not been set up. */
export async function getStoreSetup(db: TenantDb): Promise<StoreSetup | null> {
  const [row] = await db.query<SetupRow>(
    `SELECT layout_name, setup_json, config_json
       FROM dashboard_layouts
      WHERE tenant_id = :tenantId AND is_active = 1
      ORDER BY version DESC
      LIMIT 1`,
  );
  return row ? setupFromLayout(row) : null;
}

/** Setup saved with a layout, or inferred from its widgets for older layouts. */
export function setupFromLayout(row: SetupSource): StoreSetup {
  return row.setup_json ? parse(row.setup_json) : inferSetup(row);
}

export const MODULE_LABEL: Record<DashboardModule, string> = {
  storefront: 'Storefront',
  inventory: 'Inventory tracking',
  orders: 'Orders & Checkout',
  customers: 'Customer Profiles',
  marketing: 'Automated Marketing',
  customerService: 'Support Desk',
};

/**
 * Route guard: the request passes when ANY of the given modules was enabled
 * in the store's setup wizard. Must run after verifyAdmin.
 */
export function requireModule(...modules: DashboardModule[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.tenantDb) return next(new ForbiddenError());
    getStoreSetup(req.tenantDb)
      .then((setup) => {
        if (setup && modules.some((module) => setup.modules[module])) return next();
        const names = modules.map((module) => MODULE_LABEL[module]).join(' or ');
        next(new ForbiddenError(`${names} is not enabled for this store`));
      })
      .catch(next);
  };
}
