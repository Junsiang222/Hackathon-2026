import type { RowDataPacket } from 'mysql2/promise';
import type { AnalyticsMetric } from '../../config/constants';
import { NotFoundError } from '../../utils/errors';
import type { TenantDb } from '../../utils/tenantScopedDb';

// All reads/writes go through TenantDb, which pins every statement to the
// caller's tenant. Admins may see their own tenant's financial data.

// ─── Resource listings ───────────────────────────────────────────────────────

export interface ListOptions {
  status?: string;
  limit: number;
  offset: number;
}

export async function updateTicket(
  db: TenantDb,
  ticketId: number,
  changes: { status?: string; priority?: string; assignedTo?: number | null },
) {
  const setAssignee = changes.assignedTo !== undefined;
  await db.execute(
    `UPDATE support_tickets
        SET status      = COALESCE(:status, status),
            priority    = COALESCE(:priority, priority),
            assigned_to = IF(:setAssignee = 1, :assignedTo, assigned_to),
            resolved_at = CASE
                            WHEN COALESCE(:status, status) IN ('resolved', 'closed')
                              THEN COALESCE(resolved_at, UTC_TIMESTAMP())
                            ELSE NULL
                          END
      WHERE id = :ticketId AND tenant_id = :tenantId`,
    {
      status: changes.status ?? null,
      priority: changes.priority ?? null,
      setAssignee: setAssignee ? 1 : 0,
      assignedTo: changes.assignedTo ?? null,
      ticketId,
    },
  );

  const [ticket] = await db.findMany('support_tickets', { where: { id: ticketId }, limit: 1 });
  if (!ticket) throw new NotFoundError(`Ticket ${ticketId} does not exist`);
  return ticket;
}

export async function notificationSummary(db: TenantDb) {
  const [row] = await db.query<RowDataPacket>(
    `SELECT
       (SELECT COUNT(*) FROM support_tickets
         WHERE tenant_id = :tenantId
           AND status IN ('open', 'in_progress')
           AND priority IN ('high', 'urgent'))                         AS urgent_tickets,
       (SELECT COUNT(*) FROM inventory
         WHERE tenant_id = :tenantId
           AND qty_available <= restock_threshold)                     AS low_stock_products`,
  );
  const urgentTickets = Number(row?.urgent_tickets ?? 0);
  const lowStockProducts = Number(row?.low_stock_products ?? 0);
  return { urgentTickets, lowStockProducts, count: urgentTickets + lowStockProducts };
}

// ─── Analytics (non-monetary by design) ──────────────────────────────────────

export type AnalyticsRow = { date: string } & Record<string, number | string>;

const LAST_30_DAYS = `
  WITH RECURSIVE days (d) AS (
    SELECT UTC_DATE() - INTERVAL 29 DAY
    UNION ALL
    SELECT d + INTERVAL 1 DAY FROM days WHERE d < UTC_DATE()
  )`;

function toNumbers(rows: RowDataPacket[], keys: string[]): AnalyticsRow[] {
  return rows.map((row) => {
    const out: AnalyticsRow = { date: String(row.date) };
    for (const key of keys) out[key] = Number(row[key] ?? 0);
    return out;
  });
}

function percentage(part: number, whole: number): number {
  return whole > 0 ? Math.round((part / whole) * 1000) / 10 : 0;
}

async function ordersSeries(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `${LAST_30_DAYS}
     SELECT DATE_FORMAT(days.d, '%Y-%m-%d') AS date,
            COUNT(o.id)                              AS count,
            COALESCE(SUM(o.status = 'delivered'), 0) AS fulfilled
       FROM days
       LEFT JOIN orders o
              ON o.tenant_id = :tenantId
             AND o.placed_at >= days.d
             AND o.placed_at <  days.d + INTERVAL 1 DAY
      GROUP BY days.d
      ORDER BY days.d`,
  );
  const series = toNumbers(rows, ['count', 'fulfilled']);
  return series.map((row, index) => ({
    ...row,
    delta: index === 0 ? 0 : Number(row.count) - Number(series[index - 1]!.count),
  }));
}

async function customersSeries(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `${LAST_30_DAYS}
     SELECT DATE_FORMAT(days.d, '%Y-%m-%d') AS date,
            (SELECT COUNT(*) FROM customers c
              WHERE c.tenant_id = :tenantId
                AND c.created_at >= days.d AND c.created_at < days.d + INTERVAL 1 DAY) AS new_customers,
            (SELECT COUNT(*) FROM customers c
              WHERE c.tenant_id = :tenantId
                AND c.last_active_at >= days.d AND c.last_active_at < days.d + INTERVAL 1 DAY) AS active_customers
       FROM days
      ORDER BY days.d`,
  );
  return toNumbers(rows, ['new_customers', 'active_customers']);
}

async function inventorySnapshot(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `SELECT DATE_FORMAT(UTC_DATE(), '%Y-%m-%d') AS date,
            COALESCE(SUM(i.qty_available > i.restock_threshold), 0)                        AS in_stock,
            COALESCE(SUM(i.qty_available > 0 AND i.qty_available <= i.restock_threshold), 0) AS low_stock,
            COALESCE(SUM(i.qty_available = 0), 0)                                          AS out_of_stock
       FROM inventory i
       INNER JOIN products p
               ON p.tenant_id = i.tenant_id AND p.id = i.product_id AND p.status = 'active'
      WHERE i.tenant_id = :tenantId`,
  );
  return toNumbers(rows, ['in_stock', 'low_stock', 'out_of_stock']);
}

async function campaignsSeries(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `${LAST_30_DAYS}
     SELECT DATE_FORMAT(days.d, '%Y-%m-%d') AS date,
            COALESCE(SUM(c.sent_count), 0)  AS sent,
            COALESCE(SUM(c.open_count), 0)  AS opens,
            COALESCE(SUM(c.click_count), 0) AS clicks
       FROM days
       LEFT JOIN campaigns c
              ON c.tenant_id = :tenantId
             AND c.scheduled_at >= days.d
             AND c.scheduled_at <  days.d + INTERVAL 1 DAY
      GROUP BY days.d
      ORDER BY days.d`,
  );
  return toNumbers(rows, ['sent', 'opens', 'clicks']).map((row) => ({
    ...row,
    open_rate: percentage(Number(row.opens), Number(row.sent)),
  }));
}

async function ticketsSeries(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `${LAST_30_DAYS}
     SELECT DATE_FORMAT(days.d, '%Y-%m-%d') AS date,
            (SELECT COUNT(*) FROM support_tickets t
              WHERE t.tenant_id = :tenantId
                AND t.created_at >= days.d AND t.created_at < days.d + INTERVAL 1 DAY) AS opened,
            (SELECT COUNT(*) FROM support_tickets t
              WHERE t.tenant_id = :tenantId
                AND t.resolved_at >= days.d AND t.resolved_at < days.d + INTERVAL 1 DAY) AS resolved
       FROM days
      ORDER BY days.d`,
  );
  return toNumbers(rows, ['opened', 'resolved']).map((row) => ({
    ...row,
    resolution_rate: percentage(Number(row.resolved), Number(row.opened)),
  }));
}

async function storefrontSeries(db: TenantDb): Promise<AnalyticsRow[]> {
  const rows = await db.query<RowDataPacket>(
    `${LAST_30_DAYS}
     SELECT DATE_FORMAT(days.d, '%Y-%m-%d') AS date,
            COALESCE(SUM(l.event_type = 'page_view'), 0)        AS page_views,
            COALESCE(SUM(l.event_type = 'add_to_cart'), 0)      AS add_to_cart,
            COALESCE(SUM(l.event_type = 'checkout_started'), 0) AS checkouts
       FROM days
       LEFT JOIN analytics_logs l
              ON l.tenant_id = :tenantId
             AND l.event_type IN ('page_view', 'add_to_cart', 'checkout_started')
             AND l.recorded_at >= days.d
             AND l.recorded_at <  days.d + INTERVAL 1 DAY
      GROUP BY days.d
      ORDER BY days.d`,
  );
  return toNumbers(rows, ['page_views', 'add_to_cart', 'checkouts']);
}

const ANALYTICS_HANDLERS: Record<AnalyticsMetric, (db: TenantDb) => Promise<AnalyticsRow[]>> = {
  orders: ordersSeries,
  customers: customersSeries,
  inventory: inventorySnapshot,
  campaigns: campaignsSeries,
  tickets: ticketsSeries,
  storefront: storefrontSeries,
};

export function analytics(db: TenantDb, metric: AnalyticsMetric): Promise<AnalyticsRow[]> {
  return ANALYTICS_HANDLERS[metric](db);
}
