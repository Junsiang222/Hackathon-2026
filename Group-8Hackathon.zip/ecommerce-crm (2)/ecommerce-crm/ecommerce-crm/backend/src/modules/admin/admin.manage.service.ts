import bcrypt from 'bcrypt';
import type { RowDataPacket } from 'mysql2/promise';
import { BCRYPT_SALT_ROUNDS } from '../../config/constants';
import { ConflictError, NotFoundError, ValidationError } from '../../utils/errors';
import { findProductPhoto, hasSpareQuota, stockPhotosEnabled } from '../../utils/stockPhotos';
import type { TenantDb } from '../../utils/tenantScopedDb';
import type { ListOptions } from './admin.service';

// Write operations for the store admin panel. Every statement is pinned to
// the caller's tenant by TenantDb (:tenantId is injected, never supplied).

function isDuplicate(error: unknown): boolean {
  return (error as { code?: string }).code === 'ER_DUP_ENTRY';
}

// ─── Products & stock ────────────────────────────────────────────────────────

export interface ProductInput {
  skuCode: string;
  name: string;
  category: string | null;
  basePrice: number;
  /** What one unit costs the store (its own COGS); null = not entered. */
  costPrice: number | null;
  status: 'active' | 'archived' | 'draft';
  imageUrl: string | null;
  description: string | null;
}

export interface StockInput {
  qtyAvailable: number;
  restockThreshold: number;
}

const PRODUCT_SELECT = `
  SELECT p.id, p.sku_code, p.name, p.category, p.base_price, p.cost_price, p.status, p.status_color,
         p.image_url, p.description, p.created_at, p.updated_at,
         COALESCE(i.qty_available, 0)     AS qty_available,
         COALESCE(i.qty_reserved, 0)      AS qty_reserved,
         COALESCE(i.restock_threshold, 10) AS restock_threshold
    FROM products p
    LEFT JOIN inventory i ON i.tenant_id = p.tenant_id AND i.product_id = p.id
   WHERE p.tenant_id = :tenantId`;

export function listProductsWithStock(db: TenantDb, options: ListOptions & { search?: string }) {
  return db.query<RowDataPacket>(
    `${PRODUCT_SELECT}
       AND (:status IS NULL OR p.status = :status)
       AND (:search IS NULL OR p.name LIKE :search OR p.sku_code LIKE :search)
     ORDER BY p.created_at DESC, p.id DESC
     LIMIT :limit OFFSET :offset`,
    {
      status: options.status ?? null,
      search: options.search ? `%${options.search}%` : null,
      limit: String(options.limit),
      offset: String(options.offset),
    },
  );
}

export async function getProduct(db: TenantDb, productId: number) {
  const [row] = await db.query<RowDataPacket>(`${PRODUCT_SELECT} AND p.id = :productId`, { productId });
  if (!row) throw new NotFoundError(`Product ${productId} does not exist`);
  return row;
}

async function upsertStock(db: TenantDb, productId: number, stock: StockInput) {
  await db.execute(
    `INSERT INTO inventory (product_id, tenant_id, qty_available, restock_threshold, last_restocked_at)
     VALUES (:productId, :tenantId, :qty, :threshold, UTC_TIMESTAMP())
     ON DUPLICATE KEY UPDATE
       last_restocked_at = IF(VALUES(qty_available) > qty_available, UTC_TIMESTAMP(), last_restocked_at),
       qty_available     = VALUES(qty_available),
       restock_threshold = VALUES(restock_threshold)`,
    { productId, qty: stock.qtyAvailable, threshold: stock.restockThreshold },
  );
}

/**
 * Gives active products without an image a matching stock photo, so the AI
 * website has real photos. The admin can replace any of them in Products.
 */
export async function fillMissingProductPhotos(db: TenantDb, limit = 60): Promise<number> {
  if (!stockPhotosEnabled()) return 0;
  // Newest first: those are the ones the shop shows first.
  const rows = await db.query<RowDataPacket>(
    `SELECT id, name, category FROM products
      WHERE tenant_id = :tenantId AND status = 'active' AND (image_url IS NULL OR image_url = '')
      ORDER BY created_at DESC, id DESC
      LIMIT ${Math.max(1, Math.floor(limit))}`,
  );
  const used = new Set<string>();
  let filled = 0;
  // One at a time, and only while the photo quota has room to spare; the rest
  // are picked up by the next run (Refresh photos or regeneration).
  for (const row of rows) {
    if (!hasSpareQuota()) break;
    const photo = await findProductPhoto({ name: String(row.name), category: row.category as string | null }, used);
    if (!photo) continue;
    const { affectedRows } = await db.execute(
      `UPDATE products SET image_url = :url
        WHERE id = :productId AND tenant_id = :tenantId AND (image_url IS NULL OR image_url = '')`,
      { url: photo.url, productId: row.id },
    );
    filled += affectedRows;
  }
  return filled;
}

export async function createProduct(db: TenantDb, input: ProductInput, stock: StockInput | null) {
  // No image given: pick a matching stock photo (stays null when none is found).
  if (!input.imageUrl) input = { ...input, imageUrl: (await findProductPhoto(input))?.url ?? null };
  let productId: number;
  try {
    ({ insertId: productId } = await db.execute(
      `INSERT INTO products (tenant_id, sku_code, name, category, base_price, cost_price, status, image_url, description)
       VALUES (:tenantId, :skuCode, :name, :category, :basePrice, :costPrice, :status, :imageUrl, :description)`,
      { ...input },
    ));
  } catch (error) {
    if (isDuplicate(error)) throw new ConflictError(`SKU "${input.skuCode}" is already used by another product`);
    throw error;
  }
  await upsertStock(db, productId, stock ?? { qtyAvailable: 0, restockThreshold: 10 });
  return getProduct(db, productId);
}

export async function updateProduct(db: TenantDb, productId: number, input: Partial<ProductInput>) {
  await getProduct(db, productId);
  try {
    await db.execute(
      `UPDATE products
          SET sku_code    = COALESCE(:skuCode, sku_code),
              name        = COALESCE(:name, name),
              category    = IF(:setCategory = 1, :category, category),
              base_price  = COALESCE(:basePrice, base_price),
              cost_price  = IF(:setCostPrice = 1, :costPrice, cost_price),
              status      = COALESCE(:status, status),
              image_url   = IF(:setImageUrl = 1, :imageUrl, image_url),
              description = IF(:setDescription = 1, :description, description)
        WHERE id = :productId AND tenant_id = :tenantId`,
      {
        productId,
        skuCode: input.skuCode ?? null,
        name: input.name ?? null,
        setCategory: input.category !== undefined ? 1 : 0,
        category: input.category ?? null,
        basePrice: input.basePrice ?? null,
        setCostPrice: input.costPrice !== undefined ? 1 : 0,
        costPrice: input.costPrice ?? null,
        status: input.status ?? null,
        setImageUrl: input.imageUrl !== undefined ? 1 : 0,
        imageUrl: input.imageUrl ?? null,
        setDescription: input.description !== undefined ? 1 : 0,
        description: input.description ?? null,
      },
    );
  } catch (error) {
    if (isDuplicate(error)) throw new ConflictError(`SKU "${input.skuCode}" is already used by another product`);
    throw error;
  }
  return getProduct(db, productId);
}

export async function updateStock(db: TenantDb, productId: number, stock: StockInput) {
  await getProduct(db, productId);
  await upsertStock(db, productId, stock);
  return getProduct(db, productId);
}

/** Products that appear on past orders are archived instead, to keep order history intact. */
export async function deleteProduct(db: TenantDb, productId: number): Promise<{ deleted: boolean; archived: boolean }> {
  await getProduct(db, productId);
  const [used] = await db.query<RowDataPacket>(
    'SELECT 1 FROM order_items WHERE tenant_id = :tenantId AND product_id = :productId LIMIT 1',
    { productId },
  );
  if (used) {
    await db.execute(`UPDATE products SET status = 'archived' WHERE id = :productId AND tenant_id = :tenantId`, {
      productId,
    });
    return { deleted: false, archived: true };
  }
  await db.execute('DELETE FROM products WHERE id = :productId AND tenant_id = :tenantId', { productId });
  return { deleted: true, archived: false };
}

// ─── Orders ──────────────────────────────────────────────────────────────────

export type OrderStatus = 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';

export function listOrdersWithCustomer(db: TenantDb, options: ListOptions & { search?: string }) {
  return db.query<RowDataPacket>(
    `SELECT o.id, o.customer_id, o.order_ref, o.status, o.status_color, o.total_amount, o.currency,
            o.placed_at, o.fulfilled_at, c.full_name AS customer_name, c.email AS customer_email,
            (SELECT COALESCE(SUM(oi.qty), 0) FROM order_items oi
              WHERE oi.tenant_id = o.tenant_id AND oi.order_id = o.id) AS item_count
       FROM orders o
       JOIN customers c ON c.tenant_id = o.tenant_id AND c.id = o.customer_id
      WHERE o.tenant_id = :tenantId
        AND (:status IS NULL OR o.status = :status)
        AND (:search IS NULL OR o.order_ref LIKE :search OR c.full_name LIKE :search)
      ORDER BY o.placed_at DESC, o.id DESC
      LIMIT :limit OFFSET :offset`,
    {
      status: options.status ?? null,
      search: options.search ? `%${options.search}%` : null,
      limit: String(options.limit),
      offset: String(options.offset),
    },
  );
}

export async function getOrder(db: TenantDb, orderId: number) {
  const [order] = await db.query<RowDataPacket>(
    `SELECT o.id, o.customer_id, o.order_ref, o.status, o.status_color, o.total_amount, o.currency,
            o.placed_at, o.fulfilled_at, o.shipping_address, c.full_name AS customer_name,
            c.email AS customer_email, c.phone AS customer_phone
       FROM orders o
       JOIN customers c ON c.tenant_id = o.tenant_id AND c.id = o.customer_id
      WHERE o.tenant_id = :tenantId AND o.id = :orderId`,
    { orderId },
  );
  if (!order) throw new NotFoundError(`Order ${orderId} does not exist`);
  const items = await db.query<RowDataPacket>(
    `SELECT oi.id, oi.product_id, p.name AS product_name, p.sku_code, oi.qty, oi.unit_price, oi.subtotal
       FROM order_items oi
       JOIN products p ON p.tenant_id = oi.tenant_id AND p.id = oi.product_id
      WHERE oi.tenant_id = :tenantId AND oi.order_id = :orderId
      ORDER BY oi.id`,
    { orderId },
  );
  return { ...order, items };
}

export async function updateOrderStatus(db: TenantDb, orderId: number, status: OrderStatus) {
  await getOrder(db, orderId);
  await db.execute(
    `UPDATE orders
        SET status = :status,
            fulfilled_at = CASE
                             WHEN :status IN ('shipped', 'delivered')
                               THEN COALESCE(fulfilled_at, GREATEST(UTC_TIMESTAMP(), placed_at))
                             WHEN :status IN ('pending', 'confirmed') THEN NULL
                             ELSE fulfilled_at
                           END
      WHERE id = :orderId AND tenant_id = :tenantId`,
    { orderId, status },
  );
  return getOrder(db, orderId);
}

// ─── Customers ───────────────────────────────────────────────────────────────

export interface CustomerInput {
  fullName: string;
  email: string | null;
  phone: string | null;
  acquisitionChannel: string | null;
  status: 'active' | 'inactive' | 'blocked';
}

const CUSTOMER_COLUMNS = `id, full_name, email, phone, acquisition_channel, status, total_orders, ltv,
                          last_active_at, created_at`;

export function searchCustomers(db: TenantDb, options: ListOptions & { search?: string }) {
  return db.query<RowDataPacket>(
    `SELECT ${CUSTOMER_COLUMNS}
       FROM customers
      WHERE tenant_id = :tenantId
        AND (:status IS NULL OR status = :status)
        AND (:search IS NULL OR full_name LIKE :search OR email LIKE :search)
      ORDER BY created_at DESC, id DESC
      LIMIT :limit OFFSET :offset`,
    {
      status: options.status ?? null,
      search: options.search ? `%${options.search}%` : null,
      limit: String(options.limit),
      offset: String(options.offset),
    },
  );
}

async function getCustomer(db: TenantDb, customerId: number) {
  const [row] = await db.query<RowDataPacket>(
    `SELECT ${CUSTOMER_COLUMNS} FROM customers WHERE tenant_id = :tenantId AND id = :customerId`,
    { customerId },
  );
  if (!row) throw new NotFoundError(`Customer ${customerId} does not exist`);
  return row;
}

export async function createCustomer(db: TenantDb, input: CustomerInput) {
  try {
    const { insertId } = await db.execute(
      `INSERT INTO customers (tenant_id, full_name, email, phone, acquisition_channel, status)
       VALUES (:tenantId, :fullName, :email, :phone, :acquisitionChannel, :status)`,
      { ...input },
    );
    return getCustomer(db, insertId);
  } catch (error) {
    if (isDuplicate(error)) throw new ConflictError(`A customer with email ${input.email} already exists`);
    throw error;
  }
}

export async function updateCustomer(db: TenantDb, customerId: number, input: Partial<CustomerInput>) {
  await getCustomer(db, customerId);
  try {
    await db.execute(
      `UPDATE customers
          SET full_name           = COALESCE(:fullName, full_name),
              email               = IF(:setEmail = 1, :email, email),
              phone               = IF(:setPhone = 1, :phone, phone),
              acquisition_channel = IF(:setChannel = 1, :acquisitionChannel, acquisition_channel),
              status              = COALESCE(:status, status)
        WHERE id = :customerId AND tenant_id = :tenantId`,
      {
        customerId,
        fullName: input.fullName ?? null,
        setEmail: input.email !== undefined ? 1 : 0,
        email: input.email ?? null,
        setPhone: input.phone !== undefined ? 1 : 0,
        phone: input.phone ?? null,
        setChannel: input.acquisitionChannel !== undefined ? 1 : 0,
        acquisitionChannel: input.acquisitionChannel ?? null,
        status: input.status ?? null,
      },
    );
  } catch (error) {
    if (isDuplicate(error)) throw new ConflictError(`A customer with email ${input.email} already exists`);
    throw error;
  }
  return getCustomer(db, customerId);
}

// ─── Marketing campaigns ─────────────────────────────────────────────────────

export interface CampaignInput {
  name: string;
  type: 'email' | 'sms' | 'push' | 'social';
  status: 'draft' | 'scheduled' | 'running' | 'paused' | 'completed';
  scheduledAt: string | null;
}

const CAMPAIGN_COLUMNS = `id, name, type, status, status_color, sent_count, open_count, click_count, scheduled_at, created_at`;

export function listCampaigns(db: TenantDb, options: ListOptions) {
  return db.query<RowDataPacket>(
    `SELECT ${CAMPAIGN_COLUMNS}
       FROM campaigns
      WHERE tenant_id = :tenantId AND (:status IS NULL OR status = :status)
      ORDER BY COALESCE(scheduled_at, created_at) DESC, id DESC
      LIMIT :limit OFFSET :offset`,
    { status: options.status ?? null, limit: String(options.limit), offset: String(options.offset) },
  );
}

async function getCampaign(db: TenantDb, campaignId: number) {
  const [row] = await db.query<RowDataPacket>(
    `SELECT ${CAMPAIGN_COLUMNS} FROM campaigns WHERE tenant_id = :tenantId AND id = :campaignId`,
    { campaignId },
  );
  if (!row) throw new NotFoundError(`Campaign ${campaignId} does not exist`);
  return row;
}

export async function createCampaign(db: TenantDb, input: CampaignInput) {
  const { insertId } = await db.execute(
    `INSERT INTO campaigns (tenant_id, name, type, status, scheduled_at)
     VALUES (:tenantId, :name, :type, :status, :scheduledAt)`,
    { ...input },
  );
  return getCampaign(db, insertId);
}

/**
 * Status changes. Completing a campaign that never ran "sends" it to the
 * store's active customers (demo: no real messages go out).
 */
export async function updateCampaign(db: TenantDb, campaignId: number, input: Partial<CampaignInput>) {
  await getCampaign(db, campaignId);
  await db.execute(
    `UPDATE campaigns
        SET name         = COALESCE(:name, name),
            type         = COALESCE(:type, type),
            status       = COALESCE(:status, status),
            scheduled_at = IF(:setScheduledAt = 1, :scheduledAt, scheduled_at),
            sent_count   = IF(COALESCE(:status, status) IN ('running', 'completed') AND sent_count = 0,
                              (SELECT COUNT(*) FROM customers c WHERE c.tenant_id = :tenantId AND c.status = 'active'),
                              sent_count)
      WHERE id = :campaignId AND tenant_id = :tenantId`,
    {
      campaignId,
      name: input.name ?? null,
      type: input.type ?? null,
      status: input.status ?? null,
      setScheduledAt: input.scheduledAt !== undefined ? 1 : 0,
      scheduledAt: input.scheduledAt ?? null,
    },
  );
  return getCampaign(db, campaignId);
}

export async function deleteCampaign(db: TenantDb, campaignId: number) {
  await getCampaign(db, campaignId);
  await db.execute('DELETE FROM campaigns WHERE id = :campaignId AND tenant_id = :tenantId', { campaignId });
  return { deleted: true };
}

// ─── Support tickets ─────────────────────────────────────────────────────────

export function listTicketsWithCustomer(db: TenantDb, options: ListOptions & { priority?: string }) {
  return db.query<RowDataPacket>(
    `SELECT t.id, t.customer_id, t.assigned_to, t.subject, t.body, t.priority, t.status, t.status_color,
            t.channel, t.created_at, t.resolved_at, c.full_name AS customer_name, c.email AS customer_email
       FROM support_tickets t
       JOIN customers c ON c.tenant_id = t.tenant_id AND c.id = t.customer_id
      WHERE t.tenant_id = :tenantId
        AND (:status IS NULL OR t.status = :status)
        AND (:priority IS NULL OR t.priority = :priority)
      ORDER BY FIELD(t.status, 'open', 'in_progress', 'pending_customer', 'resolved', 'closed'),
               FIELD(t.priority, 'urgent', 'high', 'medium', 'low'),
               t.created_at DESC
      LIMIT :limit OFFSET :offset`,
    {
      status: options.status ?? null,
      priority: options.priority ?? null,
      limit: String(options.limit),
      offset: String(options.offset),
    },
  );
}

// ─── Overview ────────────────────────────────────────────────────────────────

/** Headline numbers for the admin home page (the frontend shows only enabled modules). */
export async function overview(db: TenantDb) {
  const [row] = await db.query<RowDataPacket>(
    `SELECT
       (SELECT COUNT(*) FROM products WHERE tenant_id = :tenantId AND status = 'active')          AS active_products,
       (SELECT COUNT(*) FROM inventory i JOIN products p ON p.tenant_id = i.tenant_id AND p.id = i.product_id
         WHERE i.tenant_id = :tenantId AND p.status = 'active' AND i.qty_available <= i.restock_threshold) AS low_stock,
       (SELECT COUNT(*) FROM orders WHERE tenant_id = :tenantId AND status IN ('pending', 'confirmed')) AS open_orders,
       (SELECT COUNT(*) FROM orders WHERE tenant_id = :tenantId
         AND placed_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY)                                       AS orders_30d,
       (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE tenant_id = :tenantId
         AND status NOT IN ('cancelled', 'refunded')
         AND placed_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY)                                       AS revenue_30d,
       (SELECT COUNT(*) FROM customers WHERE tenant_id = :tenantId)                                AS customers,
       (SELECT COUNT(*) FROM customers WHERE tenant_id = :tenantId
         AND created_at >= UTC_TIMESTAMP() - INTERVAL 30 DAY)                                      AS new_customers_30d,
       (SELECT COUNT(*) FROM campaigns WHERE tenant_id = :tenantId AND status IN ('scheduled', 'running')) AS live_campaigns,
       (SELECT COUNT(*) FROM support_tickets WHERE tenant_id = :tenantId
         AND status IN ('open', 'in_progress', 'pending_customer'))                                AS open_tickets`,
  );
  return Object.fromEntries(Object.entries(row ?? {}).map(([key, value]) => [key, Number(value)]));
}

// ─── Own account ─────────────────────────────────────────────────────────────

/**
 * The signed-in admin replaces their password (e.g. the temporary one the
 * super admin created) after proving they know the current one.
 */
export async function changeOwnPassword(db: TenantDb, userId: number, currentPassword: string, newPassword: string) {
  const [user] = await db.query<RowDataPacket>(
    'SELECT password_hash FROM users WHERE tenant_id = :tenantId AND id = :userId',
    { userId },
  );
  if (!user) throw new NotFoundError('Account not found');
  const matches = user.password_hash ? await bcrypt.compare(currentPassword, String(user.password_hash)) : false;
  if (!matches) {
    throw new ValidationError('Your current password is not correct', [
      { path: 'currentPassword', message: 'Your current password is not correct' },
    ]);
  }
  if (currentPassword === newPassword) {
    throw new ValidationError('Choose a password different from the current one', [
      { path: 'newPassword', message: 'Choose a password different from the current one' },
    ]);
  }
  await db.execute(
    `UPDATE users SET password_hash = :passwordHash, must_change_password = 0
      WHERE tenant_id = :tenantId AND id = :userId`,
    { userId, passwordHash: await bcrypt.hash(newPassword, BCRYPT_SALT_ROUNDS) },
  );
  return { changed: true };
}

// ─── Expenses (the store's own cost tracking) ────────────────────────────────

export const EXPENSE_CATEGORIES = ['rent', 'wages', 'utilities', 'marketing', 'supplies', 'shipping', 'software', 'other'] as const;

export interface ExpenseInput {
  category: (typeof EXPENSE_CATEGORIES)[number];
  description: string | null;
  amount: number;
  /** YYYY-MM-DD */
  incurredOn: string;
}

const EXPENSE_SELECT = `
  SELECT id, category, description, amount, DATE_FORMAT(incurred_on, '%Y-%m-%d') AS incurred_on, created_at
    FROM expenses
   WHERE tenant_id = :tenantId`;

export async function listExpenses(db: TenantDb, options: { from?: string; to?: string; limit: number; offset: number }) {
  const filters = { from: options.from ?? null, to: options.to ?? null };
  const [items, byCategory] = await Promise.all([
    db.query<RowDataPacket>(
      `${EXPENSE_SELECT}
         AND (:from IS NULL OR incurred_on >= :from)
         AND (:to IS NULL OR incurred_on <= :to)
       ORDER BY incurred_on DESC, id DESC
       LIMIT :limit OFFSET :offset`,
      { ...filters, limit: String(options.limit), offset: String(options.offset) },
    ),
    db.query<RowDataPacket>(
      `SELECT category, SUM(amount) AS amount, COUNT(*) AS entries
         FROM expenses
        WHERE tenant_id = :tenantId
          AND (:from IS NULL OR incurred_on >= :from)
          AND (:to IS NULL OR incurred_on <= :to)
        GROUP BY category
        ORDER BY amount DESC`,
      filters,
    ),
  ]);
  return { items, byCategory };
}

async function getExpense(db: TenantDb, expenseId: number) {
  const [row] = await db.query<RowDataPacket>(`${EXPENSE_SELECT} AND id = :expenseId`, { expenseId });
  if (!row) throw new NotFoundError('Expense not found');
  return row;
}

export async function createExpense(db: TenantDb, input: ExpenseInput, createdBy: number | null) {
  const { insertId } = await db.execute(
    `INSERT INTO expenses (tenant_id, category, description, amount, incurred_on, created_by)
     VALUES (:tenantId, :category, :description, :amount, :incurredOn, :createdBy)`,
    { ...input, createdBy },
  );
  return getExpense(db, insertId);
}

export async function updateExpense(db: TenantDb, expenseId: number, input: Partial<ExpenseInput>) {
  await getExpense(db, expenseId);
  await db.execute(
    `UPDATE expenses
        SET category    = COALESCE(:category, category),
            description = IF(:setDescription = 1, :description, description),
            amount      = COALESCE(:amount, amount),
            incurred_on = COALESCE(:incurredOn, incurred_on)
      WHERE id = :expenseId AND tenant_id = :tenantId`,
    {
      expenseId,
      category: input.category ?? null,
      setDescription: input.description !== undefined ? 1 : 0,
      description: input.description ?? null,
      amount: input.amount ?? null,
      incurredOn: input.incurredOn ?? null,
    },
  );
  return getExpense(db, expenseId);
}

export async function deleteExpense(db: TenantDb, expenseId: number) {
  await getExpense(db, expenseId);
  await db.execute('DELETE FROM expenses WHERE id = :expenseId AND tenant_id = :tenantId', { expenseId });
  return { deleted: true };
}
