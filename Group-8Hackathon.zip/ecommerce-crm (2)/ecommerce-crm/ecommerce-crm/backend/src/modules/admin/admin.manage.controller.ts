import type { Request, Response } from 'express';
import { z } from 'zod';
import { requireTenantDb, requireUser } from '../../middlewares/auth';
import { password } from '../auth/auth.controller';
import { sendSuccess } from '../../utils/apiResponse';
import * as service from './admin.manage.service';
import { getStoreSetup } from './storeSetup';

const pagination = {
  limit: z.coerce.number().int().min(1).max(200).default(50),
  offset: z.coerce.number().int().min(0).default(0),
  search: z.string().trim().min(1).max(100).optional(),
};
const idParam = (name: string) => z.object({ [name]: z.coerce.number().int().positive() });
const optionalText = (max: number) =>
  z
    .string()
    .trim()
    .max(max)
    .transform((value) => (value === '' ? null : value))
    .nullable();

// ─── Setup + overview ────────────────────────────────────────────────────────

export async function storeSetup(req: Request, res: Response) {
  return sendSuccess(res, await getStoreSetup(requireTenantDb(req)));
}

export async function overview(req: Request, res: Response) {
  return sendSuccess(res, await service.overview(requireTenantDb(req)));
}

// ─── Products ────────────────────────────────────────────────────────────────

const productStatus = z.enum(['active', 'archived', 'draft']);
const productBody = z
  .object({
    skuCode: z.string().trim().min(1).max(64),
    name: z.string().trim().min(1).max(255),
    category: optionalText(100).default(null),
    basePrice: z.coerce.number().min(0).max(99_999_999),
    costPrice: z.coerce.number().min(0).max(99_999_999).nullable().default(null),
    status: productStatus.default('active'),
    imageUrl: z
      .string()
      .trim()
      .max(2048)
      .refine((value) => value === '' || /^https?:\/\//i.test(value), 'Image URL must start with http:// or https://')
      .transform((value) => (value === '' ? null : value))
      .nullable()
      .default(null),
    description: optionalText(5000).default(null),
  })
  .strict();
const stockBody = z
  .object({
    qtyAvailable: z.coerce.number().int().min(0).max(1_000_000),
    restockThreshold: z.coerce.number().int().min(0).max(1_000_000),
  })
  .strict();
const createProductBody = productBody.extend({ stock: stockBody.optional() }).strict();
const productQuery = z.object({ ...pagination, status: productStatus.optional() });

export async function listProducts(req: Request, res: Response) {
  return sendSuccess(res, await service.listProductsWithStock(requireTenantDb(req), productQuery.parse(req.query)));
}

export async function createProduct(req: Request, res: Response) {
  const { stock, ...input } = createProductBody.parse(req.body);
  return sendSuccess(res, await service.createProduct(requireTenantDb(req), input, stock ?? null), 201);
}

export async function updateProduct(req: Request, res: Response) {
  const { productId } = idParam('productId').parse(req.params);
  const changes = productBody.partial().strict().parse(req.body);
  return sendSuccess(res, await service.updateProduct(requireTenantDb(req), productId as number, changes));
}

export async function updateStock(req: Request, res: Response) {
  const { productId } = idParam('productId').parse(req.params);
  return sendSuccess(res, await service.updateStock(requireTenantDb(req), productId as number, stockBody.parse(req.body)));
}

export async function deleteProduct(req: Request, res: Response) {
  const { productId } = idParam('productId').parse(req.params);
  return sendSuccess(res, await service.deleteProduct(requireTenantDb(req), productId as number));
}

// ─── Orders ──────────────────────────────────────────────────────────────────

const orderStatus = z.enum(['pending', 'confirmed', 'shipped', 'delivered', 'cancelled', 'refunded']);
const orderQuery = z.object({ ...pagination, status: orderStatus.optional() });

export async function listOrders(req: Request, res: Response) {
  return sendSuccess(res, await service.listOrdersWithCustomer(requireTenantDb(req), orderQuery.parse(req.query)));
}

export async function getOrder(req: Request, res: Response) {
  const { orderId } = idParam('orderId').parse(req.params);
  return sendSuccess(res, await service.getOrder(requireTenantDb(req), orderId as number));
}

export async function updateOrder(req: Request, res: Response) {
  const { orderId } = idParam('orderId').parse(req.params);
  const { status } = z.object({ status: orderStatus }).strict().parse(req.body);
  return sendSuccess(res, await service.updateOrderStatus(requireTenantDb(req), orderId as number, status));
}

// ─── Customers ───────────────────────────────────────────────────────────────

const customerStatus = z.enum(['active', 'inactive', 'blocked']);
const customerBody = z
  .object({
    fullName: z.string().trim().min(1).max(255),
    email: z
      .string()
      .trim()
      .max(320)
      .refine((value) => value === '' || z.string().email().safeParse(value).success, 'Enter a valid email')
      .transform((value) => (value === '' ? null : value.toLowerCase()))
      .nullable()
      .default(null),
    phone: optionalText(32).default(null),
    acquisitionChannel: optionalText(50).default(null),
    status: customerStatus.default('active'),
  })
  .strict();
const customerQuery = z.object({ ...pagination, status: customerStatus.optional() });

export async function listCustomers(req: Request, res: Response) {
  return sendSuccess(res, await service.searchCustomers(requireTenantDb(req), customerQuery.parse(req.query)));
}

export async function createCustomer(req: Request, res: Response) {
  return sendSuccess(res, await service.createCustomer(requireTenantDb(req), customerBody.parse(req.body)), 201);
}

export async function updateCustomer(req: Request, res: Response) {
  const { customerId } = idParam('customerId').parse(req.params);
  const changes = customerBody.partial().strict().parse(req.body);
  return sendSuccess(res, await service.updateCustomer(requireTenantDb(req), customerId as number, changes));
}

// ─── Campaigns ───────────────────────────────────────────────────────────────

const campaignStatus = z.enum(['draft', 'scheduled', 'running', 'paused', 'completed']);
const campaignBody = z
  .object({
    name: z.string().trim().min(1).max(255),
    type: z.enum(['email', 'sms', 'push', 'social']),
    status: campaignStatus.default('draft'),
    scheduledAt: z
      .string()
      .datetime({ offset: true })
      .transform((value) => new Date(value).toISOString().slice(0, 19).replace('T', ' '))
      .nullable()
      .default(null),
  })
  .strict();

export async function listCampaigns(req: Request, res: Response) {
  const query = z.object({ limit: pagination.limit, offset: pagination.offset, status: campaignStatus.optional() });
  return sendSuccess(res, await service.listCampaigns(requireTenantDb(req), query.parse(req.query)));
}

export async function createCampaign(req: Request, res: Response) {
  return sendSuccess(res, await service.createCampaign(requireTenantDb(req), campaignBody.parse(req.body)), 201);
}

export async function updateCampaign(req: Request, res: Response) {
  const { campaignId } = idParam('campaignId').parse(req.params);
  const changes = campaignBody.partial().strict().parse(req.body);
  return sendSuccess(res, await service.updateCampaign(requireTenantDb(req), campaignId as number, changes));
}

export async function deleteCampaign(req: Request, res: Response) {
  const { campaignId } = idParam('campaignId').parse(req.params);
  return sendSuccess(res, await service.deleteCampaign(requireTenantDb(req), campaignId as number));
}

// ─── Tickets ─────────────────────────────────────────────────────────────────

export async function listTickets(req: Request, res: Response) {
  const query = z.object({
    limit: pagination.limit,
    offset: pagination.offset,
    status: z.enum(['open', 'in_progress', 'pending_customer', 'resolved', 'closed']).optional(),
    priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  });
  return sendSuccess(res, await service.listTicketsWithCustomer(requireTenantDb(req), query.parse(req.query)));
}

// ─── Own account ─────────────────────────────────────────────────────────────

export async function changePassword(req: Request, res: Response) {
  const body = z
    .object({ currentPassword: z.string().min(1, 'Enter your current password').max(1024), newPassword: password })
    .strict()
    .parse(req.body);
  const user = requireUser(req);
  return sendSuccess(
    res,
    await service.changeOwnPassword(requireTenantDb(req), user.userId, body.currentPassword, body.newPassword),
  );
}

// ─── Expenses ────────────────────────────────────────────────────────────────

const day = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'Use YYYY-MM-DD');
const expenseBody = z
  .object({
    category: z.enum(service.EXPENSE_CATEGORIES),
    description: optionalText(255).default(null),
    amount: z.coerce.number().min(0, 'Amount cannot be negative').max(99_999_999),
    incurredOn: day,
  })
  .strict();
const expenseQuery = z.object({ ...pagination, from: day.optional(), to: day.optional() });

export async function listExpenses(req: Request, res: Response) {
  return sendSuccess(res, await service.listExpenses(requireTenantDb(req), expenseQuery.parse(req.query)));
}

export async function createExpense(req: Request, res: Response) {
  const user = requireUser(req);
  return sendSuccess(res, await service.createExpense(requireTenantDb(req), expenseBody.parse(req.body), user.userId), 201);
}

export async function updateExpense(req: Request, res: Response) {
  const { expenseId } = idParam('expenseId').parse(req.params);
  const changes = expenseBody.partial().strict().parse(req.body);
  return sendSuccess(res, await service.updateExpense(requireTenantDb(req), expenseId as number, changes));
}

export async function deleteExpense(req: Request, res: Response) {
  const { expenseId } = idParam('expenseId').parse(req.params);
  return sendSuccess(res, await service.deleteExpense(requireTenantDb(req), expenseId as number));
}
