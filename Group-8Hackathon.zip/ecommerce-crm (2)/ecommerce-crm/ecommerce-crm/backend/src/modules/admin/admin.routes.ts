import { Router } from 'express';
import { verifyAdmin } from '../../middlewares/auth';
import { asyncWrapper } from '../../utils/asyncWrapper';
import * as controller from './admin.controller';
import * as manage from './admin.manage.controller';
import { requireModule } from './storeSetup';

export const adminRouter = Router();

// Every route below is tenant-scoped through req.tenantDb.
adminRouter.use(verifyAdmin);

// Store setup (the super admin's wizard answers) decides which features exist.
adminRouter.get('/setup', asyncWrapper(manage.storeSetup));
adminRouter.get('/overview', asyncWrapper(manage.overview));
adminRouter.post('/account/password', asyncWrapper(manage.changePassword));
adminRouter.get('/notifications/summary', asyncWrapper(controller.notificationSummary));
adminRouter.get('/analytics/:metric', asyncWrapper(controller.analytics));

// Products are needed to sell online (Storefront) or to track stock (Inventory).
const products = requireModule('inventory', 'storefront');
adminRouter.get('/products', products, asyncWrapper(manage.listProducts));
adminRouter.post('/products', products, asyncWrapper(manage.createProduct));
adminRouter.patch('/products/:productId', products, asyncWrapper(manage.updateProduct));
adminRouter.delete('/products/:productId', products, asyncWrapper(manage.deleteProduct));
adminRouter.put('/products/:productId/stock', requireModule('inventory'), asyncWrapper(manage.updateStock));

const orders = requireModule('orders');
adminRouter.get('/orders', orders, asyncWrapper(manage.listOrders));
adminRouter.get('/orders/:orderId', orders, asyncWrapper(manage.getOrder));
adminRouter.patch('/orders/:orderId', orders, asyncWrapper(manage.updateOrder));

const customers = requireModule('customers');
adminRouter.get('/customers', customers, asyncWrapper(manage.listCustomers));
adminRouter.post('/customers', customers, asyncWrapper(manage.createCustomer));
adminRouter.patch('/customers/:customerId', customers, asyncWrapper(manage.updateCustomer));

const marketing = requireModule('marketing');
adminRouter.get('/campaigns', marketing, asyncWrapper(manage.listCampaigns));
adminRouter.post('/campaigns', marketing, asyncWrapper(manage.createCampaign));
adminRouter.patch('/campaigns/:campaignId', marketing, asyncWrapper(manage.updateCampaign));
adminRouter.delete('/campaigns/:campaignId', marketing, asyncWrapper(manage.deleteCampaign));

const supportDesk = requireModule('customerService');
adminRouter.get('/tickets', supportDesk, asyncWrapper(manage.listTickets));
adminRouter.patch('/tickets/:ticketId', supportDesk, asyncWrapper(controller.updateTicket));

// The store's own cost tracking. Every store has it; the super admin never sees it.
adminRouter.get('/expenses', asyncWrapper(manage.listExpenses));
adminRouter.post('/expenses', asyncWrapper(manage.createExpense));
adminRouter.patch('/expenses/:expenseId', asyncWrapper(manage.updateExpense));
adminRouter.delete('/expenses/:expenseId', asyncWrapper(manage.deleteExpense));
