import type { Request, Response } from 'express';
import { requireTenantDb } from '../../middlewares/auth';
import { sendSuccess } from '../../utils/apiResponse';
import * as service from './dashboard.service';

/** Returns the tenant's active AI layout, or `null` if none has been generated. */
export async function getActiveLayout(req: Request, res: Response) {
  return sendSuccess(res, await service.getActiveLayout(requireTenantDb(req)));
}

export async function listLayouts(req: Request, res: Response) {
  return sendSuccess(res, await service.listLayouts(requireTenantDb(req)));
}
