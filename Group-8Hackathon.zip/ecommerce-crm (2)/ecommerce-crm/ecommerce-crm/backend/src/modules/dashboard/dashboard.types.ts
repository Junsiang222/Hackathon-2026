import type { WidgetType } from '../../config/constants';

export interface WidgetConfig {
  widgetId: string; // uuid, always assigned server-side
  type: WidgetType;
  title: string;
  dataSourceUrl: string; // key of ANALYTICS_SOURCES, e.g. '/api/v1/admin/analytics/orders'
  colSpan: 4 | 6 | 12;
  dataKeys: string[]; // never monetary
}

export interface DashboardLayout {
  id: number;
  tenantId: number;
  layoutName: string;
  version: number;
  isActive: boolean;
  createdBy: number;
  createdAt: string;
  config: WidgetConfig[];
}

/** MySQL returns JSON columns parsed; MariaDB stores them as LONGTEXT and returns a string. */
export function parseWidgetConfig(value: WidgetConfig[] | string): WidgetConfig[] {
  return typeof value === 'string' ? (JSON.parse(value) as WidgetConfig[]) : value;
}
