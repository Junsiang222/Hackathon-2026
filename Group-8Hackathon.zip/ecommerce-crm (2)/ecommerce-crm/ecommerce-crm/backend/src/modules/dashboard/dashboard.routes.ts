import { Router } from 'express';
import { verifyAdmin } from '../../middlewares/auth';
import { asyncWrapper } from '../../utils/asyncWrapper';
import * as controller from './dashboard.controller';

export const dashboardRouter = Router();

dashboardRouter.use(verifyAdmin);

dashboardRouter.get('/layout/active', asyncWrapper(controller.getActiveLayout));
dashboardRouter.get('/layouts', asyncWrapper(controller.listLayouts));
