import type { RowDataPacket } from 'mysql2/promise';
import type { TenantDb } from '../../utils/tenantScopedDb';
import { parseWidgetConfig, type DashboardLayout, type WidgetConfig } from './dashboard.types';

interface LayoutRow extends RowDataPacket {
  id: number;
  layout_name: string;
  config_json: WidgetConfig[] | string;
  version: number;
  is_active: number;
  created_by: number;
  created_at: Date;
}

function toLayout(tenantId: number, row: LayoutRow): DashboardLayout {
  return {
    id: row.id,
    tenantId,
    layoutName: row.layout_name,
    version: row.version,
    isActive: row.is_active === 1,
    createdBy: row.created_by,
    createdAt: row.created_at.toISOString(),
    config: parseWidgetConfig(row.config_json),
  };
}

const LAYOUT_COLUMNS = ['id', 'layout_name', 'config_json', 'version', 'is_active', 'created_by', 'created_at'] as const;

export async function getActiveLayout(db: TenantDb): Promise<DashboardLayout | null> {
  const [row] = await db.findMany<'dashboard_layouts', LayoutRow>('dashboard_layouts', {
    columns: LAYOUT_COLUMNS,
    where: { is_active: 1 },
    orderBy: { column: 'version', direction: 'DESC' },
    limit: 1,
  });
  return row ? toLayout(db.tenantId, row) : null;
}

export async function listLayouts(db: TenantDb): Promise<DashboardLayout[]> {
  const rows = await db.findMany<'dashboard_layouts', LayoutRow>('dashboard_layouts', {
    columns: LAYOUT_COLUMNS,
    orderBy: { column: 'version', direction: 'DESC' },
    limit: 50,
  });
  return rows.map((row) => toLayout(db.tenantId, row));
}
